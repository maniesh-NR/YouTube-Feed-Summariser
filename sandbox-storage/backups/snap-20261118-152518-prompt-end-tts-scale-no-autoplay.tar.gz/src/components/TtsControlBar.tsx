import React from 'react';
import {
  Play,
  Pause,
  Square,
  Volume2,
  RotateCcw,
  RotateCw,
  Music,
  FastForward
} from 'lucide-react';
import { TtsWaveformVisualizer } from './TtsWaveformVisualizer';
import { getGranularTtsRates, type AdaptiveWindowFlags } from '../utils/userscript-helpers';

interface TtsControlBarProps {
  videoId: string;
  mode: 'summary' | 'transcript';
  contentText: string;
  tts: { status: 'idle' | 'playing' | 'paused'; rate: number };
  currentVol: number;
  currentPitch: number;
  skipSilence: boolean;
  selectedVoice: string;
  browserVoices: SpeechSynthesisVoice[];
  activeTtsTs: string | null;
  adaptive: AdaptiveWindowFlags;
  onSelectVoice: (voice: string) => void;
  onToggleTts: () => void;
  onRewindTts: () => void;
  onSkipTts: () => void;
  onStopTts: () => void;
  onSetRate: (rate: number) => void;
  onCycleRate: () => void;
  onSetVolume: (vol: number) => void;
  onSetPitch: (pitch: number) => void;
  onToggleSkipSilence: () => void;
}

export const TtsControlBar: React.FC<TtsControlBarProps> = ({
  mode,
  tts,
  currentVol,
  currentPitch,
  skipSilence,
  selectedVoice,
  browserVoices,
  activeTtsTs,
  adaptive,
  onSelectVoice,
  onToggleTts,
  onRewindTts,
  onSkipTts,
  onStopTts,
  onSetRate,
  onCycleRate,
  onSetVolume,
  onSetPitch,
  onToggleSkipSilence
}) => {
  const isPlaying = tts.status === 'playing';
  const isPaused = tts.status === 'paused';
  const granularRates = getGranularTtsRates();

  return (
    <div
      data-compact-tts={adaptive.compactTtsBar ? 'true' : 'false'}
      className={`flex flex-wrap items-center bg-zinc-800/80 border border-zinc-700/80 max-w-full min-w-0 box-border yt-tts-control-bar ${
        adaptive.isCompact
          ? 'gap-x-1 gap-y-1 p-1 px-1.5 rounded-xl'
          : adaptive.compactTtsBar
          ? 'gap-x-1.5 gap-y-1 p-1 px-2 rounded-xl'
          : 'gap-x-1.5 gap-y-1 p-1 px-2 rounded-2xl'
      }`}
    >
      {/* Voice Selector */}
      <select
        aria-label="Speech Voice"
        value={selectedVoice}
        onChange={(e) => onSelectVoice(e.target.value)}
        className={`bg-[#212121] text-zinc-200 border border-zinc-700 rounded-full px-2 py-0.5 text-[11px] focus:outline-none cursor-pointer truncate min-w-0 max-w-full yt-tts-voice-select ${
          adaptive.isCompact ? 'flex-1 basis-[110px]' : 'max-w-[140px] flex-shrink'
        }`}
        style={{ colorScheme: 'dark' }}
        title="Select TTS Voice (Google AI Studio Neural Voice or Browser Voice)"
      >
        <optgroup label="Google AI Studio (Studio Neural)" className="bg-[#181818] text-sky-400 font-semibold">
          <option value="ai:Kore" className="bg-[#212121] text-zinc-100">Kore (Warm)</option>
          <option value="ai:Puck" className="bg-[#212121] text-zinc-100">Puck (Narrator)</option>
          <option value="ai:Zephyr" className="bg-[#212121] text-zinc-100">Zephyr (Bright)</option>
          <option value="ai:Fenrir" className="bg-[#212121] text-zinc-100">Fenrir (Deep)</option>
          <option value="ai:Charon" className="bg-[#212121] text-zinc-100">Charon (Calm)</option>
        </optgroup>
        <optgroup label="Browser Voices (Web Speech)" className="bg-[#181818] text-indigo-400 font-semibold">
          {browserVoices.length > 0 ? (
            browserVoices.map((v) => (
              <option key={v.voiceURI} value={v.voiceURI} className="bg-[#212121] text-zinc-100">
                {v.name.slice(0, 18)}
              </option>
            ))
          ) : (
            <option value="browser:default" className="bg-[#212121] text-zinc-100">
              System Voice
            </option>
          )}
        </optgroup>
      </select>

      <button
        type="button"
        onClick={onToggleTts}
        className={`flex items-center gap-1 rounded-full text-xs font-medium transition-all flex-shrink-0 whitespace-nowrap cursor-pointer ${
          adaptive.isCompact ? 'px-2 py-0.5' : 'px-2.5 py-1 gap-1.5'
        } ${
          isPlaying
            ? 'bg-sky-500 text-zinc-950 font-semibold shadow-xs'
            : isPaused
            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            : 'text-zinc-200 hover:bg-zinc-700/60'
        }`}
        title={isPlaying ? 'Pause speech' : isPaused ? 'Resume speech' : 'Listen to summary (Web Speech / AI Studio TTS)'}
      >
        {isPlaying ? (
          <Pause className="w-3.5 h-3.5 fill-current" />
        ) : isPaused ? (
          <Play className="w-3.5 h-3.5 fill-current" />
        ) : (
          <Volume2 className="w-3.5 h-3.5" />
        )}
        <span>{isPlaying ? 'Pause' : isPaused ? 'Resume' : 'Listen'}</span>
      </button>

      <button
        type="button"
        onClick={onRewindTts}
        disabled={tts.status === 'idle'}
        aria-label="Rewind 5 seconds"
        className={`flex items-center gap-0.5 rounded-full text-xs text-zinc-300 hover:text-white hover:bg-zinc-700/60 disabled:opacity-30 disabled:hover:bg-transparent transition-all flex-shrink-0 whitespace-nowrap yt-tts-rewind-btn cursor-pointer ${
          adaptive.isCompact ? 'px-1.5 py-0.5' : 'px-2 py-1'
        }`}
        title="Rewind 5s (Left Arrow or J)"
      >
        <RotateCcw className="w-3 h-3" />
        <span className={adaptive.isCompact ? 'hidden' : 'text-[10px] font-mono tabular-nums'}>5s</span>
      </button>

      <button
        type="button"
        onClick={onSkipTts}
        disabled={tts.status === 'idle'}
        aria-label="Skip forward 5 seconds"
        className={`flex items-center gap-0.5 rounded-full text-xs text-zinc-300 hover:text-white hover:bg-zinc-700/60 disabled:opacity-30 disabled:hover:bg-transparent transition-all flex-shrink-0 whitespace-nowrap yt-tts-skip-btn cursor-pointer ${
          adaptive.isCompact ? 'px-1.5 py-0.5' : 'px-2 py-1'
        }`}
        title="Skip 5s (Right Arrow or L)"
      >
        <RotateCw className="w-3 h-3" />
        <span className={adaptive.isCompact ? 'hidden' : 'text-[10px] font-mono tabular-nums'}>5s</span>
      </button>

      <button
        type="button"
        onClick={onStopTts}
        disabled={tts.status === 'idle'}
        className="p-1.5 rounded-full hover:bg-zinc-700/60 text-zinc-400 hover:text-white disabled:opacity-30 disabled:hover:bg-transparent flex-shrink-0 cursor-pointer"
        title="Stop speech"
        aria-label="Stop speech"
      >
        <Square className="w-3.5 h-3.5 fill-current" />
      </button>

      <TtsWaveformVisualizer
        isPlaying={isPlaying}
        volume={currentVol}
        pitch={currentPitch}
        rate={tts.rate}
        compact={adaptive.isCompact}
      />

      {/* Playback Speed Controls */}
      <div
        className={`flex flex-wrap items-center gap-1.5 px-1.5 max-w-full min-w-0 ${
          adaptive.compactTtsBar ? '' : 'border-l border-zinc-700/60 ml-0.5'
        } yt-tts-speed-wrap`}
      >
        <button
          type="button"
          onClick={onCycleRate}
          className="px-2 py-0.5 text-[10px] font-mono tabular-nums font-semibold rounded-md transition-all flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700/80 flex-shrink-0 whitespace-nowrap yt-tts-speed-btn cursor-pointer"
          title={`Playback speed: ${tts.rate}x (click to cycle 0.25x steps)`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full yt-tts-speed-indicator ${
              Math.abs(tts.rate - 1.0) < 0.01
                ? 'bg-sky-400 ring-1 ring-sky-300'
                : tts.rate > 1.0
                ? 'bg-amber-400 ring-1 ring-amber-300'
                : 'bg-purple-400 ring-1 ring-purple-300'
            }`}
          />
          <span className="font-bold text-sky-300 yt-tts-speed-text">{tts.rate}x</span>
        </button>
        <div
          className={`items-center gap-0.5 yt-tts-speed-btns ${
            adaptive.isCompact ? 'hidden' : 'inline-flex flex-wrap max-w-full min-w-0'
          }`}
        >
          {granularRates.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => onSetRate(r)}
              className={`px-1.5 py-0.5 text-[10px] font-mono tabular-nums font-semibold rounded-md transition-all whitespace-nowrap flex-shrink-0 yt-tts-rate-pill yt-tts-rate-btn cursor-pointer ${
                Math.abs(tts.rate - r) < 0.01
                  ? 'bg-sky-500 text-zinc-950 font-bold active'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-700/60'
              }`}
              title={`Set speed to ${r}x`}
              data-rate={String(r)}
            >
              {r}x
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 pl-1 border-l border-zinc-700/40 min-w-0 max-w-full yt-tts-slider-row">
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.05"
            aria-label="Speech playback speed"
            value={tts.rate}
            onChange={(e) => onSetRate(parseFloat(e.target.value))}
            className={`${adaptive.isCompact ? 'w-10' : 'w-12'} h-1 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-sky-400 yt-tts-speed-slider`}
            title={`Playback speed: ${tts.rate}x`}
          />
          <span className="text-[10px] font-mono tabular-nums text-zinc-400 min-w-[24px] text-right yt-tts-speed-label">
            {tts.rate}x
          </span>
        </div>
      </div>

      {/* Volume Control Slider */}
      <div
        className={`flex items-center gap-1.5 px-1.5 min-w-0 max-w-full yt-tts-volume-wrap ${
          adaptive.compactTtsBar ? '' : 'border-l border-zinc-700/60 ml-0.5'
        }`}
        title={`Speech volume: ${Math.round(currentVol * 100)}%`}
      >
        <Volume2 className="w-3 h-3 text-zinc-400 flex-shrink-0" />
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          aria-label="Speech volume"
          value={currentVol}
          onChange={(e) => onSetVolume(parseFloat(e.target.value))}
          className={`${adaptive.isCompact ? 'w-10' : adaptive.compactTtsBar ? 'w-12' : 'w-14'} h-1 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-sky-400 yt-tts-volume-slider`}
          title={`Speech volume: ${Math.round(currentVol * 100)}%`}
        />
        <span className="text-[10px] font-mono tabular-nums text-zinc-400 min-w-[28px] text-right yt-tts-volume-label">
          {Math.round(currentVol * 100)}%
        </span>
      </div>

      {/* Pitch Control Slider */}
      <div
        className={`flex items-center gap-1.5 px-1.5 min-w-0 max-w-full yt-tts-pitch-wrap ${
          adaptive.compactTtsBar ? '' : 'border-l border-zinc-700/60 ml-0.5'
        }`}
        title={`Voice pitch: ${currentPitch}x`}
      >
        <Music className="w-3 h-3 text-purple-400 flex-shrink-0 yt-tts-pitch-icon" />
        <input
          type="range"
          min="0.5"
          max="2"
          step="0.05"
          aria-label="Speech voice pitch"
          value={currentPitch}
          onChange={(e) => onSetPitch(parseFloat(e.target.value))}
          className={`${adaptive.isCompact ? 'w-10' : adaptive.compactTtsBar ? 'w-12' : 'w-14'} h-1 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-purple-400 yt-tts-pitch-slider`}
          title={`Voice pitch: ${currentPitch}x`}
        />
        <span className="text-[10px] font-mono tabular-nums text-zinc-400 min-w-[24px] text-right yt-tts-pitch-label">
          {currentPitch}x
        </span>
      </div>

      {/* Skip Silence Toggle */}
      <button
        type="button"
        onClick={onToggleSkipSilence}
        aria-label={`Skip Silence: ${skipSilence ? 'ON' : 'OFF'}`}
        className={`flex items-center gap-1 py-0.5 rounded-full text-xs font-medium transition-all border flex-shrink-0 whitespace-nowrap yt-tts-btn yt-tts-skip-silence-btn cursor-pointer ${
          adaptive.isCompact ? 'px-2' : 'px-2.5'
        } ${
          skipSilence
            ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 active shadow-xs'
            : 'text-zinc-400 border-zinc-700/60 hover:text-white hover:bg-zinc-700/60'
        }`}
        title={
          skipSilence
            ? 'Skip Silence: ON (Automatically detecting and skipping long pauses or gap segments in transcript)'
            : 'Skip Silence: OFF (Click to automatically detect and skip segments with long pauses)'
        }
      >
        <FastForward className="w-3 h-3 text-sky-400" />
        <span className={`${adaptive.isCompact ? 'hidden' : 'text-[10px] font-medium'} yt-tts-skip-silence-label`}>
          Skip Silence
        </span>
      </button>

      {!adaptive.compactTtsBar && (
        <span
          className="text-[10px] text-zinc-400 bg-zinc-900/60 border border-zinc-700/60 px-2 py-0.5 rounded-full cursor-help hover:text-sky-300 transition-colors ml-0.5 flex-shrink-0 whitespace-nowrap yt-tts-shortcuts-hint hidden sm:inline-flex items-center"
          title="Global TTS Shortcuts:
• Space or K: Play / Pause
• ← or J: Rewind 5s
• → or L: Skip 5s
• ↑ / ↓: Volume Up / Down"
        >
          Space · &larr; · &rarr;
        </span>
      )}

      {mode === 'transcript' && activeTtsTs && (isPlaying || isPaused) && (
        <span
          className="text-[10px] text-sky-300 bg-sky-950/70 border border-sky-500/40 px-2 py-0.5 rounded-full flex items-center gap-1 font-mono tabular-nums yt-tts-speaking-pill"
          title={`Currently speaking line at timestamp ${activeTtsTs}`}
        >
          <Volume2 className="w-2.5 h-2.5 text-sky-400" />
          <span>Speaking {activeTtsTs}</span>
        </span>
      )}
    </div>
  );
};
