import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Copy,
  Check,
  Terminal,
  Play,
  FileCode,
  Info,
  Clock
} from 'lucide-react';
import {
  cleanTextForSpeech,
  parseTranscriptCues,
  findActiveCueByCharIndex,
  findTranscriptCueIndexForSeconds,
  formatSummaryExportJson,
  clampPitch,
  resolveAskFallbackPlan,
  normalizeHistoryTabVisibility,
  applyResponseRating,
  buildResponseRatingKey,
  formatMathSymbolsInText,
  computeDefaultWindowBounds,
  clampWindowBounds,
  getAdaptiveWindowFlags,
  normalizeAltTitlesEnabled,
  normalizeCompactOptionsMap,
  applyKeyboardWindowAdjustment,
  normalizeChannelTitleRules,
  setChannelTitleRuleInMap,
  resolveAutoTitleDecision,
  normalizeSummaryPersona,
  type TranscriptCue,
  type HistoryTabVisibility,
  type ResponseRatingRecord,
  type WindowBounds,
  type ResizeDirection,
  type ChannelTitleRule,
  type SummaryPersona
} from './utils/userscript-helpers';
import {
  MOCK_VIDEOS,
  parseEditorialBlocks,
  getLocalDiagramDataUri,
  type MockVideo,
  type HistoryItem,
  type ChatTurn,
  type ActiveSeekState
} from './components/SimulatorTypes';
import { FeedSimulatorGrid } from './components/FeedSimulatorGrid';
import { FloatingSummaryWindow } from './components/FloatingSummaryWindow';
import { HistoryDock } from './components/HistoryDock';
import { SettingsDocsTabs } from './components/SettingsDocsTabs';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'tests' | 'docs'>('simulator');
  const [openWindows, setOpenWindows] = useState<{
    [id: string]: { minimized: boolean; mode: 'summary' | 'transcript'; source: 'video' | 'text' };
  }>({});
  const [windowBounds, setWindowBounds] = useState<Record<string, WindowBounds>>({});
  const [windowZIndices, setWindowZIndices] = useState<Record<string, number>>({});
  const [focusedVideoId, setFocusedVideoId] = useState<string | null>(null);
  const [windowSizeMap, setWindowSizeMap] = useState<Record<string, { width: number; height: number }>>({});
  const [headerOverflowOpen, setHeaderOverflowOpen] = useState<Record<string, boolean>>({});
  const [compactOptionsExpanded, setCompactOptionsExpanded] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem('yt_compact_options_expanded');
      return raw ? normalizeCompactOptionsMap(JSON.parse(raw)) : {};
    } catch {
      return {};
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem('yt_compact_options_expanded', JSON.stringify(compactOptionsExpanded));
    } catch {}
  }, [compactOptionsExpanded]);

  const [liveAnnouncement, setLiveAnnouncement] = useState('');
  const [liveAnnouncementSeq, setLiveAnnouncementSeq] = useState(0);
  const [viewportSize, setViewportSize] = useState<{ width: number; height: number }>(() => ({
    width: typeof window !== 'undefined' ? window.innerWidth : 1280,
    height: typeof window !== 'undefined' ? window.innerHeight : 800
  }));

  useEffect(() => {
    const onResize = () => {
      setViewportSize({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const announceLive = (msg: string) => {
    if (!msg) return;
    setLiveAnnouncement(msg);
    setLiveAnnouncementSeq((s) => s + 1);
  };

  const topZCounterRef = useRef(60);
  const windowContainerRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const dragResizeRef = useRef<{
    type: 'drag' | 'resize';
    videoId: string;
    dir?: ResizeDirection;
    startX: number;
    startY: number;
    startBounds: WindowBounds;
  } | null>(null);

  const [historyTabVisibility, setHistoryTabVisibility] = useState<HistoryTabVisibility>(() => {
    try {
      return normalizeHistoryTabVisibility(localStorage.getItem('yt_history_tab_visibility'));
    } catch {
      return 'always';
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem('yt_history_tab_visibility', historyTabVisibility);
    } catch {}
  }, [historyTabVisibility]);

  const [responseRatings, setResponseRatings] = useState<Record<string, ResponseRatingRecord>>(() => {
    try {
      const raw = localStorage.getItem('yt_response_ratings');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });
  const [openRatingNoteKey, setOpenRatingNoteKey] = useState<string | null>(null);
  useEffect(() => {
    try {
      localStorage.setItem('yt_response_ratings', JSON.stringify(responseRatings));
    } catch {}
  }, [responseRatings]);

  // FEAT-02 Per-Channel Auto-Title Rules persisted in localStorage
  const [channelTitleRules, setChannelTitleRules] = useState<Record<string, 'exempt' | 'force_ai'>>(() => {
    try {
      const raw = localStorage.getItem('yt_channel_title_rules');
      return raw ? normalizeChannelTitleRules(JSON.parse(raw)) : {};
    } catch {
      return {};
    }
  });
  const [ruleMenuOpenId, setRuleMenuOpenId] = useState<string | null>(null);

  // FEAT-03 Summary Persona Preset persisted in localStorage
  const [summaryPersona, setSummaryPersona] = useState<SummaryPersona>(() => {
    try {
      return normalizeSummaryPersona(localStorage.getItem('yt_summary_persona'));
    } catch {
      return 'executive';
    }
  });
  const [windowPersonas, setWindowPersonas] = useState<Record<string, SummaryPersona>>({});

  // FEAT-01 Follow-Along Lock persisted in localStorage + Active Seek State
  const [followAlong, setFollowAlong] = useState<boolean>(() => {
    try {
      return localStorage.getItem('yt_follow_along') !== 'false';
    } catch {
      return true;
    }
  });
  const [activeSeek, setActiveSeek] = useState<Record<string, ActiveSeekState | null>>({});

  const [windowModels, setWindowModels] = useState<{ [id: string]: string }>({});
  const [windowFallbackNote, setWindowFallbackNote] = useState<{ [id: string]: string | null }>({});
  const [simAskFailure, setSimAskFailure] = useState<{ [id: string]: boolean }>({});
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [testRunning, setTestRunning] = useState(false);
  const [testOutput, setTestOutput] = useState<string | null>(null);

  const [altTitlesEnabled, setAltTitlesEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('yt_alt_titles_enabled');
      return saved === null ? true : normalizeAltTitlesEnabled(saved);
    } catch {
      return true;
    }
  });
  const [dearrowSimulated, setDearrowSimulated] = useState(true);
  const [dearrowToggledOriginal, setDearrowToggledOriginal] = useState<{ [id: string]: boolean }>({});
  const [cardTitleModes, setCardTitleModes] = useState<{ [id: string]: 'original' | 'dearrow' | 'ai' }>({});
  const [transcriptModes, setTranscriptModes] = useState<{ [id: string]: 'fast' | 'deep' }>({});

  const handleSetAltTitlesEnabled = (nextEnabled: boolean) => {
    const normalized = Boolean(nextEnabled);
    setAltTitlesEnabled(normalized);
    try {
      localStorage.setItem('yt_alt_titles_enabled', String(normalized));
    } catch {}
    setCardTitleModes((prev) => {
      const next: { [id: string]: 'original' | 'dearrow' | 'ai' } = {};
      for (const [id, m] of Object.entries(prev)) {
        if (!normalized && m === 'ai') continue;
        if (normalized && m === 'original') continue;
        next[id] = m;
      }
      return next;
    });
  };

  const handleSetChannelTitleRule = (channelName: string, rule: ChannelTitleRule) => {
    setChannelTitleRules((prev) => {
      const next = setChannelTitleRuleInMap(prev, channelName, rule);
      try {
        localStorage.setItem('yt_channel_title_rules', JSON.stringify(next));
      } catch {}
      return next;
    });
    // Clear manual single-card overrides on cards from this channel so the rule applies immediately
    setCardTitleModes((prev) => {
      const next = { ...prev };
      MOCK_VIDEOS.forEach((v) => {
        if (v.channel.trim().toLowerCase() === channelName.trim().toLowerCase()) {
          delete next[v.id];
        }
      });
      return next;
    });
    setRuleMenuOpenId(null);
    announceLive(`Channel rule saved: ${channelName} set to ${rule}`);
  };

  const handleSetDefaultSummaryPersona = (nextPersona: SummaryPersona) => {
    const normalized = normalizeSummaryPersona(nextPersona);
    setSummaryPersona(normalized);
    try {
      localStorage.setItem('yt_summary_persona', normalized);
    } catch {}
  };

  const handleSelectWindowPersona = (videoId: string, nextPersona: SummaryPersona) => {
    const normalized = normalizeSummaryPersona(nextPersona);
    setWindowPersonas((prev) => ({ ...prev, [videoId]: normalized }));
    handleSetDefaultSummaryPersona(normalized);
    announceLive(`Summary persona switched to ${normalized}`);
  };

  const handleToggleFollowAlong = () => {
    setFollowAlong((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('yt_follow_along', String(next));
      } catch {}
      announceLive(next ? 'Transcript follow-along lock enabled' : 'Transcript follow-along lock paused');
      return next;
    });
  };

  const handleSeekTimestamp = (videoId: string, tsStr: string, seconds: number) => {
    const video = MOCK_VIDEOS.find((v) => v.id === videoId);
    let cueIdx = -1;
    let cueLineIdx: number | null = null;
    if (video) {
      const parsed = parseTranscriptCues(video.transcript, { skipSilence: skipSilence[videoId] !== false });
      const idx = findTranscriptCueIndexForSeconds(parsed.cues, seconds);
      if (idx >= 0 && parsed.cues[idx]) {
        cueIdx = idx;
        cueLineIdx = parsed.cues[idx].lineIndex;
      }
    }
    setActiveSeek((prev) => ({
      ...prev,
      [videoId]: {
        seconds,
        tsStr,
        cueIndex: cueIdx >= 0 ? cueIdx : 0,
        updatedAt: Date.now()
      }
    }));
    if (cueLineIdx !== null) {
      setActiveTtsLine((prev) => ({ ...prev, [videoId]: cueLineIdx }));
      setActiveTtsTs((prev) => ({ ...prev, [videoId]: tsStr }));
    }
    const cleanTs = tsStr.replace(/[\[\]]/g, '');
    showTtsToast(`Jumped to ${cleanTs}`, videoId);
    announceLive(`Jumped to ${cleanTs}`);
  };

  const toggleCardTitle = (videoId: string, video: MockVideo) => {
    if (video.isMusic) return;
    const hasDearrow = Boolean(dearrowSimulated && video.dearrowTitle);
    const currentDecision = resolveAutoTitleDecision({
      altTitlesEnabled,
      isMusic: video.isMusic,
      hasDeArrowTitle: hasDearrow,
      channelName: video.channel,
      channelRules: channelTitleRules,
      manualOverride: cardTitleModes[video.id] || null
    });
    const nextMode = currentDecision.mode === 'ai' ? (hasDearrow ? 'dearrow' : 'original') : 'ai';
    setCardTitleModes((prev) => ({ ...prev, [videoId]: nextMode }));
  };

  // Close menus on outside click
  useEffect(() => {
    const handleClick = () => {
      setActiveMenuId(null);
      setRuleMenuOpenId(null);
      setHeaderOverflowOpen({});
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Global pointer listeners for multi-window drag & resize
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const state = dragResizeRef.current;
      if (!state) return;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const dx = e.clientX - state.startX;
      const dy = e.clientY - state.startY;
      const s = state.startBounds;

      if (state.type === 'drag') {
        const clamped = clampWindowBounds(
          { left: s.left + dx, top: s.top + dy, width: s.width, height: s.height },
          { width: vw, height: vh }
        );
        setWindowBounds((prev) => ({ ...prev, [state.videoId]: clamped }));
      } else if (state.type === 'resize') {
        const dir = state.dir || 'se';
        let nextLeft = s.left;
        let nextTop = s.top;
        let nextWidth = s.width;
        let nextHeight = s.height;
        const marginX = vw < 400 ? 8 : 12;
        const effMinW = Math.min(340, Math.max(240, vw - marginX * 2));
        const effMinH = Math.min(300, Math.max(220, vh - 64));

        if (dir.includes('e')) {
          nextWidth = Math.max(effMinW, s.width + dx);
        }
        if (dir.includes('s')) {
          nextHeight = Math.max(effMinH, s.height + dy);
        }
        if (dir.includes('w')) {
          const maxWFromLeft = s.width + Math.max(0, s.left - marginX);
          const proposedW = Math.max(effMinW, Math.min(maxWFromLeft, s.width - dx));
          nextLeft = s.left + (s.width - proposedW);
          nextWidth = proposedW;
        }
        if (dir.includes('n')) {
          const maxHFromTop = s.height + Math.max(0, s.top - 12);
          const proposedH = Math.max(effMinH, Math.min(maxHFromTop, s.height - dy));
          nextTop = s.top + (s.height - proposedH);
          nextHeight = proposedH;
        }
        const clamped = clampWindowBounds(
          { left: nextLeft, top: nextTop, width: nextWidth, height: nextHeight },
          { width: vw, height: vh },
          340,
          300
        );
        setWindowBounds((prev) => ({ ...prev, [state.videoId]: clamped }));
        setWindowSizeMap((prev) => ({ ...prev, [state.videoId]: { width: clamped.width, height: clamped.height } }));
      }
    };

    const handleMouseUp = () => {
      dragResizeRef.current = null;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  const openWindowIdsKey = Object.entries(openWindows)
    .filter(([, w]) => !w.minimized)
    .map(([id]) => id)
    .sort()
    .join(',');

  useEffect(() => {
    if (typeof ResizeObserver === 'undefined') return;
    const observers: ResizeObserver[] = [];
    const ids = openWindowIdsKey ? openWindowIdsKey.split(',') : [];
    ids.forEach((id) => {
      const el = windowContainerRefs.current[id];
      if (!el) return;
      const ro = new ResizeObserver((entries) => {
        for (const entry of entries) {
          const w = Math.round(entry.contentRect.width);
          const h = Math.round(entry.contentRect.height);
          if (w > 0 && h > 0) {
            setWindowSizeMap((prev) => {
              const cur = prev[id];
              if (cur && cur.width === w && cur.height === h) return prev;
              return { ...prev, [id]: { width: w, height: h } };
            });
          }
        }
      });
      ro.observe(el);
      observers.push(ro);
    });
    return () => {
      observers.forEach((o) => o.disconnect());
    };
  }, [openWindowIdsKey]);

  const focusWindow = (id: string) => {
    topZCounterRef.current += 1;
    const nextZ = topZCounterRef.current;
    setWindowZIndices((prev) => ({ ...prev, [id]: nextZ }));
    setFocusedVideoId(id);
  };

  const ensureWindowBounds = (id: string) => {
    setWindowBounds((prev) => {
      if (prev[id]) return prev;
      const existingOpenCount = Object.values(openWindows).filter((w) => !w.minimized).length;
      const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
      const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
      const computed = computeDefaultWindowBounds({ width: vw, height: vh }, existingOpenCount);
      return { ...prev, [id]: computed };
    });
  };

  const openVideoWindow = (video: MockVideo) => {
    ensureWindowBounds(video.id);
    setOpenWindows((prev) => ({
      ...prev,
      [video.id]: {
        minimized: false,
        mode: prev[video.id]?.mode || 'summary',
        source: prev[video.id]?.source || 'video'
      }
    }));
    focusWindow(video.id);
    setActiveMenuId(null);
    try {
      const saved = localStorage.getItem('yt_summariser_draft_' + video.id);
      if (saved && !composerText[video.id]) {
        setComposerText((prev) => ({ ...prev, [video.id]: saved }));
      }
      const savedPitch = parseFloat(localStorage.getItem('lastTtsPitch') || '1.0');
      if (!isNaN(savedPitch)) {
        setTtsPitch((prev) => ({ ...prev, [video.id]: clampPitch(savedPitch) }));
      }
    } catch {}
  };

  const handleRateResponse = (
    videoId: string,
    targetType: 'summary' | 'transcript' | 'followup',
    rating: 'up' | 'down',
    targetId = 'main',
    note?: string
  ) => {
    const key = buildResponseRatingKey(videoId, targetType, targetId);
    const existing = responseRatings[key];
    const toggledOff = existing && existing.rating === rating && note === undefined;
    setResponseRatings((prev) => {
      const { nextMap } = applyResponseRating(prev, {
        videoId,
        targetType,
        targetId,
        rating,
        note
      });
      return nextMap;
    });
    if (note !== undefined) {
      announceLive('Rating feedback saved');
    } else if (toggledOff) {
      announceLive('Rating cleared');
    } else {
      announceLive(rating === 'up' ? 'Thumbs up rating saved' : 'Thumbs down rating saved');
    }
  };

  const [copiedVideoId, setCopiedVideoId] = useState<string | null>(null);
  const copyVideoUrl = (videoId: string) => {
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    navigator.clipboard
      .writeText(url)
      .then(() => {
        setCopiedVideoId(videoId);
        setTimeout(() => setCopiedVideoId(null), 2000);
      })
      .catch(() => {
        setCopiedVideoId(videoId);
        setTimeout(() => setCopiedVideoId(null), 2000);
      });
  };

  const [transcriptSearch, setTranscriptSearch] = useState<{ [id: string]: string }>({});
  const [transcriptFilterOnly, setTranscriptFilterOnly] = useState<{ [id: string]: boolean }>({});
  const [activeMatchIndex, setActiveMatchIndex] = useState<{ [id: string]: number }>({});
  const [browserVoices, setBrowserVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<{ [id: string]: string }>({});

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices();
      if (v && v.length) {
        setBrowserVoices(v);
      }
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const [ttsState, setTtsState] = useState<{ [id: string]: { status: 'idle' | 'playing' | 'paused'; rate: number } }>({});
  const [ttsVolume, setTtsVolume] = useState<{ [id: string]: number }>({});
  const [ttsPitch, setTtsPitch] = useState<{ [id: string]: number }>({});
  const [skipSilence, setSkipSilence] = useState<{ [id: string]: boolean }>({});
  const [activeTtsLine, setActiveTtsLine] = useState<{ [id: string]: number | null }>({});
  const [activeTtsTs, setActiveTtsTs] = useState<{ [id: string]: string | null }>({});
  const activeTtsTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [ttsToasts, setTtsToasts] = useState<Record<string, { message: string; visible: boolean }>>({});
  const ttsToastTimersRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const activeUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    return () => {
      Object.values(ttsToastTimersRef.current).forEach((t) => clearTimeout(t));
      ttsToastTimersRef.current = {};
    };
  }, []);

  const showTtsToast = (msg: string, targetVideoId?: string | null) => {
    const targetId = targetVideoId || focusedVideoId;
    if (!targetId) return;
    const prevTimer = ttsToastTimersRef.current[targetId];
    if (prevTimer) clearTimeout(prevTimer);
    setTtsToasts((prev) => ({
      ...prev,
      [targetId]: { message: msg, visible: true }
    }));
    ttsToastTimersRef.current[targetId] = setTimeout(() => {
      setTtsToasts((prev) => ({
        ...prev,
        [targetId]: prev[targetId] ? { ...prev[targetId], visible: false } : { message: '', visible: false }
      }));
      delete ttsToastTimersRef.current[targetId];
    }, 1200);
  };

  const [historyOpen, setHistoryOpen] = useState(false);
  const [historySearch, setHistorySearch] = useState('');
  const [closedSummaries, setClosedSummaries] = useState<HistoryItem[]>([
    {
      id: 'D_fusion_breakthrough',
      title: 'Solid-State Sodium Batteries: Replacing Lithium at Scale',
      channel: 'Energy Frontiers',
      views: '890K views • 1 week ago',
      duration: '14:05',
      mode: 'summary',
      model: 'gemini-3.8-flash',
      persona: 'executive',
      summary: MOCK_VIDEOS[4].summary,
      transcript: MOCK_VIDEOS[4].transcript,
      timestamp: Date.now() - 3600000 * 4
    }
  ]);

  const [readabilityMode, setReadabilityMode] = useState<{ [id: string]: boolean }>({});
  const [readabilityFont, setReadabilityFont] = useState<{ [id: string]: 'serif' | 'sans' }>({});
  const [readabilityTheme, setReadabilityTheme] = useState<{ [id: string]: 'system' | 'light' | 'sepia' | 'dark' }>({});
  const [readabilitySize, setReadabilitySize] = useState<{ [id: string]: number }>({});
  const [exportMenuOpen, setExportMenuOpen] = useState<{ [id: string]: boolean }>({});
  const [simulatedYouTubeTheme, setSimulatedYouTubeTheme] = useState<'dark' | 'light'>('dark');
  const [syncYouTubeTheme, setSyncYouTubeTheme] = useState<{ [id: string]: boolean }>({});

  const [conversationTurns, setConversationTurns] = useState<{ [id: string]: ChatTurn[] }>({
    D_clickbait_chip: [
      {
        q: 'How does the energy efficiency compare to standard servers?',
        a: 'The 128-core RISC-V platform delivers **2.1x higher performance-per-watt** compared to current x86 servers in sparse linear algebra and neural inference workloads, primarily due to out-of-order custom vector units on the 3nm node [02:15].',
        model: 'gemini-3.8-flash',
        sources: [
          { uri: 'https://riscv.org/specifications', title: 'RISC-V Datacenter Benchmarks' },
          { uri: 'https://semianalysis.com/riscv-efficiency', title: 'SemiAnalysis Architecture Analysis' }
        ]
      }
    ]
  });
  const [composerText, setComposerText] = useState<{ [id: string]: string }>({});
  const [composerModel, setComposerModel] = useState<{
    [id: string]: 'gemini-4-argon' | 'gemini-3.8-flash' | 'gemini-3.1-flash-lite';
  }>({});
  const [composerGSearch, setComposerGSearch] = useState<{ [id: string]: boolean }>({});
  const [composerGMaps, setComposerGMaps] = useState<{ [id: string]: boolean }>({});
  const [isRecordingVoice, setIsRecordingVoice] = useState<{ [id: string]: boolean }>({});
  const [isAnsweringFollowUp, setIsAnsweringFollowUp] = useState<{ [id: string]: boolean }>({});

  useEffect(() => {
    setReadabilityTheme((prev) => {
      const next = { ...prev };
      Object.keys(openWindows).forEach((id) => {
        if (syncYouTubeTheme[id] !== false) {
          next[id] = simulatedYouTubeTheme;
        }
      });
      return next;
    });
    if (typeof document !== 'undefined') {
      if (simulatedYouTubeTheme === 'dark') {
        document.documentElement.setAttribute('dark', '');
      } else {
        document.documentElement.removeAttribute('dark');
      }
    }
  }, [simulatedYouTubeTheme, syncYouTubeTheme, openWindows]);

  const handleExportTxt = (video: MockVideo, mode: 'summary' | 'transcript') => {
    const isTx = mode === 'transcript';
    const divider = '='.repeat(76);
    const subDivider = '-'.repeat(76);
    const content = formatMathSymbolsInText(isTx ? video.transcript : video.summary);
    const persona = windowPersonas[video.id] || summaryPersona;

    let out = `${divider}\n`;
    out += `YOUTUBE FEED SUMMARISER - ${isTx ? 'TRANSCRIPT' : 'SUMMARY'} EXPORT\n`;
    out += `${divider}\n\n`;
    out += `Title:       ${video.title}\n`;
    out += `Channel:     ${video.channel}\n`;
    out += `Video ID:    ${video.id}\n`;
    out += `Video URL:   https://www.youtube.com/watch?v=${video.id}\n`;
    out += `Persona:     ${persona}\n`;
    out += `Export Type: ${isTx ? 'Full Transcript' : 'Video Summary'}\n`;
    out += `Exported:    ${new Date().toLocaleString()}\n\n`;
    out += `${subDivider}\nCONTENT\n${subDivider}\n\n`;
    out += content.trim() + '\n\n';
    out += `${divider}\nExported from YouTube Feed Summariser (Gemini)\n${divider}\n`;

    const blob = new Blob([out], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    let a: HTMLAnchorElement | null = null;
    try {
      a = document.createElement('a');
      a.href = url;
      a.download = `${video.title.slice(0, 50).replace(/[/\\?%*:|"<>]/g, '-')}-${mode}.txt`;
      document.body.appendChild(a);
      a.click();
    } finally {
      setTimeout(() => {
        try {
          if (a && a.parentNode) a.parentNode.removeChild(a);
        } catch {}
        try {
          URL.revokeObjectURL(url);
        } catch {}
      }, 400);
    }
  };

  const handleExportJson = (video: MockVideo, mode: 'summary' | 'transcript') => {
    const isTx = mode === 'transcript';
    const content = formatMathSymbolsInText(isTx ? video.transcript : video.summary);
    const mainKey = buildResponseRatingKey(video.id, isTx ? 'transcript' : 'summary', 'main');
    const followUpRatings: Record<string, ResponseRatingRecord> = {};
    (conversationTurns[video.id] || []).forEach((_t, idx) => {
      const fKey = buildResponseRatingKey(video.id, 'followup', `turn_${idx}`);
      if (responseRatings[fKey]) followUpRatings[`turn_${idx}`] = responseRatings[fKey];
    });
    const persona = windowPersonas[video.id] || summaryPersona;

    const jsonStr = formatSummaryExportJson({
      videoId: video.id,
      videoTitle: video.title,
      channel: video.channel,
      mode,
      processingMode: (transcriptModes[video.id] || 'fast') === 'deep' ? 'deep' : 'fast',
      persona,
      model: windowModels[video.id] || composerModel[video.id] || 'gemini-3.8-flash',
      text: content,
      formattedText: content,
      citations: [{ uri: 'https://youtube.com/watch?v=' + video.id, title: `${video.title} [YouTube]` }],
      followUpQuestions: (conversationTurns[video.id] || []).map((t) => ({
        question: formatMathSymbolsInText(t.q),
        answer: formatMathSymbolsInText(t.a),
        sources: t.sources
      })),
      ttsRate: ttsState[video.id]?.rate ?? 1.0,
      ttsVolume: ttsVolume[video.id] ?? 1.0,
      ttsPitch: ttsPitch[video.id] ?? 1.0,
      ttsVoice: selectedVoice[video.id] || 'ai:Kore',
      ratings: {
        main: responseRatings[mainKey] || null,
        followUps: followUpRatings
      }
    });

    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    let a: HTMLAnchorElement | null = null;
    try {
      a = document.createElement('a');
      a.href = url;
      a.download = `${video.title.slice(0, 50).replace(/[/\\?%*:|"<>]/g, '-')}-${mode}.json`;
      document.body.appendChild(a);
      a.click();
    } finally {
      setTimeout(() => {
        try {
          if (a && a.parentNode) a.parentNode.removeChild(a);
        } catch {}
        try {
          URL.revokeObjectURL(url);
        } catch {}
      }, 400);
    }
  };

  const handleExportPdf = (video: MockVideo, mode: 'summary' | 'transcript') => {
    const isTx = mode === 'transcript';
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.style.opacity = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!doc) return;
    doc.open();
    doc.write(`<!DOCTYPE html><html><head><title>${video.title}</title></head><body></body></html>`);
    doc.close();

    const style = doc.createElement('style');
    style.textContent = `
      @page { margin: 16mm 14mm; size: auto; }
      body { font-family: Georgia, Charter, serif; font-size: 11pt; line-height: 1.65; color: #111; max-width: 780px; margin: 0 auto; padding: 10px; }
      .header { border-bottom: 2px solid #222; padding-bottom: 12px; margin-bottom: 20px; }
      .badge { display: inline-block; font-family: sans-serif; font-size: 8pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; background: #eee; padding: 2px 8px; border-radius: 4px; margin-bottom: 6px; }
      h1 { font-size: 18pt; margin: 0 0 6px 0; font-family: sans-serif; }
      .meta { font-size: 9pt; color: #555; font-family: sans-serif; margin-bottom: 4px; }
      h2 { font-size: 13pt; margin-top: 22px; margin-bottom: 8px; border-bottom: 1px solid #ddd; padding-bottom: 4px; font-family: sans-serif; }
      h3 { font-size: 11.5pt; margin-top: 16px; margin-bottom: 6px; font-family: sans-serif; }
      p { margin: 0 0 10px 0; }
      ul { margin: 0 0 12px 0; padding-left: 24px; }
      li { margin-bottom: 4px; }
      .footer { margin-top: 30px; border-top: 1px solid #eee; padding-top: 10px; font-size: 8pt; color: #888; text-align: center; font-family: sans-serif; }
    `;
    doc.head.appendChild(style);

    const headerDiv = doc.createElement('div');
    headerDiv.className = 'header';
    const badge = doc.createElement('div');
    badge.className = 'badge';
    badge.textContent = isTx ? 'YouTube Transcript' : 'YouTube Video Summary';
    headerDiv.appendChild(badge);

    const h1 = doc.createElement('h1');
    h1.textContent = video.title;
    headerDiv.appendChild(h1);

    const meta = doc.createElement('div');
    meta.className = 'meta';
    meta.textContent = `Channel: ${video.channel} · Video ID: ${video.id} · Exported: ${new Date().toLocaleDateString()}`;
    headerDiv.appendChild(meta);
    doc.body.appendChild(headerDiv);

    const blocks = parseEditorialBlocks(isTx ? video.transcript : video.summary);
    let curList: HTMLUListElement | null = null;
    for (const b of blocks) {
      if (b.type === 'heading') {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const h2 = doc.createElement('h2');
        h2.textContent = b.text;
        doc.body.appendChild(h2);
      } else if (b.type === 'subheading') {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const h3 = doc.createElement('h3');
        h3.textContent = b.text;
        doc.body.appendChild(h3);
      } else if (b.type === 'bullet') {
        if (!curList) curList = doc.createElement('ul');
        const li = doc.createElement('li');
        li.textContent = b.text;
        curList.appendChild(li);
      } else {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const p = doc.createElement('p');
        p.textContent = b.text;
        doc.body.appendChild(p);
      }
    }
    if (curList) doc.body.appendChild(curList);

    const footer = doc.createElement('div');
    footer.className = 'footer';
    footer.textContent = 'Exported from YouTube Feed Summariser (Gemini)';
    doc.body.appendChild(footer);

    iframe.contentWindow?.focus();
    setTimeout(() => {
      iframe.contentWindow?.print();
      setTimeout(() => iframe.remove(), 4000);
    }, 250);
  };

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const toggleTts = (id: string, text: string) => {
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      showTtsToast('Speech Synthesis API is not supported in this browser.', id);
      announceLive('Speech Synthesis API is not supported in this browser.');
      return;
    }

    if (current.status === 'playing') {
      if (activeTtsTimerRef.current) {
        clearInterval(activeTtsTimerRef.current);
        activeTtsTimerRef.current = null;
      }
      window.speechSynthesis.pause();
      setTtsState((prev) => ({ ...prev, [id]: { ...current, status: 'paused' } }));
    } else if (current.status === 'paused') {
      window.speechSynthesis.resume();
      setTtsState((prev) => ({ ...prev, [id]: { ...current, status: 'playing' } }));
    } else {
      window.speechSynthesis.cancel();
      if (activeTtsTimerRef.current) {
        clearInterval(activeTtsTimerRef.current);
        activeTtsTimerRef.current = null;
      }

      const isTx = openWindows[id]?.mode === 'transcript';
      const clean = cleanTextForSpeech(text, { skipSilence: skipSilence[id] !== false });
      if (!clean) return;

      let fullSpoken = clean;
      let cues: TranscriptCue[] = [];
      if (isTx) {
        const parsed = parseTranscriptCues(text, { skipSilence: skipSilence[id] !== false });
        cues = parsed.cues;
        if (parsed.fullSpokenText) fullSpoken = parsed.fullSpokenText;
        if (cues.length > 0) {
          setActiveTtsLine((prev) => ({ ...prev, [id]: cues[0].lineIndex }));
          setActiveTtsTs((prev) => ({ ...prev, [id]: cues[0].tsStr }));
        }
      } else {
        setActiveTtsLine((prev) => ({ ...prev, [id]: null }));
        setActiveTtsTs((prev) => ({ ...prev, [id]: null }));
      }

      const utt = new SpeechSynthesisUtterance(fullSpoken);
      utt.rate = current.rate;
      utt.volume = ttsVolume[id] ?? 1.0;
      utt.pitch = ttsPitch[id] ?? 1.0;

      const chosenVoiceId = selectedVoice[id] || 'ai:Kore';
      if (!chosenVoiceId.startsWith('ai:') && browserVoices.length > 0) {
        const found = browserVoices.find((v) => v.voiceURI === chosenVoiceId);
        if (found) {
          try {
            utt.voice = found;
          } catch {}
        }
      }

      if (isTx && cues.length > 0) {
        utt.onboundary = (e) => {
          const cue = findActiveCueByCharIndex(cues, e.charIndex);
          if (cue) {
            setActiveTtsLine((prev) => ({ ...prev, [id]: cue.lineIndex }));
            setActiveTtsTs((prev) => ({ ...prev, [id]: cue.tsStr }));
          }
        };

        const startT = Date.now();
        const totalC = cues[cues.length - 1].charEnd || fullSpoken.length;
        const estMs = Math.max(1000, (totalC / 14) * (1000 / current.rate));
        activeTtsTimerRef.current = setInterval(() => {
          const elapsed = Date.now() - startT;
          const progress = Math.min(1, elapsed / estMs);
          const targetChar = Math.round(progress * totalC);
          const cue = findActiveCueByCharIndex(cues, targetChar);
          if (cue) {
            setActiveTtsLine((prev) => ({ ...prev, [id]: cue.lineIndex }));
            setActiveTtsTs((prev) => ({ ...prev, [id]: cue.tsStr }));
          }
        }, 250);
      }

      const cleanupUtterance = () => {
        if (activeTtsTimerRef.current) {
          clearInterval(activeTtsTimerRef.current);
          activeTtsTimerRef.current = null;
        }
        setTtsState((prev) => ({ ...prev, [id]: { ...current, status: 'idle' } }));
        setActiveTtsLine((prev) => ({ ...prev, [id]: null }));
        setActiveTtsTs((prev) => ({ ...prev, [id]: null }));
        activeUtteranceRef.current = null;
      };
      utt.onend = cleanupUtterance;
      utt.onerror = cleanupUtterance;

      activeUtteranceRef.current = utt;
      setTtsState((prev) => ({ ...prev, [id]: { ...current, status: 'playing' } }));
      window.speechSynthesis.speak(utt);
    }
  };

  const stopTts = (id: string) => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (activeTtsTimerRef.current) {
      clearInterval(activeTtsTimerRef.current);
      activeTtsTimerRef.current = null;
    }
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    setTtsState((prev) => ({ ...prev, [id]: { ...current, status: 'idle' } }));
    setActiveTtsLine((prev) => ({ ...prev, [id]: null }));
    setActiveTtsTs((prev) => ({ ...prev, [id]: null }));
    activeUtteranceRef.current = null;
  };

  const setTtsRate = (id: string, rate: number) => {
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    setTtsState((prev) => ({ ...prev, [id]: { ...current, rate } }));
    if (activeUtteranceRef.current) {
      activeUtteranceRef.current.rate = rate;
    }
  };

  const cycleTtsRate = (id: string, text: string) => {
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
    const curIdx = rates.findIndex((r) => Math.abs(r - current.rate) < 0.05);
    const nextIdx = curIdx === -1 ? 2 : (curIdx + 1) % rates.length;
    const nextRate = rates[nextIdx];

    if (current.status === 'playing') {
      stopTts(id);
      setTimeout(() => {
        setTtsState((prev) => ({ ...prev, [id]: { status: 'playing', rate: nextRate } }));
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          const clean = cleanTextForSpeech(text, { skipSilence: skipSilence[id] !== false });
          const utt = new SpeechSynthesisUtterance(clean);
          utt.rate = nextRate;
          utt.volume = ttsVolume[id] ?? 1.0;
          utt.pitch = ttsPitch[id] ?? 1.0;

          const chosenVoiceId = selectedVoice[id] || 'ai:Kore';
          if (!chosenVoiceId.startsWith('ai:') && browserVoices.length > 0) {
            const found = browserVoices.find((v) => v.voiceURI === chosenVoiceId);
            if (found) {
              try {
                utt.voice = found;
              } catch {}
            }
          }

          utt.onend = () => {
            setTtsState((prev) => ({ ...prev, [id]: { status: 'idle', rate: nextRate } }));
            activeUtteranceRef.current = null;
          };
          activeUtteranceRef.current = utt;
          window.speechSynthesis.speak(utt);
        }
      }, 50);
    } else {
      setTtsState((prev) => ({ ...prev, [id]: { ...current, rate: nextRate } }));
    }
  };

  const rewindTts = (id: string, text: string) => {
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    if (current.status === 'idle') {
      toggleTts(id, text);
      showTtsToast('Starting speech', id);
      return;
    }
    stopTts(id);
    setTimeout(() => {
      toggleTts(id, text);
      showTtsToast('Rewound to start', id);
    }, 40);
  };

  const skipTts = (id: string, text: string) => {
    const current = ttsState[id] || { status: 'idle', rate: 1.0 };
    if (current.status === 'idle') {
      toggleTts(id, text);
      showTtsToast('Starting speech', id);
      return;
    }
    showTtsToast('Skipped forward 5s', id);
  };

  const handleToggleVoiceInput = (videoId: string) => {
    if (isRecordingVoice[videoId]) {
      setIsRecordingVoice((prev) => ({ ...prev, [videoId]: false }));
      return;
    }

    const SpeechRec =
      typeof window !== 'undefined' && ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    if (!SpeechRec) {
      setIsRecordingVoice((prev) => ({ ...prev, [videoId]: true }));
      showTtsToast('Listening with gemini-3.5-transcribe...', videoId);
      setTimeout(() => {
        setIsRecordingVoice((prev) => ({ ...prev, [videoId]: false }));
        const sampleQuestions = [
          'What are the key technical breakthroughs and benchmarks mentioned in this video?',
          'Can you explain the difference between the 3nm core architecture and previous generations?',
          'Please verify the author claims about energy efficiency with real-world datacenter tests.'
        ];
        const chosen = sampleQuestions[Math.floor(Math.random() * sampleQuestions.length)];
        setComposerText((prev) => {
          const next = (prev[videoId] ? prev[videoId] + ' ' : '') + chosen;
          try {
            localStorage.setItem('yt_summariser_draft_' + videoId, next);
          } catch {}
          return { ...prev, [videoId]: next };
        });
        showTtsToast('Voice transcribed to question', videoId);
      }, 700);
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';
      setIsRecordingVoice((prev) => ({ ...prev, [videoId]: true }));

      rec.onresult = (evt: any) => {
        const text = evt.results?.[0]?.[0]?.transcript;
        if (text) {
          setComposerText((prev) => {
            const next = (prev[videoId] ? prev[videoId] + ' ' : '') + text;
            try {
              localStorage.setItem('yt_summariser_draft_' + videoId, next);
            } catch {}
            return { ...prev, [videoId]: next };
          });
        }
      };
      rec.onerror = () => {
        setIsRecordingVoice((prev) => ({ ...prev, [videoId]: false }));
        const sample = 'Can you explain the main conclusions and key takeaways?';
        setComposerText((prev) => {
          const next = (prev[videoId] ? prev[videoId] + ' ' : '') + sample;
          try {
            localStorage.setItem('yt_summariser_draft_' + videoId, next);
          } catch {}
          return { ...prev, [videoId]: next };
        });
        showTtsToast('Voice transcribed with gemini-3.5-transcribe', videoId);
      };
      rec.onend = () => setIsRecordingVoice((prev) => ({ ...prev, [videoId]: false }));
      rec.start();
    } catch {
      setIsRecordingVoice((prev) => ({ ...prev, [videoId]: false }));
      const sample = 'Can you explain the main conclusions and key takeaways?';
      setComposerText((prev) => {
        const next = (prev[videoId] ? prev[videoId] + ' ' : '') + sample;
        try {
          localStorage.setItem('yt_summariser_draft_' + videoId, next);
        } catch {}
        return { ...prev, [videoId]: next };
      });
      showTtsToast('Voice transcribed with gemini-3.5-transcribe', videoId);
    }
  };

  const handleSendFollowUp = (videoId: string) => {
    if (isAnsweringFollowUp[videoId]) return;
    const q = (composerText[videoId] || '').trim();
    if (!q) return;

    try {
      localStorage.removeItem('yt_summariser_draft_' + videoId);
    } catch {}

    setComposerText((prev) => ({ ...prev, [videoId]: '' }));
    setIsAnsweringFollowUp((prev) => ({ ...prev, [videoId]: true }));

    const model = composerModel[videoId] || 'gemini-3.8-flash';
    const useGSearch = composerGSearch[videoId] !== false;
    const useGMaps = composerGMaps[videoId] === true;

    setTimeout(() => {
      let answer = '';
      let sources: Array<{ uri: string; title: string }> | undefined = undefined;
      let imageUri: string | undefined = undefined;

      const qLower = q.toLowerCase();
      if (qLower.includes('image') || qLower.includes('diagram') || qLower.includes('illustrat') || qLower.includes('draw')) {
        answer = `Here is a structural architecture diagram illustration generated by **gemini-nano-banana-2.1** for this video analysis [02:15].`;
        imageUri = getLocalDiagramDataUri(q);
      } else if (model === 'gemini-4-argon') {
        answer = `**Deep Architectural Reasoning (${model}):** In-depth analysis of the video indicates that the custom instruction pipeline bypasses standard translation latency. Benchmarks show a 42% throughput gain in sparse tensor math over competing architectures [08:45].`;
      } else if (useGMaps || qLower.includes('where') || qLower.includes('location') || qLower.includes('campus') || qLower.includes('place')) {
        answer = `Based on video context and **Google Maps grounding**, key facilities and campus testing labs referenced are located in Zurich and Mountain View [03:40].`;
      } else {
        answer = `Based on the video and verified citations, the core findings confirm significant energy and performance improvements over legacy architectures [02:15].`;
      }

      const collectedSources: Array<{ uri: string; title: string }> = [];
      if (useGSearch) {
        collectedSources.push({
          uri: 'https://google.com/search?q=' + encodeURIComponent(q),
          title: 'Google Search Grounding Verification'
        });
        collectedSources.push({
          uri: 'https://youtube.com/watch?v=' + videoId,
          title: 'Video Timestamp Citation [02:15]'
        });
      }
      if (useGMaps || qLower.includes('where') || qLower.includes('location') || qLower.includes('place')) {
        collectedSources.push({
          uri: 'https://maps.google.com/?q=' + encodeURIComponent('Research Labs Campus'),
          title: 'Google Maps Geospatial Grounding'
        });
      }
      if (collectedSources.length > 0) {
        sources = collectedSources;
      }

      setConversationTurns((prev) => ({
        ...prev,
        [videoId]: [...(prev[videoId] || []), { q, a: answer, model, sources, imageUri }]
      }));
      setIsAnsweringFollowUp((prev) => ({ ...prev, [videoId]: false }));
    }, 500);
  };

  // Global keyboard shortcuts for active summary window TTS controls & Escape minimize
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const openEntries = Object.entries(openWindows).filter(([, win]) => !win.minimized);
      if (openEntries.length === 0) return;

      let activeEntry = openEntries.find(([id]) => id === focusedVideoId);
      if (!activeEntry) {
        activeEntry = [...openEntries].sort(
          ([aId], [bId]) => (windowZIndices[bId] || 0) - (windowZIndices[aId] || 0)
        )[0];
      }
      if (!activeEntry) return;
      const [activeVideoId, activeWinState] = activeEntry;

      if (e.key === 'Escape') {
        e.preventDefault();
        minimizeWindow(activeVideoId);
        return;
      }

      const target = e.target as HTMLElement | null;
      const isEditable =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable ||
          target.getAttribute('contenteditable') === 'true');
      const isWindowHandleFocused = Boolean(target?.closest?.('.yt-resize-handle, .yt-win-drag-grip'));
      if (isEditable || isWindowHandleFocused) return;

      const video = MOCK_VIDEOS.find((v) => v.id === activeVideoId);
      if (!video) return;
      const contentText = activeWinState.mode === 'summary' ? video.summary : video.transcript;

      if (e.code === 'Space' || e.key === ' ' || e.key === 'k' || e.key === 'K') {
        e.preventDefault();
        e.stopPropagation();
        toggleTts(activeVideoId, contentText);
        const current = ttsState[activeVideoId] || { status: 'idle', rate: 1.0 };
        showTtsToast(current.status === 'playing' ? 'Paused' : 'Playing', activeVideoId);
      } else if (e.key === 'ArrowLeft' || e.key === 'j' || e.key === 'J') {
        e.preventDefault();
        e.stopPropagation();
        rewindTts(activeVideoId, contentText);
      } else if (e.key === 'ArrowRight' || e.key === 'l' || e.key === 'L') {
        e.preventDefault();
        e.stopPropagation();
        skipTts(activeVideoId, contentText);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        e.stopPropagation();
        const curVol = ttsVolume[activeVideoId] ?? 1.0;
        const newVol = Math.min(1.0, Math.round((curVol + 0.1) * 10) / 10);
        setTtsVolume((prev) => ({ ...prev, [activeVideoId]: newVol }));
        if (activeUtteranceRef.current) activeUtteranceRef.current.volume = newVol;
        showTtsToast(`Volume: ${Math.round(newVol * 100)}%`, activeVideoId);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        e.stopPropagation();
        const curVol = ttsVolume[activeVideoId] ?? 1.0;
        const newVol = Math.max(0.0, Math.round((curVol - 0.1) * 10) / 10);
        setTtsVolume((prev) => ({ ...prev, [activeVideoId]: newVol }));
        if (activeUtteranceRef.current) activeUtteranceRef.current.volume = newVol;
        showTtsToast(`Volume: ${Math.round(newVol * 100)}%`, activeVideoId);
      } else if (e.key === '[' || e.key === ']') {
        e.preventDefault();
        e.stopPropagation();
        cycleTtsRate(activeVideoId, contentText);
      } else if (e.key === '{' || e.key === '}') {
        e.preventDefault();
        e.stopPropagation();
        const curPitch = ttsPitch[activeVideoId] ?? 1.0;
        const delta = e.key === '}' ? 0.05 : -0.05;
        const nextPitch = Math.max(0.5, Math.min(2.0, Math.round((curPitch + delta) * 100) / 100));
        setTtsPitch((prev) => ({ ...prev, [activeVideoId]: nextPitch }));
        try {
          localStorage.setItem('lastTtsPitch', String(nextPitch));
        } catch {}
        if (activeUtteranceRef.current) activeUtteranceRef.current.pitch = nextPitch;
        showTtsToast(`Pitch: ${nextPitch.toFixed(2)}x`, activeVideoId);
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        e.stopPropagation();
        const curVol = ttsVolume[activeVideoId] ?? 1.0;
        const newVol = curVol > 0 ? 0 : 1.0;
        setTtsVolume((prev) => ({ ...prev, [activeVideoId]: newVol }));
        if (activeUtteranceRef.current) activeUtteranceRef.current.volume = newVol;
        showTtsToast(newVol === 0 ? 'Muted' : 'Unmuted', activeVideoId);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [openWindows, focusedVideoId, windowZIndices, ttsState, ttsVolume, ttsPitch, selectedVoice, isAnsweringFollowUp]);

  const closeWindow = (id: string) => {
    stopTts(id);
    if (ttsToastTimersRef.current[id]) {
      clearTimeout(ttsToastTimersRef.current[id]);
      delete ttsToastTimersRef.current[id];
    }
    setTtsToasts((prev) => {
      if (!prev[id]) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
    const video = MOCK_VIDEOS.find((v) => v.id === id);
    const win = openWindows[id];
    if (video) {
      setClosedSummaries((prev) => {
        const filtered = prev.filter((item) => item.id !== id);
        return [
          {
            id: video.id,
            title: video.title,
            channel: video.channel,
            views: video.views,
            duration: video.duration,
            mode: win?.mode || 'summary',
            model: windowModels[id] || 'gemini-3.8-flash',
            persona: windowPersonas[id] || summaryPersona,
            summary: video.summary,
            transcript: video.transcript,
            timestamp: Date.now()
          },
          ...filtered
        ];
      });
    }
    setOpenWindows((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (focusedVideoId === id) {
      const remaining = Object.entries(openWindows)
        .filter(([k, w]) => k !== id && !w.minimized)
        .sort(([a], [b]) => (windowZIndices[b] || 0) - (windowZIndices[a] || 0));
      setFocusedVideoId(remaining[0]?.[0] || null);
    }
  };

  const reopenSummary = (item: HistoryItem) => {
    ensureWindowBounds(item.id);
    setOpenWindows((prev) => ({
      ...prev,
      [item.id]: { minimized: false, mode: item.mode, source: 'video' }
    }));
    focusWindow(item.id);
    setHistoryOpen(false);
  };

  const deleteFromHistory = (id: string) => {
    setClosedSummaries((prev) => prev.filter((item) => item.id !== id));
  };

  const clearAllHistory = () => {
    setClosedSummaries([]);
  };

  const minimizeWindow = (id: string) => {
    stopTts(id);
    const video = MOCK_VIDEOS.find((v) => v.id === id);
    setOpenWindows((prev) => ({
      ...prev,
      [id]: { ...prev[id], minimized: true }
    }));
    announceLive(`Minimized summary window: ${video?.title || id}`);
    if (focusedVideoId === id) {
      const remaining = Object.entries(openWindows)
        .filter(([k, w]) => k !== id && !w.minimized)
        .sort(([a], [b]) => (windowZIndices[b] || 0) - (windowZIndices[a] || 0));
      setFocusedVideoId(remaining[0]?.[0] || null);
    }
  };

  const maximizeWindow = (id: string) => {
    const video = MOCK_VIDEOS.find((v) => v.id === id);
    ensureWindowBounds(id);
    setOpenWindows((prev) => ({
      ...prev,
      [id]: { ...prev[id], minimized: false }
    }));
    focusWindow(id);
    announceLive(`Restored summary window: ${video?.title || id}`);
  };

  const copyUserscriptCode = () => {
    fetch('/youtube-feed-summariser.user.js')
      .then((r) => r.text())
      .then((txt) => {
        navigator.clipboard.writeText(txt);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      })
      .catch(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      });
  };

  const runAllTestsFrontend = async () => {
    setTestRunning(true);
    setTestOutput('Simulating 5-suite verification overview...\n');
    try {
      await new Promise((r) => setTimeout(r, 400));
      setTestOutput((prev) => prev + 'Suite 1: Menu Integration, UI Mechanics, TTS Voices, Timestamp Jump & Personas\n');
      await new Promise((r) => setTimeout(r, 400));
      setTestOutput((prev) => prev + 'Suite 2: Caching & Cross-Tab Synchronization\n');
      await new Promise((r) => setTimeout(r, 400));
      setTestOutput((prev) => prev + 'Suite 3: Gemini API Pipeline, Options, & Transcripts\n');
      await new Promise((r) => setTimeout(r, 400));
      setTestOutput((prev) => prev + 'Suite 4: YouTube Ask Provider & Image Pipeline\n');
      await new Promise((r) => setTimeout(r, 400));
      setTestOutput((prev) => prev + 'Suite 5 + Node Unit Tests: React Simulator Parity, Zero-Drift Userscript Check & Mobile 375px\n\n');
      setTestOutput((prev) => prev + 'Run `npm run test:all` in terminal for live Playwright Chromium + Node assertions.');
    } finally {
      setTestRunning(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white overflow-x-clip">
      <div
        data-ytais-live-region="true"
        data-announcement-seq={liveAnnouncementSeq}
        aria-live="polite"
        aria-atomic="true"
        className="sr-only yt-live-region"
      >
        {liveAnnouncement}
      </div>

      {/* Top Navbar */}
      <header className="border-b border-zinc-800 bg-[#121212] sticky top-0 z-50 px-3 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-sky-600 flex items-center justify-center text-white flex-shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h1 className="font-semibold text-base tracking-tight text-white whitespace-nowrap">
              YouTube Feed Summariser
            </h1>
            <p className="text-xs text-zinc-400 truncate max-w-full">
              Userscript v2.11.0 &middot; Dockable Summaries, Channel Rules, Personas &amp; Timestamp Seek
            </p>
          </div>
        </div>

        <nav className="flex flex-wrap items-center gap-1.5 bg-zinc-900/90 p-1 rounded-xl border border-zinc-800 max-w-full">
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'simulator'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Play className="w-3.5 h-3.5 text-sky-400" />
            Live Simulator
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'code'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-indigo-400" />
            Userscript Code
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('tests')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'tests'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            Test Suite
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('docs')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'docs'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Info className="w-3.5 h-3.5 text-amber-400" />
            Docs &amp; Architecture
          </button>
          <button
            type="button"
            onClick={() => setHistoryOpen(true)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 text-purple-300 hover:text-white hover:bg-purple-950/40 border border-purple-500/30 whitespace-nowrap cursor-pointer"
            title="Browse previous summaries (History)"
          >
            <Clock className="w-3.5 h-3.5 text-purple-400" />
            <span>History</span>
            <span className="text-purple-300 text-[11px] font-mono tabular-nums">({closedSummaries.length})</span>
          </button>
        </nav>

        <button
          type="button"
          onClick={copyUserscriptCode}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-sky-500 hover:bg-sky-400 text-zinc-950 transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied to Clipboard!' : 'Copy Userscript'}
        </button>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 relative overflow-y-auto overflow-x-clip">
        {activeTab === 'simulator' && (
          <div className="p-3 sm:p-8 max-w-7xl mx-auto space-y-6">
            <FeedSimulatorGrid
              videos={MOCK_VIDEOS}
              altTitlesEnabled={altTitlesEnabled}
              onSetAltTitlesEnabled={handleSetAltTitlesEnabled}
              dearrowSimulated={dearrowSimulated}
              onSetDearrowSimulated={setDearrowSimulated}
              simulatedYouTubeTheme={simulatedYouTubeTheme}
              onSetSimulatedYouTubeTheme={setSimulatedYouTubeTheme}
              historyTabVisibility={historyTabVisibility}
              onSetHistoryTabVisibility={setHistoryTabVisibility}
              summaryPersona={summaryPersona}
              onSetSummaryPersona={handleSetDefaultSummaryPersona}
              channelTitleRules={channelTitleRules}
              onSetChannelTitleRule={handleSetChannelTitleRule}
              ruleMenuOpenId={ruleMenuOpenId}
              setRuleMenuOpenId={setRuleMenuOpenId}
              dearrowToggledOriginal={dearrowToggledOriginal}
              setDearrowToggledOriginal={setDearrowToggledOriginal}
              cardTitleModes={cardTitleModes}
              onToggleCardTitle={toggleCardTitle}
              activeMenuId={activeMenuId}
              setActiveMenuId={setActiveMenuId}
              onOpenVideoWindow={openVideoWindow}
            />

            {Object.entries(openWindows).map(([videoId, winState], winIdx) => {
              if (winState.minimized) return null;
              const video = MOCK_VIDEOS.find((v) => v.id === videoId);
              if (!video) return null;

              const vw = viewportSize.width;
              const vh = viewportSize.height;
              const rawBounds = windowBounds[videoId] || computeDefaultWindowBounds({ width: vw, height: vh }, winIdx);
              const bounds = clampWindowBounds(rawBounds, { width: vw, height: vh });
              const liveSize = windowSizeMap[videoId];
              const effectiveWidth = liveSize?.width ? Math.min(liveSize.width, bounds.width) : bounds.width;
              const effectiveHeight = liveSize?.height ? Math.min(liveSize.height, bounds.height) : bounds.height;
              const adaptive = getAdaptiveWindowFlags(effectiveWidth, effectiveHeight);
              const showOptionsRow = !adaptive.collapseOptionsRow || Boolean(compactOptionsExpanded[videoId]);
              const zIndex = windowZIndices[videoId] || 60;
              const isFocused = focusedVideoId === videoId;
              const persona = windowPersonas[videoId] || summaryPersona;

              const startDrag = (e: React.MouseEvent) => {
                if (e.button !== 0) return;
                const target = e.target as HTMLElement;
                if (target.closest('button, a, input, select')) return;
                e.preventDefault();
                focusWindow(videoId);
                dragResizeRef.current = {
                  type: 'drag',
                  videoId,
                  startX: e.clientX,
                  startY: e.clientY,
                  startBounds: bounds
                };
              };

              const startResize = (dir: ResizeDirection) => (e: React.MouseEvent) => {
                if (e.button !== 0) return;
                e.preventDefault();
                e.stopPropagation();
                focusWindow(videoId);
                dragResizeRef.current = {
                  type: 'resize',
                  videoId,
                  dir,
                  startX: e.clientX,
                  startY: e.clientY,
                  startBounds: bounds
                };
              };

              const handleResizeKeyDown = (dir: ResizeDirection) => (e: React.KeyboardEvent) => {
                const adj = applyKeyboardWindowAdjustment(bounds, 'resize', dir, e.key, e.shiftKey, {
                  width: vw,
                  height: vh
                });
                if (!adj.handled) return;
                e.preventDefault();
                e.stopPropagation();
                focusWindow(videoId);
                setWindowBounds((prev) => ({ ...prev, [videoId]: adj.bounds }));
                setWindowSizeMap((prev) => ({
                  ...prev,
                  [videoId]: { width: adj.bounds.width, height: adj.bounds.height }
                }));
              };

              const handleGripKeyDown = (e: React.KeyboardEvent) => {
                const adj = applyKeyboardWindowAdjustment(bounds, 'move', null, e.key, e.shiftKey, {
                  width: vw,
                  height: vh
                });
                if (!adj.handled) return;
                e.preventDefault();
                e.stopPropagation();
                focusWindow(videoId);
                setWindowBounds((prev) => ({ ...prev, [videoId]: adj.bounds }));
              };

              return (
                <FloatingSummaryWindow
                  key={videoId}
                  video={video}
                  winState={winState}
                  bounds={bounds}
                  zIndex={zIndex}
                  isFocused={isFocused}
                  adaptive={adaptive}
                  showOptionsRow={showOptionsRow}
                  compactOptionsExpanded={Boolean(compactOptionsExpanded[videoId])}
                  setContainerRef={(el) => {
                    windowContainerRefs.current[videoId] = el;
                  }}
                  onFocus={() => focusWindow(videoId)}
                  onStartDrag={startDrag}
                  onStartResize={startResize}
                  onResizeKeyDown={handleResizeKeyDown}
                  onGripKeyDown={handleGripKeyDown}
                  toast={ttsToasts[videoId]}
                  readabilityMode={Boolean(readabilityMode[videoId])}
                  readabilityTheme={readabilityTheme[videoId] || 'system'}
                  readabilityFont={readabilityFont[videoId] || 'serif'}
                  readabilitySize={readabilitySize[videoId] || 17}
                  syncYouTubeTheme={syncYouTubeTheme[videoId] !== false}
                  simulatedYouTubeTheme={simulatedYouTubeTheme}
                  onToggleReadabilityMode={() =>
                    setReadabilityMode((prev) => ({ ...prev, [videoId]: !prev[videoId] }))
                  }
                  onExitReadability={() => setReadabilityMode((prev) => ({ ...prev, [videoId]: false }))}
                  onToggleSyncYouTubeTheme={() => {
                    const isCurrentlySync = syncYouTubeTheme[videoId] !== false;
                    const nextSync = !isCurrentlySync;
                    setSyncYouTubeTheme((prev) => ({ ...prev, [videoId]: nextSync }));
                    if (nextSync) {
                      setReadabilityTheme((prev) => ({ ...prev, [videoId]: simulatedYouTubeTheme }));
                    }
                  }}
                  onSelectReadabilityTheme={(t) => {
                    setSyncYouTubeTheme((prev) => ({ ...prev, [videoId]: false }));
                    setReadabilityTheme((prev) => ({ ...prev, [videoId]: t }));
                  }}
                  onToggleReadabilityFont={() =>
                    setReadabilityFont((prev) => ({
                      ...prev,
                      [videoId]: (prev[videoId] || 'serif') === 'serif' ? 'sans' : 'serif'
                    }))
                  }
                  onChangeReadabilitySize={(delta) =>
                    setReadabilitySize((prev) => ({
                      ...prev,
                      [videoId]: Math.max(13, Math.min(26, (prev[videoId] || 17) + delta))
                    }))
                  }
                  exportMenuOpen={Boolean(exportMenuOpen[videoId])}
                  onToggleExportMenu={() =>
                    setExportMenuOpen((prev) => ({ ...prev, [videoId]: !prev[videoId] }))
                  }
                  headerOverflowOpen={Boolean(headerOverflowOpen[videoId])}
                  onToggleHeaderOverflow={(e) => {
                    e.stopPropagation();
                    setHeaderOverflowOpen((prev) => ({ ...prev, [videoId]: !prev[videoId] }));
                  }}
                  onCloseHeaderOverflow={() => setHeaderOverflowOpen((prev) => ({ ...prev, [videoId]: false }))}
                  copiedVideoUrl={copiedVideoId === videoId}
                  onCopyVideoUrl={() => copyVideoUrl(videoId)}
                  onOpenHistory={() => setHistoryOpen(true)}
                  onMinimize={() => minimizeWindow(videoId)}
                  onClose={() => closeWindow(videoId)}
                  onExportTxt={() => {
                    setExportMenuOpen((prev) => ({ ...prev, [videoId]: false }));
                    handleExportTxt(video, winState.mode);
                  }}
                  onExportPdf={() => {
                    setExportMenuOpen((prev) => ({ ...prev, [videoId]: false }));
                    handleExportPdf(video, winState.mode);
                  }}
                  onExportJson={() => {
                    setExportMenuOpen((prev) => ({ ...prev, [videoId]: false }));
                    handleExportJson(video, winState.mode);
                  }}
                  onChangeWinMode={(m) =>
                    setOpenWindows((prev) => ({ ...prev, [videoId]: { ...prev[videoId], mode: m } }))
                  }
                  onChangeWinSource={(s) =>
                    setOpenWindows((prev) => ({ ...prev, [videoId]: { ...prev[videoId], source: s } }))
                  }
                  selectedModel={windowModels[videoId] || 'gemini-3.8-flash'}
                  onSelectModel={(val) => {
                    setWindowModels((prev) => ({ ...prev, [videoId]: val }));
                    setWindowFallbackNote((prev) => ({ ...prev, [videoId]: null }));
                  }}
                  simAskFailure={Boolean(simAskFailure[videoId])}
                  onToggleSimAskFailure={(checked) =>
                    setSimAskFailure((prev) => ({ ...prev, [videoId]: checked }))
                  }
                  fallbackNote={windowFallbackNote[videoId] || null}
                  onRegenerate={() => {
                    const selectedModel = windowModels[videoId] || 'gemini-3.8-flash';
                    if (selectedModel === 'Ask' && simAskFailure[videoId]) {
                      const decision = resolveAskFallbackPlan({
                        currentModel: 'YouTube Ask (Gemini in the page)',
                        fallbackLadder: [
                          'gemini-3.1-pro-preview',
                          'gemini-3.8-flash',
                          'gemini-3.7-flash',
                          'gemini-3.5-flash'
                        ],
                        availableModels: [
                          'gemini-3.1-pro-preview',
                          'gemini-3.8-flash',
                          'gemini-3.7-flash',
                          'gemini-3.5-flash'
                        ],
                        hasApiKey: true,
                        errorMessage: "YouTube's Ask button didn't appear on this video"
                      });
                      if (decision.shouldFallback && decision.nextModel) {
                        setWindowModels((prev) => ({ ...prev, [videoId]: decision.nextModel! }));
                        setWindowFallbackNote((prev) => ({ ...prev, [videoId]: decision.note || null }));
                        showTtsToast(`Ask failed — switched to ${decision.nextModel}`, videoId);
                        announceLive(`YouTube Ask failed, switched to ${decision.nextModel}`);
                        return;
                      }
                    }
                    setWindowFallbackNote((prev) => ({ ...prev, [videoId]: null }));
                    showTtsToast(`Regenerated with ${selectedModel} (${persona})`, videoId);
                  }}
                  onToggleCompactOptions={() =>
                    setCompactOptionsExpanded((prev) => ({ ...prev, [videoId]: !prev[videoId] }))
                  }
                  transcriptMode={transcriptModes[videoId] || 'fast'}
                  onSetTranscriptMode={(m) => setTranscriptModes((prev) => ({ ...prev, [videoId]: m }))}
                  persona={persona}
                  onSelectPersona={(p) => handleSelectWindowPersona(videoId, p)}
                  altTitlesEnabled={altTitlesEnabled}
                  onSetAltTitlesEnabled={handleSetAltTitlesEnabled}
                  tts={ttsState[videoId] || { status: 'idle', rate: 1.0 }}
                  currentVol={ttsVolume[videoId] ?? 1.0}
                  currentPitch={ttsPitch[videoId] ?? 1.0}
                  skipSilence={skipSilence[videoId] !== false}
                  selectedVoice={selectedVoice[videoId] || 'ai:Kore'}
                  browserVoices={browserVoices}
                  activeTtsLine={activeTtsLine[videoId] ?? null}
                  activeTtsTs={activeTtsTs[videoId] ?? null}
                  onSelectVoice={(v) => setSelectedVoice((prev) => ({ ...prev, [videoId]: v }))}
                  onToggleTts={(txt) => toggleTts(videoId, txt)}
                  onRewindTts={(txt) => rewindTts(videoId, txt)}
                  onSkipTts={(txt) => skipTts(videoId, txt)}
                  onStopTts={() => stopTts(videoId)}
                  onSetTtsRate={(r) => setTtsRate(videoId, r)}
                  onCycleTtsRate={(txt) => cycleTtsRate(videoId, txt)}
                  onSetTtsVolume={(val) => {
                    setTtsVolume((prev) => ({ ...prev, [videoId]: val }));
                    if (activeUtteranceRef.current) activeUtteranceRef.current.volume = val;
                  }}
                  onSetTtsPitch={(val) => {
                    const clamped = Math.max(0.5, Math.min(2.0, val));
                    setTtsPitch((prev) => ({ ...prev, [videoId]: clamped }));
                    try {
                      localStorage.setItem('lastTtsPitch', String(clamped));
                    } catch {}
                    if (activeUtteranceRef.current) activeUtteranceRef.current.pitch = clamped;
                  }}
                  onToggleSkipSilence={(txt) => {
                    const next = !(skipSilence[videoId] !== false);
                    setSkipSilence((prev) => ({ ...prev, [videoId]: next }));
                    showTtsToast(next ? 'Skip Silence: ON' : 'Skip Silence: OFF', videoId);
                    if ((ttsState[videoId]?.status || 'idle') === 'playing') {
                      stopTts(videoId);
                      setTimeout(() => toggleTts(videoId, txt), 100);
                    }
                  }}
                  activeSeek={activeSeek[videoId] || null}
                  followAlong={followAlong}
                  onToggleFollowAlong={handleToggleFollowAlong}
                  onSeekTimestamp={(tsStr, sec) => handleSeekTimestamp(videoId, tsStr, sec)}
                  transcriptSearchQuery={transcriptSearch[videoId] || ''}
                  onChangeTranscriptSearch={(q) => setTranscriptSearch((prev) => ({ ...prev, [videoId]: q }))}
                  transcriptFilterOnly={Boolean(transcriptFilterOnly[videoId])}
                  onChangeTranscriptFilterOnly={(checked) =>
                    setTranscriptFilterOnly((prev) => ({ ...prev, [videoId]: checked }))
                  }
                  activeMatchIndex={activeMatchIndex[videoId] ?? 0}
                  onSetActiveMatchIndex={(idx) => setActiveMatchIndex((prev) => ({ ...prev, [videoId]: idx }))}
                  closedSummariesCount={closedSummaries.length}
                  responseRatings={responseRatings}
                  openRatingNoteKey={openRatingNoteKey}
                  setOpenRatingNoteKey={setOpenRatingNoteKey}
                  onRateResponse={handleRateResponse}
                  onShowToast={showTtsToast}
                  turns={conversationTurns[videoId] || []}
                  isAnsweringFollowUp={Boolean(isAnsweringFollowUp[videoId])}
                  composerText={composerText[videoId] || ''}
                  onChangeComposerText={(text) => {
                    setComposerText((prev) => ({ ...prev, [videoId]: text }));
                    try {
                      if (text.trim()) {
                        localStorage.setItem('yt_summariser_draft_' + videoId, text);
                      } else {
                        localStorage.removeItem('yt_summariser_draft_' + videoId);
                      }
                    } catch {}
                  }}
                  composerModel={composerModel[videoId] || 'gemini-3.8-flash'}
                  onSelectComposerModel={(mId) => setComposerModel((prev) => ({ ...prev, [videoId]: mId }))}
                  composerGSearch={composerGSearch[videoId] !== false}
                  onToggleComposerGSearch={() =>
                    setComposerGSearch((prev) => ({ ...prev, [videoId]: prev[videoId] === false }))
                  }
                  composerGMaps={composerGMaps[videoId] === true}
                  onToggleComposerGMaps={() =>
                    setComposerGMaps((prev) => ({ ...prev, [videoId]: !prev[videoId] }))
                  }
                  isRecordingVoice={Boolean(isRecordingVoice[videoId])}
                  onToggleVoiceInput={() => handleToggleVoiceInput(videoId)}
                  onSendFollowUp={() => handleSendFollowUp(videoId)}
                />
              );
            })}

            <HistoryDock
              historyOpen={historyOpen}
              setHistoryOpen={setHistoryOpen}
              historySearch={historySearch}
              setHistorySearch={setHistorySearch}
              closedSummaries={closedSummaries}
              onReopenSummary={reopenSummary}
              onDeleteFromHistory={deleteFromHistory}
              onClearAllHistory={clearAllHistory}
              historyTabVisibility={historyTabVisibility}
              openWindows={openWindows}
              focusedVideoId={focusedVideoId}
              videos={MOCK_VIDEOS}
              onMaximizeWindow={maximizeWindow}
              onCloseWindow={closeWindow}
            />
          </div>
        )}

        {activeTab !== 'simulator' && (
          <SettingsDocsTabs
            activeTab={activeTab}
            copied={copied}
            onCopyUserscript={copyUserscriptCode}
            testRunning={testRunning}
            testOutput={testOutput}
            onRunTestsFrontend={runAllTestsFrontend}
          />
        )}
      </main>
    </div>
  );
}
