import React from 'react';
import { Copy, Check, Play, RefreshCw, ShieldAlert } from 'lucide-react';

interface SettingsDocsTabsProps {
  activeTab: 'code' | 'tests' | 'docs';
  copied: boolean;
  onCopyUserscript: () => void;
  testRunning: boolean;
  testOutput: string | null;
  onRunTestsFrontend: () => void;
}

export const SettingsDocsTabs: React.FC<SettingsDocsTabsProps> = ({
  activeTab,
  copied,
  onCopyUserscript,
  testRunning,
  testOutput,
  onRunTestsFrontend
}) => {
  if (activeTab === 'code') {
    return (
      <div className="p-8 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <div>
            <h2 className="text-base font-semibold text-white">youtube-feed-summariser.user.js (v2.11.0)</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Production Tampermonkey script &middot; Compliant with YouTube Trusted Types and Shadow DOM isolation.
            </p>
          </div>

          <button
            type="button"
            onClick={onCopyUserscript}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-zinc-950 transition-colors shadow-sm cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied Full Script!' : 'Copy to Clipboard'}
          </button>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden font-mono text-xs">
          <div className="bg-zinc-900/80 px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-zinc-400">
            <span className="text-zinc-300 font-sans font-medium">Installation Instructions</span>
            <span className="text-[11px] font-mono">Tampermonkey / Violentmonkey</span>
          </div>
          <div className="p-5 space-y-3 text-zinc-300 font-sans text-xs border-b border-zinc-800 bg-zinc-900/30">
            <p>
              1. Open Tampermonkey dashboard &rarr; click <strong>&ldquo;Create a new script&rdquo;</strong> (or open your existing YouTube Feed Summariser script).
            </p>
            <p>
              2. Select all and <strong>paste this file over the old script</strong> (it preserves stored API keys, options, channel title rules, persona preset, and cached summaries because the <code className="text-sky-400">@namespace</code> and <code className="text-sky-400">@name</code> match exactly).
            </p>
            <p>
              3. Save (<kbd className="px-1.5 py-0.5 bg-zinc-800 border border-zinc-700 rounded text-[11px]">Ctrl+S</kbd> / <kbd className="px-1.5 py-0.5 bg-zinc-800 border border-zinc-700 rounded text-[11px]">Cmd+S</kbd>) and reload YouTube.
            </p>
          </div>

          <div className="p-4 max-h-[500px] overflow-y-auto text-zinc-400 leading-relaxed">
            <pre className="text-[11px] text-zinc-300">
{`// ==UserScript==
// @name         YouTube Feed Summariser (Gemini)
// @namespace    local.yt-feed-summariser
// @version      2.11.0
// @description  Adds dockable Gemini video summaries, transcripts, alternative descriptive thumbnail titles, per-channel rules, personas, and TTS shortcuts.
// @match        https://www.youtube.com/*
// @noframes
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_addValueChangeListener
// @grant        GM_registerMenuCommand
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @connect      generativelanguage.googleapis.com
// @connect      commons.wikimedia.org
// ==/UserScript==

// [Delivered in full at /youtube-feed-summariser.user.js in workspace]`}
            </pre>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'tests') {
    return (
      <div className="p-8 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <div>
            <h2 className="text-base font-semibold text-white">Acceptance Test Suite Overview</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              5-suite Playwright Chromium + Node unit/parity harness testing Userscript DOM, Gemini pipeline, Ask provider, and React Simulator.
            </p>
          </div>

          <button
            type="button"
            onClick={onRunTestsFrontend}
            disabled={testRunning}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 transition-colors shadow-sm disabled:opacity-50 cursor-pointer"
          >
            {testRunning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
            {testRunning ? 'Running Simulation...' : 'Simulate Suite Run'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-200">Suite 1: Menu, UI, TTS, Timestamp &amp; Persona Controls</span>
              <span className="text-emerald-400 font-mono text-[11px]">Playwright E2E</span>
            </div>
            <p className="text-xs text-zinc-400">
              Covers menu injection, 8-handle resize &amp; keyboard movement, TTS voice/pitch/speed sliders, interactive [MM:SS] player seek &amp; Follow-Along lock, per-channel title rules, and Summary Persona prompt/cache scoping.
            </p>
          </div>

          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-200">Suite 2: Cache &amp; Cross-Tab Sync</span>
              <span className="text-emerald-400 font-mono text-[11px]">Playwright E2E</span>
            </div>
            <p className="text-xs text-zinc-400">
              Covers zero-API-request cache reopen, conversation turns persistence, cross-tab GM value listeners, persona cache key isolation, and unread notification pulse.
            </p>
          </div>

          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-200">Suite 3 &amp; 4: Gemini Pipeline, Ask &amp; Visuals</span>
              <span className="text-emerald-400 font-mono text-[11px]">Playwright E2E</span>
            </div>
            <p className="text-xs text-zinc-400">
              Covers model fallback ladder, YouTube Ask zero-quota bypass &amp; iframe variants, FRAME storyboard sprites, Wikimedia search, and Nano Banana diagrams.
            </p>
          </div>

          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-200">Suite 5 &amp; Node: Simulator Parity &amp; Zero-Drift Helper Check</span>
              <span className="text-emerald-400 font-mono text-[11px]">Automated Parity</span>
            </div>
            <p className="text-xs text-zinc-400">
              Verifies React Simulator parity, 375px mobile zero-overflow layout, ARIA live announcements, and exact output parity between userscript helpers and <code className="text-sky-400">userscript-helpers.ts</code>.
            </p>
          </div>
        </div>

        {testOutput && (
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 font-mono text-xs text-emerald-400 whitespace-pre-wrap leading-relaxed shadow-inner">
            {testOutput}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-6">
      <div className="bg-amber-950/20 border border-amber-900/40 rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
          <ShieldAlert className="w-5 h-5" />
          Architecture Notes &amp; Platform Safeguards
        </div>
        <ul className="text-xs text-zinc-300 space-y-2 list-disc pl-5 leading-relaxed">
          <li>
            <strong>Interactive Timestamp Jump-Sync &amp; Follow-Along Lock:</strong> Clicking any <code className="text-amber-300">[MM:SS]</code> marker jumps the watch video / player seek badge and highlights the nearest transcript cue via <code className="text-amber-300">findTranscriptCueIndexForSeconds</code>, while <code className="text-amber-300">yt-follow-along-btn</code> lets users pause or resume automatic scrolling.
          </li>
          <li>
            <strong>Per-Channel Auto-Title Rules:</strong> Channel-level <code className="text-amber-300">Default</code>, <code className="text-amber-300">Exempt</code>, and <code className="text-amber-300">Always AI</code> preferences persist across cards and tabs while respecting the global auto-title toggle and DeArrow priority rules.
          </li>
          <li>
            <strong>Summary Persona &amp; Output Presets:</strong> Supports <code className="text-amber-300">Executive Brief</code>, <code className="text-amber-300">Deep Technical / Code</code>, <code className="text-amber-300">Study Quiz &amp; Flashcards</code>, and <code className="text-amber-300">Chronological Timeline</code>, dynamically shaping Gemini instructions, non-executive cache keys, and JSON exports.
          </li>
          <li>
            <strong>Zero-Drift Shared Core &amp; Modular UI:</strong> React simulator UI is decomposed under <code className="text-amber-300">src/components/</code> and continuously validated for parity against <code className="text-amber-300">youtube-feed-summariser.user.js</code> with zero Trusted Types DOM sinks or blocking dialogs.
          </li>
        </ul>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-4">
        <h3 className="font-semibold text-sm text-zinc-100">Files Built &amp; Verified in Repository</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <span className="text-sky-400 font-semibold">youtube-feed-summariser.user.js</span>
            <p className="text-[11px] text-zinc-400 font-sans mt-1">v2.11.0 complete Trusted-Types-clean userscript</p>
          </div>
          <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <span className="text-indigo-400 font-semibold">src/components/*</span>
            <p className="text-[11px] text-zinc-400 font-sans mt-1">Modular React Simulator components &amp; hooks</p>
          </div>
          <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <span className="text-emerald-400 font-semibold">src/utils/userscript-helpers.ts</span>
            <p className="text-[11px] text-zinc-400 font-sans mt-1">Shared pure helpers tested against userscript exports</p>
          </div>
          <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800">
            <span className="text-amber-400 font-semibold">run_all_tests.js &amp; test_simulator_ui.js</span>
            <p className="text-[11px] text-zinc-400 font-sans mt-1">5-suite Playwright E2E + React Simulator verification</p>
          </div>
        </div>
      </div>
    </div>
  );
};
