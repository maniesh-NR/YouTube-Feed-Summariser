// ==UserScript==
// @name         YouTube Feed Summariser (Gemini)
// @namespace    local.yt-feed-summariser
// @version      2.11.0
// @description  Adds dockable Gemini video summaries, transcripts, alternative descriptive thumbnail titles, and global TTS keyboard shortcuts to YouTube feeds without opening videos.
// @match        https://www.youtube.com/*
// @noframes
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_addValueChangeListener
// @grant        GM_registerMenuCommand
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @connect      generativelanguage.googleapis.com
// @connect      commons.wikimedia.org
// ==/UserScript==

'use strict';

(function () {
  // --- CONFIGURATION ---
  const CONFIG = {
    version: '2.11.0',
    textModels: [
      'gemini-4-argon',
      'gemini-3.8-flash',
      'gemini-3.7-flash',
      'gemini-3.6-flash',
      'gemini-3.5-flash',
      'gemini-3-flash-preview',
      'gemini-3.5-flash-lite',
      'gemini-3.1-flash-lite',
      'gemini-3.1-pro-preview',
      'gemini-flash-latest'
    ],
    transcribeModel: 'gemini-3.5-transcribe', // audio-file model: shown greyed out, cannot take a YouTube URL
    imageModels: [
      'gemini-3-pro-image',
      'gemini-nano-banana-2.1',
      'gemini-3.1-flash-image',
      'gemini-3.1-flash-lite-image'
    ],
    imageModelNames: {
      'gemini-3-pro-image': 'Nano Banana Pro',
      'gemini-nano-banana-2.1': 'Nano Banana 2.1',
      'gemini-3.1-flash-image': 'Nano Banana 2',
      'gemini-3.1-flash-lite-image': 'Nano Banana 2 Lite'
    },
    defaultModel: 'gemini-3.8-flash',
    outputLanguage: 'English',
    menuLabel: 'Summarize',
    menuFontSize: '16px',
    menuMinHeight: 44,
    savePattern: /save to playlist/i,
    downloadPattern: /^download$/i,
    watchLaterPattern: /watch later/i,
    lowMediaResolution: true,
    thinkingLevel: null,
    maxVisuals: 6,
    maxGenImages: 3,
    historyTurns: 6,
    cacheMax: 100,
    requestTimeoutMs: 300000,
    heartbeatMs: 5000,
    staleMs: 20000,
    modelCheckTtlMs: 300000,
    maxTranscriptChars: 1500000,
    fallbackLadder: [
      'gemini-3.1-pro-preview',
      'gemini-3.8-flash',
      'gemini-3.7-flash',
      'gemini-3.6-flash',
      'gemini-3.5-flash',
      'gemini-3-flash-preview',
      'gemini-3.5-flash-lite',
      'gemini-3.1-flash-lite',
      'gemini-flash-latest'
    ],
    factPreferred: [
      'gemini-3.8-flash',
      'gemini-3.7-flash',
      'gemini-3.5-flash',
      'gemini-3.5-flash-lite',
      'gemini-3.1-flash-lite',
      'gemini-flash-latest'
    ],
    ttsModel: 'gemini-3.8-flash-lite-tts',
    aiVoices: [
      { id: 'ai:Kore', name: 'Gemini Kore (Natural Female) ★', voiceName: 'Kore' },
      { id: 'ai:Puck', name: 'Gemini Puck (Natural Male)', voiceName: 'Puck' },
      { id: 'ai:Zephyr', name: 'Gemini Zephyr (Warm Female)', voiceName: 'Zephyr' },
      { id: 'ai:Fenrir', name: 'Gemini Fenrir (Deep Male)', voiceName: 'Fenrir' },
      { id: 'ai:Charon', name: 'Gemini Charon (Calm Male)', voiceName: 'Charon' }
    ],
    defaultTtsVoice: 'ai:Kore',
    defaultTtsPitch: 1.0,
    ttsRates: [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0],
    defaultReadabilityTheme: 'system',
    altTitlesEnabled: true,
    altTitleMaxChars: 150,
    transcriptMode: 'fast',
    defaultSkipSilence: true,
    askConcurrency: 2,
    askLoadMs: 30000,
    askStableMs: 3000,
    askAnswerMs: 120000,
    debug: true
  };

  const DEFAULT_OPTS = {
    fc: true,
    img: true,
    src: true,
    gen: false,
    altTitles: true,
    transcriptMode: 'fast',
    skipSilence: true,
    think: '',
    mres: '',
    gsearch: false,
    gmaps: false,
    code: false,
    imgModel: '',
    imgThink: '',
    imgAspect: '',
    imgSize: '',
    imgOut: 'both',
    imgSearch: false,
    factModel: '',
    retries: 2,
    fallback: false,
    txFallback: false,
    ttsVoice: 'ai:Kore'
  };

  const TAB_ID = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

  // --- BOUNDED LRU MEMORY CACHE ---
  function createBoundedMap(maxCapacity = 100) {
    const map = new Map();
    const cap = Math.max(1, maxCapacity);
    return {
      get(key) {
        if (!map.has(key)) return undefined;
        const val = map.get(key);
        map.delete(key);
        map.set(key, val);
        return val;
      },
      set(key, val) {
        if (map.has(key)) {
          map.delete(key);
        } else if (map.size >= cap) {
          const oldestKey = map.keys().next().value;
          if (oldestKey !== undefined) map.delete(oldestKey);
        }
        map.set(key, val);
        return this;
      },
      has(key) {
        return map.has(key);
      },
      delete(key) {
        return map.delete(key);
      },
      clear() {
        map.clear();
      },
      get size() {
        return map.size;
      },
      keys() {
        return map.keys();
      },
      values() {
        return map.values();
      },
      entries() {
        return map.entries();
      },
      forEach(fn, thisArg) {
        map.forEach(fn, thisArg);
      },
      [Symbol.iterator]() {
        return map[Symbol.iterator]();
      }
    };
  }

  // In-memory runtime caches (strictly bounded to prevent memory growth across long sessions)
  const storyboardCache = createBoundedMap(50); // videoId -> storyboard config
  const transcriptCache = createBoundedMap(50); // videoId -> text
  const altTitlesMemoryCache = createBoundedMap(100); // videoId -> alternative title string
  const processedFeedCards = new WeakSet();

  // --- TRUSTED-TYPES COMPLIANT DOM HELPER ---
  function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v === undefined || v === null) continue;
        if (k.startsWith('on') && typeof v === 'function') {
          el.addEventListener(k.slice(2).toLowerCase(), v);
        } else if (k === 'style') {
          if (typeof v === 'object') {
            Object.assign(el.style, v);
          } else {
            el.style.cssText = String(v);
          }
        } else if (k === 'className') {
          el.className = v;
        } else if (k === 'checked' || k === 'disabled' || k === 'selected') {
          el[k] = Boolean(v);
        } else if (k === 'value') {
          el.value = v;
        } else {
          el.setAttribute(k, v);
        }
      }
    }
    for (const child of children) {
      if (child === null || child === undefined || child === false) continue;
      if (Array.isArray(child)) {
        for (const sub of child) {
          if (sub instanceof Node) el.appendChild(sub);
          else if (sub !== null && sub !== undefined) el.appendChild(document.createTextNode(String(sub)));
        }
      } else if (child instanceof Node) {
        el.appendChild(child);
      } else {
        el.appendChild(document.createTextNode(String(child)));
      }
    }
    return el;
  }

  function hSvg(tag, attrs, ...children) {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v === undefined || v === null) continue;
        el.setAttribute(k, v);
      }
    }
    for (const child of children) {
      if (child instanceof Node) el.appendChild(child);
    }
    return el;
  }

  function clearEl(el) {
    while (el.firstChild) {
      el.removeChild(el.firstChild);
    }
  }

  // Common SVG Icons
  function iconSparkle(size = 20, fill = 'currentColor') {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: fill },
      hSvg('path', {
        d: 'M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z'
      })
    );
  }

  function iconBolt(size = 14, fill = 'currentColor') {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: fill },
      hSvg('path', { d: 'M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66.19-.34.05-.08.07-.12C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.49 0 .56.33.47.51l-.07.15C12.9 17.06 11 21 11 21z' })
    );
  }

  function iconMusic(size = 14, fill = 'currentColor') {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: fill },
      hSvg('path', { d: 'M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z' })
    );
  }

  function iconDocument(size = 14, fill = 'currentColor') {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: fill },
      hSvg('path', { d: 'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z' })
    );
  }

  function iconSkipSilence(size = 14, fill = 'currentColor') {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: fill },
      hSvg('path', {
        d: 'M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6zM21 6h2v12h-2z'
      })
    );
  }

  function iconClose(size = 18) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z' })
    );
  }

  function iconMinimize(size = 18) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M19 13H5v-2h14v2z' })
    );
  }

  function iconMaximize(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M3 3h8v2H5v6H3V3zm18 0h-8v2h6v6h2V3zM3 21h8v-2H5v-6H3v8zm18 0h-8v-2h6v-6h2v8z' })
    );
  }

  function iconCheck(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z' })
    );
  }

  function iconAlert(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z' })
    );
  }

  function iconGear(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z'
      })
    );
  }

  function iconRefresh(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z'
      })
    );
  }

  function iconSync(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z'
      })
    );
  }

  function iconSpeaker(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z'
      })
    );
  }

  function iconMic(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z'
      }),
      hSvg('path', {
        d: 'M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z'
      })
    );
  }

  function iconPause(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z' })
    );
  }

  function iconPlay(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M8 5v14l11-7z' })
    );
  }

  function iconStop(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M6 6h12v12H6z' })
    );
  }

  function iconRewind(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z' })
    );
  }

  function iconSkip(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', { d: 'M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z' })
    );
  }

  function iconCopy(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z'
      })
    );
  }

  function iconExternal(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z'
      })
    );
  }

  function iconSearch(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z'
      })
    );
  }

  function iconHistory(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z'
      })
    );
  }

  function iconBook(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4zm12 16H6V16h12v4zm0-6h-5V4h5v10z'
      })
    );
  }

  function iconExport(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z'
      })
    );
  }

  function iconFileText(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z'
      })
    );
  }

  function iconPdf(size = 16) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v1.5h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zm4.5 1.5h1v-3h-1v3zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6z'
      })
    );
  }

  function iconThumbsUp(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z'
      })
    );
  }

  function iconThumbsDown(size = 14) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z'
      })
    );
  }

  function iconMoreVert(size = 18) {
    return hSvg(
      'svg',
      { viewBox: '0 0 24 24', width: size, height: size, fill: 'currentColor' },
      hSvg('path', {
        d: 'M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z'
      })
    );
  }

  const SUPERSCRIPT_CHAR_MAP = {
    '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
    '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
    '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
    n: 'ⁿ', i: 'ⁱ'
  };

  const SUBSCRIPT_CHAR_MAP = {
    '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
    '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
    '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎',
    a: 'ₐ', e: 'ₑ', o: 'ₒ', x: 'ₓ', h: 'ₕ',
    k: 'ₖ', l: 'ₗ', m: 'ₘ', n: 'ₙ', p: 'ₚ',
    s: 'ₛ', t: 'ₜ'
  };

  const LATEX_COMMAND_REPLACEMENTS = [
    [/\\(?:text|mathrm|textbf|textit|mathbf|mathit|mathsf|mathtt|ce|units|operatorname)\{([^{}]*)\}/g, '$1'],
    [/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, '$1/$2'],
    [/\\sqrt\{([^{}]+)\}/g, '√$1'],
    [/\\(?:approx|asymp)\b/g, '≈'],
    [/\\simeq\b/g, '≃'],
    [/\\cong\b/g, '≅'],
    [/\\equiv\b/g, '≡'],
    [/\\sim\b/g, '~'],
    [/\\pm\b/g, '±'],
    [/\\mp\b/g, '∓'],
    [/\\times\b/g, '×'],
    [/\\cdot\b/g, '·'],
    [/\\div\b/g, '÷'],
    [/\\(?:leq|le)\b/g, '≤'],
    [/\\(?:geq|ge)\b/g, '≥'],
    [/\\(?:neq|ne)\b/g, '≠'],
    [/\\ll\b/g, '≪'],
    [/\\gg\b/g, '≫'],
    [/\\(?:rightarrow|to)\b/g, '→'],
    [/\\(?:leftarrow|gets)\b/g, '←'],
    [/\\leftrightarrow\b/g, '↔'],
    [/\\(?:Rightarrow|implies)\b/g, '⇒'],
    [/\\(?:Leftrightarrow|iff)\b/g, '⇔'],
    [/\\infty\b/g, '∞'],
    [/\\partial\b/g, '∂'],
    [/\\nabla\b/g, '∇'],
    [/\\sum\b/g, '∑'],
    [/\\prod\b/g, '∏'],
    [/\\int\b/g, '∫'],
    [/\\propto\b/g, '∝'],
    [/\\in\b/g, '∈'],
    [/\\notin\b/g, '∉'],
    [/\\subseteq\b/g, '⊆'],
    [/\\subset\b/g, '⊂'],
    [/\\cup\b/g, '∪'],
    [/\\cap\b/g, '∩'],
    [/\\emptyset\b/g, '∅'],
    [/\\forall\b/g, '∀'],
    [/\\exists\b/g, '∃'],
    [/\\therefore\b/g, '∴'],
    [/\\because\b/g, '∵'],
    [/\\angle\b/g, '∠'],
    [/\\triangle\b/g, '△'],
    [/\\(?:degree|deg|circ)\b/g, '°'],
    [/\\alpha\b/g, 'α'],
    [/\\beta\b/g, 'β'],
    [/\\gamma\b/g, 'γ'],
    [/\\delta\b/g, 'δ'],
    [/\\(?:varepsilon|epsilon)\b/g, 'ε'],
    [/\\zeta\b/g, 'ζ'],
    [/\\eta\b/g, 'η'],
    [/\\(?:vartheta|theta)\b/g, 'θ'],
    [/\\iota\b/g, 'ι'],
    [/\\kappa\b/g, 'κ'],
    [/\\lambda\b/g, 'λ'],
    [/\\(?:mu|micro)\b/g, 'μ'],
    [/\\nu\b/g, 'ν'],
    [/\\xi\b/g, 'ξ'],
    [/\\pi\b/g, 'π'],
    [/\\rho\b/g, 'ρ'],
    [/\\sigma\b/g, 'σ'],
    [/\\tau\b/g, 'τ'],
    [/\\upsilon\b/g, 'υ'],
    [/\\(?:varphi|phi)\b/g, 'φ'],
    [/\\chi\b/g, 'χ'],
    [/\\psi\b/g, 'ψ'],
    [/\\omega\b/g, 'ω'],
    [/\\Gamma\b/g, 'Γ'],
    [/\\Delta\b/g, 'Δ'],
    [/\\Theta\b/g, 'Θ'],
    [/\\Lambda\b/g, 'Λ'],
    [/\\Xi\b/g, 'Ξ'],
    [/\\Pi\b/g, 'Π'],
    [/\\Sigma\b/g, 'Σ'],
    [/\\Phi\b/g, 'Φ'],
    [/\\Psi\b/g, 'Ψ'],
    [/\\Omega\b/g, 'Ω'],
    [/\\hbar\b/g, 'ℏ'],
    [/\\ell\b/g, 'ℓ'],
    [/\\AA\b/g, 'Å'],
    [/\\%/g, '%'],
    [/\\\$/g, '$'],
    [/\\&/g, '&'],
    [/\\(?:left|right)\b/g, ''],
    [/\\[,;:! ]/g, ' ']
  ];

  function mapUnicodeScript(raw, map, fallbackPrefix) {
    const chars = Array.from(raw);
    if (chars.length > 0 && chars.every((ch) => map[ch] !== undefined)) {
      return chars.map((ch) => map[ch]).join('');
    }
    return raw.length > 1 ? `${fallbackPrefix}(${raw})` : `${fallbackPrefix}${raw}`;
  }

  function convertLatexFragment(fragment) {
    let out = fragment.trim();
    out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
    out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
    for (let pass = 0; pass < 3; pass++) {
      const prev = out;
      for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
        out = out.replace(re, rep);
      }
      if (out === prev) break;
    }
    out = out.replace(/\^\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUPERSCRIPT_CHAR_MAP, '^'));
    out = out.replace(/\^([0-9+\-=ni])/g, (_m, ch) => SUPERSCRIPT_CHAR_MAP[ch] || `^${ch}`);
    out = out.replace(/_\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUBSCRIPT_CHAR_MAP, '_'));
    out = out.replace(/_([0-9+\-=aehklmnopstx])/g, (_m, ch) => SUBSCRIPT_CHAR_MAP[ch] || `_${ch}`);
    out = out.replace(/\{([^{}]*)\}/g, '$1');
    out = out.replace(/\s*°\s*/g, '°');
    out = out.replace(/\s{2,}/g, ' ').trim();
    return out;
  }

  function formatMathSymbolsInText(text) {
    if (!text) return '';
    let out = String(text);

    out = out.replace(/\$\$([\s\S]+?)\$\$/g, (_m, inner) => convertLatexFragment(inner));
    out = out.replace(/\\\[([\s\S]+?)\\\]/g, (_m, inner) => convertLatexFragment(inner));
    out = out.replace(/\\\(([^\n]+?)\\\)/g, (_m, inner) => convertLatexFragment(inner));

    out = out.replace(/\$([^$\n]+?)\$/g, (match, inner) => {
      if (!inner || /^\s|\s$/.test(inner)) return match;
      const hasMathSignal =
        /[\\^{}_=<>~±×÷≈≠≤≥°]/.test(inner) ||
        /^[A-Za-z](?:\d+|['’])?$/.test(inner);
      if (!hasMathSignal) return match;
      return convertLatexFragment(inner);
    });

    out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
    out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
    if (/\\(?:text|mathrm|textbf|textit|ce|approx|pm|times|div|leq|geq|neq|degree|circ|alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|omega|Delta|Sigma|Omega)\b/.test(out)) {
      for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
        out = out.replace(re, rep);
      }
      out = out.replace(/\s*°\s*/g, '°');
    }

    return out;
  }

  function stripInlineMarkdown(str) {
    if (!str) return '';
    return formatMathSymbolsInText(str)
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/_([^_]+)_/g, '$1')
      .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
      .trim();
  }

  function parseCleanEditorialBlocks(text) {
    if (!text) return [];
    let clean = text.replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '');
    clean = clean.replace(/^[-*_]{3,}\s*$/gm, '');
    const lines = clean.split('\n');
    const blocks = [];

    for (const rawLine of lines) {
      const trimmed = rawLine.trim();
      if (!trimmed) continue;

      // Heading (## or ###)
      if (trimmed.startsWith('#')) {
        const level = (trimmed.match(/^#+/) || [''])[0].length;
        const title = stripInlineMarkdown(trimmed.slice(level));
        blocks.push({
          type: level <= 2 ? 'heading' : 'subheading',
          text: title
        });
        continue;
      }

      // Bullet point
      const bulletMatch = /^[-*•]\s+(.+)$/.exec(trimmed);
      if (bulletMatch) {
        blocks.push({
          type: 'bullet',
          text: stripInlineMarkdown(bulletMatch[1])
        });
        continue;
      }

      // Numbered list
      const numMatch = /^(\d+)\.\s+(.+)$/.exec(trimmed);
      if (numMatch) {
        blocks.push({
          type: 'numbered',
          number: numMatch[1],
          text: stripInlineMarkdown(numMatch[2])
        });
        continue;
      }

      // Transcript timestamp line: [01:15] text or [1:02:30] text
      const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
      if (tsMatch) {
        const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
        const rest = trimmed.slice(tsStr.length).trim();
        blocks.push({
          type: 'transcript_line',
          ts: tsStr,
          text: stripInlineMarkdown(rest)
        });
        continue;
      }

      // Regular paragraph
      blocks.push({
        type: 'p',
        text: stripInlineMarkdown(trimmed)
      });
    }
    return blocks;
  }

  function formatAsExportText(win) {
    const isTranscript = win.mode === 'transcript';
    const divider = '='.repeat(76);
    const subDivider = '-'.repeat(76);
    const nowStr = new Date().toLocaleString();

    let out = `${divider}\n`;
    out += `YOUTUBE FEED SUMMARISER - ${isTranscript ? 'TRANSCRIPT' : 'SUMMARY'} EXPORT\n`;
    out += `${divider}\n\n`;
    out += `Title:       ${win.title}\n`;
    out += `Video ID:    ${win.videoId}\n`;
    out += `Video URL:   https://www.youtube.com/watch?v=${win.videoId}\n`;
    out += `Export Type: ${isTranscript ? 'Full Transcript' : 'Video Summary'}\n`;
    out += `Source:      ${win.source === 'text' ? 'Transcript' : 'Video'}\n`;
    out += `Model:       ${win.modelId || 'Default'}\n`;
    out += `Exported:    ${nowStr}\n\n`;
    out += `${subDivider}\nCONTENT\n${subDivider}\n\n`;

    const cleanContent = formatMathSymbolsInText(
      (win.text || '').replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '').trim()
    );
    out += cleanContent + '\n\n';

    if (win.fact && win.fact.text) {
      out += `${subDivider}\nFACT CHECK & VERIFICATION\n${subDivider}\n\n`;
      out += formatMathSymbolsInText(win.fact.text.trim()) + '\n\n';
      if (win.fact.sources && win.fact.sources.length) {
        out += 'Sources consulted:\n';
        for (const s of win.fact.sources) {
          out += `• ${s.title || s.uri} (${s.uri})\n`;
        }
        out += '\n';
      }
    }

    if (win.turns && win.turns.length) {
      out += `${subDivider}\nFOLLOW-UP QUESTIONS & ANSWERS\n${subDivider}\n\n`;
      for (const t of win.turns) {
        out += `Q: ${formatMathSymbolsInText(t.q)}\n\n`;
        out += `A: ${formatMathSymbolsInText(t.a)}\n\n`;
      }
    }

    out += `${divider}\nGenerated with YouTube Feed Summariser (Gemini)\n${divider}\n`;
    return out;
  }

  function downloadAsTxt(win) {
    const content = formatAsExportText(win);
    const safeTitle = (win.title || win.videoId || 'summary')
      .replace(/[/\\?%*:|"<>]/g, '-')
      .slice(0, 60)
      .trim();
    const filename = `${safeTitle}-${win.mode || 'summary'}.txt`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    let a = null;
    try {
      a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    } finally {
      setTimeout(() => {
        try {
          if (a && a.parentNode) a.parentNode.removeChild(a);
        } catch (_) {}
        try {
          URL.revokeObjectURL(url);
        } catch (_) {}
      }, 500);
    }
  }

  function formatAsExportJson(win) {
    const isTranscript = win.mode === 'transcript';
    const processingMode = win.opts?.transcriptMode || (isTranscript ? 'fast' : 'standard');
    let channelName = win.channel || win.author || '';
    if (!channelName && typeof document !== 'undefined') {
      try {
        const ch = document.querySelector('#owner #channel-name, ytd-channel-name #text, #upload-info #channel-name, .ytd-video-owner-renderer #text');
        channelName = ch?.textContent?.trim() || '';
      } catch (_) {}
    }
    if (!channelName) channelName = 'YouTube Creator';

    const mainTargetType = isTranscript ? 'transcript' : 'summary';
    const mainRating = getResponseRating(win.videoId, mainTargetType, 'main');
    const followUpRatings = {};
    (win.turns || []).forEach((_t, idx) => {
      const r = getResponseRating(win.videoId, 'followup', `turn_${idx}`);
      if (r) followUpRatings[`turn_${idx}`] = r;
    });

    const payload = {
      generator: 'YouTube Feed Summariser (Gemini)',
      version: '2.12.0',
      exportedAt: new Date().toISOString(),
      metadata: {
        videoId: win.videoId,
        videoTitle: win.title || win.videoId || 'Untitled Video',
        channel: channelName,
        videoUrl: `https://www.youtube.com/watch?v=${win.videoId}`,
        mode: win.mode || 'summary',
        source: win.source || 'video',
        processingMode: processingMode,
        model: win.modelId || CONFIG.defaultModel,
        ttsSettings: {
          rate: typeof win.ttsRate === 'number' ? win.ttsRate : 1.0,
          volume: typeof win.ttsVolume === 'number' ? win.ttsVolume : 1.0,
          pitch: typeof win.ttsPitch === 'number' ? win.ttsPitch : 1.0,
          voice: win.ttsVoice || CONFIG.defaultTtsVoice
        }
      },
      content: {
        rawText: formatMathSymbolsInText(win.text || ''),
        formattedText: formatAsExportText(win),
        factCheck: win.fact?.text ? formatMathSymbolsInText(win.fact.text) : null,
        citations: win.sources || [],
        followUpQuestions: (win.turns || []).map((t) => ({
          question: formatMathSymbolsInText(t.q),
          answer: formatMathSymbolsInText(t.a),
          sources: t.sources || []
        })),
        ratings: {
          main: mainRating,
          followUps: followUpRatings
        }
      }
    };

    return JSON.stringify(payload, null, 2);
  }

  function downloadAsJson(win) {
    const content = formatAsExportJson(win);
    const safeTitle = (win.title || win.videoId || 'summary')
      .replace(/[/\\?%*:|"<>]/g, '-')
      .slice(0, 60)
      .trim();
    const filename = `${safeTitle}-${win.mode || 'summary'}.json`;
    const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    let a = null;
    try {
      a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
    } finally {
      setTimeout(() => {
        try {
          if (a && a.parentNode) a.parentNode.removeChild(a);
        } catch (_) {}
        try {
          URL.revokeObjectURL(url);
        } catch (_) {}
      }, 500);
    }
  }

  function exportAsPdf(win) {
    const isTranscript = win.mode === 'transcript';
    const printIframe = document.createElement('iframe');
    printIframe.style.position = 'fixed';
    printIframe.style.right = '0';
    printIframe.style.bottom = '0';
    printIframe.style.width = '0';
    printIframe.style.height = '0';
    printIframe.style.border = '0';
    printIframe.style.opacity = '0';
    printIframe.style.pointerEvents = 'none';
    document.body.appendChild(printIframe);

    const doc = printIframe.contentDocument || printIframe.contentWindow.document;
    doc.open();
    doc.write('<!DOCTYPE html><html><head><title>' + (win.title || 'Export') + '</title></head><body></body></html>');
    doc.close();

    const style = doc.createElement('style');
    style.textContent = `
      @page { margin: 16mm 14mm; size: auto; }
      body {
        font-family: Georgia, Charter, Cambria, serif;
        font-size: 11pt;
        line-height: 1.6;
        color: #111;
        max-width: 800px;
        margin: 0 auto;
        padding: 10px;
      }
      .header { border-bottom: 2px solid #222; padding-bottom: 12px; margin-bottom: 20px; }
      .badge { display: inline-block; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 8pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; background: #eee; padding: 2px 8px; border-radius: 4px; margin-bottom: 6px; }
      h1 { font-size: 18pt; margin: 0 0 6px 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.25; }
      .meta { font-size: 9pt; color: #555; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin-bottom: 4px; }
      .meta a { color: #0056b3; text-decoration: none; }
      h2 { font-size: 13pt; margin-top: 22px; margin-bottom: 8px; border-bottom: 1px solid #ddd; padding-bottom: 4px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      h3 { font-size: 11.5pt; margin-top: 16px; margin-bottom: 6px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      p { margin: 0 0 10px 0; }
      ul, ol { margin: 0 0 12px 0; padding-left: 24px; }
      li { margin-bottom: 4px; }
      .timestamp { font-weight: 600; color: #0056b3; font-family: monospace; font-size: 9.5pt; }
      .fact-section { margin-top: 24px; padding: 12px; background: #f8f9fa; border-left: 3px solid #28a745; border-radius: 4px; }
      .qa-item { margin-top: 14px; padding-bottom: 10px; border-bottom: 1px dashed #ccc; }
      .q-text { font-weight: 600; margin-bottom: 4px; }
      .footer { margin-top: 30px; border-top: 1px solid #eee; padding-top: 10px; font-size: 8pt; color: #888; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; text-align: center; }
    `;
    doc.head.appendChild(style);

    const headerDiv = doc.createElement('div');
    headerDiv.className = 'header';
    const badge = doc.createElement('div');
    badge.className = 'badge';
    badge.textContent = isTranscript ? 'YouTube Transcript' : 'YouTube Video Summary';
    headerDiv.appendChild(badge);

    const h1 = doc.createElement('h1');
    h1.textContent = win.title;
    headerDiv.appendChild(h1);

    const meta = doc.createElement('div');
    meta.className = 'meta';
    meta.textContent = `Video ID: ${win.videoId} · Source: ${win.source} · Model: ${win.modelId || 'Default'} · Exported: ${new Date().toLocaleDateString()}`;
    headerDiv.appendChild(meta);

    const link = doc.createElement('div');
    link.className = 'meta';
    const a = doc.createElement('a');
    a.href = `https://www.youtube.com/watch?v=${win.videoId}`;
    a.textContent = `https://www.youtube.com/watch?v=${win.videoId}`;
    link.appendChild(a);
    headerDiv.appendChild(link);

    doc.body.appendChild(headerDiv);

    const blocks = parseCleanEditorialBlocks(win.text || '');
    let curList = null;

    for (const block of blocks) {
      if (block.type === 'heading') {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const h2 = doc.createElement('h2');
        h2.textContent = block.text;
        doc.body.appendChild(h2);
      } else if (block.type === 'subheading') {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const h3 = doc.createElement('h3');
        h3.textContent = block.text;
        doc.body.appendChild(h3);
      } else if (block.type === 'bullet') {
        if (!curList || curList.tagName !== 'UL') {
          if (curList) doc.body.appendChild(curList);
          curList = doc.createElement('ul');
        }
        const li = doc.createElement('li');
        li.textContent = block.text;
        curList.appendChild(li);
      } else if (block.type === 'numbered') {
        if (!curList || curList.tagName !== 'OL') {
          if (curList) doc.body.appendChild(curList);
          curList = doc.createElement('ol');
        }
        const li = doc.createElement('li');
        li.textContent = block.text;
        curList.appendChild(li);
      } else {
        if (curList) { doc.body.appendChild(curList); curList = null; }
        const p = doc.createElement('p');
        p.textContent = block.text;
        doc.body.appendChild(p);
      }
    }
    if (curList) doc.body.appendChild(curList);

    if (win.fact && win.fact.text) {
      const factBox = doc.createElement('div');
      factBox.className = 'fact-section';
      const factH = doc.createElement('h2');
      factH.textContent = 'Fact-Check & Verification';
      factBox.appendChild(factH);
      const factBlocks = parseCleanEditorialBlocks(win.fact.text);
      for (const fb of factBlocks) {
        const p = doc.createElement('p');
        p.textContent = fb.text;
        factBox.appendChild(p);
      }
      doc.body.appendChild(factBox);
    }

    if (win.turns && win.turns.length) {
      const qaH = doc.createElement('h2');
      qaH.textContent = 'Follow-up Questions & Answers';
      doc.body.appendChild(qaH);
      for (const t of win.turns) {
        const qDiv = doc.createElement('div');
        qDiv.className = 'qa-item';
        const qP = doc.createElement('p');
        qP.className = 'q-text';
        qP.textContent = `Q: ${t.q}`;
        qDiv.appendChild(qP);
        const aP = doc.createElement('p');
        aP.textContent = `A: ${t.a}`;
        qDiv.appendChild(aP);
        doc.body.appendChild(qDiv);
      }
    }

    const footer = doc.createElement('div');
    footer.className = 'footer';
    footer.textContent = 'Exported from YouTube Feed Summariser (Gemini)';
    doc.body.appendChild(footer);

    printIframe.contentWindow.focus();
    setTimeout(() => {
      try {
        printIframe.contentWindow.print();
      } catch (e) {
        console.warn('[YTAIS] Print error:', e);
      }
      setTimeout(() => {
        printIframe.remove();
      }, 4000);
    }, 250);
  }

  function cleanTextForSpeech(text, opts = {}) {
    if (!text) return '';
    const skipSilence = opts && typeof opts.skipSilence === 'boolean' ? opts.skipSilence : true;
    let clean = text;

    if (skipSilence) {
      // 1. Filter out lines that are purely silence / pause / music / applause markers
      const silenceLineRegex = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,}|[-_—]{2,})\s*$/gim;
      clean = clean.replace(silenceLineRegex, '');

      // 2. Filter out standalone silence / pause markers without timestamps
      const standaloneSilenceRegex = /^\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,})\s*$/gim;
      clean = clean.replace(standaloneSilenceRegex, '');

      // 3. Remove inline silence / pause tokens
      clean = clean.replace(/\[(?:silence|pause|long pause|music|applause|laughter|no audio|blank)\]/gi, '');
      clean = clean.replace(/\((?:silence|pause|long pause|music|applause|laughter|no audio|blank)\)/gi, '');

      // 4. Collapse extended pause punctuation (e.g. ".....", "---")
      clean = clean.replace(/\.{3,}/g, '. ');
      clean = clean.replace(/[-_—]{2,}/g, ', ');

      // 5. Detect timestamp gaps > 3 seconds between consecutive timestamped transcript lines
      const lines = clean.split('\n');
      const processedLines = [];
      let prevTsSec = -1;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(line);
        if (tsMatch) {
          const hrs = tsMatch[1] ? parseInt(tsMatch[1], 10) : 0;
          const mins = parseInt(tsMatch[2], 10);
          const secs = parseInt(tsMatch[3], 10);
          const currentTsSec = hrs * 3600 + mins * 60 + secs;
          const rest = tsMatch[4].trim();

          // If line has no meaningful words (just filler/empty), skip it
          if (!rest || /^(?:\[.*?\]|\(.*?\)|[-_.\s]+)$/.test(rest)) {
            continue;
          }

          prevTsSec = currentTsSec;
          processedLines.push(line);
        } else {
          processedLines.push(line);
        }
      }
      clean = processedLines.join('\n');
    }

    // Strip visual markers
    clean = clean.replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]+\]\]/gi, '');
    // Strip HTML / script tags
    clean = clean.replace(/<[^>]+>/g, '');
    // Convert timestamps like [01:15] or [1:02:30] to spoken phrases
    clean = clean.replace(/\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]/g, function (_match, h, m, s) {
      const hrs = h ? parseInt(h, 10) : 0;
      const mins = parseInt(m, 10);
      const secs = parseInt(s, 10);
      const parts = [];
      if (hrs > 0) parts.push(`${hrs} hour${hrs > 1 ? 's' : ''}`);
      if (mins > 0) parts.push(`${mins} minute${mins > 1 ? 's' : ''}`);
      if (secs > 0) parts.push(`${secs} second${secs > 1 ? 's' : ''}`);
      return parts.length ? `at ${parts.join(' ')}` : '';
    });
    // Format LaTeX / scientific symbols (e.g., $100^\circ\text{C}$ -> 100°C)
    clean = formatMathSymbolsInText(clean);
    // Strip markdown formatting symbols
    clean = clean.replace(/#{1,6}\s+/g, '');
    clean = clean.replace(/\*\*([^*]+)\*\*/g, '$1');
    clean = clean.replace(/\*([^*]+)\*/g, '$1');
    clean = clean.replace(/`([^`]+)`/g, '$1');
    clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
    clean = clean.replace(/https?:\/\/\S+/g, '');
    clean = clean.replace(/^[-*•]\s+/gm, '');
    return clean.replace(/\s+/g, ' ').trim();
  }

  function parseTranscriptCues(transcriptText, opts = { skipSilence: true }) {
    if (!transcriptText) return { cues: [], fullSpokenText: '' };
    const lines = transcriptText.split('\n');
    const cues = [];
    const spokenParts = [];
    let currentOffset = 0;

    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const trimmed = rawLine.trim();
      if (!trimmed) continue;

      const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
      if (!tsMatch) continue;

      const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
      const restText = trimmed.slice(tsStr.length).trim();
      const parts = tsStr.slice(1, -1).split(':').map(Number);
      let sec = 0;
      if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
      else sec = parts[0] * 60 + parts[1];

      const spokenLine = cleanTextForSpeech(trimmed, opts);
      if (!spokenLine) continue;

      const charStart = currentOffset;
      const charEnd = currentOffset + spokenLine.length;
      currentOffset = charEnd + 1;
      spokenParts.push(spokenLine);

      cues.push({
        lineIndex: i,
        rawLine,
        tsStr,
        startSec: sec,
        text: restText,
        spokenText: spokenLine,
        charStart,
        charEnd
      });
    }

    const fullSpokenText = spokenParts.join(' ');
    return { cues, fullSpokenText };
  }

  function findActiveCueByCharIndex(cues, charIndex) {
    if (!cues || cues.length === 0) return null;
    if (charIndex <= 0) return cues[0];

    for (let i = 0; i < cues.length; i++) {
      const cue = cues[i];
      if (charIndex >= cue.charStart && charIndex <= cue.charEnd) {
        return cue;
      }
      if (i < cues.length - 1 && charIndex > cue.charEnd && charIndex < cues[i + 1].charStart) {
        return cue;
      }
    }

    if (charIndex > cues[cues.length - 1].charEnd) {
      return cues[cues.length - 1];
    }
    return cues[0];
  }

  function findActiveCueByTime(cues, currentTimeSec, totalDurationSec) {
    if (!cues || cues.length === 0) return null;
    if (totalDurationSec <= 0 || currentTimeSec <= 0) return cues[0];

    const progress = Math.min(1, Math.max(0, currentTimeSec / totalDurationSec));
    const totalChars = cues[cues.length - 1].charEnd;
    const targetChar = Math.round(progress * totalChars);

    return findActiveCueByCharIndex(cues, targetChar);
  }

  // --- STORAGE & PERSISTENCE HELPERS ---
  function getStoredKeys() {
    let keys = GM_getValue('keys', null);
    if (!Array.isArray(keys)) {
      const legacy = GM_getValue('gemini_api_key', null);
      if (legacy && typeof legacy === 'string' && legacy.trim()) {
        keys = [{ id: 'k_' + Math.random().toString(36).slice(2, 8), name: 'Default', key: legacy.trim() }];
        GM_setValue('keys', keys);
        GM_deleteValue('gemini_api_key');
      } else {
        keys = [];
      }
    }
    return keys;
  }

  function saveStoredKeys(keys) {
    GM_setValue('keys', keys);
  }

  function getGlobalOpts() {
    return Object.assign({}, DEFAULT_OPTS, GM_getValue('opts', {}));
  }

  function saveGlobalOpts(opts) {
    GM_setValue('opts', opts);
  }

  function getAutoStart() {
    return Boolean(GM_getValue('autoStart', false));
  }

  function setAutoStart(val) {
    GM_setValue('autoStart', Boolean(val));
  }

  function getLastModel() {
    return GM_getValue('lastModel', CONFIG.defaultModel);
  }

  function setLastModel(m) {
    GM_setValue('lastModel', m);
  }

  function getLastKeyId() {
    return GM_getValue('lastKeyId', '');
  }

  function setLastKeyId(id) {
    GM_setValue('lastKeyId', id);
  }

  function getLastSource() {
    return GM_getValue('lastSource', 'video');
  }

  function setLastSource(s) {
    GM_setValue('lastSource', s);
  }

  function getCustomModels() {
    return GM_getValue('customModels', []);
  }

  function addCustomModel(id) {
    const list = getCustomModels();
    if (!list.includes(id)) {
      list.push(id);
      GM_setValue('customModels', list);
    }
  }

  function getLastTtsVoice() {
    return GM_getValue('lastTtsVoice', CONFIG.defaultTtsVoice);
  }

  function setLastTtsVoice(v) {
    GM_setValue('lastTtsVoice', v);
  }

  function getLastTtsVolume() {
    const val = GM_getValue('lastTtsVolume', 1.0);
    return typeof val === 'number' && !isNaN(val) ? Math.max(0, Math.min(1, val)) : 1.0;
  }

  function setLastTtsVolume(v) {
    const vol = typeof v === 'number' && !isNaN(v) ? Math.max(0, Math.min(1, v)) : 1.0;
    GM_setValue('lastTtsVolume', vol);
  }

  function getLastTtsRate() {
    const val = GM_getValue('lastTtsRate', 1.0);
    return typeof val === 'number' && !isNaN(val) ? Math.max(0.5, Math.min(2.0, val)) : 1.0;
  }

  function setLastTtsRate(r) {
    const rate = typeof r === 'number' && !isNaN(r) ? Math.max(0.5, Math.min(2.0, r)) : 1.0;
    GM_setValue('lastTtsRate', rate);
  }

  function clampPitch(val) {
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (!isFinite(num)) return 1.0;
    return Math.max(0.5, Math.min(2.0, Math.round(num * 100) / 100));
  }

  function getLastTtsPitch() {
    const val = GM_getValue('lastTtsPitch', CONFIG.defaultTtsPitch || 1.0);
    return clampPitch(val);
  }

  function setLastTtsPitch(p) {
    const pitch = clampPitch(p);
    GM_setValue('lastTtsPitch', pitch);
  }

  function computeWaveformAmplitudes(options) {
    const barCount = Math.max(4, options?.barCount || 12);
    const volume = options?.volume !== undefined ? Math.max(0, Math.min(1, options.volume)) : 1.0;
    const pitch = options?.pitch !== undefined ? clampPitch(options.pitch) : 1.0;
    const rate = options?.rate !== undefined ? Math.max(0.25, Math.min(3, options.rate)) : 1.0;
    const t = (options?.timestamp !== undefined ? options.timestamp : Date.now()) / 1000;
    const pulse = Math.max(0, Math.min(1, options?.boundaryPulse || 0));

    if (!options?.isPlaying || volume === 0) {
      return new Array(barCount).fill(0.08);
    }

    const bars = [];
    const baseFreq = 3.2 * rate;

    for (let i = 0; i < barCount; i++) {
      const normIdx = i / (barCount - 1);
      const formantCenter = 0.35 * Math.sqrt(pitch);
      const formantWidth = 0.28;
      const formantDist = Math.abs(normIdx - formantCenter);
      const formantWeight = Math.exp(-Math.pow(formantDist / formantWidth, 2));

      const harmonic1 = Math.sin(t * baseFreq * 2.1 + i * 0.8) * 0.5 + 0.5;
      const harmonic2 = Math.sin(t * baseFreq * 4.3 - i * 1.2) * 0.3 + 0.3;
      const harmonic3 = Math.cos(t * baseFreq * 1.1 + i * 0.4) * 0.2 + 0.2;
      const attackBoost = pulse * (0.3 + 0.7 * Math.sin(i * 0.5));

      let amp = (formantWeight * 0.5 + 0.25) * (harmonic1 * 0.45 + harmonic2 * 0.35 + harmonic3 * 0.2) + attackBoost;
      amp = Math.max(0.08, Math.min(1.0, amp * volume));
      bars.push(Math.round(amp * 100) / 100);
    }
    return bars;
  }

  function getLastReadabilityTheme() {
    return GM_getValue('lastReadabilityTheme', CONFIG.defaultReadabilityTheme || 'system');
  }

  function setLastReadabilityTheme(theme) {
    GM_setValue('lastReadabilityTheme', theme);
  }

  function detectYouTubeTheme(doc) {
    const targetDoc = doc || (typeof document !== 'undefined' ? document : null);
    if (!targetDoc) return 'dark';

    const docEl = targetDoc.documentElement;
    if (docEl) {
      if (typeof docEl.hasAttribute === 'function' && docEl.hasAttribute('dark')) return 'dark';
      if (typeof docEl.getAttribute === 'function') {
        const darkAttr = docEl.getAttribute('dark');
        if (darkAttr !== null && darkAttr !== 'false') return 'dark';
        const themeAttr = docEl.getAttribute('theme');
        if (themeAttr === 'dark') return 'dark';
      }
      if (docEl.classList && docEl.classList.contains && (docEl.classList.contains('dark') || docEl.classList.contains('yt-dark'))) {
        return 'dark';
      }
    }

    if (typeof targetDoc.querySelector === 'function') {
      if (targetDoc.querySelector('html[dark]')) return 'dark';
      if (targetDoc.querySelector('ytd-app[dark]')) return 'dark';
      const ytdApp = targetDoc.querySelector('ytd-app');
      if (ytdApp && typeof ytdApp.hasAttribute === 'function' && ytdApp.hasAttribute('dark')) return 'dark';
      if (targetDoc.body && typeof targetDoc.body.hasAttribute === 'function' && targetDoc.body.hasAttribute('dark')) return 'dark';
    }

    return 'light';
  }

  function getLastSyncYouTubeTheme() {
    return Boolean(GM_getValue('sync_yt_theme', true));
  }

  function setLastSyncYouTubeTheme(val) {
    GM_setValue('sync_yt_theme', Boolean(val));
  }

  function getAltTitlesEnabled() {
    return Boolean(GM_getValue('alt_titles_enabled', true));
  }

  function setAltTitlesEnabled(val) {
    const enabled = Boolean(val);
    GM_setValue('alt_titles_enabled', enabled);
    if (shadowRoot) {
      const altCheckboxes = shadowRoot.querySelectorAll('.yt-alt-titles-setting-checkbox');
      for (const cb of altCheckboxes) {
        cb.checked = enabled;
      }
    }
    if (typeof refreshAllFeedCardTitles === 'function') {
      refreshAllFeedCardTitles();
    }
  }

  function getCachedAltTitle(videoId) {
    if (!videoId) return null;
    if (altTitlesMemoryCache.has(videoId)) return altTitlesMemoryCache.get(videoId);
    const val = GM_getValue('alt_title:' + videoId, null);
    if (val && typeof val === 'string') {
      altTitlesMemoryCache.set(videoId, val);
      return val;
    }
    return null;
  }

  const MAX_ALT_TITLES_CACHE = 500;
  function setCachedAltTitle(videoId, title) {
    if (!videoId || !title) return;
    if (altTitlesMemoryCache.size >= MAX_ALT_TITLES_CACHE && !altTitlesMemoryCache.has(videoId)) {
      const oldestKey = altTitlesMemoryCache.keys().next().value;
      if (oldestKey) altTitlesMemoryCache.delete(oldestKey);
    }
    altTitlesMemoryCache.set(videoId, title);
    GM_setValue('alt_title:' + videoId, title);
  }

  function getDraftFollowUp(videoId) {
    if (!videoId) return '';
    const draft = GM_getValue('draft:' + videoId, '');
    return typeof draft === 'string' ? draft : '';
  }

  function setDraftFollowUp(videoId, text) {
    if (!videoId) return;
    if (!text || !text.trim()) {
      GM_deleteValue('draft:' + videoId);
    } else {
      GM_setValue('draft:' + videoId, text);
    }
  }

  function clearDraftFollowUp(videoId) {
    if (!videoId) return;
    GM_deleteValue('draft:' + videoId);
  }

  function normalizeHistoryTabVisibility(val) {
    if (val === 'always' || val === 'with_tabs' || val === 'never') {
      return val;
    }
    return 'always';
  }

  function getHistoryTabVisibility() {
    return normalizeHistoryTabVisibility(GM_getValue('history_tab_visibility', 'always'));
  }

  function setHistoryTabVisibility(val) {
    const normalized = normalizeHistoryTabVisibility(val);
    GM_setValue('history_tab_visibility', normalized);
    if (typeof updateDockHistoryTab === 'function') {
      updateDockHistoryTab();
    }
    if (shadowRoot) {
      const selects = shadowRoot.querySelectorAll('.yt-history-visibility-select');
      for (const s of selects) {
        if (s.value !== normalized) s.value = normalized;
      }
    }
    return normalized;
  }

  function shouldShowHistoryTab({ visibility, cachedCount, activeTabCount }) {
    const mode = normalizeHistoryTabVisibility(visibility);
    if (!cachedCount || cachedCount <= 0) return false;
    if (mode === 'never') return false;
    if (mode === 'with_tabs') return (activeTabCount || 0) > 0;
    return true;
  }

  function buildResponseRatingKey(videoId, targetType, targetId = 'main') {
    return `${videoId}:${targetType}:${targetId || 'main'}`;
  }

  function getResponseRatings() {
    const map = GM_getValue('response_ratings', {});
    return map && typeof map === 'object' ? map : {};
  }

  function getResponseRating(videoId, targetType, targetId = 'main') {
    if (!videoId) return null;
    const map = getResponseRatings();
    return map[buildResponseRatingKey(videoId, targetType, targetId)] || null;
  }

  function setResponseRating(videoId, targetType, targetId = 'main', rating, note) {
    if (!videoId) return null;
    const map = Object.assign({}, getResponseRatings());
    const key = buildResponseRatingKey(videoId, targetType, targetId);
    const existing = map[key];

    if (existing && existing.rating === rating && note === undefined) {
      delete map[key];
      GM_setValue('response_ratings', map);
      return null;
    }

    const record = {
      videoId,
      targetType,
      targetId: targetId || 'main',
      rating,
      note: note !== undefined ? note : existing?.note,
      updatedAt: Date.now()
    };
    map[key] = record;
    GM_setValue('response_ratings', map);
    return record;
  }

  function clampWindowBounds(bounds, viewport, minWidth = 340, minHeight = 300) {
    const vw = Math.max(360, viewport?.width || (typeof window !== 'undefined' ? window.innerWidth : 1280) || 1280);
    const vh = Math.max(360, viewport?.height || (typeof window !== 'undefined' ? window.innerHeight : 800) || 800);
    const maxW = Math.max(minWidth, vw - 24);
    const maxH = Math.max(minHeight, vh - 64);

    const width = Math.round(Math.max(minWidth, Math.min(maxW, bounds.width)));
    const height = Math.round(Math.max(minHeight, Math.min(maxH, bounds.height)));
    const maxLeft = Math.max(12, vw - width - 12);
    const maxTop = Math.max(12, vh - height - 52);
    const left = Math.round(Math.max(12, Math.min(maxLeft, bounds.left)));
    const top = Math.round(Math.max(12, Math.min(maxTop, bounds.top)));
    return { left, top, width, height };
  }

  function computeDefaultWindowBounds(viewport, cascadeIndex = 0, preferred = null) {
    const vw = Math.max(360, viewport?.width || (typeof window !== 'undefined' ? window.innerWidth : 1280) || 1280);
    const vh = Math.max(360, viewport?.height || (typeof window !== 'undefined' ? window.innerHeight : 800) || 800);
    const defaultWidth = preferred?.width ?? Math.min(920, Math.max(360, vw - 64));
    const defaultHeight = preferred?.height ?? Math.min(760, Math.max(380, vh - 110));
    const step = (Math.max(0, cascadeIndex) % 5) * 28;
    const baseLeft = preferred?.left ?? Math.max(16, Math.round((vw - defaultWidth) / 2) + step - 28);
    const baseTop = preferred?.top ?? Math.max(16, Math.round((vh - defaultHeight - 44) / 2) + step - 28);
    return clampWindowBounds({ left: baseLeft, top: baseTop, width: defaultWidth, height: defaultHeight }, { width: vw, height: vh });
  }

  function classifyWindowSizeTier(width) {
    if (width < 540) return 'compact';
    if (width < 780) return 'medium';
    return 'wide';
  }

  function getAdaptiveWindowFlags(width, height) {
    const tier = classifyWindowSizeTier(width);
    return {
      tier,
      isCompact: tier === 'compact',
      isMedium: tier === 'medium',
      isWide: tier === 'wide',
      isShort: height < 460,
      useOverflowHeaderMenu: width < 540,
      collapseOptionsRow: width < 540,
      compactTtsBar: width < 780,
      singleColumnAdvPanel: width < 580
    };
  }

  function getLastWindowBounds() {
    const raw = GM_getValue('lastWindowBounds', null);
    if (raw && typeof raw === 'object' && typeof raw.width === 'number' && typeof raw.height === 'number') {
      return raw;
    }
    return null;
  }

  function setLastWindowBounds(bounds) {
    if (!bounds || typeof bounds.width !== 'number' || typeof bounds.height !== 'number') return;
    GM_setValue('lastWindowBounds', bounds);
  }

  // Cache slot calculation
  function mk(mode, source) {
    if (mode === 'transcript') {
      return source === 'text' ? 'trt:' : 'trn:';
    }
    return source === 'text' ? 'sut:' : 'sum:';
  }

  function touchCacheIndex(key) {
    let index = GM_getValue('cache_index', {});
    index[key] = Date.now();
    const entries = Object.entries(index);
    if (entries.length > CONFIG.cacheMax) {
      entries.sort((a, b) => a[1] - b[1]);
      const openWins = new Set(
        GM_listValues()
          .filter((k) => k.startsWith('win:'))
          .map((k) => k.slice(4))
      );
      while (entries.length > CONFIG.cacheMax) {
        const [oldKey] = entries.shift();
        const id = oldKey.slice(4);
        if (!openWins.has(id)) {
          GM_deleteValue(oldKey);
          delete index[oldKey];
        }
      }
    }
    GM_setValue('cache_index', index);
  }

  function readCache(videoId, mode, source, skipTouch = false) {
    const prefix = mk(mode, source);
    const key = prefix + videoId;
    const entry = GM_getValue(key, null);
    if (entry) {
      if (!skipTouch) touchCacheIndex(key);
      return entry;
    }
    // Also try alternate source if not present
    const altPrefix = mk(mode, source === 'text' ? 'video' : 'text');
    const altKey = altPrefix + videoId;
    const altEntry = GM_getValue(altKey, null);
    if (altEntry) {
      if (!skipTouch) touchCacheIndex(altKey);
      return altEntry;
    }
    return null;
  }

  function writeCache(videoId, mode, source, data) {
    const prefix = mk(mode, source);
    const key = prefix + videoId;
    data.videoId = videoId;
    data.ts = Date.now();
    data.ts2 = Date.now() + Math.random();
    GM_setValue(key, data);
    touchCacheIndex(key);
  }

  function clearAllCache() {
    const openWins = new Set(
      GM_listValues()
        .filter((k) => k.startsWith('win:'))
        .map((k) => k.slice(4))
    );
    const all = GM_listValues();
    const prefixes = ['sum:', 'trn:', 'sut:', 'trt:'];
    for (const k of all) {
      if (prefixes.some((p) => k.startsWith(p))) {
        const id = k.slice(4);
        if (!openWins.has(id)) {
          GM_deleteValue(k);
        }
      }
    }
    GM_setValue('cache_index', {});
  }

  function getAllCachedSummaries() {
    const allKeys = GM_listValues();
    const prefixes = ['sum:', 'sut:', 'trn:', 'trt:'];
    const items = [];
    const seenIds = new Set();

    const index = GM_getValue('cache_index', {});
    const sortedKeys = Object.keys(index).sort((a, b) => (index[b] || 0) - (index[a] || 0));

    const fullKeys = [...sortedKeys];
    for (const k of allKeys) {
      if (prefixes.some((p) => k.startsWith(p)) && !fullKeys.includes(k)) {
        fullKeys.push(k);
      }
    }

    for (const k of fullKeys) {
      if (!prefixes.some((p) => k.startsWith(p))) continue;
      const videoId = k.slice(4);
      if (seenIds.has(videoId)) continue;

      const entry = GM_getValue(k, null);
      if (entry && entry.text) {
        seenIds.add(videoId);
        const isTranscript = k.startsWith('trn:') || k.startsWith('trt:');
        const isTextSource = k.startsWith('sut:') || k.startsWith('trt:');
        items.push({
          key: k,
          videoId: entry.videoId || videoId,
          title: entry.title || `Video ${videoId}`,
          text: entry.text,
          mode: isTranscript ? 'transcript' : 'summary',
          source: isTextSource ? 'text' : 'video',
          model: entry.model || '',
          ts: entry.ts || index[k] || Date.now(),
          turns: entry.turns || [],
          notes: entry.notes || [],
          images: entry.images || null,
          fact: entry.fact || null
        });
      }
    }
    return items;
  }

  function deleteCachedVideo(videoId) {
    if (!videoId) return;
    const prefixes = ['sum:', 'sut:', 'trn:', 'trt:'];
    let index = GM_getValue('cache_index', {});
    for (const p of prefixes) {
      const key = p + videoId;
      GM_deleteValue(key);
      delete index[key];
    }
    GM_setValue('cache_index', index);
  }

  // --- MODEL AVAILABILITY CHECK ---
  let modelsCache = GM_getValue('models_cache', {});

  async function checkModelsForKey(keyObj, force = false) {
    if (!keyObj || !keyObj.key) return null;
    const keyId = keyObj.id;
    const now = Date.now();
    if (!force && modelsCache[keyId] && now - modelsCache[keyId].ts < CONFIG.modelCheckTtlMs) {
      return modelsCache[keyId].ids;
    }

    try {
      const ids = [];
      let pageToken = '';
      let url = 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000';
      do {
        const reqUrl = pageToken ? `${url}&pageToken=${encodeURIComponent(pageToken)}` : url;
        const res = await new Promise((resolve, reject) => {
          GM_xmlhttpRequest({
            method: 'GET',
            url: reqUrl,
            headers: { 'x-goog-api-key': keyObj.key },
            timeout: 15000,
            onload: (r) => {
              if (r.status >= 200 && r.status < 300) {
                try {
                  resolve(JSON.parse(r.responseText));
                } catch (e) {
                  reject(new Error('Invalid JSON from models endpoint'));
                }
              } else {
                reject(new Error(`HTTP ${r.status}: ${r.responseText}`));
              }
            },
            ontimeout: () => reject(new Error('Models request timed out')),
            onerror: (e) => reject(new Error('Models request error: ' + (e.error || 'network error')))
          });
        });

        if (res.models && Array.isArray(res.models)) {
          for (const m of res.models) {
            const rawName = m.name ? m.name.replace(/^models\//, '') : '';
            const methods = m.supportedGenerationMethods || [];
            const usable =
              methods.length === 0 ||
              methods.includes('generateContent') ||
              methods.some((meth) => /nteraction/i.test(meth));
            if (rawName && usable) {
              ids.push(rawName);
            }
          }
        }
        pageToken = res.nextPageToken || '';
      } while (pageToken);

      modelsCache[keyId] = { ts: now, ids: ids };
      GM_setValue('models_cache', modelsCache);
      return ids;
    } catch (err) {
      if (CONFIG.debug) console.warn('[YTAIS] checkModelsForKey failed:', err);
      return null;
    }
  }

  // --- GEMINI API CALLS & ERROR FORMATTING ---
  function apiError(status, text) {
    let parsed = null;
    try {
      parsed = JSON.parse(text);
    } catch (_) {}

    const err = new Error(parsed?.error?.message || text || `API Error ${status}`);
    err.status = status;
    err.code = status === 429 ? 'QUOTA' : String(status);
    err.raw = text;

    if (parsed?.error?.details && Array.isArray(parsed.error.details)) {
      for (const d of parsed.error.details) {
        if (d['@type']?.includes('RetryInfo') && d.retryDelay) {
          const match = /(\d+)s/.exec(d.retryDelay);
          if (match) err.retryMs = parseInt(match[1], 10) * 1000;
        }
        if (d['@type']?.includes('QuotaFailure') && Array.isArray(d.violations)) {
          err.violations = d.violations.map((v) => `${v.quotaId || ''} · ${v.subject || ''}`);
        }
      }
    }
    return err;
  }

  function callGeminiRaw(model, key, body, timeoutMs = CONFIG.requestTimeoutMs) {
    return new Promise((resolve, reject) => {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
      GM_xmlhttpRequest({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': key
        },
        data: JSON.stringify(body),
        timeout: timeoutMs,
        onload: (res) => {
          if (res.status >= 200 && res.status < 300) {
            try {
              resolve(JSON.parse(res.responseText));
            } catch (e) {
              reject(new Error('Invalid JSON from Gemini'));
            }
          } else {
            reject(apiError(res.status, res.responseText));
          }
        },
        ontimeout: () => reject(new Error('Gemini request timed out')),
        onerror: (err) => reject(new Error('Gemini network error: ' + (err.error || 'failed')))
      });
    });
  }

  async function callGeminiWithDrops(model, key, makeBody, { requireTools = false, onDrop = null } = {}) {
    let dropMediaRes = false;
    let dropThink = false;
    let dropTools = false;

    for (let attempt = 0; attempt < 4; attempt++) {
      const body = makeBody({ dropMediaRes, dropThink, dropTools });
      try {
        const res = await callGeminiRaw(model, key, body);
        return { res, dropMediaRes, dropThink, dropTools };
      } catch (err) {
        const msg = String(err.message || '').toLowerCase();
        const raw = String(err.raw || '').toLowerCase();
        const combined = msg + ' ' + raw;

        if (err.status === 400 && combined.includes('resolution') && !dropMediaRes) {
          dropMediaRes = true;
          if (onDrop) onDrop('mediaResolution');
          continue;
        }
        if (err.status === 400 && combined.includes('think') && !dropThink) {
          dropThink = true;
          if (onDrop) onDrop('thinking');
          continue;
        }
        if (
          !dropTools &&
          !requireTools &&
          (combined.includes('tool') ||
            combined.includes('search') ||
            combined.includes('ground') ||
            combined.includes('map') ||
            combined.includes('code') ||
            combined.includes('function') ||
            err.status === 429 ||
            err.status === 403)
        ) {
          dropTools = true;
          if (onDrop) onDrop('tools', err.status === 429 ? 'quota' : 'unsupported');
          continue;
        }
        throw err;
      }
    }
  }

  // Interactions API for images
  function callInteractionsRaw(model, key, body, timeoutMs = CONFIG.requestTimeoutMs) {
    return new Promise((resolve, reject) => {
      const url = `https://generativelanguage.googleapis.com/v1beta/interactions`;
      const fullBody = Object.assign({ model }, body);
      GM_xmlhttpRequest({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': key
        },
        data: JSON.stringify(fullBody),
        timeout: timeoutMs,
        onload: (res) => {
          if (res.status >= 200 && res.status < 300) {
            try {
              resolve(JSON.parse(res.responseText));
            } catch (e) {
              reject(new Error('Invalid JSON from Interactions API'));
            }
          } else {
            reject(apiError(res.status, res.responseText));
          }
        },
        ontimeout: () => reject(new Error('Interactions request timed out')),
        onerror: (err) => reject(new Error('Interactions network error: ' + (err.error || 'failed')))
      });
    });
  }

  // --- STORYBOARD & COMMONS & TRANSCRIPT HELPERS ---
  async function fetchStoryboardSpec(videoId) {
    if (storyboardCache.has(videoId)) return storyboardCache.get(videoId);
    try {
      const res = await fetch(`/watch?v=${encodeURIComponent(videoId)}`);
      const html = await res.text();
      const match = /"playerStoryboardSpecRenderer":\{"spec":"([^"]+)"\}/.exec(html);
      if (!match) return null;
      const specStr = JSON.parse(`"${match[1]}"`);
      const parts = specStr.split('|');
      const baseUrl = parts[0];
      const levels = [];
      for (let i = 1; i < parts.length; i++) {
        const [w, h, count, cols, rows, intervalMs, name, sigh] = parts[i].split('#');
        if (parseInt(intervalMs, 10) === 0) continue;
        levels.push({
          levelIdx: i - 1,
          w: parseInt(w, 10),
          h: parseInt(h, 10),
          count: parseInt(count, 10),
          cols: parseInt(cols, 10),
          rows: parseInt(rows, 10),
          intervalMs: parseInt(intervalMs, 10),
          name,
          sigh
        });
      }
      if (!levels.length) return null;
      const best = levels[levels.length - 1]; // highest level
      const config = { baseUrl, level: best };
      storyboardCache.set(videoId, config);
      return config;
    } catch (e) {
      if (CONFIG.debug) console.warn('[YTAIS] fetchStoryboardSpec failed:', e);
      return null;
    }
  }

  function getFrameUrlAndOffset(config, seconds) {
    const { baseUrl, level } = config;
    const ms = seconds * 1000;
    const idx = Math.floor(ms / level.intervalMs);
    const perSheet = level.cols * level.rows;
    const sheetIdx = Math.floor(idx / perSheet);
    const inSheetIdx = idx % perSheet;
    const col = inSheetIdx % level.cols;
    const row = Math.floor(inSheetIdx / level.cols);

    let name = level.name.replace('$M', String(sheetIdx));
    let url = baseUrl.replace('$L', String(level.levelIdx)).replace('$N', name);
    if (!url.includes('&sigh=') && level.sigh) {
      url += `&sigh=${encodeURIComponent(level.sigh)}`;
    }
    return {
      url,
      x: col * level.w,
      y: row * level.h,
      w: level.w,
      h: level.h
    };
  }

  function searchCommons(terms) {
    return new Promise((resolve) => {
      const url = `https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=6&gsrsearch=${encodeURIComponent(
        terms
      )} filetype:bitmap|drawing&prop=imageinfo&iiprop=url|extmetadata|size&iiurlwidth=720`;
      GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        timeout: 10000,
        onload: (res) => {
          try {
            const data = JSON.parse(res.responseText);
            if (!data?.query?.pages) return resolve(null);
            const pages = Object.values(data.query.pages);
            for (const p of pages) {
              const info = p.imageinfo?.[0];
              if (info && (info.width >= 300 || info.thumbwidth >= 300)) {
                const meta = info.extmetadata || {};
                const license = meta.LicenseShortName?.value || 'CC';
                const artist = (meta.Artist?.value || '').replace(/<[^>]+>/g, '').trim() || 'Wikimedia Commons';
                return resolve({
                  thumbUrl: info.thumburl || info.url,
                  fileUrl: info.descriptionurl || p.fullurl || `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(p.title)}`,
                  artist,
                  license
                });
              }
            }
            resolve(null);
          } catch (_) {
            resolve(null);
          }
        },
        ontimeout: () => resolve(null),
        onerror: () => resolve(null)
      });
    });
  }

  // YouTube transcript route A & route B
  async function fetchTranscriptRouteA(videoId) {
    const watchRes = await fetch(`/watch?v=${encodeURIComponent(videoId)}`);
    const html = await watchRes.text();
    const endpointMatch = /"getTranscriptEndpoint":\{"params":"([^"]+)"/.exec(html);
    const keyMatch = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(html);
    const clientVerMatch = /"INNERTUBE_CONTEXT_CLIENT_VERSION":"([^"]+)"/.exec(html);

    if (!endpointMatch || !keyMatch) {
      throw new Error('Transcript endpoint markers not found in watch page');
    }

    const params = endpointMatch[1];
    const key = keyMatch[1];
    const clientVersion = clientVerMatch ? clientVerMatch[1] : '2.20240101.00.00';

    const postRes = await fetch(`/youtubei/v1/get_transcript?prettyPrint=false&key=${encodeURIComponent(key)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: clientVersion,
            hl: 'en'
          }
        },
        params: params
      })
    });

    if (!postRes.ok) throw new Error(`Transcript API error ${postRes.status}`);
    const data = await postRes.json();
    const segments = [];

    function walk(node) {
      if (!node || typeof node !== 'object') return;
      if (node.transcriptSegmentRenderer) {
        const seg = node.transcriptSegmentRenderer;
        const startMs = parseInt(seg.startMs, 10) || 0;
        let text = '';
        if (seg.snippet?.runs) {
          text = seg.snippet.runs.map((r) => r.text).join('');
        } else if (seg.snippet?.simpleText) {
          text = seg.snippet.simpleText;
        }
        if (text) {
          segments.push({ startMs, text: text.trim() });
        }
      }
      for (const k of Object.keys(node)) {
        walk(node[k]);
      }
    }

    walk(data);
    if (!segments.length) throw new Error('No transcript segments found');
    return segments;
  }

  async function fetchTranscriptRouteB(videoId, signal) {
    return new Promise((resolve, reject) => {
      const iframe = h('iframe', {
        src: `/watch?v=${encodeURIComponent(videoId)}`,
        title: 'Transcript helper',
        allow: "autoplay 'none'",
        style: 'position: fixed; left: -20000px; width: 1400px; height: 900px; opacity: 0; pointer-events: none;'
      });

      let timer = null;
      let cleaned = false;

      function cleanup() {
        if (cleaned) return;
        cleaned = true;
        if (timer) clearInterval(timer);
        if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
      }

      if (signal) {
        signal.addEventListener('abort', () => {
          cleanup();
          reject(new Error('Aborted'));
        });
      }

      document.documentElement.appendChild(iframe);

      iframe.onload = () => {
        let attempts = 0;
        let clicked = false;
        timer = setInterval(() => {
          attempts++;
          if (attempts > 40) {
            cleanup();
            return reject(new Error('Transcript panel timed out (Route B)'));
          }
          try {
            const doc = iframe.contentDocument || iframe.contentWindow?.document;
            if (!doc) return;

            if (!clicked) {
              const btn =
                doc.querySelector('ytd-video-description-transcript-section-renderer button[aria-label]') ||
                doc.querySelector('chip-view-model button[aria-label="Transcript"]');
              if (btn) {
                btn.click();
                clicked = true;
              } else if (attempts > 20) {
                cleanup();
                return reject(new Error('No transcript button on video page'));
              }
            }

            const panel = doc.querySelector(
              'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"][visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"], ytd-engagement-panel-section-list-renderer[target-id="PAmodern_transcript_view"][visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"]'
            );
            if (panel) {
              const text = panel.innerText || '';
              const lines = text
                .split('\n')
                .map((l) => l.trim())
                .filter(Boolean);
              const segs = [];
              let currentTs = '';
              for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                const tsMatch = /^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})$/.exec(line);
                if (tsMatch) {
                  currentTs = line;
                } else if (currentTs) {
                  const parts = currentTs.split(':').map(Number);
                  let sec = 0;
                  if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
                  else sec = parts[0] * 60 + parts[1];
                  segs.push({ startMs: sec * 1000, text: line });
                  currentTs = '';
                } else {
                  // inline timestamp like "0:05 hello"
                  const inlineMatch = /^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\s+(.+)$/.exec(line);
                  if (inlineMatch) {
                    const tsStr = line.split(/\s+/)[0];
                    const parts = tsStr.split(':').map(Number);
                    let sec = 0;
                    if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
                    else sec = parts[0] * 60 + parts[1];
                    segs.push({ startMs: sec * 1000, text: inlineMatch[4] });
                  }
                }
              }
              if (segs.length >= 2) {
                cleanup();
                return resolve(segs);
              }
            }
          } catch (e) {
            // ignore cross-origin or transient
          }
        }, 60);
      };

      iframe.onerror = () => {
        cleanup();
        reject(new Error('Iframe load error in Route B'));
      };
    });
  }

  function formatTime(seconds) {
    const s = Math.floor(seconds);
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;
    const pad = (n) => String(n).padStart(2, '0');
    if (hrs > 0) {
      return `${hrs}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  }

  async function getTranscriptText(videoId, retries = 0, signal = null) {
    if (transcriptCache.has(videoId)) return transcriptCache.get(videoId);

    let lastErr = null;
    for (let att = 0; att <= retries; att++) {
      try {
        const segs = await fetchTranscriptRouteA(videoId);
        const lines = segs.map((s) => `[${formatTime(s.startMs / 1000)}] ${s.text}`);
        let full = lines.join('\n');
        if (full.length > CONFIG.maxTranscriptChars) {
          full = full.slice(0, CONFIG.maxTranscriptChars) + '\n[...truncated...]';
        }
        transcriptCache.set(videoId, full);
        return full;
      } catch (errA) {
        lastErr = errA;
        try {
          const segs = await fetchTranscriptRouteB(videoId, signal);
          const lines = segs.map((s) => `[${formatTime(s.startMs / 1000)}] ${s.text}`);
          let full = lines.join('\n');
          if (full.length > CONFIG.maxTranscriptChars) {
            full = full.slice(0, CONFIG.maxTranscriptChars) + '\n[...truncated...]';
          }
          transcriptCache.set(videoId, full);
          return full;
        } catch (errB) {
          lastErr = errB;
        }
      }
      if (att < retries) {
        await new Promise((r) => setTimeout(r, 1500 * (att + 1)));
      }
    }
    const err = new Error(
      `Couldn't get this video's transcript (it may have no captions, or be age-restricted/unavailable): ${lastErr?.message || 'failed'}`
    );
    err.code = 'TRANSCRIPT';
    throw err;
  }

  // --- YOUTUBE ASK SEMAPHORE & PROVIDER (§12) ---
  class AskSemaphore {
    constructor(max) {
      this.max = max;
      this.current = 0;
      this.queue = [];
    }

    async acquire() {
      if (this.current < this.max) {
        this.current++;
        return;
      }
      await new Promise((resolve) => this.queue.push(resolve));
      this.current++;
    }

    release() {
      this.current--;
      if (this.queue.length > 0) {
        const next = this.queue.shift();
        next();
      }
    }
  }

  const askLimiter = new AskSemaphore(CONFIG.askConcurrency);

  function domToMarkdown(node) {
    if (!node) return '';
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent.replace(/\s+/g, ' ');
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return '';

    const el = node;
    const tag = el.tagName.toLowerCase();
    if (
      [
        'button',
        'svg',
        'img',
        'style',
        'script',
        'noscript',
        'yt-icon',
        'yt-touch-feedback-shape'
      ].includes(tag) ||
      el.getAttribute('aria-hidden') === 'true' ||
      el.style.display === 'none'
    ) {
      return '';
    }

    const childrenMd = Array.from(el.childNodes)
      .map(domToMarkdown)
      .join('');

    if (tag === 'h1' || tag === 'h2') return `\n\n## ${childrenMd.trim()}\n\n`;
    if (tag === 'h3' || tag === 'h4' || tag === 'h5' || tag === 'h6') return `\n\n### ${childrenMd.trim()}\n\n`;
    if (tag === 'p') return `\n\n${childrenMd.trim()}\n\n`;
    if (tag === 'br') return '\n';
    if (tag === 'strong' || tag === 'b') return `**${childrenMd.trim()}**`;
    if (tag === 'em' || tag === 'i') return `*${childrenMd.trim()}*`;
    if (tag === 'code') return `\`${childrenMd.trim()}\``;
    if (tag === 'pre') return `\n\`\`\`\n${childrenMd.trim()}\n\`\`\`\n`;
    if (tag === 'li') return `\n- ${childrenMd.trim()}`;
    if (tag === 'a') {
      const href = el.getAttribute('href') || '';
      const text = childrenMd.trim();
      const tsMatch = /^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})$/.exec(text);
      if (tsMatch) return `[${text}]`;
      let finalHref = href;
      if (finalHref.includes('/redirect?q=')) {
        const u = new URL(finalHref, window.location.origin);
        finalHref = u.searchParams.get('q') || finalHref;
      }
      return `[${text}](${finalHref})`;
    }
    if (tag === 'tr') {
      const cells = Array.from(el.children).map((c) => domToMarkdown(c).trim());
      return `\n- ${cells.join(' | ')}`;
    }
    return childrenMd;
  }

  async function runYouTubeAsk(videoId, prompt, { isSummary = true, signal = null, onPhase = null } = {}) {
    await askLimiter.acquire();
    const prevActive = document.activeElement;
    let iframe = null;

    try {
      if (onPhase) onPhase('Connecting to YouTube Ask…');
      iframe = h('iframe', {
        src: `/watch?v=${encodeURIComponent(videoId)}`,
        title: 'YouTube Ask helper (hidden)',
        allow: "autoplay 'none'",
        style: 'position: fixed; left: -20000px; width: 1400px; height: 900px; opacity: 0; pointer-events: none;'
      });
      document.documentElement.appendChild(iframe);

      const res = await new Promise((resolve, reject) => {
        let abortHandler = () => {
          reject(new Error('Ask job was cancelled'));
        };
        if (signal) signal.addEventListener('abort', abortHandler);

        const startTime = Date.now();
        let step = 'find_button';
        let askBtnClicked = false;
        let baselineItems = -1;
        let baselineTime = 0;
        let sentMethod = '';
        let questionSentTime = 0;
        let lastAnswerText = '';
        let lastChangeTime = 0;
        let formSubmitted = false;

        const interval = setInterval(() => {
          if (signal?.aborted) {
            clearInterval(interval);
            return reject(new Error('Ask job was cancelled'));
          }

          const doc = iframe.contentDocument || iframe.contentWindow?.document;
          if (!doc) return;

          // Mute and pause any video playing in helper frame
          const vids = doc.querySelectorAll('video');
          for (const v of vids) {
            if (!v.paused) v.pause();
            v.muted = true;
          }

          const elapsed = Date.now() - startTime;

          // STEP 1: Find visible Ask button (not the player fullscreen decoy) or detect if panel is already open
          if (step === 'find_button') {
            if (elapsed > CONFIG.askLoadMs) {
              clearInterval(interval);
              const err = new Error(
                "YouTube's Ask button didn't appear in this video. Ask requires being signed in to a Google account with YouTube experiment access. Try selecting a Gemini model with an API key."
              );
              err.code = 'ASK';
              return reject(err);
            }

            // Check if engagement panel is already open and visible in the page
            const existingPanel = doc.querySelector(
              'ytd-engagement-panel-section-list-renderer[target-id="PAyouchat"][visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"]'
            );
            if (existingPanel && (existingPanel.offsetWidth > 0 || existingPanel.offsetHeight > 0 || existingPanel.getClientRects().length > 0)) {
              askBtnClicked = true;
              step = 'wait_panel';
              if (onPhase) onPhase('Ask panel detected, preparing…');
              return;
            }

            // Inspect element matchers from YouTube feeds and watch page:
            // 1. Below video in action bar (#top-level-buttons-computed .you-chat-entrypoint-button button)
            // 2. In video description section (yt-video-description-youchat-section-view-model .you-chat-entrypoint-button button)
            // 3. Flexible buttons container, aria-label="Ask" or aria-label="Ask questions"
            const selectors = [
              '#top-level-buttons-computed .you-chat-entrypoint-button button',
              '#flexible-item-buttons .you-chat-entrypoint-button button',
              'yt-video-description-youchat-section-view-model .you-chat-entrypoint-button button',
              'yt-video-description-youchat-section-view-model button',
              '.you-chat-entrypoint-button button',
              'button[aria-label="Ask" i]',
              'button[aria-label="Ask questions" i]',
              'button[aria-label*="Ask" i]',
              '[aria-label*="Ask" i] button'
            ];
            let targetBtn = null;
            for (const sel of selectors) {
              const buttons = Array.from(doc.querySelectorAll(sel));
              for (const b of buttons) {
                if (b.closest('.html5-video-player')) continue; // Skip hidden player decoy!
                if (b.offsetWidth > 0 || b.offsetHeight > 0 || b.getClientRects().length > 0) {
                  targetBtn = b;
                  break;
                }
              }
              if (targetBtn) break;
            }

            if (!targetBtn) {
              // check if one inside ytd-watch-metadata or description
              const fallbackBtns = Array.from(doc.querySelectorAll('.you-chat-entrypoint-button button, button[aria-label*="Ask" i]'));
              for (const b of fallbackBtns) {
                if (!b.closest('.html5-video-player')) {
                  targetBtn = b;
                  break;
                }
              }
            }

            if (targetBtn && !askBtnClicked) {
              targetBtn.click();
              askBtnClicked = true;
              step = 'wait_panel';
              if (onPhase) onPhase('Opening Ask panel…');
            }
          }

          // STEP 2: Wait for panel and textarea
          else if (step === 'wait_panel') {
            const panel = doc.querySelector(
              'ytd-engagement-panel-section-list-renderer[target-id="PAyouchat"][visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"], #chat-container'
            );
            const ta = doc.querySelector('textarea.chatInputViewModelChatInput, textarea[placeholder*="Ask"]');
            if (panel && ta) {
              step = 'wait_baseline';
              if (onPhase) onPhase('Waiting for Ask ready…');
            }
          }

          // STEP 3: Baseline items stability
          else if (step === 'wait_baseline') {
            const items = doc.querySelectorAll('you-chat-item-view-model, .chat-item');
            const count = items.length;
            if (baselineItems !== count) {
              baselineItems = count;
              baselineTime = Date.now();
            } else if (Date.now() - baselineTime >= 1200) {
              step = 'send_ladder';
              if (onPhase) onPhase('Sending question to Ask…');
            }
          }

          // STEP 4: Send Ladder
          else if (step === 'send_ladder') {
            const ta = doc.querySelector('textarea.chatInputViewModelChatInput, textarea[placeholder*="Ask"]');
            const form = doc.querySelector('.chatInputViewModelChatInputForm, form');
            const sendBtn = doc.querySelector('.chatInputViewModelChatInputForm button[aria-label="Send"], button[aria-label="Send"]');

            if (!ta) return;

            // Check if question appeared
            const promptLead = prompt.slice(0, 40);
            const currentItems = Array.from(doc.querySelectorAll('you-chat-item-view-model, .chat-item'));
            const questionItem = currentItems.find((it) => it.textContent.includes(promptLead));

            if (questionItem || (baselineItems >= 0 && currentItems.length > baselineItems + 1)) {
              step = 'wait_answer';
              questionSentTime = Date.now();
              lastChangeTime = Date.now();
              if (onPhase) onPhase('Ask is generating answer…');
              return;
            }

            if (!sentMethod) {
              sentMethod = 'typing';
              try {
                iframe.contentWindow?.focus();
                ta.focus();
                ta.select();
                const inserted = doc.execCommand('insertText', false, prompt);
                if (!inserted || ta.value !== prompt) {
                  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
                  if (nativeSetter) nativeSetter.call(ta, prompt);
                  else ta.value = prompt;
                  ta.dispatchEvent(new Event('input', { bubbles: true }));
                }
              } catch (_) {}
            }

            const sendEnabled = sendBtn && !sendBtn.disabled && sendBtn.getAttribute('aria-disabled') !== 'true';

            if (sentMethod === 'typing' && sendEnabled) {
              sendBtn.click();
              sentMethod = 'clicked_send';
              return;
            }

            // If 2.5s passed after typing and not sent, try input events
            if (Date.now() - (baselineTime + 1200) > 2500 && sentMethod === 'typing') {
              sentMethod = 'events';
              try {
                const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
                if (nativeSetter) nativeSetter.call(ta, prompt);
                else ta.value = prompt;
                ta.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: prompt }));
                ta.dispatchEvent(new Event('change', { bubbles: true }));
                ta.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
              } catch (_) {}
            }

            if (sentMethod === 'events' && sendEnabled) {
              sendBtn.click();
              sentMethod = 'clicked_send_events';
              return;
            }

            // Try enter keydown
            if (Date.now() - (baselineTime + 1200) > 5000 && sentMethod === 'events') {
              sentMethod = 'enter';
              ta.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13 }));
            }

            // Try form submit event (NEVER requestSubmit!)
            if (Date.now() - (baselineTime + 1200) > 7500 && sentMethod === 'enter' && !formSubmitted) {
              sentMethod = 'submit';
              formSubmitted = true;
              if (form) {
                form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
              }
            }

            // Try forced click
            if (Date.now() - (baselineTime + 1200) > 10000 && sentMethod === 'submit') {
              sentMethod = 'forced_click';
              if (sendBtn) {
                sendBtn.disabled = false;
                sendBtn.removeAttribute('aria-disabled');
                sendBtn.click();
              }
            }

            // For summary, try chips
            if (Date.now() - (baselineTime + 1200) > 12500 && isSummary && sentMethod === 'forced_click') {
              sentMethod = 'chips';
              const chips = Array.from(doc.querySelectorAll('button.ytwYouChatChipsDataChip, .chat-chip, yt-chip-cloud-chip-renderer button'));
              const sumChip = chips.find((c) => /summari[sz]e/i.test(c.textContent || ''));
              if (sumChip) {
                sumChip.click();
              }
            }

            // Timeout send ladder
            if (Date.now() - (baselineTime + 1200) > 16000) {
              clearInterval(interval);
              console.warn('Ask: could not send the prompt', {
                tried: sentMethod,
                textareaChars: ta.value.length,
                send: { disabled: sendBtn?.disabled, ariaDisabled: sendBtn?.getAttribute('aria-disabled') },
                formFound: Boolean(form),
                htmlSnippet: doc.querySelector('yt-chat-input-view-model, .chat-input-view')?.outerHTML?.slice(0, 2500)
              });
              const err = new Error(
                `Ask's Send button never became available (tried: ${sentMethod}). Details were written to the browser console. Try selecting a Gemini model.`
              );
              err.code = 'ASK';
              return reject(err);
            }
          }

          // STEP 5: Wait for answer
          else if (step === 'wait_answer') {
            if (Date.now() - questionSentTime > CONFIG.askAnswerMs) {
              clearInterval(interval);
              return reject(new Error('Ask answer generation timed out'));
            }

            const items = Array.from(doc.querySelectorAll('you-chat-item-view-model, .chat-item'));
            const promptLead = prompt.slice(0, 40);
            let qIdx = items.findIndex((it) => it.textContent.includes(promptLead));
            if (qIdx === -1 && Date.now() - questionSentTime > 8000) {
              qIdx = baselineItems >= 0 ? baselineItems : 0;
            }

            const answerItems = qIdx >= 0 ? items.slice(qIdx + 1) : items;
            let ansNode = null;
            for (let i = answerItems.length - 1; i >= 0; i--) {
              const mdDiv = answerItems[i].querySelector('markdown-div, .markdown-content');
              if (mdDiv) {
                ansNode = mdDiv;
                break;
              }
            }

            if (!ansNode && answerItems.length > 0) {
              ansNode = answerItems[answerItems.length - 1];
            }

            const isBusy = doc.querySelector('yt-item-section-renderer[data-target-id="youchat_messages_section"][aria-busy="true"]');

            if (ansNode) {
              const currentText = ansNode.innerText || ansNode.textContent || '';
              if (currentText !== lastAnswerText) {
                lastAnswerText = currentText;
                lastChangeTime = Date.now();
              } else if (currentText.length > 30 && !isBusy && Date.now() - lastChangeTime >= CONFIG.askStableMs) {
                clearInterval(interval);
                const markdown = domToMarkdown(ansNode);
                resolve({
                  text: markdown.trim(),
                  note: isSummary && sentMethod === 'chips' ? 'ℹ Used YouTube Ask summary chip (sponsor filter not applied).' : null
                });
              }
            }
          }
        }, 100);
      });

      return res;
    } finally {
      if (iframe && iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
      }
      askLimiter.release();
      if (prevActive && typeof prevActive.focus === 'function') {
        try {
          prevActive.focus();
        } catch (_) {}
      }
    }
  }

  // --- MARKDOWN RENDERER (DOM-BUILDING, NO INNERHTML) ---
  function renderMarkdownToDom(text, win, onSeek) {
    const container = h('div', { className: 'yt-markdown-body' });
    if (!text) return container;

    // Normalise visual markers onto their own lines
    const normalised = text.replace(/(\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]+\]\])/g, '\n$1\n');
    const lines = normalised.split('\n');

    let currentList = null;
    let listType = null;
    let visualCount = 0;
    let genCount = 0;

    function flushList() {
      if (currentList) {
        container.appendChild(currentList);
        currentList = null;
        listType = null;
      }
    }

    function parseInline(str) {
      const frag = document.createDocumentFragment();
      const formatted = formatMathSymbolsInText(str || '');
      // Match inline tokens: bold, italic, code, link, timestamp [mm:ss]
      const tokenRegex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]|\[([^\]]+)\]\((https?:\/\/[^\s)]+)\))/g;
      let lastIdx = 0;
      let match;

      while ((match = tokenRegex.exec(formatted)) !== null) {
        if (match.index > lastIdx) {
          frag.appendChild(document.createTextNode(formatted.slice(lastIdx, match.index)));
        }
        const full = match[0];
        if (full.startsWith('**') && full.endsWith('**')) {
          frag.appendChild(h('strong', {}, full.slice(2, -2)));
        } else if (full.startsWith('*') && full.endsWith('*')) {
          frag.appendChild(h('em', {}, full.slice(1, -1)));
        } else if (full.startsWith('`') && full.endsWith('`')) {
          frag.appendChild(h('code', {}, full.slice(1, -1)));
        } else if (match[2] !== undefined || (match[3] !== undefined && match[4] !== undefined)) {
          // Timestamp [mm:ss] or [h:mm:ss]
          const tsText = full.slice(1, -1);
          const parts = tsText.split(':').map(Number);
          let sec = 0;
          if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
          else sec = parts[0] * 60 + parts[1];

          const a = h(
            'a',
            {
              className: 'yt-ts-link',
              href: `/watch?v=${encodeURIComponent(win.videoId)}&t=${sec}s`,
              title: `Jump to ${tsText}`,
              onclick: (e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  if (onSeek) onSeek(sec);
                }
              }
            },
            full
          );
          frag.appendChild(a);
        } else if (match[5] && match[6]) {
          // Link [text](url)
          frag.appendChild(
            h(
              'a',
              {
                href: match[6],
                target: '_blank',
                rel: 'noopener noreferrer',
                className: 'yt-ext-link'
              },
              match[5]
            )
          );
        }
        lastIdx = tokenRegex.lastIndex;
      }

      if (lastIdx < formatted.length) {
        frag.appendChild(document.createTextNode(formatted.slice(lastIdx)));
      }
      return frag;
    }

    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const trimmed = rawLine.trim();

      if (!trimmed) {
        flushList();
        continue;
      }

      // Check for visual markers
      const frameMatch = /^\[\[FRAME\s+((?:(\d{1,2}):)?(\d{1,2}):(\d{2}))(?:\s*\|\s*([^\]]*))?\]\]$/i.exec(trimmed);
      if (frameMatch && win.opts.img && visualCount < CONFIG.maxVisuals) {
        flushList();
        visualCount++;
        const tsText = frameMatch[1];
        const caption = frameMatch[5] || `Video frame at ${tsText}`;
        const parts = tsText.split(':').map(Number);
        let sec = 0;
        if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
        else sec = parts[0] * 60 + parts[1];

        const card = h('div', { className: 'yt-visual-card yt-frame-card' });
        const previewBox = h('div', {
          className: 'yt-frame-preview',
          title: `Play at ${tsText}`,
          onclick: () => onSeek && onSeek(sec)
        });
        const badge = h('div', { className: 'yt-frame-badge' }, `▶ ${tsText}`);
        previewBox.appendChild(badge);
        card.appendChild(previewBox);
        card.appendChild(h('div', { className: 'yt-visual-caption' }, caption));
        container.appendChild(card);

        // Load storyboard sprite
        fetchStoryboardSpec(win.videoId).then((cfg) => {
          if (!cfg) {
            previewBox.style.background = '#222';
            return;
          }
          const info = getFrameUrlAndOffset(cfg, sec);
          previewBox.style.backgroundImage = `url("${info.url}")`;
          previewBox.style.backgroundPosition = `-${info.x}px -${info.y}px`;
          previewBox.style.width = '100%';
          previewBox.style.aspectRatio = '16/9';
          previewBox.style.backgroundSize = 'cover';
        });
        continue;
      }

      const imgMatch = /^\[\[IMG\s+([^|\]]+)(?:\s*\|\s*([^\]]*))?\]\]$/i.exec(trimmed);
      if (imgMatch && win.opts.img && visualCount < CONFIG.maxVisuals) {
        flushList();
        visualCount++;
        const terms = imgMatch[1].trim();
        const caption = imgMatch[2] ? imgMatch[2].trim() : terms;

        const card = h('div', { className: 'yt-visual-card yt-commons-card' });
        const imgWrap = h('div', { className: 'yt-commons-loading' }, 'Loading Commons illustration…');
        card.appendChild(imgWrap);
        const captionEl = h('div', { className: 'yt-visual-caption' }, caption);
        card.appendChild(captionEl);
        container.appendChild(card);

        searchCommons(terms).then((res) => {
          if (!res) {
            card.remove();
            return;
          }
          clearEl(imgWrap);
          imgWrap.className = 'yt-commons-img-wrap';
          const img = h('img', {
            src: res.thumbUrl,
            alt: caption,
            className: 'yt-commons-img',
            onclick: () => window.open(res.fileUrl, '_blank')
          });
          imgWrap.appendChild(img);
          clearEl(captionEl);
          captionEl.appendChild(document.createTextNode(caption + ' — '));
          captionEl.appendChild(
            h(
              'a',
              { href: res.fileUrl, target: '_blank', rel: 'noopener noreferrer' },
              `${res.artist} (${res.license})`
            )
          );
        });
        continue;
      }

      const aiImageMatch = /^\[\[IMAGE\s+(\d+)(?:\s*\|\s*([^\]]*))?\]\]$/i.exec(trimmed);
      if (aiImageMatch && win.images && win.images['i' + aiImageMatch[1]]) {
        flushList();
        const imgData = win.images['i' + aiImageMatch[1]];
        const caption = aiImageMatch[2] || imgData.prompt || 'AI-generated illustration';
        const card = h('div', { className: 'yt-visual-card yt-ai-image-card' });
        const img = h('img', {
          src: imgData.url,
          alt: caption,
          className: 'yt-ai-img',
          onclick: () => window.open(imgData.url, '_blank')
        });
        card.appendChild(img);
        const modelName = CONFIG.imageModelNames[imgData.model] || imgData.model || 'Nano Banana';
        card.appendChild(h('div', { className: 'yt-visual-caption' }, `${caption} [AI-generated illustration (${modelName}) · may contain inaccuracies]`));
        container.appendChild(card);
        continue;
      }

      // Ignore GEN markers in final render (they were already converted to AI images)
      if (/^\[\[GEN\s+/i.test(trimmed)) {
        continue;
      }

      // Headings
      if (trimmed.startsWith('#')) {
        flushList();
        const level = (trimmed.match(/^#+/) || [''])[0].length;
        const text = trimmed.slice(level).trim();
        const hTag = level <= 2 ? 'h3' : 'h4';
        container.appendChild(h(hTag, { className: `yt-md-${hTag}` }, parseInline(text)));
        continue;
      }

      // Horizontal Rule
      if (/^[-*_]{3,}$/.test(trimmed)) {
        flushList();
        container.appendChild(h('hr', { className: 'yt-md-hr' }));
        continue;
      }

      // Lists
      const listMatch = /^(\s*)([-*•]|\d+\.)\s+(.+)$/.exec(rawLine);
      if (listMatch) {
        const indent = listMatch[1].length;
        const bullet = listMatch[2];
        const itemContent = listMatch[3];
        const isNum = /\d+\./.test(bullet);

        if (!currentList || (listType === 'ol') !== isNum) {
          flushList();
          listType = isNum ? 'ol' : 'ul';
          currentList = h(listType, { className: 'yt-md-list' });
        }

        const li = h('li', { className: indent >= 2 ? 'yt-md-nested-li' : '' }, parseInline(itemContent));
        currentList.appendChild(li);
        continue;
      }

      // Regular paragraph
      flushList();
      container.appendChild(h('p', { className: 'yt-md-p' }, parseInline(trimmed)));
    }

    flushList();
    return container;
  }

  // --- FACT-CHECK PASS (§10) ---
  async function runFactCheckPass(win, summaryText, { keyObj, modelId = '' } = {}) {
    const key = keyObj?.key;
    if (!key) throw new Error('No API key provided for fact check');

    // Build candidate list with automatic fallback
    const candidateModels = [];
    if (modelId) candidateModels.push(modelId);
    else if (win.opts.factModel) candidateModels.push(win.opts.factModel);

    const available = (await checkModelsForKey(keyObj)) || [];
    for (const pref of CONFIG.factPreferred) {
      if ((available.length === 0 || available.includes(pref) || available.includes(pref + '-preview')) && !candidateModels.includes(pref)) {
        candidateModels.push(pref);
      }
    }
    if (win.modelId && !win.modelId.includes('Ask') && !candidateModels.includes(win.modelId)) {
      candidateModels.push(win.modelId);
    }
    if (!candidateModels.includes(CONFIG.defaultModel)) {
      candidateModels.push(CONFIG.defaultModel);
    }

    const clippedSummary = summaryText.slice(0, 30000);
    const prompt = `You are checking a summary of a YouTube video titled "${win.title}".
Use Google Search. Sections:
${win.opts.fc ? '## Fact-check\n(claims with [MM:SS], verdicts ✅ Supported / ⚠️ Partly true / ❌ Contradicted / ❓ Unverifiable, 1–2 sentences evidence; skip opinions)\n' : ''}
${win.opts.src ? '## Further reading\n(3–8 authoritative links as Markdown links)\n' : ''}
Only URLs from search results. Do not repeat the summary.

SUMMARY TO CHECK:
"""
${clippedSummary}
"""`;

    const body = {
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      tools: [{ google_search: {} }]
    };

    let res = null;
    let targetModel = candidateModels[0] || CONFIG.defaultModel;
    let lastErr = null;

    for (const model of candidateModels) {
      try {
        res = await callGeminiRaw(model, key, body);
        targetModel = model;
        break;
      } catch (err) {
        lastErr = err;
        if (CONFIG.debug) {
          console.warn(`[YTAIS] Fact check on ${model} failed, trying next:`, err.message || err);
        }
      }
    }

    if (!res) {
      throw lastErr || new Error('Fact check failed across available models');
    }

    const candidate = res.candidates?.[0];
    const text = candidate?.content?.parts?.map((p) => p.text || '').join('') || '';

    const sources = [];
    if (candidate?.groundingMetadata?.groundingChunks) {
      for (const c of candidate.groundingMetadata.groundingChunks) {
        if (c.web?.uri) {
          sources.push({ uri: c.web.uri, title: c.web.title || c.web.uri });
        }
      }
    }

    // Dedupe sources
    const seen = new Set();
    const uniqueSources = [];
    for (const s of sources) {
      if (!seen.has(s.uri)) {
        seen.add(s.uri);
        uniqueSources.push(s);
      }
    }

    return {
      text,
      sources: uniqueSources,
      model: targetModel,
      ts: Date.now()
    };
  }

  // --- INDEPENDENT VISUAL COORDINATOR PASS ---
  // Coordinates video frame screenshots, Wikimedia Commons diagrams, and AI illustration prompts
  // to illustrate summaries (especially YouTube Ask summaries which have no native visual capabilities).
  async function coordinateVisualsForSummary(win, summaryText, keyObj, job) {
    if (!summaryText || !keyObj?.key) return { text: summaryText };
    const key = keyObj.key;

    const available = (await checkModelsForKey(keyObj)) || [];
    let modelToUse = CONFIG.defaultModel;
    if (available.length > 0 && !available.includes(modelToUse) && !available.includes(modelToUse + '-preview')) {
      modelToUse = available.find((m) => CONFIG.textModels.includes(m)) || available[0] || CONFIG.defaultModel;
    }

    const prompt = `You are an expert visual coordinator enriching a YouTube video summary titled "${win.title}".
YouTube Ask produced the summary below, but YouTube Ask cannot show images.
Analyze the summary and identify up to 5 key moments and concepts that strongly benefit from visual accompaniment:

1. VIDEO FRAMES / SCREENSHOTS:
For moments where the video itself demonstrated a diagram, graph, chart, slide, software demo, physical hardware, or map, insert:
[[FRAME MM:SS | Descriptive caption of what is shown in the video]]
Use timestamps matching the video's timeline discussed in that paragraph (e.g. [[FRAME 02:45 | Architecture diagram of the system]]).

2. SEARCH IMAGES & DIAGRAMS (from Wikimedia Commons / web search):
For core concepts, scientific principles, circuit topologies, or entities where an authoritative reference diagram or photo exists, insert:
[[IMG generic search query | Descriptive caption]]
Use clear, generic English search terms (e.g. [[IMG solar cell layer structure | Perovskite silicon tandem cell layers]]).

${win.opts.gen ? `3. AI GENERATED ILLUSTRATIONS (Nano Banana):
For abstract concepts or complex mechanisms needing a clean custom diagram, insert:
[[GEN clean flat educational diagram of ... | Descriptive caption]] (max 2)` : ''}

SUMMARY TO ENRICH:
"""
${summaryText.slice(0, 30000)}
"""

INSTRUCTIONS:
- Insert the visual markers on their own separate lines directly AFTER the paragraph they illustrate.
- Preserve all existing headings, text, and bullet points verbatim. Do not delete or summarize the text.
- Do NOT place more than 5 total visual markers.
- Return the full summary with the markers inserted.`;

    const body = {
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.2
      }
    };

    const res = await callGeminiRaw(modelToUse, key, body, 120000);
    const candidate = res.candidates?.[0];
    const enrichedText = candidate?.content?.parts?.map((p) => p.text || '').join('') || '';

    if (
      enrichedText.trim() &&
      (enrichedText.includes('[[FRAME') ||
        enrichedText.includes('[[IMG') ||
        enrichedText.includes('[[GEN') ||
        enrichedText.includes('[[IMAGE'))
    ) {
      return {
        text: enrichedText.trim(),
        note: `ℹ Visuals & diagrams coordinated by ${modelToUse}`
      };
    }

    return { text: summaryText };
  }

  // --- AI STUDIO NEURAL TTS PIPELINE ---
  const ttsAudioCache = createBoundedMap(30);

  async function generateAiSpeech(cleanText, voiceName, keyObj) {
    const key = keyObj?.key;
    if (!key) throw new Error('No API key configured for AI Studio TTS');

    const cacheKey = `${voiceName || 'Kore'}:${cleanText.slice(0, 300)}`;
    if (ttsAudioCache.has(cacheKey)) {
      return ttsAudioCache.get(cacheKey);
    }

    const clippedText = cleanText.slice(0, 6000);
    const body = {
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: clippedText,
              speechMetadata: {
                style: 'Natural, clear and engaging narrator'
              }
            }
          ]
        }
      ],
      generationConfig: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' }
          }
        }
      }
    };

    const res = await callGeminiRaw(CONFIG.ttsModel, key, body, 60000);
    const candidate = res.candidates?.[0];
    const audioData =
      candidate?.content?.parts?.[0]?.inlineData?.data ||
      candidate?.content?.parts?.[0]?.inline_data?.data;
    if (!audioData) {
      throw new Error('No audio returned from AI Studio TTS');
    }

    const dataUrl = `data:audio/wav;base64,${audioData}`;
    ttsAudioCache.set(cacheKey, dataUrl);
    return dataUrl;
  }

  // --- AI IMAGES GENERATION PIPELINE (§10) ---
  async function generateAiImages(win, summaryText, keyObj) {
    const key = keyObj?.key;
    if (!key) return { summaryText, images: {} };

    // Extract [[GEN prompt | caption]]
    const genRegex = /\[\[GEN\s+([^|\]]+)(?:\s*\|\s*([^\]]*))?\]\]/gi;
    const prompts = [];
    let match;
    while ((match = genRegex.exec(summaryText)) !== null && prompts.length < CONFIG.maxGenImages) {
      prompts.push({
        full: match[0],
        prompt: match[1].trim(),
        caption: match[2] ? match[2].trim() : match[1].trim()
      });
    }

    if (!prompts.length) return { summaryText, images: {} };

    // Determine image model hierarchy
    let chosenModel = win.opts.imgModel;
    if (!chosenModel) {
      const textM = (win.modelId || '').toLowerCase();
      if (textM.includes('pro')) chosenModel = CONFIG.imageModels[0];
      else if (textM.includes('lite')) chosenModel = CONFIG.imageModels[3];
      else chosenModel = CONFIG.imageModels[1];
    }

    const available = (await checkModelsForKey(keyObj)) || [];
    const modelsToTry = [chosenModel];
    if (win.opts.fallback) {
      const idx = CONFIG.imageModels.indexOf(chosenModel);
      if (idx !== -1) {
        for (let i = idx + 1; i < CONFIG.imageModels.length; i++) {
          modelsToTry.push(CONFIG.imageModels[i]);
        }
      }
    }

    const validModels = modelsToTry.filter(
      (m) => available.length === 0 || available.includes(m) || available.includes(m + '-preview')
    );
    if (!validModels.length) validModels.push(chosenModel);

    const images = {};
    const placedImages = [];

    for (let i = 0; i < prompts.length; i++) {
      const p = prompts[i];
      const imgKey = 'i' + (i + 1);
      const enhancedPrompt = `Create a clean, clear, accurate illustration. ${p.prompt}`;
      let imageData = null;
      let usedModel = '';

      for (const model of validModels) {
        try {
          const body = {
            contents: [{ role: 'user', parts: [{ text: enhancedPrompt }] }],
            generationConfig: {
              responseModalities: win.opts.imgOut === 'image' ? ['IMAGE'] : ['TEXT', 'IMAGE']
            }
          };
          if (win.opts.imgAspect) {
            body.generationConfig.imageConfig = { aspectRatio: win.opts.imgAspect };
          }
          if (win.opts.imgSearch) {
            body.tools = [{ google_search: { searchTypes: { webSearch: {}, imageSearch: {} } } }];
          }

          const res = await callGeminiRaw(model, key, body, 60000);
          const parts = res.candidates?.[0]?.content?.parts || [];
          for (const part of parts) {
            if (part.inlineData || part.inline_data) {
              const inline = part.inlineData || part.inline_data;
              imageData = `data:${inline.mimeType || inline.mime_type || 'image/jpeg'};base64,${inline.data}`;
              usedModel = model;
              break;
            }
          }
          if (imageData) break;
        } catch (genErr) {
          // Fallback to Interactions API
          try {
            const intBody = {
              input: [{ type: 'text', text: enhancedPrompt }],
              response_format: { type: 'image', mime_type: 'image/jpeg' }
            };
            const intRes = await callInteractionsRaw(model, key, intBody, 60000);
            if (intRes?.output) {
              for (const out of intRes.output) {
                if (out.type === 'image' && out.data) {
                  imageData = `data:${out.mime_type || 'image/jpeg'};base64,${out.data}`;
                  usedModel = model;
                  break;
                }
              }
            }
            if (imageData) break;
          } catch (_) {}
        }
      }

      if (imageData) {
        images[imgKey] = { url: imageData, model: usedModel, prompt: p.caption };
        placedImages.push({ index: i + 1, caption: p.caption, dataUrl: imageData });
      }
    }

    if (!placedImages.length) {
      // Strip [[GEN ...]] markers
      const cleaned = summaryText.replace(genRegex, '');
      return { summaryText: cleaned, images: {} };
    }

    // Call Gemini to get placements
    let newSummary = summaryText;
    try {
      const placementPrompt = `You are placing AI-generated illustrations into a summary.
Summary:
"""
${summaryText.replace(genRegex, '')}
"""

Images created:
${placedImages.map((img) => `Image ${img.index}: ${img.caption}`).join('\n')}

Return JSON with exact placement instructions:
{"placements":[{"image":1,"after":"<25-80 verbatim characters from the summary where this image belongs>","caption":"..."}]}`;

      const placeRes = await callGeminiRaw(
        win.modelId || CONFIG.defaultModel,
        key,
        {
          contents: [{ role: 'user', parts: [{ text: placementPrompt }] }],
          generationConfig: { responseMimeType: 'application/json' }
        },
        30000
      );

      const placeJsonText = placeRes.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      const parsed = JSON.parse(placeJsonText);
      let workSummary = summaryText.replace(genRegex, '');

      if (parsed.placements && Array.isArray(parsed.placements)) {
        for (const pl of parsed.placements) {
          const afterSnippet = (pl.after || '').trim();
          const marker = `\n\n[[IMAGE ${pl.image} | ${pl.caption || ''}]]\n\n`;
          if (afterSnippet && workSummary.includes(afterSnippet)) {
            const idx = workSummary.indexOf(afterSnippet) + afterSnippet.length;
            workSummary = workSummary.slice(0, idx) + marker + workSummary.slice(idx);
          } else {
            workSummary += marker;
          }
        }
        newSummary = workSummary;
      }
    } catch (_) {
      // Fallback: append at end
      let cleaned = summaryText.replace(genRegex, '');
      for (const img of placedImages) {
        cleaned += `\n\n[[IMAGE ${img.index} | ${img.caption}]]\n\n`;
      }
      newSummary = cleaned;
    }

    return { summaryText: newSummary, images };
  }

  // --- RETRY & FALLBACK POLICY ENGINE (§9) ---
  function getNextModelDown(currentModel, availableKeysModels = []) {
    const ladder = CONFIG.fallbackLadder;
    const isAsk = String(currentModel || '').toLowerCase().includes('ask');
    let startIdx = 0;
    if (!isAsk) {
      let idx = ladder.indexOf(currentModel);
      if (idx === -1) {
        // Find first non-pro
        idx = ladder.findIndex((m) => !m.includes('pro'));
        if (idx === -1) idx = 0;
      }
      startIdx = idx + 1;
    }
    for (let i = startIdx; i < ladder.length; i++) {
      const candidate = ladder[i];
      if (
        availableKeysModels.length === 0 ||
        availableKeysModels.includes(candidate) ||
        availableKeysModels.includes(candidate + '-preview')
      ) {
        return candidate;
      }
    }
    return null;
  }

  async function runPolicy(win, job, makeSpec, { retries = 0, fallback = false, startModel = '' } = {}) {
    const keyObj = getStoredKeys().find((k) => k.id === win.keyId) || getStoredKeys()[0];
    if (!keyObj) {
      const err = new Error('No API key configured');
      err.code = 'NO_KEY';
      throw err;
    }

    const available = (await checkModelsForKey(keyObj)) || [];
    let curModel = startModel || win.modelId || CONFIG.defaultModel;
    const triedModels = new Set();
    const notes = [];

    while (curModel && !job.cancelled) {
      triedModels.add(curModel);
      let modelSucceeded = false;
      let lastErr = null;

      for (let attempt = 0; attempt <= retries && !job.cancelled; attempt++) {
        if (attempt > 0) {
          win.phase = `Retrying (${attempt}/${retries})`;
          win.renderStatus();
          const delay = Math.min(60000, lastErr?.retryMs || 2500 * attempt);
          await new Promise((r) => setTimeout(r, delay));
        }

        try {
          win.phase = `Trying ${curModel}`;
          win.renderStatus();
          const spec = makeSpec(curModel, keyObj.key);
          const result = await callGeminiWithDrops(curModel, keyObj.key, spec.makeBody, {
            requireTools: spec.requireTools,
            onDrop: (item, reason) => {
              notes.push(`ℹ ${curModel} skipped: ${item}${reason ? ` (${reason})` : ''}`);
            }
          });
          modelSucceeded = true;
          return { res: result.res, model: curModel, notes };
        } catch (err) {
          lastErr = err;
          if (err.code === 'NO_KEY' || (err.message && err.message.toLowerCase().includes('api key'))) {
            throw err;
          }
          if (err.status === 404 || err.status === 403 || (err.retryMs && err.retryMs > 60000)) {
            break; // not retryable on this model
          }
        }
      }

      if (lastErr) {
        const firstLine = (lastErr.message || 'unknown error').split('\n')[0];
        notes.push(`⚠ ${curModel} failed: ${firstLine}`);
      }

      if (fallback) {
        const next = getNextModelDown(curModel, available);
        if (next && !triedModels.has(next)) {
          curModel = next;
          continue;
        }
      }

      if (lastErr) {
        lastErr.notes = notes;
        throw lastErr;
      }
      break;
    }

    throw new Error('All models exhausted');
  }

  // --- CORE PRODUCER FUNCTION (§7) ---
  async function produce(win, job) {
    win.status = 'loading';
    win.busy = true;
    win.errMsg = '';
    win.errCode = '';
    win.notes = Array.isArray(win.notes) ? win.notes.slice() : [];
    win.owner = TAB_ID;
    win.jobId = job.id;
    win.hb = Date.now();
    win.commit(false);

    try {
      let askFallbackUsed = false;

      // Ask provider
      if (win.modelId.includes('Ask')) {
        win.source = 'video';
        win.phase = 'Running YouTube Ask…';
        win.renderStatus();
        try {
          const res = await runYouTubeAsk(win.videoId, win.buildSummaryPrompt(), {
            isSummary: true,
            signal: job.abortController.signal,
            onPhase: (p) => {
              win.phase = p;
              win.renderStatus();
            }
          });
          if (job.cancelled) return;

          win.text = res.text;
          if (res.note) win.notes.push(res.note);

          // Independent Visual Coordinator Pass:
          // Coordinate video frames/screenshots, search diagrams, and AI illustrations
          const keyObj = getStoredKeys().find((k) => k.id === win.keyId) || getStoredKeys()[0];
          if ((win.opts.img || win.opts.gen) && keyObj?.key) {
            try {
              win.phase = 'Coordinating video frames & diagrams…';
              win.renderStatus();
              const coordRes = await coordinateVisualsForSummary(win, win.text, keyObj, job);
              if (coordRes?.text) {
                win.text = coordRes.text;
                if (coordRes.note) win.notes.push(coordRes.note);
              }
            } catch (coordErr) {
              if (CONFIG.debug) console.warn('[YTAIS] Visual coordination failed:', coordErr);
              win.notes.push(`ℹ Visual coordination skipped: ${coordErr.message || 'model unavailable'}`);
            }

            // If AI images are enabled and GEN markers were placed, generate illustrations
            if (win.opts.gen && /\[\[GEN\s+/i.test(win.text)) {
              try {
                win.phase = 'Generating illustrations (Nano Banana)…';
                win.renderStatus();
                const aiRes = await generateAiImages(win, win.text, keyObj);
                win.text = aiRes.summaryText;
                win.images = aiRes.images;
              } catch (imgErr) {
                if (CONFIG.debug) console.warn('[YTAIS] Image generation failed:', imgErr);
              }
            }
          } else if ((win.opts.img || win.opts.gen) && !keyObj?.key) {
            win.notes.push('ℹ Visuals & diagrams for YouTube Ask are coordinated by an independent Gemini model. Add an API key (⚙ in toolbar) to enable video frames and illustrations.');
          }

          win.onDone();
          return;
        } catch (askErr) {
          if (job.cancelled || job.abortController.signal.aborted) return;

          const keyObj = getStoredKeys().find((k) => k.id === win.keyId) || getStoredKeys()[0];
          if (!keyObj || !keyObj.key) {
            throw askErr;
          }

          const available = (await checkModelsForKey(keyObj)) || [];
          const nextModel = getNextModelDown(win.modelId, available);
          if (!nextModel) {
            throw askErr;
          }

          const firstLine = (askErr.message || 'YouTube Ask failed').split('\n')[0];
          win.notes.push(`⚠ YouTube Ask failed (${firstLine}). Automatically proceeding with ${nextModel}.`);
          win.modelId = nextModel;
          askFallbackUsed = true;
          win.phase = `YouTube Ask failed — falling back to ${nextModel}…`;
          win.commit(false);
          win.renderAll();
          win.renderStatus();
        }
      }

      // Transcript source
      let transcriptText = '';
      if (win.source === 'text') {
        win.phase = 'Fetching YouTube transcript…';
        win.renderStatus();
        transcriptText = await getTranscriptText(win.videoId, win.opts.retries, job.abortController.signal);
        if (job.cancelled) return;

        if (win.mode === 'transcript') {
          // Transcribe + Transcript mode: Return straight from captions, NO AI CALL!
          win.text = `## Transcript (YouTube captions)\n\n` + transcriptText;
          win.notes.push("Taken straight from YouTube's captions… No AI was involved.");
          win.onDone();
          return;
        }
      }

      // Gemini Pipeline
      const makeSpec = (model, key) => {
        return {
          requireTools: false,
          makeBody: ({ dropMediaRes, dropThink, dropTools }) => {
            const prompt = win.mode === 'transcript' ? win.buildTranscriptPrompt() : win.buildSummaryPrompt();
            const parts = [];

            if (win.source === 'video') {
              parts.push({ file_data: { file_uri: `https://www.youtube.com/watch?v=${win.videoId}` } });
              parts.push({ text: prompt });
            } else {
              parts.push({ text: prompt + '\n\nTRANSCRIPT:\n' + transcriptText });
            }

            const body = { contents: [{ role: 'user', parts }] };
            if (win.mode !== 'transcript') {
              body.systemInstruction = { parts: [{ text: win.getSystemInstruction() }] };
            }
            const genConfig = {};

            if (win.source === 'video' && !dropMediaRes) {
              const res = win.opts.mres || (CONFIG.lowMediaResolution ? 'MEDIA_RESOLUTION_LOW' : '');
              if (res) genConfig.mediaResolution = res;
            }

            if (!dropThink && win.opts.think) {
              genConfig.thinkingConfig = { thinkingLevel: win.opts.think };
            }

            if (Object.keys(genConfig).length > 0) {
              body.generationConfig = genConfig;
            }

            if (!dropTools && win.mode !== 'transcript') {
              const tools = [];
              if (win.opts.gsearch) tools.push({ google_search: {} });
              if (win.opts.gmaps) tools.push({ google_maps: {} });
              if (win.opts.code) tools.push({ code_execution: {} });
              if (tools.length > 0) body.tools = tools;
            }

            return body;
          }
        };
      };

      let policyRes;
      try {
        policyRes = await runPolicy(win, job, makeSpec, {
          retries: win.mode === 'transcript' ? win.opts.retries : 0,
          fallback: win.opts.fallback || askFallbackUsed,
          startModel: win.modelId
        });
      } catch (err) {
        // Video limit quota fallback
        if (
          win.source === 'video' &&
          win.opts.txFallback &&
          err.code === 'QUOTA' &&
          /video|hour|youtube/i.test(err.message + ' ' + (err.violations || []).join(' '))
        ) {
          win.source = 'text';
          win.notes.push('The video-input limit was reached, so the transcript was used instead.');
          return produce(win, job);
        }
        throw err;
      }

      if (job.cancelled) return;

      const candidate = policyRes.res.candidates?.[0];
      let answerText = candidate?.content?.parts?.map((p) => p.text || '').join('') || '';

      if (!answerText.trim()) {
        throw new Error('Returned no answer — video may be private, age-restricted, live, or too long');
      }

      win.text = answerText;
      if (policyRes.notes) win.notes.push(...policyRes.notes);
      win.modelId = policyRes.model;

      // Dedupe web sources
      win.sources = [];
      if (candidate?.groundingMetadata?.groundingChunks) {
        for (const c of candidate.groundingMetadata.groundingChunks) {
          if (c.web?.uri) {
            win.sources.push({ uri: c.web.uri, title: c.web.title || c.web.uri });
          }
        }
      }

      // Handle AI Images
      if (win.opts.gen && win.mode === 'summary') {
        win.phase = 'Generating illustrations (Nano Banana)…';
        win.renderStatus();
        const keyObj = getStoredKeys().find((k) => k.id === win.keyId) || getStoredKeys()[0];
        const aiRes = await generateAiImages(win, win.text, keyObj);
        win.text = aiRes.summaryText;
        win.images = aiRes.images;
      }

      win.onDone();
    } catch (err) {
      if (job.cancelled) return;
      win.status = 'error';
      win.busy = false;
      win.errMsg = err.message || 'Unknown error occurred';
      win.errCode = err.code || 'UNKNOWN';
      if (err.notes) win.notes.push(...err.notes);
      win.commit(false);
      win.renderAll();
    }
  }

  // --- WINDOW CONTROLLER & UI CLASS (§6) ---
  const activeWindows = new Map(); // videoId -> SummaryWindow instance
  let maximizedWindow = null;
  let topWindowZIndex = 10;
  let shadowRoot = null;
  let dockContainer = null;
  let modalsContainer = null;

  function getOpenWindows() {
    return Array.from(activeWindows.values()).filter((w) => w.isOpen);
  }

  class SummaryWindow {
    constructor(videoId, title, initialMeta = {}) {
      this.videoId = videoId;
      this.title = title || 'YouTube Video';
      this.created = initialMeta.created || Date.now();
      this.mode = initialMeta.mode || 'summary';
      this.source = initialMeta.source || getLastSource();
      this.status = initialMeta.status || 'idle';
      this.busy = Boolean(initialMeta.busy);
      this.owner = initialMeta.owner || null;
      this.hb = initialMeta.hb || 0;
      this.jobId = initialMeta.jobId || null;
      this.unread = Boolean(initialMeta.unread);
      this.errMsg = initialMeta.errMsg || '';
      this.errCode = initialMeta.errCode || '';
      this.modelId = initialMeta.modelId || getLastModel();
      this.keyId = initialMeta.keyId || getLastKeyId() || (getStoredKeys()[0]?.id || '');
      this.opts = Object.assign({}, getGlobalOpts(), initialMeta.opts || {});
      this.phase = '';
      this.notes = initialMeta.notes || [];

      // Multi-window floating position, z-order & responsive state
      this.isOpen = Boolean(initialMeta.isOpen);
      this.zIndex = typeof initialMeta.zIndex === 'number' ? initialMeta.zIndex : ++topWindowZIndex;
      const openCount = getOpenWindows().length;
      const savedBounds = initialMeta.bounds || getLastWindowBounds();
      const viewport = {
        width: typeof window !== 'undefined' ? window.innerWidth : 1280,
        height: typeof window !== 'undefined' ? window.innerHeight : 800
      };
      this.bounds = computeDefaultWindowBounds(viewport, openCount, savedBounds ? { width: savedBounds.width, height: savedBounds.height } : null);
      this.sizeTier = classifyWindowSizeTier(this.bounds.width);
      this.compactOptionsOpen = false;
      this._resizeObserver = null;
      this._interactionCleanup = [];
      this.winOverflowMenuEl = null;

      // Cached content
      this.text = '';
      this.sources = [];
      this.turns = [];
      this.images = {};
      this.fact = null;
      this.cacheDate = null;

      // DOM Elements
      this.dockTab = null;
      this.modalScrim = null;
      this.windowBox = null;
      this.bodyEl = null;
      this.playerSlot = null;
      this.playerIframe = null;
      this.composerTa = null;
      this.composerBtn = null;
      this.currentJob = null;

      // Text-to-Speech (TTS) State
      this.ttsState = 'idle'; // 'idle' | 'loading' | 'playing' | 'paused'
      this.ttsRate = typeof initialMeta.ttsRate === 'number' ? initialMeta.ttsRate : getLastTtsRate();
      this.ttsVolume = typeof initialMeta.ttsVolume === 'number' ? initialMeta.ttsVolume : getLastTtsVolume();
      this.ttsPitch = typeof initialMeta.ttsPitch === 'number' ? initialMeta.ttsPitch : getLastTtsPitch();
      this.ttsVoice = initialMeta.ttsVoice || getLastTtsVoice();
      this.channel = initialMeta.channel || '';
      this.ttsUtterance = null;
      this.ttsAudioEl = null;
      this.ttsPlayBtn = null;
      this.ttsStopBtn = null;
      this.ttsRateBtn = null;
      this.ttsSpeedWrap = null;
      this.ttsSpeedBtns = [];
      this.ttsSpeedSlider = null;
      this.ttsSpeedLabel = null;
      this.ttsVolumeWrap = null;
      this.ttsVolumeSlider = null;
      this.ttsVolumeLabel = null;
      this.ttsPitchWrap = null;
      this.ttsPitchSlider = null;
      this.ttsPitchLabel = null;
      this.ttsVoiceSelect = null;
      this.ttsRewindBtn = null;
      this.ttsSkipBtn = null;
      this.ttsSkipSilenceBtn = null;
      this.skipSilence = typeof this.opts.skipSilence === 'boolean' ? this.opts.skipSilence : true;
      this.ttsSentenceIndex = 0;
      this._ttsFeedbackTimer = null;
      this._prevTtsVolume = 1.0;

      // Real-time Audio Waveform Visualizer
      this.ttsWaveformWrap = null;
      this.ttsWaveformCanvas = null;
      this.ttsWaveformBars = [];
      this.waveformAnimId = null;
      this.ttsBoundaryPulse = 0;

      // Transcript Search & Keyword Jump State
      this.transcriptSearchQuery = '';
      this.transcriptFilterOnly = false;
      this.transcriptMatchIdx = 0;
      this.transcriptMatchCount = 0;
      this.transcriptMarks = [];
      this.transcriptSearchInput = null;
      this.transcriptCountEl = null;
      this.transcriptClearBtn = null;

      // Readability Mode & Export State
      this.readabilityMode = Boolean(initialMeta.readabilityMode);
      this.readabilityFont = initialMeta.readabilityFont || 'serif';
      this.syncYouTubeTheme = initialMeta.syncYouTubeTheme !== undefined ? Boolean(initialMeta.syncYouTubeTheme) : getLastSyncYouTubeTheme();
      if (this.syncYouTubeTheme) {
        this.readabilityTheme = detectYouTubeTheme();
      } else {
        this.readabilityTheme = initialMeta.readabilityTheme || getLastReadabilityTheme() || 'system';
      }
      this.readabilitySize = typeof initialMeta.readabilitySize === 'number' ? initialMeta.readabilitySize : 17;
      this.readabilityContainer = null;
      this.exportMenuEl = null;
      this.ytThemeObserver = null;
      if (this.readabilityMode && this.syncYouTubeTheme) {
        this.setupYouTubeThemeObserver();
      }

      activeWindows.set(this.videoId, this);
      this.createDockTab();
    }

    toRecord() {
      return {
        videoId: this.videoId,
        title: this.title,
        created: this.created,
        mode: this.mode,
        source: this.source,
        status: this.status,
        busy: this.busy,
        owner: this.owner,
        hb: this.hb,
        jobId: this.jobId,
        unread: this.unread,
        errMsg: this.errMsg,
        errCode: this.errCode,
        modelId: this.modelId,
        keyId: this.keyId,
        opts: this.opts,
        notes: this.notes,
        isOpen: this.isOpen,
        zIndex: this.zIndex,
        bounds: this.bounds,
        ttsVoice: this.ttsVoice,
        ttsVolume: this.ttsVolume,
        ttsRate: this.ttsRate,
        ttsPitch: this.ttsPitch,
        channel: this.channel,
        readabilityMode: this.readabilityMode,
        readabilityFont: this.readabilityFont,
        readabilityTheme: this.readabilityTheme,
        readabilitySize: this.readabilitySize,
        syncYouTubeTheme: this.syncYouTubeTheme
      };
    }

    commit(quiet = false) {
      if (this.closed) return;
      GM_setValue('win:' + this.videoId, this.toRecord());
      if (!quiet) {
        GM_setValue('sync_ping', { id: this.videoId, tab: TAB_ID, t: Date.now(), n: Math.random() });
      }
    }

    getTranscriptMode() {
      return this.opts.transcriptMode || 'fast';
    }

    getSystemInstruction() {
      const isFast = this.getTranscriptMode() === 'fast';
      if (isFast) {
        return `You are an expert executive summarizer. Produce an ultra-fast, high-signal, concise summary in English.
Prioritize brevity, punchy takeaways, and rapid consumption (< 2 minutes reading time).
Focus strictly on the core thesis and top 3-5 crucial insights.
Eliminate all filler, pleasantries, and tangential elaboration.
Deliver maximum information density in the shortest reading time.`;
      }
      return `You are an expert analytical researcher. Produce an exhaustive, deep, and highly detailed summary in English.
Provide a thorough chronological walkthrough with precise timestamps [MM:SS] for every distinct topic change.
Delve deeply into specific claims, quantitative figures, underlying mechanics, formulas, and arguments.
Include rich context, nuance, technical distinctions, and direct quotes where significant.
Ensure comprehensive coverage so no important insight is omitted.`;
    }

    buildSummaryPrompt() {
      const isFast = this.getTranscriptMode() === 'fast';
      let prompt = isFast
        ? `Watch this YouTube video (titled "${this.title}") and write an executive, concise summary in English (Fast Mode).
Use Markdown with these concise sections:
- "## TL;DR": 1-2 rapid sentences capturing the core message.
- "## Key takeaways": 3-5 punchy, high-impact bullet points covering the primary insights.
- "## Concise summary": chronological overview covering major points with [MM:SS] timestamps (use [H:MM:SS] after one hour).
- "## Notable details": key figures, tools, or critical caveats.
- "## Worth your time?": 1 sentence on who it is for and whether it delivers on its title or is clickbait / padded.
EXCLUDE entirely: sponsor segments, paid promotions, ad reads, and self-promotion.
Only report what is actually said or shown. Never invent details, quotes, timestamps or URLs.`
        : `Watch this YouTube video (titled "${this.title}") and write a verbose, faithful summary in English (Deep Mode).
Use Markdown with these sections, in this order (omit a section if it does not apply):
- "## TL;DR": 2-3 sentences capturing the core message.
- "## Detailed summary": walk through the video chronologically. Start each part with a heading "### [MM:SS] Section title" (use [H:MM:SS] after one hour), then cover the specific claims, arguments, examples, steps, names, numbers and conclusions … short paragraphs and bullets. Be thorough rather than terse.
- "## Key takeaways": bulleted list.
- "## Notable details": figures, tools, products, brief quotes and caveats that matter.
- "## Worth your time?": 1-2 sentences on who it is for and whether it delivers on its title or is clickbait / padded.
EXCLUDE entirely: sponsor segments, paid promotions and ad reads; and any self-promotion by the creator or guests – merchandise, Patreon/memberships/donation requests, charities or causes unrelated to the video's subject, tour dates or live events, courses, other products or services they sell, and plugs for their other channels, newsletters or social media (including "like and subscribe" requests). Treat these as if they were not in the video: do not summarize, mention or timestamp them, however much runtime they take up. A cause or organization that is genuinely the subject of the video is not self-promotion.
Only report what is actually said or shown. Never invent details, quotes, timestamps or URLs.`;

      if (this.source === 'text') {
        const verb = isFast ? 'an executive, concise summary' : 'a verbose, faithful summary';
        prompt = `Read this timestamped transcript of a YouTube video (titled "${this.title}") and write ${verb} in English.\n` + prompt.slice(prompt.indexOf('Use Markdown'));
      }

      if (this.opts.gsearch) {
        prompt += '\nUse Google Search to verify facts. Only include URLs that appear in your search results; never guess or reconstruct a URL.';
      }
      if (this.opts.img) {
        prompt +=
          '\nVisuals: add marker lines after the relevant paragraph (max 6): "[[FRAME mm:ss | caption]]" for a moment where the video itself shows a diagram/chart/graph/slide/map/demo (only if you can see it; omitted for transcript source); "[[IMG search terms | caption]]" for a standard illustration to be looked up on Wikimedia Commons (short generic English terms). Nothing else.';
      }
      if (this.opts.gen) {
        prompt +=
          '\nAI images: "[[GEN image prompt | caption]]" (max 3). You are only DESIGNING the prompt for an image model (Nano Banana) which draws it afterwards; each prompt must be self-contained (subject, layout, clean flat educational style, short English labels, aspect ratio); no real people\'s likenesses, logos or copyrighted characters.';
      }
      prompt += '\nIf the video is mostly music or has little speech, describe what happens instead.';
      return prompt;
    }

    buildTranscriptPrompt() {
      return `Watch this YouTube video (titled "${this.title}") and produce a complete, accurate transcript of everything spoken, in the original language(s). Markdown; new paragraph per speaker/topic change starting with [MM:SS] ([H:MM:SS] after an hour); label speakers only if >1 voice; do not summarize/paraphrase/skip; mention significant non-speech audio in italics in brackets only when it matters; never invent words or timestamps.`;
    }

    onDone() {
      this.status = 'done';
      this.busy = false;
      this.errMsg = '';
      this.phase = '';
      if (maximizedWindow !== this || document.hidden) {
        this.unread = true;
      }
      // Save to cache before committing
      writeCache(this.videoId, this.mode, this.source, {
        videoId: this.videoId,
        title: this.title,
        gen: this.opts.gen,
        text: this.text,
        sources: this.sources,
        notes: this.notes,
        model: this.modelId,
        usedOpts: this.opts,
        turns: this.turns,
        images: this.images,
        fact: this.fact
      });
      this.commit(false);
      this.renderAll();
      this.updateTtsUI();
      updateDockHistoryTab();

      // Trigger automatic fact check if requested
      if ((this.opts.fc || this.opts.src) && this.mode === 'summary' && !this.fact) {
        this.runFactCheck();
      }
    }

    async runFactCheck() {
      const keyObj = getStoredKeys().find((k) => k.id === this.keyId) || getStoredKeys()[0];
      if (!keyObj) return;

      try {
        const factRes = await runFactCheckPass(this, this.text, { keyObj });
        this.fact = factRes;
        writeCache(this.videoId, this.mode, this.source, {
          videoId: this.videoId,
          title: this.title,
          gen: this.opts.gen,
          text: this.text,
          sources: this.sources,
          notes: this.notes,
          model: this.modelId,
          usedOpts: this.opts,
          turns: this.turns,
          images: this.images,
          fact: this.fact
        });
        this.renderBody();
        updateDockHistoryTab();
      } catch (err) {
        if (CONFIG.debug) console.warn('[YTAIS] Fact check failed:', err);
      }
    }

    startJob() {
      this.stopTts();
      if (this.currentJob) {
        this.currentJob.abort();
      }
      const job = {
        id: Math.random().toString(36).slice(2),
        cancelled: false,
        abortController: new AbortController(),
        abort() {
          this.cancelled = true;
          this.abortController.abort();
        }
      };
      this.currentJob = job;
      produce(this, job);
    }

    createDockTab() {
      const tab = h('div', {
        className: 'yt-dock-tab',
        onclick: () => this.maximize()
      });

      const iconBox = h('div', { className: 'yt-dock-status-icon' });
      const titleBox = h('div', { className: 'yt-dock-title' });
      const maxBtn = h(
        'button',
        {
          className: 'yt-dock-btn yt-dock-max-btn',
          title: 'Maximize window',
          onclick: (e) => {
            e.stopPropagation();
            this.maximize();
          }
        },
        iconMaximize()
      );
      const closeBtn = h(
        'button',
        {
          className: 'yt-dock-btn yt-dock-close-btn',
          title: 'Close window',
          onclick: (e) => {
            e.stopPropagation();
            this.close();
          }
        },
        iconClose()
      );

      tab.appendChild(iconBox);
      tab.appendChild(titleBox);
      tab.appendChild(maxBtn);
      tab.appendChild(closeBtn);

      this.dockTab = tab;
      dockContainer.appendChild(tab);
      this.renderDockTab();
      updateDockHistoryTab();
    }

    renderDockTab() {
      if (!this.dockTab) return;
      const tab = this.dockTab;
      tab.className = 'yt-dock-tab';

      if (this.status === 'error') tab.classList.add('error');
      else if (this.unread) tab.classList.add('unread');
      if (this.isOpen && maximizedWindow === this) tab.classList.add('active-focus');

      const iconBox = tab.querySelector('.yt-dock-status-icon');
      const titleBox = tab.querySelector('.yt-dock-title');
      clearEl(iconBox);

      let statusDesc = 'Idle';
      if (this.status === 'loading') {
        statusDesc = this.owner === TAB_ID ? 'Working…' : 'Working in another tab…';
        iconBox.appendChild(h('div', { className: 'yt-spinner' }));
      } else if (this.status === 'done') {
        statusDesc = 'Done';
        iconBox.appendChild(iconCheck());
      } else if (this.status === 'error') {
        statusDesc = `Error: ${this.errMsg}`;
        iconBox.appendChild(iconAlert());
      } else {
        iconBox.appendChild(h('span', { className: 'yt-dock-bullet' }, '•'));
      }

      const prefix = this.mode === 'transcript' ? 'Transcript · ' : '';
      titleBox.textContent = prefix + this.title;
      tab.title = `${this.title} — ${statusDesc}`;
    }

    focus() {
      if (!this.isOpen) return;
      topWindowZIndex += 1;
      this.zIndex = topWindowZIndex;
      maximizedWindow = this;
      if (topWindowZIndex > 3000) {
        const sorted = getOpenWindows().sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
        sorted.forEach((w, idx) => { w.zIndex = idx + 1; });
        topWindowZIndex = sorted.length + 1;
        this.zIndex = topWindowZIndex;
      }
      for (const win of activeWindows.values()) {
        const zVal = String(2147480000 + Math.min(3500, win.zIndex || 1));
        if (win.windowBox) {
          win.windowBox.classList.toggle('focused', win === this);
          win.windowBox.style.zIndex = zVal;
        }
        if (win.modalScrim) {
          win.modalScrim.style.zIndex = zVal;
        }
        win.renderDockTab();
      }
    }

    maximize() {
      this.unread = false;
      this.isOpen = true;
      topWindowZIndex += 1;
      this.zIndex = topWindowZIndex;
      maximizedWindow = this;
      if (!this.modalScrim || !this.windowBox) {
        this.showModal();
      } else {
        this.focus();
      }
      this.commit(true);
      this.renderDockTab();
    }

    cleanupWindowInteractions() {
      if (this._resizeObserver) {
        try { this._resizeObserver.disconnect(); } catch (_) {}
        this._resizeObserver = null;
      }
      if (Array.isArray(this._interactionCleanup) && this._interactionCleanup.length) {
        for (const fn of this._interactionCleanup) {
          try { fn(); } catch (_) {}
        }
        this._interactionCleanup = [];
      }
      if (this.winOverflowMenuEl) {
        try { this.winOverflowMenuEl.remove(); } catch (_) {}
        this.winOverflowMenuEl = null;
      }
      if (this.exportMenuEl) {
        try { this.exportMenuEl.remove(); } catch (_) {}
        this.exportMenuEl = null;
      }
    }

    minimize(skipCommit = false) {
      this.stopTts();
      this.cleanupWindowInteractions();
      this.isOpen = false;
      if (this.modalScrim) {
        this.modalScrim.remove();
        this.modalScrim = null;
      }
      this.windowBox = null;
      this.stopPlayer();

      if (maximizedWindow === this) {
        const remaining = getOpenWindows().sort((a, b) => (b.zIndex || 0) - (a.zIndex || 0));
        maximizedWindow = remaining[0] || null;
        if (maximizedWindow) {
          maximizedWindow.focus();
        }
      }
      if (!skipCommit && !this.closed) {
        this.commit(true);
      }
      this.renderDockTab();
    }

    close(fromSync = false) {
      this.closed = true;
      if (this.ytThemeObserver) {
        this.ytThemeObserver.disconnect();
        this.ytThemeObserver = null;
      }
      this.cleanupWindowInteractions();
      this.stopTts();
      if (this._speechRecInstance) {
        try { this._speechRecInstance.stop(); } catch (_) {}
        this._speechRecInstance = null;
      }
      this._isListening = false;
      if (this.currentJob) {
        this.currentJob.abort();
      }
      this.minimize(true);
      if (this.dockTab) {
        this.dockTab.remove();
        this.dockTab = null;
      }
      activeWindows.delete(this.videoId);
      if (!fromSync) {
        GM_deleteValue('win:' + this.videoId);
        GM_setValue('sync_ping', { id: this.videoId, tab: TAB_ID, t: Date.now(), n: Math.random() });
      }
      updateDockHistoryTab();
    }

    applyWindowBounds(nextBounds, persist = false) {
      const clamped = clampWindowBounds(nextBounds, {
        width: window.innerWidth || 1280,
        height: window.innerHeight || 800
      });
      this.bounds = clamped;
      if (this.windowBox) {
        this.windowBox.style.left = `${clamped.left}px`;
        this.windowBox.style.top = `${clamped.top}px`;
        this.windowBox.style.width = `${clamped.width}px`;
        this.windowBox.style.height = `${clamped.height}px`;
      }
      this.updateAdaptiveLayout(clamped.width, clamped.height);
      if (persist) {
        setLastWindowBounds(clamped);
        this.commit(true);
      }
      return clamped;
    }

    resizeWindow(width, height) {
      const cur = this.bounds || computeDefaultWindowBounds({ width: window.innerWidth || 1280, height: window.innerHeight || 800 });
      return this.applyWindowBounds({ ...cur, width, height }, true);
    }

    moveWindow(left, top) {
      const cur = this.bounds || computeDefaultWindowBounds({ width: window.innerWidth || 1280, height: window.innerHeight || 800 });
      return this.applyWindowBounds({ ...cur, left, top }, true);
    }

    updateAdaptiveLayout(widthOverride, heightOverride) {
      if (!this.windowBox) return;
      const width = Math.round(widthOverride || this.windowBox.clientWidth || this.bounds?.width || 900);
      const height = Math.round(heightOverride || this.windowBox.clientHeight || this.bounds?.height || 680);
      const flags = getAdaptiveWindowFlags(width, height);
      this.sizeTier = flags.tier;
      this.windowBox.classList.toggle('yt-win-compact', flags.isCompact);
      this.windowBox.classList.toggle('yt-win-medium', flags.isMedium);
      this.windowBox.classList.toggle('yt-win-wide', flags.isWide);
      this.windowBox.classList.toggle('yt-win-short', flags.isShort);
      this.windowBox.setAttribute('data-size-tier', flags.tier);
      this.windowBox.setAttribute('data-short', flags.isShort ? 'true' : 'false');

      const optRow = this.windowBox.querySelector('.yt-options-row');
      const compactToggle = this.windowBox.querySelector('.yt-compact-options-btn');
      if (optRow) {
        if (flags.collapseOptionsRow) {
          optRow.classList.toggle('yt-options-collapsed', !this.compactOptionsOpen);
        } else {
          optRow.classList.remove('yt-options-collapsed');
        }
      }
      if (compactToggle) {
        compactToggle.style.display = flags.collapseOptionsRow ? 'inline-flex' : 'none';
        compactToggle.textContent = this.compactOptionsOpen ? 'Options ▴' : 'Options ▾';
      }
    }

    setupWindowInteractions(headerEl, winBox) {
      // 1. Focus on click anywhere inside window
      const onWinDown = () => this.focus();
      winBox.addEventListener('mousedown', onWinDown);
      this._interactionCleanup.push(() => winBox.removeEventListener('mousedown', onWinDown));

      // 2. Dragging via Header
      const onHeaderDown = (e) => {
        if (e.button !== 0) return;
        if (e.target.closest('button, a, input, select, .yt-win-header-btns, .yt-win-overflow-menu')) return;
        e.preventDefault();
        this.focus();
        const startX = e.clientX;
        const startY = e.clientY;
        const startBounds = { ...this.bounds };

        const onMove = (ev) => {
          const dx = ev.clientX - startX;
          const dy = ev.clientY - startY;
          this.applyWindowBounds({ ...startBounds, left: startBounds.left + dx, top: startBounds.top + dy }, false);
        };
        const cleanupDrag = () => {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
          const idx = this._interactionCleanup.indexOf(cleanupDrag);
          if (idx !== -1) this._interactionCleanup.splice(idx, 1);
        };
        const onUp = () => {
          cleanupDrag();
          setLastWindowBounds(this.bounds);
          this.commit(true);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        this._interactionCleanup.push(cleanupDrag);
      };
      headerEl.addEventListener('mousedown', onHeaderDown);
      this._interactionCleanup.push(() => headerEl.removeEventListener('mousedown', onHeaderDown));

      // 3. Resize Handles (e, s, se, w, sw)
      const edges = [
        { dir: 'e', label: 'Resize width' },
        { dir: 's', label: 'Resize height' },
        { dir: 'se', label: 'Resize summary window' },
        { dir: 'w', label: 'Resize width from left' },
        { dir: 'sw', label: 'Resize corner bottom-left' }
      ];
      for (const edge of edges) {
        const handle = h('div', {
          className: `yt-resize-handle yt-resize-handle-${edge.dir}`,
          'data-resize-dir': edge.dir,
          role: 'separator',
          'aria-label': edge.label,
          title: 'Drag to resize window'
        });
        const onResizeDown = (e) => {
          if (e.button !== 0) return;
          e.preventDefault();
          e.stopPropagation();
          this.focus();
          const startX = e.clientX;
          const startY = e.clientY;
          const startBounds = { ...this.bounds };

          const onMove = (ev) => {
            const dx = ev.clientX - startX;
            const dy = ev.clientY - startY;
            let next = { ...startBounds };
            if (edge.dir.includes('e')) {
              next.width = startBounds.width + dx;
            }
            if (edge.dir.includes('s')) {
              next.height = startBounds.height + dy;
            }
            if (edge.dir.includes('w')) {
              const proposedW = Math.max(340, startBounds.width - dx);
              const actualDx = startBounds.width - proposedW;
              next.width = proposedW;
              next.left = startBounds.left + actualDx;
            }
            this.applyWindowBounds(next, false);
          };
          const cleanupResize = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            const idx = this._interactionCleanup.indexOf(cleanupResize);
            if (idx !== -1) this._interactionCleanup.splice(idx, 1);
          };
          const onUp = () => {
            cleanupResize();
            setLastWindowBounds(this.bounds);
            this.commit(true);
          };
          document.addEventListener('mousemove', onMove);
          document.addEventListener('mouseup', onUp);
          this._interactionCleanup.push(cleanupResize);
        };
        handle.addEventListener('mousedown', onResizeDown);
        winBox.appendChild(handle);
      }

      // 4. ResizeObserver for adaptive layout updates
      if (typeof ResizeObserver !== 'undefined') {
        this._resizeObserver = new ResizeObserver((entries) => {
          for (const entry of entries) {
            const cw = Math.round(entry.contentRect.width);
            const ch = Math.round(entry.contentRect.height);
            if (cw > 0 && ch > 0) {
              this.updateAdaptiveLayout(cw, ch);
            }
          }
        });
        this._resizeObserver.observe(winBox);
      }
    }

    seekPlayer(seconds) {
      if (!this.playerSlot) return;
      this.playerSlot.style.display = 'block';
      clearEl(this.playerSlot);

      const closePlayer = h(
        'button',
        {
          className: 'yt-player-close-btn',
          title: 'Close player',
          onclick: () => this.stopPlayer()
        },
        iconClose(16)
      );

      const iframe = h('iframe', {
        src: `https://www.youtube.com/embed/${encodeURIComponent(this.videoId)}?start=${Math.floor(
          seconds
        )}&autoplay=1&rel=0`,
        className: 'yt-player-iframe',
        referrerpolicy: 'strict-origin-when-cross-origin',
        allow: 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share',
        allowfullscreen: true
      });

      this.playerIframe = iframe;
      this.playerSlot.appendChild(closePlayer);
      this.playerSlot.appendChild(iframe);
    }

    stopPlayer() {
      if (this.playerSlot) {
        clearEl(this.playerSlot);
        this.playerSlot.style.display = 'none';
      }
      this.playerIframe = null;
    }

    showModal() {
      this.cleanupWindowInteractions();
      if (this.modalScrim) this.modalScrim.remove();

      this.isOpen = true;
      const clamped = clampWindowBounds(
        this.bounds || computeDefaultWindowBounds({ width: window.innerWidth || 1280, height: window.innerHeight || 800 }),
        { width: window.innerWidth || 1280, height: window.innerHeight || 800 }
      );
      this.bounds = clamped;

      const scrim = h('div', {
        className: 'yt-modal-scrim yt-floating-scrim',
        style: `z-index: ${2147483000 + Math.min(40, this.zIndex)};`
      });

      const winBox = h('div', {
        className: `yt-window-box yt-floating-window ${maximizedWindow === this ? 'focused' : ''} ${this.readabilityMode ? 'yt-readability-active yt-theme-' + this.readabilityTheme : ''}`,
        'data-video-id': this.videoId,
        style: `left:${clamped.left}px;top:${clamped.top}px;width:${clamped.width}px;height:${clamped.height}px;`,
        onwheel: (e) => e.stopPropagation()
      });
      this.windowBox = winBox;
      this.el = winBox;

      // 1. Header
      const header = this.buildHeader();
      winBox.appendChild(header);

      // 2. Toolbar
      const toolbar = this.buildToolbar();
      winBox.appendChild(toolbar);

      // 3. Advanced panel
      const advPanel = this.buildAdvancedPanel();
      winBox.appendChild(advPanel);

      // 4. In-window player slot
      const playerSlot = h('div', { className: 'yt-player-slot', style: 'display:none;' });
      this.playerSlot = playerSlot;
      winBox.appendChild(playerSlot);

      // 5. Body
      const body = h('div', { className: 'yt-window-body' });
      this.bodyEl = body;
      winBox.appendChild(body);

      // 6. Composer pinned below body
      const composer = this.buildComposer();
      winBox.appendChild(composer);

      this.setupWindowInteractions(header, winBox);
      scrim.appendChild(winBox);
      modalsContainer.appendChild(scrim);
      this.modalScrim = scrim;

      this.updateAdaptiveLayout(clamped.width, clamped.height);
      this.focus();
      this.renderBody();
    }

    openHeaderOverflowMenu(anchorEl) {
      if (this.winOverflowMenuEl) {
        this.winOverflowMenuEl.remove();
        this.winOverflowMenuEl = null;
        return;
      }

      const menu = h('div', {
        className: 'yt-win-overflow-menu',
        onclick: (e) => e.stopPropagation()
      });

      const addItem = (iconNode, label, onClick) => {
        const item = h(
          'button',
          {
            className: 'yt-export-item',
            onclick: () => {
              menu.remove();
              this.winOverflowMenuEl = null;
              onClick();
            }
          },
          iconNode,
          h('span', { className: 'yt-export-item-title' }, label)
        );
        menu.appendChild(item);
      };

      addItem(iconExport(15), 'Export (.txt / .pdf / .json)', () => this.openExportMenu(anchorEl));
      addItem(iconHistory(15), 'Previous summaries (History)', () => openHistoryDialog());
      addItem(iconCopy(15), 'Copy video URL', () => {
        const videoUrl = `https://www.youtube.com/watch?v=${this.videoId}`;
        if (typeof GM_setClipboard === 'function') GM_setClipboard(videoUrl);
        else if (navigator.clipboard?.writeText) navigator.clipboard.writeText(videoUrl);
      });
      addItem(iconExternal(15), 'Open video in new tab', () => {
        window.open(`https://www.youtube.com/watch?v=${this.videoId}`, '_blank');
      });

      const rect = anchorEl.getBoundingClientRect();
      const parentRect = (this.windowBox || document.body).getBoundingClientRect();
      menu.style.top = `${rect.bottom - parentRect.top + 6}px`;
      menu.style.right = `${Math.max(8, parentRect.right - rect.right)}px`;

      const closeHandler = (e) => {
        if (!menu.contains(e.target) && e.target !== anchorEl) {
          menu.remove();
          this.winOverflowMenuEl = null;
          document.removeEventListener('click', closeHandler, true);
        }
      };
      setTimeout(() => document.addEventListener('click', closeHandler, true), 30);

      (this.windowBox || modalsContainer).appendChild(menu);
      this.winOverflowMenuEl = menu;
    }

    buildHeader() {
      const header = h('div', { className: 'yt-win-header', title: 'Drag header to move window' });
      const titleCol = h('div', { className: 'yt-win-title-col' });
      const titleEl = h(
        'a',
        {
          className: 'yt-win-title yt-win-title-link',
          href: `https://www.youtube.com/watch?v=${this.videoId}`,
          target: '_blank',
          rel: 'noopener noreferrer',
          title: `${this.title} (Open video in new tab)`
        },
        this.title
      );
      const statusLine = h('div', { className: 'yt-win-status-line' });
      this.statusLineEl = statusLine;
      titleCol.appendChild(titleEl);
      titleCol.appendChild(statusLine);

      const btnGroup = h('div', { className: 'yt-win-header-btns' });

      const readabilityBtn = h(
        'button',
        {
          className: `yt-win-btn yt-win-readability-btn ${this.readabilityMode ? 'active' : ''}`,
          title: this.readabilityMode
            ? 'Exit Readability Mode (Return to standard interactive view)'
            : 'Readability Mode (Clean, centered distraction-free reader)',
          onclick: () => this.toggleReadability()
        },
        iconBook(18)
      );

      const exportBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-export-btn yt-win-secondary-btn',
          title: 'Export summary / transcript (.txt, .pdf, or .json)',
          onclick: (e) => {
            e.stopPropagation();
            this.openExportMenu(exportBtn);
          }
        },
        iconExport(18)
      );

      const historyBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-history-btn yt-win-secondary-btn',
          title: 'Browse previous summaries (History)',
          onclick: () => openHistoryDialog()
        },
        iconHistory(18)
      );

      const copyUrlBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-copy-btn yt-win-secondary-btn',
          title: 'Copy video URL',
          onclick: () => {
            const videoUrl = `https://www.youtube.com/watch?v=${this.videoId}`;
            if (typeof GM_setClipboard === 'function') {
              GM_setClipboard(videoUrl);
            } else if (navigator.clipboard?.writeText) {
              navigator.clipboard.writeText(videoUrl);
            }
            copyUrlBtn.classList.add('copied');
            clearEl(copyUrlBtn);
            copyUrlBtn.appendChild(iconCheck(18));
            copyUrlBtn.title = 'Copied video URL!';
            setTimeout(() => {
              copyUrlBtn.classList.remove('copied');
              clearEl(copyUrlBtn);
              copyUrlBtn.appendChild(iconCopy(18));
              copyUrlBtn.title = 'Copy video URL';
            }, 1800);
          }
        },
        iconCopy(18)
      );

      const openUrlBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-open-btn yt-win-secondary-btn',
          title: 'Open video in new tab',
          onclick: () => {
            window.open(`https://www.youtube.com/watch?v=${this.videoId}`, '_blank');
          }
        },
        iconExternal(18)
      );

      const overflowBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-overflow-btn',
          title: 'More actions',
          'aria-label': 'More window actions',
          onclick: (e) => {
            e.stopPropagation();
            this.openHeaderOverflowMenu(overflowBtn);
          }
        },
        iconMoreVert(18)
      );

      const minBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-min-btn',
          title: 'Minimize (Esc)',
          onclick: () => this.minimize()
        },
        iconMinimize(20)
      );
      const closeBtn = h(
        'button',
        {
          className: 'yt-win-btn yt-win-close-btn',
          title: 'Close window',
          onclick: () => this.close()
        },
        iconClose(20)
      );

      btnGroup.appendChild(readabilityBtn);
      btnGroup.appendChild(exportBtn);
      btnGroup.appendChild(historyBtn);
      btnGroup.appendChild(copyUrlBtn);
      btnGroup.appendChild(openUrlBtn);
      btnGroup.appendChild(overflowBtn);
      btnGroup.appendChild(minBtn);
      btnGroup.appendChild(closeBtn);

      header.appendChild(titleCol);
      header.appendChild(btnGroup);
      this.renderStatus();
      return header;
    }

    renderStatus() {
      if (!this.statusLineEl) return;
      clearEl(this.statusLineEl);

      let text = 'Idle';
      if (this.status === 'loading') {
        text = this.owner === TAB_ID ? (this.phase || 'Working…') : 'Working in another tab…';
      } else if (this.status === 'done') {
        text = this.cacheDate ? `Cached from ${new Date(this.cacheDate).toLocaleDateString()}` : 'Completed';
      } else if (this.status === 'error') {
        text = `Error: ${this.errMsg}`;
      }
      this.statusLineEl.textContent = text;
      this.renderDockTab();
    }

    buildToolbar() {
      const toolbar = h('div', { className: 'yt-win-toolbar' });

      // Row 1
      const r1 = h('div', { className: 'yt-toolbar-row' });

      // Mode toggle
      const modeWrap = h('div', { className: 'yt-segmented-btn' });
      const sumBtn = h(
        'button',
        {
          className: `yt-seg-btn ${this.mode === 'summary' ? 'active' : ''}`,
          disabled: this.status === 'loading',
          onclick: () => {
            if (this.mode !== 'summary') {
              this.mode = 'summary';
              this.onModeOrSourceChanged();
            }
          }
        },
        'Summarize'
      );
      const trnBtn = h(
        'button',
        {
          className: `yt-seg-btn ${this.mode === 'transcript' ? 'active' : ''}`,
          disabled: this.status === 'loading',
          onclick: () => {
            if (this.mode !== 'transcript') {
              this.mode = 'transcript';
              this.onModeOrSourceChanged();
            }
          }
        },
        'Transcribe'
      );
      modeWrap.appendChild(sumBtn);
      modeWrap.appendChild(trnBtn);
      r1.appendChild(modeWrap);

      // Source toggle
      const srcWrap = h('div', { className: 'yt-segmented-btn' });
      const vidBtn = h(
        'button',
        {
          className: `yt-seg-btn ${this.source === 'video' ? 'active' : ''}`,
          disabled: this.status === 'loading' || this.modelId.includes('Ask'),
          onclick: () => {
            if (this.source !== 'video') {
              this.source = 'video';
              setLastSource('video');
              this.onModeOrSourceChanged();
            }
          }
        },
        'Video'
      );
      const txtBtn = h(
        'button',
        {
          className: `yt-seg-btn ${this.source === 'text' ? 'active' : ''}`,
          disabled: this.status === 'loading' || this.modelId.includes('Ask'),
          onclick: () => {
            if (this.source !== 'text') {
              this.source = 'text';
              setLastSource('text');
              this.onModeOrSourceChanged();
            }
          }
        },
        'Transcript'
      );
      srcWrap.appendChild(vidBtn);
      srcWrap.appendChild(txtBtn);
      r1.appendChild(srcWrap);

      // Model select + recheck
      const modelWrap = h('div', { className: 'yt-control-wrap' });
      const modelSel = h('select', {
        className: 'yt-select yt-model-select',
        onchange: (e) => {
          if (e.target.value === '__custom__') {
            const custom = prompt('Enter custom Gemini model ID (e.g. gemini-3.8-flash):');
            if (custom && custom.trim()) {
              addCustomModel(custom.trim());
              this.modelId = custom.trim();
              setLastModel(this.modelId);
            }
          } else {
            this.modelId = e.target.value;
            setLastModel(this.modelId);
          }
          if (this.modelId.includes('Ask')) {
            this.source = 'video';
          }
          this.commit(true);
          if (this.status === 'loading' || this.status === 'error') {
            this.startJob();
          }
          this.renderAll();
        }
      });
      this.populateModelSelect(modelSel);
      const recheckBtn = h(
        'button',
        {
          className: 'yt-icon-tool-btn',
          title: 'Re-check models',
          onclick: async () => {
            const keyObj = getStoredKeys().find((k) => k.id === this.keyId) || getStoredKeys()[0];
            if (keyObj) {
              await checkModelsForKey(keyObj, true);
              this.populateModelSelect(modelSel);
            }
          }
        },
        iconRefresh(16)
      );
      modelWrap.appendChild(modelSel);
      modelWrap.appendChild(recheckBtn);
      r1.appendChild(modelWrap);

      // Key select + manage keys button
      const keyWrap = h('div', { className: 'yt-control-wrap' });
      const keySel = h('select', {
        className: 'yt-select yt-key-select',
        onchange: (e) => {
          if (e.target.value === '__manage__') {
            openKeyManagerDialog(() => this.renderAll());
          } else {
            this.keyId = e.target.value;
            setLastKeyId(this.keyId);
            this.commit(true);
            if (this.status === 'loading' || this.status === 'error') {
              this.startJob();
            }
            this.renderAll();
          }
        }
      });
      this.populateKeySelect(keySel);
      const gearBtn = h(
        'button',
        {
          className: 'yt-icon-tool-btn',
          title: 'Manage API keys',
          onclick: () => openKeyManagerDialog(() => this.renderAll())
        },
        iconGear(16)
      );
      const histBtn = h(
        'button',
        {
          className: 'yt-icon-tool-btn yt-history-btn',
          title: 'Browse previous summaries (History)',
          onclick: () => openHistoryDialog()
        },
        iconHistory(16)
      );
      keyWrap.appendChild(keySel);
      keyWrap.appendChild(gearBtn);
      keyWrap.appendChild(histBtn);
      r1.appendChild(keyWrap);

      // Spacer
      r1.appendChild(h('div', { className: 'yt-spacer' }));

      // TTS Speech Controls
      const ttsControls = this.buildTtsControls();
      r1.appendChild(ttsControls);

      // Primary Action Button
      let btnLabel = this.mode === 'transcript' ? 'Transcribe' : 'Start';
      if (this.status === 'loading') btnLabel = 'Restart';
      else if (this.status === 'done') btnLabel = 'Regenerate';

      const actionBtn = h(
        'button',
        {
          className: 'yt-primary-btn',
          onclick: () => {
            if (this.status === 'done' && this.turns.length > 0) {
              if (!confirm('Regenerating will clear your follow-up conversation. Continue?')) {
                return;
              }
            }
            this.turns = [];
            this.startJob();
          }
        },
        btnLabel
      );
      r1.appendChild(actionBtn);

      // Row 2
      const r2 = h('div', { className: 'yt-toolbar-row yt-options-row' });
      const isTranscribe = this.mode === 'transcript';
      const isAsk = this.modelId.includes('Ask');

      if (!isTranscribe) {
        const fcCheck = this.buildCheckbox('Fact-check', this.opts.fc, (v) => {
          this.opts.fc = v;
          this.saveOpts();
        });
        const imgCheck = this.buildCheckbox(
          isAsk ? 'Images & diagrams (Gemini coordinator)' : 'Images & diagrams',
          this.opts.img,
          (v) => {
            this.opts.img = v;
            this.saveOpts();
          }
        );
        const srcCheck = this.buildCheckbox('Source links', this.opts.src, (v) => {
          this.opts.src = v;
          this.saveOpts();
        });
        const genCheck = this.buildCheckbox(
          isAsk ? 'AI images (Nano Banana)' : 'AI images',
          this.opts.gen,
          (v) => {
            this.opts.gen = v;
            this.saveOpts();
          }
        );

        r2.appendChild(fcCheck);
        r2.appendChild(imgCheck);
        r2.appendChild(srcCheck);
        r2.appendChild(genCheck);

        // Transcript Processing Panel
        const tpPanel = h('div', {
          className: 'yt-transcript-processing-panel',
          title: 'Transcript Processing: Choose between Fast (Concise executive brief) and Deep (Detailed exhaustive breakdown)'
        });
        const tpLabel = h('span', { className: 'yt-tp-label' }, 'Transcript Processing:');
        const tpFastBtn = h(
          'button',
          {
            className: `yt-tp-btn yt-tp-fast-btn ${this.opts.transcriptMode === 'fast' || !this.opts.transcriptMode ? 'active' : ''}`,
            title: 'Fast (Concise): Rapid executive takeaways (< 2 min read), punchy bullet points, high signal-to-noise ratio',
            onclick: () => {
              this.opts.transcriptMode = 'fast';
              this.saveOpts();
              tpFastBtn.classList.add('active');
              tpDeepBtn.classList.remove('active');
            }
          },
          '⚡ Fast (Concise)'
        );
        const tpDeepBtn = h(
          'button',
          {
            className: `yt-tp-btn yt-tp-deep-btn ${this.opts.transcriptMode === 'deep' ? 'active' : ''}`,
            title: 'Deep (Detailed): Exhaustive chronological analysis with timestamped sections, technical depth, and complete context',
            onclick: () => {
              this.opts.transcriptMode = 'deep';
              this.saveOpts();
              tpDeepBtn.classList.add('active');
              tpFastBtn.classList.remove('active');
            }
          },
          '🔍 Deep (Detailed)'
        );
        tpPanel.appendChild(tpLabel);
        tpPanel.appendChild(tpFastBtn);
        tpPanel.appendChild(tpDeepBtn);
        r2.appendChild(tpPanel);
      }

      const autoCheck = this.buildCheckbox('Auto-start', getAutoStart(), (v) => {
        setAutoStart(v);
      });
      r2.appendChild(autoCheck);

      r2.appendChild(h('div', { className: 'yt-spacer' }));

      const advToggle = h(
        'button',
        {
          className: 'yt-link-btn',
          onclick: () => {
            const panel = this.windowBox.querySelector('.yt-adv-panel');
            if (panel) {
              const isHidden = panel.style.display === 'none';
              panel.style.display = isHidden ? 'grid' : 'none';
              advToggle.textContent = isHidden ? 'Advanced ▴' : 'Advanced ▾';
            }
          }
        },
        'Advanced ▾'
      );
      r2.appendChild(advToggle);

      const compactBar = h('div', { className: 'yt-compact-options-bar' });
      const compactOptsBtn = h(
        'button',
        {
          className: 'yt-link-btn yt-compact-options-btn',
          style: 'display:none;',
          onclick: () => {
            this.compactOptionsOpen = !this.compactOptionsOpen;
            this.updateAdaptiveLayout();
          }
        },
        this.compactOptionsOpen ? 'Options ▴' : 'Options ▾'
      );
      const compactAdvBtn = h(
        'button',
        {
          className: 'yt-link-btn yt-compact-adv-btn',
          onclick: () => {
            const panel = this.windowBox?.querySelector('.yt-adv-panel');
            if (panel) {
              const isHidden = panel.style.display === 'none';
              panel.style.display = isHidden ? 'grid' : 'none';
            }
          }
        },
        'Advanced ▾'
      );
      compactBar.appendChild(compactOptsBtn);
      compactBar.appendChild(compactAdvBtn);

      toolbar.appendChild(r1);
      toolbar.appendChild(compactBar);
      toolbar.appendChild(r2);
      return toolbar;
    }

    buildTtsControls() {
      const wrap = h('div', { className: 'yt-tts-group' });
      const canPlay = this.status === 'done' && Boolean(this.text);

      const playBtn = h(
        'button',
        {
          className: `yt-tts-btn yt-tts-play-btn ${this.ttsState === 'playing' ? 'active' : ''}`,
          title:
            this.ttsState === 'loading'
              ? 'Generating AI Studio neural speech…'
              : this.ttsState === 'playing'
              ? 'Pause speech'
              : this.ttsState === 'paused'
              ? 'Resume speech'
              : 'Listen to summary (Google AI Studio neural speech or browser voice)',
          disabled: !canPlay || this.ttsState === 'loading',
          onclick: () => this.toggleTts()
        },
        this.ttsState === 'loading'
          ? h('div', { className: 'yt-spinner', style: 'width:12px;height:12px;margin-right:2px;' })
          : this.ttsState === 'playing'
          ? iconPause(14)
          : this.ttsState === 'paused'
          ? iconPlay(14)
          : iconSpeaker(14),
        h(
          'span',
          {},
          this.ttsState === 'loading'
            ? 'Generating…'
            : this.ttsState === 'playing'
            ? 'Pause'
            : this.ttsState === 'paused'
            ? 'Resume'
            : 'Listen'
        )
      );
      this.ttsPlayBtn = playBtn;

      const rewindBtn = h(
        'button',
        {
          className: 'yt-tts-btn yt-tts-rewind-btn',
          title: 'Rewind 5s (Left Arrow or J)',
          disabled: !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance),
          onclick: () => this.rewindTts(5)
        },
        iconRewind(12),
        h('span', {}, '5s')
      );
      this.ttsRewindBtn = rewindBtn;

      const skipBtn = h(
        'button',
        {
          className: 'yt-tts-btn yt-tts-skip-btn',
          title: 'Skip 5s (Right Arrow or L)',
          disabled: !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance),
          onclick: () => this.skipTts(5)
        },
        iconSkip(12),
        h('span', {}, '5s')
      );
      this.ttsSkipBtn = skipBtn;

      const stopBtn = h(
        'button',
        {
          className: 'yt-tts-btn yt-tts-stop-btn',
          title: 'Stop speech',
          disabled: !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance),
          onclick: () => this.stopTts()
        },
        iconStop(12),
        h('span', {}, 'Stop')
      );
      this.ttsStopBtn = stopBtn;

      // Predefined buttons (0.5x, 0.75x, 1x, 1.25x, 1.5x, 1.75x, 2x) & speed slider
      const rateIndicator = h('span', {
        className: `yt-tts-speed-indicator ${this.ttsRate > 1.0 ? 'speed-boost' : this.ttsRate < 1.0 ? 'speed-slow' : 'speed-normal'}`
      });
      const rateText = h('span', { className: 'yt-tts-speed-text' }, `${this.ttsRate}x`);
      const rateBtn = h(
        'button',
        {
          className: 'yt-tts-btn yt-tts-speed-btn',
          title: `Playback speed: ${this.ttsRate}x (click to cycle 0.25x steps)`,
          disabled: !canPlay,
          onclick: () => this.cycleTtsRate()
        },
        rateIndicator,
        rateText
      );
      this.ttsRateBtn = rateBtn;

      const speedWrap = h('div', {
        className: 'yt-tts-speed-wrap',
        title: `Playback speed: ${this.ttsRate}x`
      });

      const speedBtnsWrap = h('div', { className: 'yt-tts-speed-btns' });
      this.ttsSpeedBtns = [];
      const presetRates = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
      for (const r of presetRates) {
        const label = `${r}x`;
        const btn = h(
          'button',
          {
            className: `yt-tts-rate-pill yt-tts-rate-btn ${Math.abs(this.ttsRate - r) < 0.01 ? 'active' : ''}`,
            title: `Set playback speed to ${label}`,
            'data-rate': String(r),
            disabled: !canPlay,
            onclick: () => this.setTtsRate(r)
          },
          label
        );
        this.ttsSpeedBtns.push(btn);
        speedBtnsWrap.appendChild(btn);
      }

      const speedSliderRow = h('div', { className: 'yt-tts-slider-row yt-tts-speed-slider-row' });
      const speedSlider = h('input', {
        type: 'range',
        className: 'yt-tts-speed-slider',
        min: '0.5',
        max: '2',
        step: '0.05',
        value: String(this.ttsRate),
        title: `Playback speed: ${this.ttsRate}x`,
        disabled: !canPlay,
        oninput: (e) => {
          this.setTtsRate(parseFloat(e.target.value));
        }
      });
      const speedLabel = h('span', { className: 'yt-tts-speed-label' }, `${this.ttsRate}x`);
      speedSliderRow.appendChild(speedSlider);
      speedSliderRow.appendChild(speedLabel);

      speedWrap.appendChild(speedBtnsWrap);
      speedWrap.appendChild(speedSliderRow);

      this.ttsSpeedWrap = speedWrap;
      this.ttsSpeedSlider = speedSlider;
      this.ttsSpeedLabel = speedLabel;

      // Voice Selector dropdown (Google AI Studio neural voices + Browser voices)
      const voiceSelect = h('select', {
        className: 'yt-select yt-tts-voice-select',
        title: 'Choose speech voice: Google AI Studio Neural Voices (natural) or Browser Voices',
        onchange: (e) => {
          this.setTtsVoice(e.target.value);
          if (this.ttsState === 'playing') {
            this.stopTts();
            this.startTts();
          }
        }
      });
      this.ttsVoiceSelect = voiceSelect;
      this.populateTtsVoices(voiceSelect);

      // Volume control slider alongside speed controls
      const volWrap = h('div', {
        className: 'yt-tts-volume-wrap',
        title: `Speech volume: ${Math.round(this.ttsVolume * 100)}%`
      });
      const volIcon = h('span', { className: 'yt-tts-volume-icon' }, iconSpeaker(12));
      const volSlider = h('input', {
        type: 'range',
        className: 'yt-tts-volume-slider',
        min: '0',
        max: '1',
        step: '0.05',
        value: String(this.ttsVolume),
        title: `Speech volume: ${Math.round(this.ttsVolume * 100)}%`,
        oninput: (e) => {
          this.setTtsVolume(parseFloat(e.target.value));
        }
      });
      const volLabel = h('span', { className: 'yt-tts-volume-label' }, `${Math.round(this.ttsVolume * 100)}%`);

      volWrap.appendChild(volIcon);
      volWrap.appendChild(volSlider);
      volWrap.appendChild(volLabel);

      this.ttsVolumeWrap = volWrap;
      this.ttsVolumeSlider = volSlider;
      this.ttsVolumeLabel = volLabel;

      // Pitch control slider (0.5x - 2.0x) to customize voice character
      const pitchWrap = h('div', {
        className: 'yt-tts-pitch-wrap',
        title: `Voice pitch: ${this.ttsPitch}x`
      });
      const pitchIcon = h('span', { className: 'yt-tts-pitch-icon', title: 'Voice pitch character' }, iconMusic(12));
      const pitchSlider = h('input', {
        type: 'range',
        className: 'yt-tts-pitch-slider',
        min: '0.5',
        max: '2',
        step: '0.05',
        value: String(this.ttsPitch),
        title: `Voice pitch: ${this.ttsPitch}x`,
        disabled: !canPlay,
        oninput: (e) => {
          this.setTtsPitch(parseFloat(e.target.value));
        }
      });
      const pitchLabel = h('span', { className: 'yt-tts-pitch-label' }, `${this.ttsPitch}x`);

      pitchWrap.appendChild(pitchIcon);
      pitchWrap.appendChild(pitchSlider);
      pitchWrap.appendChild(pitchLabel);

      this.ttsPitchWrap = pitchWrap;
      this.ttsPitchSlider = pitchSlider;
      this.ttsPitchLabel = pitchLabel;

      // Skip Silence toggle button
      const skipSilenceBtn = h(
        'button',
        {
          className: `yt-tts-btn yt-tts-skip-silence-btn ${this.skipSilence ? 'active' : ''}`,
          title: this.skipSilence
            ? 'Skip Silence: ON (Automatically detecting and skipping long pauses or gap segments in transcript)'
            : 'Skip Silence: OFF (Click to automatically detect and skip segments with long pauses)',
          disabled: !canPlay,
          onclick: () => this.setSkipSilence(!this.skipSilence)
        },
        iconSkipSilence(12),
        h('span', { className: 'yt-tts-skip-silence-label' }, 'Skip Silence')
      );
      this.ttsSkipSilenceBtn = skipSilenceBtn;

      // Dynamic audio waveform visualizer (reflects real-time speech amplitude & frequencies)
      const waveformWrap = h('div', {
        className: 'yt-tts-waveform-wrap',
        title: 'Dynamic audio waveform reflecting real-time speech synthesis amplitude'
      });
      const waveformCanvas = h('canvas', {
        className: 'yt-tts-waveform-canvas',
        width: 68,
        height: 18
      });
      const waveformBars = h('div', { className: 'yt-tts-waveform-bars' });
      const barCount = 12;
      this.ttsWaveformBars = [];
      for (let i = 0; i < barCount; i++) {
        const bar = h('span', { className: 'yt-tts-waveform-bar' });
        this.ttsWaveformBars.push(bar);
        waveformBars.appendChild(bar);
      }
      waveformWrap.appendChild(waveformCanvas);
      waveformWrap.appendChild(waveformBars);
      this.ttsWaveformWrap = waveformWrap;
      this.ttsWaveformCanvas = waveformCanvas;

      wrap.appendChild(playBtn);
      wrap.appendChild(rewindBtn);
      wrap.appendChild(skipBtn);
      wrap.appendChild(stopBtn);
      wrap.appendChild(waveformWrap);
      wrap.appendChild(rateBtn);
      wrap.appendChild(speedWrap);
      wrap.appendChild(volWrap);
      wrap.appendChild(pitchWrap);
      wrap.appendChild(skipSilenceBtn);
      wrap.appendChild(voiceSelect);
      const shortcutsHint = h(
        'span',
        {
          className: 'yt-tts-shortcuts-hint',
          title: 'Global TTS Shortcuts:\n• Space or K: Play / Pause\n• ← or J: Rewind 5s / 10s\n• → or L: Skip 5s / 10s\n• ↑ / ↓: Volume Up / Down\n• [ / ]: Speed Down / Up\n• M: Mute / Unmute'
        },
        '⌨ Space • ← • →'
      );
      wrap.appendChild(shortcutsHint);
      return wrap;
    }

    setSkipSilence(val) {
      const s = Boolean(val);
      this.skipSilence = s;
      this.opts.skipSilence = s;
      this.saveOpts();
      if (this.ttsSkipSilenceBtn) {
        this.ttsSkipSilenceBtn.classList.toggle('active', s);
        this.ttsSkipSilenceBtn.title = s
          ? 'Skip Silence: ON (Automatically detecting and skipping long pauses or gap segments in transcript)'
          : 'Skip Silence: OFF (Click to automatically detect and skip segments with long pauses)';
      }
      this.showTtsFeedback(s ? '⚡ Skip Silence: ON' : '⏸ Skip Silence: OFF');
      if (this.ttsState === 'playing') {
        this.stopTts();
        this.startTts();
      }
    }

    setTtsRate(val) {
      const r = typeof val === 'number' && !isNaN(val) ? Math.max(0.5, Math.min(2.0, val)) : 1.0;
      this.ttsRate = r;
      setLastTtsRate(r);
      if (this.ttsUtterance) {
        this.ttsUtterance.rate = r;
      }
      if (this.ttsAudioEl) {
        this.ttsAudioEl.playbackRate = r;
      }
      this.updateTtsUI();
    }

    setTtsVolume(val) {
      const v = typeof val === 'number' && !isNaN(val) ? Math.max(0, Math.min(1, val)) : 1.0;
      this.ttsVolume = v;
      setLastTtsVolume(v);
      if (this.ttsAudioEl) {
        this.ttsAudioEl.volume = v;
      }
      if (this.ttsVolumeSlider && this.ttsVolumeSlider.value !== String(v)) {
        this.ttsVolumeSlider.value = String(v);
      }
      if (this.ttsVolumeSlider) {
        this.ttsVolumeSlider.title = `Speech volume: ${Math.round(v * 100)}%`;
      }
      if (this.ttsVolumeLabel) {
        this.ttsVolumeLabel.textContent = `${Math.round(v * 100)}%`;
      }
      if (this.ttsVolumeWrap) {
        this.ttsVolumeWrap.title = `Speech volume: ${Math.round(v * 100)}%`;
      }
    }

    setTtsPitch(val) {
      const p = typeof val === 'number' && !isNaN(val) ? Math.max(0.5, Math.min(2.0, val)) : 1.0;
      this.ttsPitch = Math.round(p * 100) / 100;
      setLastTtsPitch(this.ttsPitch);
      if (this.ttsUtterance) {
        this.ttsUtterance.pitch = this.ttsPitch;
      }
      if (this.ttsPitchSlider && Math.abs(parseFloat(this.ttsPitchSlider.value) - this.ttsPitch) > 0.01) {
        this.ttsPitchSlider.value = String(this.ttsPitch);
      }
      if (this.ttsPitchSlider) {
        this.ttsPitchSlider.title = `Voice pitch: ${this.ttsPitch}x`;
      }
      if (this.ttsPitchLabel) {
        this.ttsPitchLabel.textContent = `${this.ttsPitch}x`;
      }
      if (this.ttsPitchWrap) {
        this.ttsPitchWrap.title = `Voice pitch: ${this.ttsPitch}x`;
      }
      this.commit(true);
    }

    getTtsVoice() {
      return this.ttsVoice || getLastTtsVoice() || CONFIG.defaultTtsVoice;
    }

    setTtsVoice(v) {
      this.ttsVoice = v;
      setLastTtsVoice(v);
      this.commit(true);
    }

    populateTtsVoices(select) {
      if (!select) return;
      clearEl(select);
      const currentVoice = this.getTtsVoice();

      // 1. Google AI Studio Neural Voices (Human-like, non-robotic!)
      const aiGroup = h('optgroup', { label: 'Google AI Studio (Neural AI Voices)' });
      for (const v of CONFIG.aiVoices) {
        aiGroup.appendChild(h('option', { value: v.id }, v.name));
      }
      select.appendChild(aiGroup);

      // 2. Browser Voices Group (speechSynthesis)
      const browserGroup = h('optgroup', { label: 'Browser Voices' });
      const browserVoices = typeof window !== 'undefined' && window.speechSynthesis?.getVoices
        ? window.speechSynthesis.getVoices()
        : [];

      // Sort: Google and Natural voices at top of browser voices
      const sorted = browserVoices.slice().sort((a, b) => {
        const aGoogle = a.name.includes('Google') || a.name.includes('Natural');
        const bGoogle = b.name.includes('Google') || b.name.includes('Natural');
        if (aGoogle && !bGoogle) return -1;
        if (!aGoogle && bGoogle) return 1;
        return a.name.localeCompare(b.name);
      });

      for (const bv of sorted) {
        const opt = h('option', { value: 'browser:' + bv.name }, bv.name + (bv.lang ? ` (${bv.lang})` : ''));
        browserGroup.appendChild(opt);
      }

      if (sorted.length > 0) {
        select.appendChild(browserGroup);
      }

      select.value = currentVoice;
      if (!select.value && select.options.length > 0) {
        select.selectedIndex = 0;
      }
    }

    toggleTts() {
      if (this.ttsState === 'playing') {
        this.pauseTts();
      } else if (this.ttsState === 'paused') {
        this.resumeTts();
      } else {
        this.startTts();
      }
    }

    highlightActiveTranscriptLine(cue) {
      if (!this.bodyEl) return;
      this.currentSpeakingCue = cue;
      const allLines = this.bodyEl.querySelectorAll('.yt-transcript-line');
      for (const line of allLines) {
        line.classList.remove('yt-transcript-line-speaking');
        const ind = line.querySelector('.yt-speaking-indicator');
        if (ind) ind.remove();
      }

      if (!cue) return;
      let targetEl = cue.lineEl && cue.lineEl.isConnected ? cue.lineEl : null;
      if (!targetEl) {
        targetEl = this.bodyEl.querySelector(`.yt-transcript-line[data-start-sec="${cue.startSec}"]`);
      }
      if (!targetEl && cue.tsStr) {
        targetEl = this.bodyEl.querySelector(`.yt-transcript-line[data-ts="${cue.tsStr}"]`);
      }
      if (!targetEl && typeof cue.lineIndex === 'number') {
        targetEl = this.bodyEl.querySelector(`.yt-transcript-line[data-line-idx="${cue.lineIndex}"]`);
      }
      if (targetEl) {
        targetEl.classList.add('yt-transcript-line-speaking');
        if (!targetEl.querySelector('.yt-speaking-indicator')) {
          const badge = h('span', { className: 'yt-speaking-indicator', title: `Speaking ${cue.tsStr}` });
          badge.appendChild(iconSpeaker(12));
          targetEl.insertBefore(badge, targetEl.firstChild);
        }
        try {
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } catch (_) {}
      }
    }

    clearTranscriptHighlight() {
      this.currentSpeakingCue = null;
      if (this.ttsProgressTimer) {
        clearInterval(this.ttsProgressTimer);
        this.ttsProgressTimer = null;
      }
      if (!this.bodyEl) return;
      const allLines = this.bodyEl.querySelectorAll('.yt-transcript-line');
      for (const line of allLines) {
        line.classList.remove('yt-transcript-line-speaking');
        const ind = line.querySelector('.yt-speaking-indicator');
        if (ind) ind.remove();
      }
    }

    async startTts() {
      if (!this.text || this.status !== 'done') return;
      this.stopTts();
      const clean = cleanTextForSpeech(this.text, { skipSilence: this.skipSilence });
      if (!clean) return;

      this.clearTranscriptHighlight();

      let transcriptCues = null;
      let fullSpoken = clean;
      if (this.mode === 'transcript') {
        const parsed = parseTranscriptCues(this.text, { skipSilence: this.skipSilence });
        transcriptCues = parsed.cues;
        if (parsed.fullSpokenText) fullSpoken = parsed.fullSpokenText;
        this.transcriptCues = transcriptCues;
        if (transcriptCues.length > 0) {
          this.highlightActiveTranscriptLine(transcriptCues[0]);
        }
      }

      const voiceChoice = this.getTtsVoice();

      // Path 1: Google AI Studio Neural Voice (gemini-3.8-flash-lite-tts)
      if (voiceChoice.startsWith('ai:')) {
        const voiceName = voiceChoice.slice(3);
        const keyObj = getStoredKeys().find((k) => k.id === this.keyId) || getStoredKeys()[0];

        if (keyObj?.key) {
          try {
            this.ttsState = 'loading';
            this.updateTtsUI();

            const dataUrl = await generateAiSpeech(fullSpoken, voiceName, keyObj);
            if (this.ttsState !== 'loading') return; // Cancelled

            const audio = new Audio(dataUrl);
            audio.playbackRate = this.ttsRate;
            audio.volume = this.ttsVolume;

            if (transcriptCues && transcriptCues.length > 0) {
              audio.ontimeupdate = () => {
                if (this.mode !== 'transcript' || !audio.duration) return;
                const cue = findActiveCueByTime(transcriptCues, audio.currentTime, audio.duration);
                if (cue && this.currentSpeakingCue !== cue) {
                  this.highlightActiveTranscriptLine(cue);
                }
              };
            }

            audio.onended = () => {
              this.clearTranscriptHighlight();
              this.ttsState = 'idle';
              this.ttsAudioEl = null;
              this.updateTtsUI();
            };
            audio.onerror = (e) => {
              if (CONFIG.debug) console.warn('[YTAIS] AI Audio playback error:', e);
              this.clearTranscriptHighlight();
              this.ttsState = 'idle';
              this.ttsAudioEl = null;
              this.updateTtsUI();
            };

            this.ttsAudioEl = audio;
            this.ttsState = 'playing';
            this.updateTtsUI();

            try {
              await audio.play();
            } catch (err) {
              if (CONFIG.debug) console.warn('[YTAIS] Audio play rejected:', err);
              this.clearTranscriptHighlight();
              this.ttsState = 'idle';
              this.ttsAudioEl = null;
              this.updateTtsUI();
            }
            return;
          } catch (aiErr) {
            if (CONFIG.debug) console.warn('[YTAIS] AI Studio TTS generation failed, falling back to Web Speech:', aiErr);
            if (!this.notes.some((n) => n.includes('AI Studio TTS'))) {
              this.notes.push(`ℹ AI Studio TTS (${voiceName}) unavailable (${aiErr.message || 'error'}), using browser voice.`);
              this.renderBody();
            }
          }
        } else {
          // No key configured: notify user that neural voice needs an API key
          if (!this.notes.some((n) => n.includes('AI Studio Neural voices require'))) {
            this.notes.push('ℹ Google AI Studio Neural voices require an API key (⚙ in toolbar). Using browser voice.');
            this.renderBody();
          }
        }
      }

      // Path 2: Browser Web Speech API (fallback or when browser voice chosen)
      if (!window.speechSynthesis) return;
      window.speechSynthesis.cancel();

      const utt = new SpeechSynthesisUtterance(fullSpoken);
      utt.rate = this.ttsRate;
      utt.volume = this.ttsVolume;
      utt.pitch = this.ttsPitch;

      // Select matching browser voice or pick best Google voice
      const voices = window.speechSynthesis.getVoices ? window.speechSynthesis.getVoices() : [];
      let targetVoice = null;
      if (voiceChoice.startsWith('browser:')) {
        const vName = voiceChoice.slice(8);
        targetVoice = voices.find((v) => v.name === vName);
      }
      if (!targetVoice) {
        targetVoice =
          voices.find((v) => (v.name.includes('Google') || v.name.includes('Natural')) && v.lang?.startsWith('en')) ||
          voices.find((v) => v.name.includes('Google')) ||
          voices.find((v) => v.lang?.startsWith('en')) ||
          voices[0];
      }
      if (targetVoice) {
        try {
          utt.voice = targetVoice;
        } catch (_) {}
      }

      if (transcriptCues && transcriptCues.length > 0) {
        utt.onboundary = (e) => {
          this.ttsBoundaryPulse = 1.0;
          if (this.mode !== 'transcript') return;
          const cue = findActiveCueByCharIndex(transcriptCues, e.charIndex);
          if (cue && this.currentSpeakingCue !== cue) {
            this.highlightActiveTranscriptLine(cue);
          }
        };

        const startPlaybackTime = Date.now();
        const totalChars = transcriptCues[transcriptCues.length - 1].charEnd || fullSpoken.length;
        const estTotalDurationMs = Math.max(1000, (totalChars / 14) * (1000 / this.ttsRate));
        this.ttsProgressTimer = setInterval(() => {
          if (this.ttsState !== 'playing') {
            if (this.ttsProgressTimer) clearInterval(this.ttsProgressTimer);
            return;
          }
          const elapsed = Date.now() - startPlaybackTime;
          const progress = Math.min(1, elapsed / estTotalDurationMs);
          const estChar = Math.round(progress * totalChars);
          const cue = findActiveCueByCharIndex(transcriptCues, estChar);
          if (cue && this.currentSpeakingCue !== cue) {
            this.highlightActiveTranscriptLine(cue);
          }
        }, 250);
      } else {
        utt.onboundary = () => {
          this.ttsBoundaryPulse = 1.0;
        };
      }

      utt.onend = () => {
        this.clearTranscriptHighlight();
        this.ttsState = 'idle';
        this.ttsUtterance = null;
        this.updateTtsUI();
      };
      utt.onerror = (e) => {
        if (e && e.error !== 'canceled' && e.error !== 'interrupted') {
          console.warn('TTS error:', e);
        }
        this.clearTranscriptHighlight();
        this.ttsState = 'idle';
        this.ttsUtterance = null;
        this.updateTtsUI();
      };

      this.ttsUtterance = utt;
      this.ttsState = 'playing';
      if (transcriptCues && transcriptCues.length > 0) {
        this.highlightActiveTranscriptLine(transcriptCues[0]);
      }
      window.speechSynthesis.speak(utt);
      this.updateTtsUI();
    }

    pauseTts() {
      if (this.ttsProgressTimer) {
        clearInterval(this.ttsProgressTimer);
        this.ttsProgressTimer = null;
      }
      if (this.ttsAudioEl) {
        this.ttsAudioEl.pause();
        this.ttsState = 'paused';
        this.updateTtsUI();
        this.showTtsFeedback('⏸ Paused');
      } else if (window.speechSynthesis && this.ttsState === 'playing') {
        window.speechSynthesis.pause();
        this.ttsState = 'paused';
        this.updateTtsUI();
        this.showTtsFeedback('⏸ Paused');
      }
    }

    resumeTts() {
      if (this.ttsAudioEl && this.ttsState === 'paused') {
        this.ttsAudioEl.play();
        this.ttsState = 'playing';
        this.updateTtsUI();
        this.showTtsFeedback('▶ Playing');
      } else if (window.speechSynthesis && this.ttsState === 'paused') {
        window.speechSynthesis.resume();
        this.ttsState = 'playing';
        this.updateTtsUI();
        this.showTtsFeedback('▶ Playing');
      }
    }

    stopTts() {
      this.clearTranscriptHighlight();
      if (this.ttsProgressTimer) {
        clearInterval(this.ttsProgressTimer);
        this.ttsProgressTimer = null;
      }
      if (this._ttsFeedbackTimer) {
        clearTimeout(this._ttsFeedbackTimer);
        this._ttsFeedbackTimer = null;
      }
      if (this.ttsAudioEl) {
        try {
          this.ttsAudioEl.ontimeupdate = null;
          this.ttsAudioEl.onended = null;
          this.ttsAudioEl.onerror = null;
          this.ttsAudioEl.pause();
          this.ttsAudioEl.currentTime = 0;
          this.ttsAudioEl.src = '';
          this.ttsAudioEl.load();
        } catch (_) {}
        this.ttsAudioEl = null;
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      this.ttsState = 'idle';
      this.ttsUtterance = null;
      this.updateTtsUI();
    }

    rewindTts(sec = 5) {
      if (this.status !== 'done' || !this.text) return;

      if (this.ttsAudioEl) {
        const cur = this.ttsAudioEl.currentTime || 0;
        const target = Math.max(0, cur - sec);
        this.ttsAudioEl.currentTime = target;
        const s = Math.round(target);
        const m = Math.floor(s / 60);
        const secRem = s % 60;
        this.showTtsFeedback(`⏪ Rewind ${sec}s (${m}:${secRem < 10 ? '0' : ''}${secRem})`);
        return;
      }

      if (window.speechSynthesis) {
        const clean = cleanTextForSpeech(this.text, { skipSilence: this.skipSilence });
        if (!clean) return;

        if (this.ttsState === 'idle') {
          this.startTts();
          this.showTtsFeedback(`⏪ Rewind ${sec}s`);
          return;
        }

        const sentences = clean.match(/[^.!?\n]+[.!?\n]*/g) || [clean];
        const prevIdx = Math.max(0, (this.ttsSentenceIndex || 0) - 1);
        this.ttsSentenceIndex = prevIdx;
        this.speakFromSentence(sentences, prevIdx);
        this.showTtsFeedback(`⏪ Rewound (${prevIdx + 1}/${sentences.length})`);
      }
    }

    skipTts(sec = 5) {
      if (this.status !== 'done' || !this.text) return;

      if (this.ttsAudioEl) {
        const cur = this.ttsAudioEl.currentTime || 0;
        const dur = this.ttsAudioEl.duration || Infinity;
        const target = Math.min(dur, cur + sec);
        this.ttsAudioEl.currentTime = target;
        const s = Math.round(target);
        const m = Math.floor(s / 60);
        const secRem = s % 60;
        this.showTtsFeedback(`⏩ Skip ${sec}s (${m}:${secRem < 10 ? '0' : ''}${secRem})`);
        return;
      }

      if (window.speechSynthesis) {
        const clean = cleanTextForSpeech(this.text, { skipSilence: this.skipSilence });
        if (!clean) return;

        if (this.ttsState === 'idle') {
          this.startTts();
          this.showTtsFeedback(`⏩ Skip ${sec}s`);
          return;
        }

        const sentences = clean.match(/[^.!?\n]+[.!?\n]*/g) || [clean];
        const nextIdx = Math.min(sentences.length - 1, (this.ttsSentenceIndex || 0) + 1);
        this.ttsSentenceIndex = nextIdx;
        this.speakFromSentence(sentences, nextIdx);
        this.showTtsFeedback(`⏩ Skipped (${nextIdx + 1}/${sentences.length})`);
      }
    }

    speakFromSentence(sentences, startIndex) {
      if (!window.speechSynthesis) return;
      window.speechSynthesis.cancel();

      const remainingText = sentences.slice(startIndex).join(' ').trim();
      if (!remainingText) {
        this.ttsState = 'idle';
        this.ttsUtterance = null;
        this.updateTtsUI();
        return;
      }

      const utt = new SpeechSynthesisUtterance(remainingText);
      utt.rate = this.ttsRate;
      utt.volume = this.ttsVolume;
      utt.pitch = this.ttsPitch;

      const voiceChoice = this.getTtsVoice();
      const voices = window.speechSynthesis.getVoices ? window.speechSynthesis.getVoices() : [];
      let targetVoice = null;
      if (voiceChoice.startsWith('browser:')) {
        const vName = voiceChoice.slice(8);
        targetVoice = voices.find((v) => v.name === vName);
      }
      if (!targetVoice) {
        targetVoice =
          voices.find((v) => (v.name.includes('Google') || v.name.includes('Natural')) && v.lang?.startsWith('en')) ||
          voices.find((v) => v.name.includes('Google')) ||
          voices.find((v) => v.lang?.startsWith('en')) ||
          voices[0];
      }
      if (targetVoice) {
        try { utt.voice = targetVoice; } catch (_) {}
      }

      utt.onboundary = () => {
        this.ttsBoundaryPulse = 1.0;
      };

      utt.onend = () => {
        this.ttsState = 'idle';
        this.ttsUtterance = null;
        this.updateTtsUI();
      };
      utt.onerror = (e) => {
        if (e && e.error !== 'canceled' && e.error !== 'interrupted') {
          console.warn('TTS error:', e);
        }
        this.ttsState = 'idle';
        this.ttsUtterance = null;
        this.updateTtsUI();
      };

      this.ttsUtterance = utt;
      this.ttsState = 'playing';
      window.speechSynthesis.speak(utt);
      this.updateTtsUI();
    }

    stepTtsRate(dir) {
      const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
      const curIdx = rates.findIndex((r) => Math.abs(r - this.ttsRate) < 0.05);
      let nextIdx = curIdx === -1 ? 2 : curIdx + dir;
      nextIdx = Math.max(0, Math.min(rates.length - 1, nextIdx));
      this.setTtsRate(rates[nextIdx]);
      this.showTtsFeedback(`⚡ Speed: ${rates[nextIdx]}x`);
    }

    toggleTtsMute() {
      if (this.ttsAudioEl) {
        this.ttsAudioEl.muted = !this.ttsAudioEl.muted;
        this.showTtsFeedback(this.ttsAudioEl.muted ? '🔇 Muted' : `🔊 Volume: ${Math.round(this.ttsVolume * 100)}%`);
      } else {
        if (this.ttsVolume > 0) {
          this._prevTtsVolume = this.ttsVolume;
          this.setTtsVolume(0);
          this.showTtsFeedback('🔇 Muted');
        } else {
          const restore = this._prevTtsVolume || 1.0;
          this.setTtsVolume(restore);
          this.showTtsFeedback(`🔊 Volume: ${Math.round(restore * 100)}%`);
        }
      }
    }

    showTtsFeedback(msg) {
      const container = this.windowBox || this.el || this.modalScrim || modalsContainer;
      if (!container) return;
      let toast = container.querySelector('.yt-tts-toast');
      if (!toast) {
        toast = h('div', { className: 'yt-tts-toast' });
        container.appendChild(toast);
      }
      toast.textContent = msg;
      toast.classList.remove('yt-tts-toast-show');
      void toast.offsetWidth; // trigger reflow
      toast.classList.add('yt-tts-toast-show');

      if (this._ttsFeedbackTimer) clearTimeout(this._ttsFeedbackTimer);
      this._ttsFeedbackTimer = setTimeout(() => {
        toast?.classList.remove('yt-tts-toast-show');
      }, 1200);
    }

    cycleTtsRate() {
      const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
      const curIdx = rates.findIndex((r) => Math.abs(r - this.ttsRate) < 0.05);
      const nextIdx = curIdx === -1 ? 2 : (curIdx + 1) % rates.length;
      this.setTtsRate(rates[nextIdx]);
    }

    startWaveformAnimation() {
      if (this.waveformAnimId) return;

      const render = () => {
        const isPlaying = this.ttsState === 'playing';
        const amps = computeWaveformAmplitudes({
          isPlaying,
          volume: this.ttsVolume,
          pitch: this.ttsPitch,
          rate: this.ttsRate,
          timestamp: Date.now(),
          barCount: 12,
          boundaryPulse: this.ttsBoundaryPulse || 0
        });

        if (this.ttsBoundaryPulse > 0.05) {
          this.ttsBoundaryPulse *= 0.88;
        } else {
          this.ttsBoundaryPulse = 0;
        }

        // Draw on canvas
        if (this.ttsWaveformCanvas) {
          const cvs = this.ttsWaveformCanvas;
          const ctx = cvs.getContext ? cvs.getContext('2d') : null;
          if (ctx) {
            const w = cvs.width || 68;
            const h = cvs.height || 18;
            ctx.clearRect(0, 0, w, h);

            const numBars = amps.length;
            const gap = 2;
            const totalGap = gap * (numBars - 1);
            const barW = Math.max(2, (w - totalGap) / numBars);

            const grad = ctx.createLinearGradient(0, h, 0, 0);
            grad.addColorStop(0, '#0284c7');
            grad.addColorStop(0.5, '#38bdf8');
            grad.addColorStop(1, '#c084fc');

            for (let i = 0; i < numBars; i++) {
              const a = amps[i];
              const barH = Math.max(2, a * (h - 2));
              const x = i * (barW + gap);
              const y = (h - barH) / 2;

              ctx.fillStyle = isPlaying ? grad : 'rgba(255, 255, 255, 0.2)';
              ctx.beginPath();
              if (ctx.roundRect) {
                ctx.roundRect(x, y, barW, barH, 1.5);
              } else {
                ctx.rect(x, y, barW, barH);
              }
              ctx.fill();
            }
          }
        }

        // Also update DOM bars for accessibility and test verification
        if (this.ttsWaveformBars && this.ttsWaveformBars.length) {
          for (let i = 0; i < this.ttsWaveformBars.length; i++) {
            const bar = this.ttsWaveformBars[i];
            const a = amps[i] || 0.08;
            bar.style.height = `${Math.round(a * 16)}px`;
            bar.setAttribute('data-amp', String(a));
          }
        }

        if (this.ttsState === 'playing') {
          this.waveformAnimId = requestAnimationFrame(render);
        } else {
          this.waveformAnimId = null;
        }
      };

      this.waveformAnimId = requestAnimationFrame(render);
    }

    stopWaveformAnimation() {
      if (this.waveformAnimId) {
        cancelAnimationFrame(this.waveformAnimId);
        this.waveformAnimId = null;
      }
      this.ttsBoundaryPulse = 0;
      if (this.ttsWaveformCanvas) {
        const cvs = this.ttsWaveformCanvas;
        const ctx = cvs.getContext ? cvs.getContext('2d') : null;
        if (ctx) {
          const w = cvs.width || 68;
          const h = cvs.height || 18;
          ctx.clearRect(0, 0, w, h);
          const numBars = 12;
          const gap = 2;
          const barW = Math.max(2, (w - gap * (numBars - 1)) / numBars);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
          for (let i = 0; i < numBars; i++) {
            const x = i * (barW + gap);
            const y = (h - 2) / 2;
            ctx.fillRect(x, y, barW, 2);
          }
        }
      }
      if (this.ttsWaveformBars) {
        for (const bar of this.ttsWaveformBars) {
          bar.style.height = '2px';
          bar.setAttribute('data-amp', '0.08');
        }
      }
    }

    updateTtsUI() {
      if (!this.ttsPlayBtn || !this.ttsStopBtn) return;
      const canPlay = this.status === 'done' && Boolean(this.text);

      if (this.ttsState === 'playing') {
        this.startWaveformAnimation();
      } else {
        this.stopWaveformAnimation();
      }
      if (this.ttsWaveformWrap) {
        this.ttsWaveformWrap.classList.toggle('playing', this.ttsState === 'playing');
      }

      this.ttsPlayBtn.disabled = !canPlay || this.ttsState === 'loading';
      this.ttsPlayBtn.className = `yt-tts-btn yt-tts-play-btn ${this.ttsState === 'playing' ? 'active' : ''}`;
      this.ttsPlayBtn.title =
        this.ttsState === 'loading'
          ? 'Generating AI Studio neural speech…'
          : this.ttsState === 'playing'
          ? 'Pause speech'
          : this.ttsState === 'paused'
          ? 'Resume speech'
          : 'Listen to summary (Google AI Studio neural speech or browser voice)';
      clearEl(this.ttsPlayBtn);
      this.ttsPlayBtn.appendChild(
        this.ttsState === 'loading'
          ? h('div', { className: 'yt-spinner', style: 'width:12px;height:12px;margin-right:2px;' })
          : this.ttsState === 'playing'
          ? iconPause(14)
          : this.ttsState === 'paused'
          ? iconPlay(14)
          : iconSpeaker(14)
      );
      this.ttsPlayBtn.appendChild(
        h(
          'span',
          {},
          this.ttsState === 'loading'
            ? 'Generating…'
            : this.ttsState === 'playing'
            ? 'Pause'
            : this.ttsState === 'paused'
            ? 'Resume'
            : 'Listen'
        )
      );

      this.ttsStopBtn.disabled = !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance);
      if (this.ttsRewindBtn) {
        this.ttsRewindBtn.disabled = !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance);
      }
      if (this.ttsSkipBtn) {
        this.ttsSkipBtn.disabled = !canPlay || (this.ttsState === 'idle' && !this.ttsAudioEl && !this.ttsUtterance);
      }

      if (this.ttsSpeedSlider) {
        this.ttsSpeedSlider.disabled = !canPlay;
        this.ttsSpeedSlider.value = String(this.ttsRate);
        this.ttsSpeedSlider.title = `Playback speed: ${this.ttsRate}x`;
      }
      if (this.ttsSpeedLabel) {
        this.ttsSpeedLabel.textContent = `${this.ttsRate}x`;
      }
      if (this.ttsSpeedBtns && this.ttsSpeedBtns.length) {
        for (const b of this.ttsSpeedBtns) {
          const br = parseFloat(b.getAttribute('data-rate'));
          b.classList.toggle('active', Math.abs(br - this.ttsRate) < 0.01);
          b.disabled = !canPlay;
        }
      }
      if (this.ttsRateBtn) {
        this.ttsRateBtn.disabled = !canPlay;
        this.ttsRateBtn.title = `Playback speed: ${this.ttsRate}x (click to cycle 0.25x steps)`;
        let ind = this.ttsRateBtn.querySelector('.yt-tts-speed-indicator');
        let txt = this.ttsRateBtn.querySelector('.yt-tts-speed-text');
        if (!ind || !txt) {
          this.ttsRateBtn.innerHTML = '';
          ind = h('span', {
            className: `yt-tts-speed-indicator ${this.ttsRate > 1.0 ? 'speed-boost' : this.ttsRate < 1.0 ? 'speed-slow' : 'speed-normal'}`
          });
          txt = h('span', { className: 'yt-tts-speed-text' }, `${this.ttsRate}x`);
          this.ttsRateBtn.appendChild(ind);
          this.ttsRateBtn.appendChild(txt);
        } else {
          ind.className = `yt-tts-speed-indicator ${this.ttsRate > 1.0 ? 'speed-boost' : this.ttsRate < 1.0 ? 'speed-slow' : 'speed-normal'}`;
          txt.textContent = `${this.ttsRate}x`;
        }
      }

      if (this.ttsVolumeSlider) {
        this.ttsVolumeSlider.value = String(this.ttsVolume);
        this.ttsVolumeSlider.title = `Speech volume: ${Math.round(this.ttsVolume * 100)}%`;
      }
      if (this.ttsVolumeLabel) {
        this.ttsVolumeLabel.textContent = `${Math.round(this.ttsVolume * 100)}%`;
      }
      if (this.ttsVolumeWrap) {
        this.ttsVolumeWrap.title = `Speech volume: ${Math.round(this.ttsVolume * 100)}%`;
      }

      if (this.ttsPitchSlider) {
        this.ttsPitchSlider.disabled = !canPlay;
        this.ttsPitchSlider.value = String(this.ttsPitch);
        this.ttsPitchSlider.title = `Voice pitch: ${this.ttsPitch}x`;
      }
      if (this.ttsPitchLabel) {
        this.ttsPitchLabel.textContent = `${this.ttsPitch}x`;
      }
      if (this.ttsPitchWrap) {
        this.ttsPitchWrap.title = `Voice pitch: ${this.ttsPitch}x`;
      }

      if (this.ttsVoiceSelect) {
        this.ttsVoiceSelect.value = this.getTtsVoice();
      }

      if (this.ttsSkipSilenceBtn) {
        this.ttsSkipSilenceBtn.disabled = !canPlay;
        this.ttsSkipSilenceBtn.classList.toggle('active', Boolean(this.skipSilence));
        this.ttsSkipSilenceBtn.title = this.skipSilence
          ? 'Skip Silence: ON (Automatically detecting and skipping long pauses or gap segments in transcript)'
          : 'Skip Silence: OFF (Click to automatically detect and skip segments with long pauses)';
      }
    }

    buildCheckbox(label, checked, onChange, disabled = false) {
      const wrap = h('label', { className: `yt-checkbox-label ${disabled ? 'off' : ''}` });
      const input = h('input', {
        type: 'checkbox',
        checked: checked,
        disabled: disabled,
        onchange: (e) => onChange(e.target.checked)
      });
      wrap.appendChild(input);
      wrap.appendChild(document.createTextNode(label));
      return wrap;
    }

    saveOpts() {
      saveGlobalOpts(this.opts);
      this.commit(true);
    }

    populateModelSelect(select) {
      clearEl(select);

      // 1. YouTube Ask
      const askOpt = h(
        'option',
        {
          value: 'YouTube Ask (Gemini in the page)',
          disabled: this.mode === 'transcript'
        },
        'YouTube Ask (Gemini in the page) — Free, no API limit' + (this.mode === 'transcript' ? ' (summaries only)' : '')
      );
      select.appendChild(askOpt);

      // 2. Recommended Group
      const recGroup = h('optgroup', { label: 'Recommended models' });
      for (const m of CONFIG.textModels) {
        recGroup.appendChild(h('option', { value: m }, m));
      }
      select.appendChild(recGroup);

      // 3. Custom Group
      const customs = getCustomModels();
      if (customs.length > 0) {
        const custGroup = h('optgroup', { label: 'Custom models' });
        for (const c of customs) {
          custGroup.appendChild(h('option', { value: c }, c));
        }
        select.appendChild(custGroup);
      }

      // 4. Add custom option
      select.appendChild(h('option', { value: '__custom__' }, '+ Add custom model…'));

      select.value = this.modelId;
      if (!select.value && select.options.length > 0) {
        select.selectedIndex = 1;
        this.modelId = select.value;
      }
    }

    populateKeySelect(select) {
      clearEl(select);
      const keys = getStoredKeys();
      if (keys.length === 0) {
        select.appendChild(h('option', { value: '' }, 'No API keys configured'));
      } else {
        for (const k of keys) {
          const last4 = k.key.length >= 4 ? k.key.slice(-4) : k.key;
          select.appendChild(h('option', { value: k.id }, `${k.name} (…${last4})`));
        }
      }
      select.appendChild(h('option', { value: '__manage__' }, '⚙ Add / manage keys…'));
      select.value = this.keyId || (keys[0]?.id || '');
    }

    buildAdvancedPanel() {
      const panel = h('div', { className: 'yt-adv-panel', style: 'display:none;' });

      // Group 1: Gemini
      const g1 = h('div', { className: 'yt-adv-group' });
      g1.appendChild(h('div', { className: 'yt-adv-title' }, 'Gemini options'));
      g1.appendChild(
        this.buildSelectRow('Thinking', this.opts.think, ['', 'low', 'medium', 'high'], (v) => {
          this.opts.think = v;
          this.saveOpts();
        })
      );
      g1.appendChild(
        this.buildSelectRow(
          'Media resolution',
          this.opts.mres,
          ['', 'MEDIA_RESOLUTION_LOW', 'MEDIA_RESOLUTION_MEDIUM', 'MEDIA_RESOLUTION_HIGH'],
          (v) => {
            this.opts.mres = v;
            this.saveOpts();
          }
        )
      );
      g1.appendChild(
        this.buildCheckbox('Google Search grounding', this.opts.gsearch, (v) => {
          this.opts.gsearch = v;
          this.saveOpts();
        })
      );
      g1.appendChild(
        this.buildCheckbox('Google Maps grounding', this.opts.gmaps, (v) => {
          this.opts.gmaps = v;
          this.saveOpts();
        })
      );
      g1.appendChild(
        this.buildCheckbox('Code execution', this.opts.code, (v) => {
          this.opts.code = v;
          this.saveOpts();
        })
      );
      panel.appendChild(g1);

      // Group 2: Fact-check & sources
      const g2 = h('div', { className: 'yt-adv-group' });
      g2.appendChild(h('div', { className: 'yt-adv-title' }, 'Fact-check & sources'));
      g2.appendChild(
        this.buildSelectRow('Fact-check model', this.opts.factModel, ['', ...CONFIG.factPreferred], (v) => {
          this.opts.factModel = v;
          this.saveOpts();
        })
      );
      panel.appendChild(g2);

      // Group 3: Images (Nano Banana)
      const g3 = h('div', { className: 'yt-adv-group' });
      g3.appendChild(h('div', { className: 'yt-adv-title' }, 'Images (Nano Banana)'));
      g3.appendChild(
        this.buildSelectRow('Image model', this.opts.imgModel, ['', ...CONFIG.imageModels], (v) => {
          this.opts.imgModel = v;
          this.saveOpts();
        })
      );
      g3.appendChild(
        this.buildSelectRow(
          'Aspect ratio',
          this.opts.imgAspect,
          ['', '1:1', '2:3', '3:2', '3:4', '4:3', '4:5', '5:4', '9:16', '16:9', '21:9'],
          (v) => {
            this.opts.imgAspect = v;
            this.saveOpts();
          }
        )
      );
      g3.appendChild(
        this.buildSelectRow('Output mode', this.opts.imgOut, ['both', 'image'], (v) => {
          this.opts.imgOut = v;
          this.saveOpts();
        })
      );
      g3.appendChild(
        this.buildCheckbox('Image Search grounding', this.opts.imgSearch, (v) => {
          this.opts.imgSearch = v;
          this.saveOpts();
        })
      );
      panel.appendChild(g3);

      // Group 4: Reliability
      const g4 = h('div', { className: 'yt-adv-group' });
      g4.appendChild(h('div', { className: 'yt-adv-title' }, 'Reliability & Fallbacks'));
      g4.appendChild(
        this.buildSelectRow(
          'Auto-retry count',
          String(this.opts.retries),
          ['0', '1', '2', '3', '5', '10'],
          (v) => {
            this.opts.retries = parseInt(v, 10);
            this.saveOpts();
          }
        )
      );
      g4.appendChild(
        this.buildCheckbox('Fall back to next model down', this.opts.fallback, (v) => {
          this.opts.fallback = v;
          this.saveOpts();
        })
      );
      g4.appendChild(
        this.buildCheckbox('Use transcript if video limit hit', this.opts.txFallback, (v) => {
          this.opts.txFallback = v;
          this.saveOpts();
        })
      );
      const altTitleCbRow = this.buildCheckbox('Alternative AI titles for feed thumbnails (<= 150 chars, no clickbait)', getAltTitlesEnabled(), (v) => {
        setAltTitlesEnabled(v);
      });
      const altCbInput = altTitleCbRow.querySelector('input[type="checkbox"]');
      if (altCbInput) altCbInput.classList.add('yt-alt-titles-setting-checkbox');
      g4.appendChild(altTitleCbRow);
      panel.appendChild(g4);

      // Group 5: Transcript Processing Settings
      const g5 = h('div', { className: 'yt-adv-group yt-adv-tp-group' });
      g5.appendChild(h('div', { className: 'yt-adv-title' }, 'Transcript Processing'));
      g5.appendChild(
        this.buildSelectRow(
          'Processing Mode',
          this.opts.transcriptMode || 'fast',
          ['fast', 'deep'],
          (v) => {
            this.opts.transcriptMode = v;
            this.saveOpts();
            if (this.windowBox) {
              const fBtn = this.windowBox.querySelector('.yt-tp-fast-btn');
              const dBtn = this.windowBox.querySelector('.yt-tp-deep-btn');
              if (fBtn && dBtn) {
                fBtn.classList.toggle('active', v === 'fast');
                dBtn.classList.toggle('active', v === 'deep');
              }
            }
          }
        )
      );
      const tpDesc = h(
        'div',
        { className: 'yt-adv-desc', style: 'font-size:11px; color:#aaa; margin-top:4px;' },
        'Modifies the Gemini system prompt: "Fast" creates a concise executive brief; "Deep" creates an exhaustive chronological analysis with deep technical context.'
      );
      g5.appendChild(tpDesc);
      panel.appendChild(g5);

      // Group 6: Dock & Interface Settings
      const g6 = h('div', { className: 'yt-adv-group yt-adv-dock-group' });
      g6.appendChild(h('div', { className: 'yt-adv-title' }, 'Dock & Interface'));
      const visRow = h('div', { className: 'yt-adv-row' });
      visRow.appendChild(h('span', { className: 'yt-adv-label' }, 'History dock tab'));
      const visSelect = h(
        'select',
        {
          className: 'yt-select yt-adv-select yt-history-visibility-select',
          'aria-label': 'History tab visibility',
          onchange: (e) => {
            setHistoryTabVisibility(e.target.value);
          }
        },
        h('option', { value: 'always' }, 'Always shown'),
        h('option', { value: 'with_tabs' }, 'Only with open/minimized tabs'),
        h('option', { value: 'never' }, 'Never shown')
      );
      visSelect.value = getHistoryTabVisibility();
      visRow.appendChild(visSelect);
      g6.appendChild(visRow);
      panel.appendChild(g6);

      return panel;
    }

    buildSelectRow(label, currentVal, options, onChange) {
      const wrap = h('div', { className: 'yt-adv-row' });
      wrap.appendChild(h('span', { className: 'yt-adv-label' }, label));
      const sel = h('select', {
        className: 'yt-select yt-adv-select',
        onchange: (e) => onChange(e.target.value)
      });
      for (const opt of options) {
        sel.appendChild(h('option', { value: opt }, opt || 'Auto / Default'));
      }
      sel.value = currentVal;
      wrap.appendChild(sel);
      return wrap;
    }

    buildComposer() {
      const wrap = h('div', { className: 'yt-composer-wrap' });
      const savedDraft = getDraftFollowUp(this.videoId);

      const ta = h('textarea', {
        className: 'yt-composer-textarea',
        placeholder: this.status === 'done' ? 'Ask a follow-up question (Enter to send)…' : 'Summarise first to ask follow-up questions',
        disabled: this.status !== 'done' || this.busy,
        rows: 1,
        oninput: (e) => {
          // Auto-grow textarea up to 120px
          ta.style.height = 'auto';
          ta.style.height = Math.min(120, Math.max(38, ta.scrollHeight)) + 'px';
          // Auto-save draft on input
          setDraftFollowUp(this.videoId, ta.value);
          if (this.composerDraftBadge) {
            this.composerDraftBadge.style.display = ta.value.trim() ? 'inline-flex' : 'none';
          }
        },
        onkeydown: (e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            this.sendFollowUp();
          }
        }
      });
      if (savedDraft) {
        ta.value = savedDraft;
        setTimeout(() => {
          if (ta) {
            ta.style.height = 'auto';
            ta.style.height = Math.min(120, Math.max(38, ta.scrollHeight)) + 'px';
          }
        }, 10);
      }
      this.composerTa = ta;

      const draftBadge = h(
        'span',
        {
          className: 'yt-composer-draft-badge',
          title: 'Unfinished question auto-saved to local storage (persists if window closes)',
          style: { display: savedDraft ? 'inline-flex' : 'none' }
        },
        'Draft auto-saved'
      );
      this.composerDraftBadge = draftBadge;

      const micBtn = h(
        'button',
        {
          className: 'yt-composer-mic-btn',
          title: 'Voice input (Speech to Text with gemini-3.5-transcribe / Web Speech)',
          disabled: this.status !== 'done' || this.busy,
          onclick: () => this.toggleVoiceInput(micBtn, ta)
        },
        iconMic(14)
      );
      this.composerMicBtn = micBtn;

      const sendBtn = h(
        'button',
        {
          className: 'yt-composer-send-btn',
          disabled: this.status !== 'done' || this.busy,
          onclick: () => this.sendFollowUp()
        },
        'Send'
      );
      this.composerBtn = sendBtn;

      wrap.appendChild(ta);
      wrap.appendChild(draftBadge);
      wrap.appendChild(micBtn);
      wrap.appendChild(sendBtn);
      return wrap;
    }

    toggleVoiceInput(micBtn, ta) {
      const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (this._isListening) {
        if (this._speechRecInstance) {
          try { this._speechRecInstance.stop(); } catch (_) {}
          this._speechRecInstance = null;
        }
        this._isListening = false;
        if (micBtn) {
          micBtn.classList.remove('yt-mic-recording');
          micBtn.title = 'Voice input (Speech to Text with gemini-3.5-transcribe / Web Speech)';
        }
        return;
      }

      if (window.__yt_mock_voice_text || !SpeechRec) {
        const sample = window.__yt_mock_voice_text || 'Can you highlight the key takeaways and conclusions?';
        if (ta) {
          ta.value = (ta.value ? ta.value + ' ' : '') + sample;
          setDraftFollowUp(this.videoId, ta.value);
          if (this.composerDraftBadge) {
            this.composerDraftBadge.style.display = 'inline-flex';
          }
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        }
        this.showTtsFeedback('🎤 Voice transcribed');
        return;
      }

      try {
        const rec = new SpeechRec();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = 'en-US';
        this._speechRecInstance = rec;
        this._isListening = true;

        if (micBtn) {
          micBtn.classList.add('yt-mic-recording');
          micBtn.title = 'Listening… Click to stop';
        }

        rec.onresult = (evt) => {
          const transcript = evt.results?.[0]?.[0]?.transcript;
          if (transcript && ta) {
            ta.value = (ta.value ? ta.value + ' ' : '') + transcript;
            setDraftFollowUp(this.videoId, ta.value);
            if (this.composerDraftBadge) {
              this.composerDraftBadge.style.display = 'inline-flex';
            }
            ta.dispatchEvent(new Event('input', { bubbles: true }));
          }
        };

        rec.onerror = () => {
          this._isListening = false;
          if (micBtn) {
            micBtn.classList.remove('yt-mic-recording');
            micBtn.title = 'Voice input (Speech to Text with gemini-3.5-transcribe / Web Speech)';
          }
        };

        rec.onend = () => {
          this._isListening = false;
          if (micBtn) {
            micBtn.classList.remove('yt-mic-recording');
            micBtn.title = 'Voice input (Speech to Text with gemini-3.5-transcribe / Web Speech)';
          }
        };

        rec.start();
      } catch (err) {
        this._isListening = false;
        if (micBtn) {
          micBtn.classList.remove('yt-mic-recording');
        }
      }
    }

    async sendFollowUp() {
      if (!this.composerTa || this.busy || this.status === 'busy') return;
      const q = this.composerTa.value.trim();
      if (!q) return;

      clearDraftFollowUp(this.videoId);
      if (this.composerDraftBadge) {
        this.composerDraftBadge.style.display = 'none';
      }
      this.composerTa.value = '';
      this.composerTa.style.height = '38px';
      this.busy = true;
      this.status = 'busy';
      this.renderBody();

      try {
        let answerText = '';
        let answerSources = [];
        let askFellBack = false;

        const runGeminiFollowUp = async (modelToTry) => {
          const keyObj = getStoredKeys().find((k) => k.id === this.keyId) || getStoredKeys()[0];
          if (!keyObj) throw new Error('No API key configured for follow-up');

          const followPrompt = `You are answering a user follow-up question about the YouTube video "${this.title}".
Answer accurately using the video and Google Search if available. Cite timestamps [MM:SS] when relevant.
EXCLUDE entirely: sponsor segments and self-promotion unless the user asks specifically.

${this.mode === 'transcript' ? 'TRANSCRIPT YOU WROTE:' : 'SUMMARY YOU WROTE:'}
"""
${this.text.slice(0, 8000)}
"""

RECENT CONVERSATION:
${this.turns.slice(-CONFIG.historyTurns).map((t) => `User: ${t.q}\nAssistant: ${t.a}`).join('\n\n')}

FOLLOW-UP QUESTION:
${q}`;

          const parts = [];
          if (this.source === 'video') {
            parts.push({ file_data: { file_uri: `https://www.youtube.com/watch?v=${this.videoId}` } });
          }
          parts.push({ text: followPrompt });

          const body = { contents: [{ role: 'user', parts }] };
          const tools = [];
          if (this.opts.gsearch) tools.push({ google_search: {} });
          if (this.opts.gmaps) tools.push({ google_maps: {} });
          if (tools.length > 0) body.tools = tools;

          const res = await callGeminiRaw(modelToTry, keyObj.key, body);
          const cand = res.candidates?.[0];
          const textOut = cand?.content?.parts?.map((p) => p.text || '').join('') || '';
          const sourcesOut = [];
          if (cand?.groundingMetadata?.groundingChunks) {
            for (const c of cand.groundingMetadata.groundingChunks) {
              if (c.web?.uri) sourcesOut.push({ uri: c.web.uri, title: c.web.title || c.web.uri });
              if (c.maps?.uri) sourcesOut.push({ uri: c.maps.uri, title: c.maps.title || c.maps.uri });
            }
          }
          return { textOut, sourcesOut };
        };

        if (this.modelId.includes('Ask')) {
          const askFollowPrompt = `Earlier you wrote this summary of this video:
"""
${this.text.slice(0, 5000)}
"""
${this.turns.slice(-3).map((t) => `Q: ${t.q}\nA: ${t.a}`).join('\n')}

Now answer this follow-up question about the video, accurately and concisely: ${q}`;

          try {
            const res = await runYouTubeAsk(this.videoId, askFollowPrompt, { isSummary: false });
            answerText = res.text;
          } catch (askErr) {
            const keyObj = getStoredKeys().find((k) => k.id === this.keyId) || getStoredKeys()[0];
            if (!keyObj || !keyObj.key) throw askErr;

            const available = (await checkModelsForKey(keyObj)) || [];
            let curModel = getNextModelDown(this.modelId, available);
            const tried = new Set();
            let lastErr = askErr;
            let succeeded = false;

            while (curModel && !tried.has(curModel)) {
              tried.add(curModel);
              try {
                const gemRes = await runGeminiFollowUp(curModel);
                answerText = gemRes.textOut;
                answerSources = gemRes.sourcesOut;
                const firstLine = (askErr.message || 'YouTube Ask failed').split('\n')[0];
                this.notes.push(`⚠ YouTube Ask failed during follow-up (${firstLine}). Automatically answered with ${curModel}.`);
                this.modelId = curModel;
                askFellBack = true;
                succeeded = true;
                break;
              } catch (gemErr) {
                lastErr = gemErr;
                curModel = getNextModelDown(curModel, available);
              }
            }

            if (!succeeded) throw lastErr;
          }
        } else {
          const gemRes = await runGeminiFollowUp(this.modelId);
          answerText = gemRes.textOut;
          answerSources = gemRes.sourcesOut;
        }

        this.turns.push({ q, a: answerText, sources: answerSources });
        this.status = 'done';
        this.busy = false;

        // Save updated cache
        writeCache(this.videoId, this.mode, this.source, {
          videoId: this.videoId,
          title: this.title,
          gen: this.opts.gen,
          text: this.text,
          sources: this.sources,
          notes: this.notes,
          model: this.modelId,
          usedOpts: this.opts,
          turns: this.turns,
          images: this.images,
          fact: this.fact
        });
        this.commit(true);
        if (askFellBack) {
          this.renderAll();
          return;
        }
      } catch (err) {
        this.turns.push({ q, a: `⚠ Error answering question: ${err.message}` });
        this.status = 'done';
        this.busy = false;
        if (this.composerTa) {
          this.composerTa.value = q;
          setDraftFollowUp(this.videoId, q);
          if (this.composerDraftBadge) {
            this.composerDraftBadge.style.display = 'inline-flex';
          }
        }
      }

      this.renderBody();
    }

    renderBody() {
      if (!this.bodyEl) return;
      clearEl(this.bodyEl);

      // Loading View
      if (this.status === 'loading') {
        const loadBox = h('div', { className: 'yt-loading-view' });
        loadBox.appendChild(h('div', { className: 'yt-big-spinner' }));
        const label = this.source === 'video' ? 'Gemini is watching the video…' : 'Reading the transcript…';
        loadBox.appendChild(h('div', { className: 'yt-loading-text' }, label));
        if (this.phase) {
          loadBox.appendChild(h('div', { className: 'yt-loading-phase' }, this.phase));
        }
        loadBox.appendChild(
          h(
            'div',
            { className: 'yt-loading-tip' },
            'Tip: You can minimize this window to the dock while it runs and keep browsing YouTube!'
          )
        );
        this.bodyEl.appendChild(loadBox);
        return;
      }

      // Error View
      if (this.status === 'error') {
        const errBox = h('div', { className: 'yt-error-view' });
        errBox.appendChild(h('div', { className: 'yt-error-title' }, 'Operation failed'));
        errBox.appendChild(h('div', { className: 'yt-error-msg' }, this.errMsg));

        const actions = h('div', { className: 'yt-error-actions' });
        const retryBtn = h('button', { className: 'yt-primary-btn', onclick: () => this.startJob() }, 'Retry');
        actions.appendChild(retryBtn);

        if (this.errCode === 'NO_KEY') {
          actions.appendChild(
            h(
              'button',
              { className: 'yt-sec-btn', onclick: () => openKeyManagerDialog(() => this.renderAll()) },
              'Add / manage API keys'
            )
          );
        }

        if (this.errCode === 'QUOTA' || this.errCode === 'ASK') {
          const next = getNextModelDown(this.modelId, []);
          if (next) {
            actions.appendChild(
              h(
                'button',
                {
                  className: 'yt-sec-btn',
                  onclick: () => {
                    this.modelId = next;
                    setLastModel(next);
                    this.startJob();
                  }
                },
                `Try ${next}`
              )
            );
          }
        }

        // YouTube Ask Quota Bypass Option (Free • No API Limit / 8-hour daily video limit bypass)
        if (
          this.mode === 'summary' &&
          (this.errCode === 'QUOTA' || /quota|limit|8.?hour|exhausted/i.test(this.errMsg || '')) &&
          !this.modelId.includes('Ask')
        ) {
          actions.appendChild(
            h(
              'button',
              {
                className: 'yt-primary-btn yt-ask-fallback-btn',
                onclick: () => {
                  this.modelId = 'YouTube Ask (Gemini in the page)';
                  this.source = 'video';
                  setLastModel(this.modelId);
                  setLastSource('video');
                  this.startJob();
                }
              },
              'Summarize with YouTube Ask (Free • No API Limit)'
            )
          );
        }

        if (this.source === 'video') {
          actions.appendChild(
            h(
              'button',
              {
                className: 'yt-sec-btn',
                onclick: () => {
                  this.source = 'text';
                  setLastSource('text');
                  this.startJob();
                }
              },
              'Summarize transcript instead'
            )
          );
        }

        const cached = readCache(this.videoId, this.mode, this.source);
        if (cached) {
          actions.appendChild(
            h(
              'button',
              {
                className: 'yt-sec-btn',
                onclick: () => {
                  this.loadFromCache(cached);
                  this.renderAll();
                }
              },
              'Show previous cached summary'
            )
          );
        }

        errBox.appendChild(actions);
        this.bodyEl.appendChild(errBox);
        return;
      }

      // Readability Mode View: If active, render the clean centered typography reader view
      if (this.readabilityMode && this.text) {
        const readerView = this.buildReadabilityView();
        this.bodyEl.appendChild(readerView);
        return;
      }

      // Notes (Warnings & Infos)
      if (this.notes && this.notes.length > 0) {
        const notesWrap = h('div', { className: 'yt-notes-wrap' });
        for (const note of this.notes) {
          notesWrap.appendChild(h('div', { className: 'yt-note-line' }, note));
        }
        this.bodyEl.appendChild(notesWrap);
      }

      // Summary page top action bar (Quick video link, Readability toggle, Export & history browser)
      const pageBar = h('div', { className: 'yt-summary-page-bar' });
      const openVideoPill = h(
        'a',
        {
          className: 'yt-action-pill yt-open-video-pill',
          href: `https://www.youtube.com/watch?v=${this.videoId}`,
          target: '_blank',
          rel: 'noopener noreferrer',
          title: 'Open this YouTube video in a new tab'
        },
        iconExternal(13),
        h('span', {}, 'Open video in new tab')
      );
      const readabilityPill = h(
        'button',
        {
          className: `yt-action-pill yt-readability-pill ${this.readabilityMode ? 'active' : ''}`,
          title: 'Switch to clean distraction-free reader view',
          onclick: () => this.toggleReadability()
        },
        iconBook(13),
        h('span', {}, 'Readability')
      );
      const exportPill = h(
        'button',
        {
          className: 'yt-action-pill yt-export-pill',
          title: 'Export formatted summary or transcript (.txt or .pdf)',
          onclick: (e) => {
            e.stopPropagation();
            this.openExportMenu(exportPill);
          }
        },
        iconExport(13),
        h('span', {}, 'Export')
      );
      const historyPill = h(
        'button',
        {
          className: 'yt-action-pill yt-history-pill',
          title: 'Browse previous summaries that were closed',
          onclick: () => openHistoryDialog()
        },
        iconHistory(13),
        h('span', {}, 'Previous summaries')
      );
      pageBar.appendChild(openVideoPill);
      pageBar.appendChild(readabilityPill);
      pageBar.appendChild(exportPill);
      pageBar.appendChild(historyPill);
      this.bodyEl.appendChild(pageBar);

      // Render Markdown content / Transcript
      if (this.text) {
        if (this.mode === 'transcript') {
          const searchBar = this.buildTranscriptSearch();
          this.bodyEl.appendChild(searchBar);
          const transcriptEl = this.buildTranscriptBody();
          this.bodyEl.appendChild(transcriptEl);
        } else {
          const mdEl = renderMarkdownToDom(this.text, this, (sec) => this.seekPlayer(sec));
          this.bodyEl.appendChild(mdEl);
        }

        const mainTargetType = this.mode === 'transcript' ? 'transcript' : 'summary';
        const ratingBar = this.buildResponseRatingBar({
          targetType: mainTargetType,
          targetId: 'main',
          label: this.mode === 'transcript' ? 'Was this transcript accurate?' : 'Rate this summary'
        });
        this.bodyEl.appendChild(ratingBar);
      }

      // Fact-check box
      if (this.fact) {
        const factBox = h('div', { className: 'yt-fact-box' });
        factBox.appendChild(h('div', { className: 'yt-fact-header' }, 'Fact-check & Verification'));
        const factMd = renderMarkdownToDom(this.fact.text, this, (sec) => this.seekPlayer(sec));
        factBox.appendChild(factMd);

        if (this.fact.sources && this.fact.sources.length > 0) {
          const srcList = h('div', { className: 'yt-sources-consulted' });
          srcList.appendChild(h('div', { className: 'yt-sources-title' }, 'Sources consulted (Google Search):'));
          for (const s of this.fact.sources) {
            srcList.appendChild(
              h(
                'div',
                { className: 'yt-source-item' },
                h('a', { href: s.uri, target: '_blank', rel: 'noopener noreferrer' }, s.title || s.uri)
              )
            );
          }
          factBox.appendChild(srcList);
        }

        const recheckBar = h('div', { className: 'yt-fact-recheck-bar' });
        const recheckBtn = h(
          'button',
          { className: 'yt-sec-btn', onclick: () => this.runFactCheck() },
          'Re-run Fact Check'
        );
        recheckBar.appendChild(recheckBtn);
        factBox.appendChild(recheckBar);

        this.bodyEl.appendChild(factBox);
      }

      // Follow-up conversation bubbles
      if (this.turns && this.turns.length > 0) {
        const thread = h('div', { className: 'yt-thread-wrap' });
        this.turns.forEach((turn, idx) => {
          const userBubble = h('div', { className: 'yt-bubble yt-user-bubble' }, formatMathSymbolsInText(turn.q));
          const ansBubble = h('div', { className: 'yt-bubble yt-ans-bubble' });
          ansBubble.appendChild(renderMarkdownToDom(turn.a, this, (sec) => this.seekPlayer(sec)));
          ansBubble.appendChild(
            this.buildResponseRatingBar({
              targetType: 'followup',
              targetId: `turn_${idx}`,
              label: 'Rate answer',
              compact: true
            })
          );
          thread.appendChild(userBubble);
          thread.appendChild(ansBubble);
        });
        this.bodyEl.appendChild(thread);
      }

      // Scroll to bottom if busy with follow-up
      if (this.busy) {
        const busySpinner = h('div', { className: 'yt-followup-busy' }, 'Gemini is typing answer…');
        this.bodyEl.appendChild(busySpinner);
        setTimeout(() => {
          this.bodyEl.scrollTop = this.bodyEl.scrollHeight;
        }, 10);
      }
    }

    buildResponseRatingBar({ targetType = 'summary', targetId = 'main', label = 'Rate this summary', compact = false } = {}) {
      const existing = getResponseRating(this.videoId, targetType, targetId);
      const wrap = h('div', {
        className: `yt-rating-bar ${compact ? 'compact' : ''}`,
        'data-target-type': targetType,
        'data-target-id': targetId
      });

      const left = h('div', { className: 'yt-rating-left' });
      const labelEl = h('span', { className: 'yt-rating-label' }, label);
      const upBtn = h(
        'button',
        {
          className: `yt-rating-btn yt-rating-up-btn ${existing?.rating === 'up' ? 'active' : ''}`,
          type: 'button',
          title: 'Thumbs up (Helpful)',
          'aria-label': `${label}: Thumbs up`,
          'aria-pressed': existing?.rating === 'up' ? 'true' : 'false'
        },
        iconThumbsUp(13),
        h('span', {}, 'Helpful')
      );
      const downBtn = h(
        'button',
        {
          className: `yt-rating-btn yt-rating-down-btn ${existing?.rating === 'down' ? 'active' : ''}`,
          type: 'button',
          title: 'Thumbs down (Needs improvement)',
          'aria-label': `${label}: Thumbs down`,
          'aria-pressed': existing?.rating === 'down' ? 'true' : 'false'
        },
        iconThumbsDown(13),
        h('span', {}, 'Needs work')
      );
      const statusEl = h(
        'span',
        { className: 'yt-rating-status' },
        existing?.rating === 'up' ? 'Marked helpful' : existing?.rating === 'down' ? 'Feedback noted' : ''
      );

      const noteWrap = h('div', {
        className: 'yt-rating-note-wrap',
        style: existing?.rating === 'down' || existing?.note ? 'display:flex;' : 'display:none;'
      });
      const noteInput = h('input', {
        type: 'text',
        className: 'yt-rating-note-input',
        placeholder: 'Optional feedback note…',
        value: existing?.note || ''
      });
      const saveNoteBtn = h(
        'button',
        {
          className: 'yt-rating-note-save-btn',
          type: 'button',
          onclick: () => {
            const cur = getResponseRating(this.videoId, targetType, targetId);
            const r = cur?.rating || 'down';
            setResponseRating(this.videoId, targetType, targetId, r, noteInput.value.trim());
            statusEl.textContent = 'Feedback saved';
          }
        },
        'Save'
      );
      noteWrap.appendChild(noteInput);
      noteWrap.appendChild(saveNoteBtn);

      const syncUI = (rec) => {
        const val = rec?.rating || null;
        upBtn.classList.toggle('active', val === 'up');
        upBtn.setAttribute('aria-pressed', val === 'up' ? 'true' : 'false');
        downBtn.classList.toggle('active', val === 'down');
        downBtn.setAttribute('aria-pressed', val === 'down' ? 'true' : 'false');
        statusEl.textContent = val === 'up' ? 'Marked helpful' : val === 'down' ? 'Feedback noted' : '';
        noteWrap.style.display = val === 'down' || rec?.note ? 'flex' : 'none';
      };

      upBtn.addEventListener('click', () => {
        const rec = setResponseRating(this.videoId, targetType, targetId, 'up');
        syncUI(rec);
      });
      downBtn.addEventListener('click', () => {
        const rec = setResponseRating(this.videoId, targetType, targetId, 'down');
        syncUI(rec);
      });

      left.appendChild(labelEl);
      left.appendChild(upBtn);
      left.appendChild(downBtn);
      left.appendChild(statusEl);
      wrap.appendChild(left);
      if (!compact) {
        wrap.appendChild(noteWrap);
      }
      return wrap;
    }

    buildTranscriptSearch() {
      const bar = h('div', { className: 'yt-transcript-search-bar' });

      const inputWrap = h('div', { className: 'yt-transcript-input-wrap' });
      const searchIcon = iconSearch(14);
      const input = h('input', {
        type: 'text',
        className: 'yt-transcript-search-input',
        placeholder: 'Search keywords in transcript (Enter / Shift+Enter to jump)…',
        value: this.transcriptSearchQuery || '',
        oninput: (e) => {
          this.transcriptSearchQuery = e.target.value;
          this.transcriptMatchIdx = 0;
          this.clearBtnVisible();
          this.refreshTranscriptBody();
        },
        onkeydown: (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            if (e.shiftKey) {
              this.jumpTranscriptMatch(-1);
            } else {
              this.jumpTranscriptMatch(1);
            }
          } else if (e.key === 'Escape') {
            this.transcriptSearchQuery = '';
            input.value = '';
            this.clearBtnVisible();
            this.refreshTranscriptBody();
          }
        }
      });
      this.transcriptSearchInput = input;

      const clearBtn = h(
        'button',
        {
          className: 'yt-transcript-clear-btn',
          title: 'Clear search',
          style: this.transcriptSearchQuery ? 'display:flex;' : 'display:none;',
          onclick: () => {
            this.transcriptSearchQuery = '';
            input.value = '';
            this.clearBtnVisible();
            this.refreshTranscriptBody();
            input.focus();
          }
        },
        iconClose(12)
      );
      this.transcriptClearBtn = clearBtn;

      inputWrap.appendChild(searchIcon);
      inputWrap.appendChild(input);
      inputWrap.appendChild(clearBtn);

      const countBadge = h('span', { className: 'yt-transcript-match-count' }, '0 matches');
      this.transcriptCountEl = countBadge;

      const prevBtn = h(
        'button',
        {
          className: 'yt-transcript-nav-btn yt-transcript-prev-btn',
          title: 'Previous match (Shift+Enter)',
          onclick: () => this.jumpTranscriptMatch(-1)
        },
        '▲'
      );
      this.transcriptPrevBtn = prevBtn;

      const nextBtn = h(
        'button',
        {
          className: 'yt-transcript-nav-btn yt-transcript-next-btn',
          title: 'Next match (Enter)',
          onclick: () => this.jumpTranscriptMatch(1)
        },
        '▼'
      );
      this.transcriptNextBtn = nextBtn;

      const filterToggle = this.buildCheckbox('Filter lines', Boolean(this.transcriptFilterOnly), (v) => {
        this.transcriptFilterOnly = v;
        this.refreshTranscriptBody();
      });

      bar.appendChild(inputWrap);
      bar.appendChild(countBadge);
      bar.appendChild(prevBtn);
      bar.appendChild(nextBtn);
      bar.appendChild(filterToggle);

      return bar;
    }

    clearBtnVisible() {
      if (this.transcriptClearBtn) {
        this.transcriptClearBtn.style.display = this.transcriptSearchQuery ? 'flex' : 'none';
      }
    }

    refreshTranscriptBody() {
      const existing = this.bodyEl?.querySelector('.yt-transcript-container');
      if (existing) {
        const newBody = this.buildTranscriptBody();
        existing.replaceWith(newBody);
      }
    }

    buildTranscriptBody() {
      const container = h('div', { className: 'yt-markdown-body yt-transcript-container' });
      this.transcriptMarks = [];
      this.transcriptCues = [];

      const query = (this.transcriptSearchQuery || '').trim();
      const queryLower = query.toLowerCase();
      const lines = (this.text || '').split('\n');

      for (let i = 0; i < lines.length; i++) {
        const rawLine = lines[i];
        const trimmed = rawLine.trim();
        if (!trimmed) continue;

        // In filter-only mode, skip non-matching lines (unless it's the main header)
        if (this.transcriptFilterOnly && queryLower) {
          if (!trimmed.toLowerCase().includes(queryLower) && !trimmed.startsWith('## Transcript')) {
            continue;
          }
        }

        // Headings like ## Transcript
        if (trimmed.startsWith('#')) {
          const level = (trimmed.match(/^#+/) || [''])[0].length;
          const text = formatMathSymbolsInText(trimmed.slice(level).trim());
          const hTag = level <= 2 ? 'h3' : 'h4';
          const heading = h(hTag, { className: `yt-md-${hTag}` });
          this.appendTranscriptHighlightedText(heading, text, query);
          container.appendChild(heading);
          continue;
        }

        // Check for timestamp format: [01:15] or [1:02:30]
        const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
        if (tsMatch) {
          const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
          const restText = formatMathSymbolsInText(trimmed.slice(tsStr.length).trim());

          const parts = tsStr.slice(1, -1).split(':').map(Number);
          let sec = 0;
          if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
          else sec = parts[0] * 60 + parts[1];

          const isCurrentlySpeaking = Boolean(
            (this.ttsState === 'playing' || this.ttsState === 'paused') &&
            this.currentSpeakingCue &&
            (this.currentSpeakingCue.startSec === sec || this.currentSpeakingCue.rawIndex === i)
          );

          const lineEl = h('div', {
            className: 'yt-transcript-line' + (isCurrentlySpeaking ? ' yt-transcript-line-speaking' : ''),
            'data-start-sec': String(sec),
            'data-ts': tsStr,
            'data-line-idx': String(i)
          });

          this.transcriptCues.push({
            lineEl,
            rawIndex: i,
            startSec: sec,
            tsStr,
            text: restText
          });

          if (isCurrentlySpeaking) {
            const badge = h('span', { className: 'yt-speaking-indicator', title: `Speaking ${tsStr}` });
            badge.appendChild(iconSpeaker(12));
            lineEl.appendChild(badge);
          }

          const tsLink = h(
            'a',
            {
              className: 'yt-ts-link',
              href: `/watch?v=${encodeURIComponent(this.videoId)}&t=${sec}s`,
              title: `Jump video to ${tsStr}`,
              onclick: (e) => {
                if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
                  e.preventDefault();
                  this.seekPlayer(sec);
                }
              }
            },
            tsStr + ' '
          );
          lineEl.appendChild(tsLink);

          const textSpan = h('span', { className: 'yt-transcript-text' });
          this.appendTranscriptHighlightedText(textSpan, restText, query);
          lineEl.appendChild(textSpan);
          container.appendChild(lineEl);
          continue;
        }

        // Generic paragraph
        const p = h('p', { className: 'yt-md-p' });
        this.appendTranscriptHighlightedText(p, formatMathSymbolsInText(trimmed), query);
        container.appendChild(p);
      }

      // Update match count badge
      const total = this.transcriptMarks.length;
      this.transcriptMatchCount = total;

      if (!query) {
        if (this.transcriptCountEl) this.transcriptCountEl.textContent = '0 matches';
        if (this.transcriptPrevBtn) this.transcriptPrevBtn.disabled = true;
        if (this.transcriptNextBtn) this.transcriptNextBtn.disabled = true;
      } else if (total === 0) {
        if (this.transcriptCountEl) this.transcriptCountEl.textContent = 'No matches';
        if (this.transcriptPrevBtn) this.transcriptPrevBtn.disabled = true;
        if (this.transcriptNextBtn) this.transcriptNextBtn.disabled = true;
      } else {
        if (this.transcriptMatchIdx >= total) this.transcriptMatchIdx = 0;
        if (this.transcriptCountEl) {
          this.transcriptCountEl.textContent = `${this.transcriptMatchIdx + 1} of ${total}`;
        }
        if (this.transcriptPrevBtn) this.transcriptPrevBtn.disabled = false;
        if (this.transcriptNextBtn) this.transcriptNextBtn.disabled = false;
        this.transcriptMarks[this.transcriptMatchIdx]?.classList.add('active');
      }

      return container;
    }

    appendTranscriptHighlightedText(parent, text, query) {
      if (!query) {
        parent.appendChild(document.createTextNode(text));
        return;
      }
      const lower = text.toLowerCase();
      const qLower = query.toLowerCase();
      let start = 0;
      let idx = lower.indexOf(qLower, start);

      while (idx !== -1) {
        if (idx > start) {
          parent.appendChild(document.createTextNode(text.slice(start, idx)));
        }
        const matchText = text.slice(idx, idx + query.length);
        const mark = h('mark', { className: 'yt-transcript-highlight' }, matchText);
        parent.appendChild(mark);
        this.transcriptMarks.push(mark);
        start = idx + query.length;
        idx = lower.indexOf(qLower, start);
      }

      if (start < text.length) {
        parent.appendChild(document.createTextNode(text.slice(start)));
      }
    }

    jumpTranscriptMatch(delta) {
      if (this.transcriptMarks.length === 0) return;
      this.transcriptMarks[this.transcriptMatchIdx]?.classList.remove('active');
      this.transcriptMatchIdx =
        (this.transcriptMatchIdx + delta + this.transcriptMarks.length) % this.transcriptMarks.length;
      const target = this.transcriptMarks[this.transcriptMatchIdx];
      if (target) {
        target.classList.add('active');
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      if (this.transcriptCountEl) {
        this.transcriptCountEl.textContent = `${this.transcriptMatchIdx + 1} of ${this.transcriptMarks.length}`;
      }
    }

    onModeOrSourceChanged() {
      const cached = readCache(this.videoId, this.mode, this.source);
      if (cached) {
        this.loadFromCache(cached);
      } else {
        this.text = '';
        this.sources = [];
        this.turns = [];
        this.images = {};
        this.fact = null;
        this.status = 'idle';
      }
      this.commit(true);
      this.renderAll();
    }

    loadFromCache(entry) {
      this.text = entry.text || '';
      this.sources = entry.sources || [];
      this.notes = entry.notes || [];
      this.turns = entry.turns || [];
      this.images = entry.images || {};
      this.fact = entry.fact || null;
      this.modelId = entry.model || this.modelId;
      this.cacheDate = entry.ts || null;
      this.status = 'done';
      this.busy = false;
      this.unread = false;
    }

    toggleReadability(forceVal = null) {
      this.readabilityMode = forceVal !== null ? Boolean(forceVal) : !this.readabilityMode;
      if (this.readabilityMode && this.syncYouTubeTheme) {
        this.readabilityTheme = detectYouTubeTheme();
        this.setupYouTubeThemeObserver();
      } else if (!this.readabilityMode && this.ytThemeObserver) {
        this.ytThemeObserver.disconnect();
        this.ytThemeObserver = null;
      }
      if (this.windowBox) {
        this.windowBox.classList.toggle('yt-readability-active', this.readabilityMode);
        this.windowBox.classList.remove('yt-theme-system', 'yt-theme-light', 'yt-theme-sepia', 'yt-theme-dark');
        if (this.readabilityMode) {
          this.windowBox.classList.add(`yt-theme-${this.readabilityTheme}`);
        }
        const headerReadBtn = this.windowBox.querySelector('.yt-win-readability-btn');
        if (headerReadBtn) {
          headerReadBtn.classList.toggle('active', this.readabilityMode);
          headerReadBtn.title = this.readabilityMode
            ? 'Exit Readability Mode (Return to standard interactive view)'
            : 'Readability Mode (Clean, centered distraction-free reader)';
        }
      }
      this.renderBody();
    }

    setReadabilityTheme(theme, userInitiated = true) {
      const valid = ['system', 'light', 'sepia', 'dark'];
      this.readabilityTheme = valid.includes(theme) ? theme : 'system';
      if (userInitiated) {
        this.syncYouTubeTheme = false;
      }
      setLastReadabilityTheme(this.readabilityTheme);
      this.commit(true);
      if (this.windowBox) {
        this.windowBox.classList.remove('yt-theme-system', 'yt-theme-light', 'yt-theme-sepia', 'yt-theme-dark');
        this.windowBox.classList.add(`yt-theme-${this.readabilityTheme}`);
      }
      this.renderBody();
    }

    setSyncYouTubeTheme(enable) {
      this.syncYouTubeTheme = Boolean(enable);
      setLastSyncYouTubeTheme(this.syncYouTubeTheme);
      if (this.syncYouTubeTheme) {
        this.readabilityTheme = detectYouTubeTheme();
        setLastReadabilityTheme(this.readabilityTheme);
        this.setupYouTubeThemeObserver();
      }
      this.commit(true);
      if (this.windowBox) {
        this.windowBox.classList.remove('yt-theme-system', 'yt-theme-light', 'yt-theme-sepia', 'yt-theme-dark');
        this.windowBox.classList.add(`yt-theme-${this.readabilityTheme}`);
      }
      this.renderBody();
    }

    setupYouTubeThemeObserver() {
      if (this.ytThemeObserver) return;
      if (typeof MutationObserver === 'undefined') return;

      const handleThemeMutation = () => {
        if (!this.syncYouTubeTheme || !this.readabilityMode) return;
        const detected = detectYouTubeTheme();
        if (this.readabilityTheme !== detected) {
          this.readabilityTheme = detected;
          setLastReadabilityTheme(this.readabilityTheme);
          if (this.windowBox) {
            this.windowBox.classList.remove('yt-theme-system', 'yt-theme-light', 'yt-theme-sepia', 'yt-theme-dark');
            this.windowBox.classList.add(`yt-theme-${this.readabilityTheme}`);
          }
          this.renderBody();
        }
      };

      this.ytThemeObserver = new MutationObserver(() => {
        handleThemeMutation();
      });

      if (document.documentElement) {
        this.ytThemeObserver.observe(document.documentElement, {
          attributes: true,
          attributeFilter: ['dark', 'theme', 'class', 'style']
        });
      }
      const ytdApp = document.querySelector('ytd-app');
      if (ytdApp) {
        this.ytThemeObserver.observe(ytdApp, {
          attributes: true,
          attributeFilter: ['dark', 'theme']
        });
      }
    }

    buildReadabilityView() {
      const wrap = h('div', {
        className: `yt-readability-container yt-readability-theme-${this.readabilityTheme} theme-${this.readabilityTheme}`
      });
      this.readabilityContainer = wrap;

      // Calculate words and read time
      const words = (this.text || '').trim().split(/\s+/).filter(Boolean).length;
      const readMin = Math.max(1, Math.ceil(words / 220));

      // 1. Reader Controls Bar
      const bar = h('div', { className: 'yt-readability-bar' });

      const exitBtn = h(
        'button',
        {
          className: 'yt-readability-btn yt-readability-exit-btn',
          title: 'Exit Readability Mode',
          onclick: () => this.toggleReadability(false)
        },
        iconClose(14),
        h('span', {}, 'Exit Reader')
      );

      // Theme Selector: System, Light, Sepia, Dark
      const themeGroup = h('div', {
        className: 'yt-readability-theme-group',
        title: `Reading Theme: ${this.readabilityTheme}`
      });

      // Theme Synchronization Toggle with YouTube
      const currentYtTheme = detectYouTubeTheme();
      const syncBtn = h(
        'button',
        {
          className: `yt-readability-btn yt-readability-sync-theme-btn ${this.syncYouTubeTheme ? 'active' : ''}`,
          title: this.syncYouTubeTheme
            ? `YouTube Theme Sync: ON (Detected: ${currentYtTheme.toUpperCase()} mode — auto-matching YouTube)`
            : 'YouTube Theme Sync: OFF (Click to automatically synchronize Reader view with YouTube\'s Dark/Light mode)',
          onclick: () => this.setSyncYouTubeTheme(!this.syncYouTubeTheme)
        },
        iconSync(13),
        h('span', { className: 'yt-sync-label' }, this.syncYouTubeTheme ? `Sync YouTube (${currentYtTheme})` : 'Sync YouTube')
      );

      const themes = [
        { id: 'system', label: 'System', title: 'System default (follows OS dark/light mode)' },
        { id: 'light', label: 'Light', title: 'Comfortable clean light reading mode' },
        { id: 'sepia', label: 'Sepia', title: 'Warm parchment sepia reading mode' },
        { id: 'dark', label: 'Dark', title: 'High-contrast dark mode' }
      ];

      for (const t of themes) {
        const btn = h(
          'button',
          {
            className: `yt-readability-theme-btn ${this.readabilityTheme === t.id ? 'active' : ''}`,
            title: t.title,
            'data-theme': t.id,
            onclick: () => this.setReadabilityTheme(t.id)
          },
          t.label
        );
        themeGroup.appendChild(btn);
      }

      const themeSelect = h(
        'select',
        {
          className: 'yt-select yt-readability-theme-select',
          title: 'Select reading theme',
          onchange: (e) => this.setReadabilityTheme(e.target.value)
        },
        h('option', { value: 'system', selected: this.readabilityTheme === 'system' }, 'System'),
        h('option', { value: 'light', selected: this.readabilityTheme === 'light' }, 'Light'),
        h('option', { value: 'sepia', selected: this.readabilityTheme === 'sepia' }, 'Sepia'),
        h('option', { value: 'dark', selected: this.readabilityTheme === 'dark' }, 'Dark')
      );

      const fontToggleBtn = h(
        'button',
        {
          className: 'yt-readability-btn yt-readability-font-btn',
          title: `Switch font family (currently ${this.readabilityFont})`,
          onclick: () => {
            this.readabilityFont = this.readabilityFont === 'serif' ? 'sans' : 'serif';
            this.renderBody();
          }
        },
        h('span', {}, this.readabilityFont === 'serif' ? 'Serif font' : 'Sans font')
      );

      const sizeGroup = h('div', { className: 'yt-readability-size-group' });
      const decBtn = h(
        'button',
        {
          className: 'yt-readability-size-btn yt-readability-size-dec',
          title: 'Decrease font size',
          onclick: () => {
            this.readabilitySize = Math.max(13, this.readabilitySize - 1);
            this.renderBody();
          }
        },
        'A-'
      );
      const sizeLabel = h('span', { className: 'yt-readability-size-label' }, `${this.readabilitySize}px`);
      const incBtn = h(
        'button',
        {
          className: 'yt-readability-size-btn yt-readability-size-inc',
          title: 'Increase font size',
          onclick: () => {
            this.readabilitySize = Math.min(26, this.readabilitySize + 1);
            this.renderBody();
          }
        },
        'A+'
      );
      sizeGroup.appendChild(decBtn);
      sizeGroup.appendChild(sizeLabel);
      sizeGroup.appendChild(incBtn);

      const statsBadge = h(
        'div',
        { className: 'yt-readability-stats', title: `${words.toLocaleString()} words` },
        `${words.toLocaleString()} words · ~${readMin} min read`
      );

      const exportQuickBtn = h(
        'button',
        {
          className: 'yt-readability-btn yt-readability-export-btn',
          title: 'Export text or PDF',
          onclick: (e) => {
            e.stopPropagation();
            this.openExportMenu(exportQuickBtn);
          }
        },
        iconExport(14),
        h('span', {}, 'Export')
      );

      const exportJsonBtn = h(
        'button',
        {
          className: 'yt-readability-btn yt-readability-export-json-btn',
          title: 'Export transcript summary as JSON (.json) with metadata',
          onclick: (e) => {
            e.stopPropagation();
            this.exportAsJson();
          }
        },
        iconFileText(14),
        h('span', {}, 'JSON')
      );

      bar.appendChild(exitBtn);
      bar.appendChild(h('div', { className: 'yt-readability-divider' }));
      bar.appendChild(syncBtn);
      bar.appendChild(themeGroup);
      bar.appendChild(themeSelect);
      bar.appendChild(h('div', { className: 'yt-readability-divider' }));
      bar.appendChild(fontToggleBtn);
      bar.appendChild(sizeGroup);
      bar.appendChild(h('div', { className: 'yt-spacer' }));
      bar.appendChild(statsBadge);
      bar.appendChild(exportQuickBtn);
      bar.appendChild(exportJsonBtn);
      wrap.appendChild(bar);

      // 2. Reading Content (Centered typography layout)
      const content = h('div', {
        className: `yt-readability-content font-${this.readabilityFont}`,
        style: {
          fontSize: `${this.readabilitySize}px`,
          fontFamily:
            this.readabilityFont === 'serif'
              ? 'Charter, Georgia, "Times New Roman", Cambria, serif'
              : '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif'
        }
      });

      // Editorial Title & Meta
      const editorialHeader = h('div', { className: 'yt-readability-header' });
      const docTypeBadge = h(
        'div',
        { className: 'yt-readability-type-badge' },
        this.mode === 'transcript' ? 'YouTube Transcript' : 'Video Summary'
      );
      const editorialTitle = h('h1', { className: 'yt-readability-title' }, this.title);
      const editorialMeta = h(
        'div',
        { className: 'yt-readability-meta' },
        `Model: ${this.modelId || 'Default'} · Source: ${this.source === 'text' ? 'Transcript' : 'Video'} · Video ID: ${this.videoId}`
      );
      editorialHeader.appendChild(docTypeBadge);
      editorialHeader.appendChild(editorialTitle);
      editorialHeader.appendChild(editorialMeta);
      content.appendChild(editorialHeader);

      // Clean Editorial Blocks
      const blocks = parseCleanEditorialBlocks(this.text);
      let curList = null;

      for (const b of blocks) {
        if (b.type === 'heading') {
          if (curList) { content.appendChild(curList); curList = null; }
          const h2 = h('h2', { className: 'yt-readability-h2' }, b.text);
          content.appendChild(h2);
        } else if (b.type === 'subheading') {
          if (curList) { content.appendChild(curList); curList = null; }
          const h3 = h('h3', { className: 'yt-readability-h3' });
          const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(b.text);
          if (tsMatch) {
            const tsStr = b.text.slice(0, b.text.indexOf(']') + 1);
            const rest = b.text.slice(tsStr.length).trim();
            const parts = tsStr.slice(1, -1).split(':').map(Number);
            let sec = 0;
            if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
            else sec = parts[0] * 60 + parts[1];

            const link = h(
              'a',
              {
                className: 'yt-readability-ts',
                title: `Play video at ${tsStr}`,
                onclick: (e) => {
                  e.preventDefault();
                  this.seekPlayer(sec);
                }
              },
              tsStr
            );
            h3.appendChild(link);
            h3.appendChild(document.createTextNode(' ' + rest));
          } else {
            h3.textContent = b.text;
          }
          content.appendChild(h3);
        } else if (b.type === 'bullet') {
          if (!curList || curList.tagName !== 'UL') {
            if (curList) content.appendChild(curList);
            curList = h('ul', { className: 'yt-readability-ul' });
          }
          const li = h('li', { className: 'yt-readability-li' }, b.text);
          curList.appendChild(li);
        } else if (b.type === 'numbered') {
          if (!curList || curList.tagName !== 'OL') {
            if (curList) content.appendChild(curList);
            curList = h('ol', { className: 'yt-readability-ol' });
          }
          const li = h('li', { className: 'yt-readability-li' }, b.text);
          curList.appendChild(li);
        } else if (b.type === 'transcript_line') {
          if (curList) { content.appendChild(curList); curList = null; }
          const lineEl = h('div', { className: 'yt-readability-tx-line' });
          const parts = b.ts.slice(1, -1).split(':').map(Number);
          let sec = 0;
          if (parts.length === 3) sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
          else sec = parts[0] * 60 + parts[1];

          const tsLink = h(
            'a',
            {
              className: 'yt-readability-ts',
              title: `Play at ${b.ts}`,
              onclick: (e) => {
                e.preventDefault();
                this.seekPlayer(sec);
              }
            },
            b.ts
          );
          lineEl.appendChild(tsLink);
          lineEl.appendChild(document.createTextNode(' ' + b.text));
          content.appendChild(lineEl);
        } else {
          if (curList) { content.appendChild(curList); curList = null; }
          const p = h('p', { className: 'yt-readability-p' }, b.text);
          content.appendChild(p);
        }
      }
      if (curList) content.appendChild(curList);

      if (this.fact && this.fact.text) {
        const factSec = h('div', { className: 'yt-readability-fact-box' });
        factSec.appendChild(h('h2', { className: 'yt-readability-h2' }, 'Fact-Check & Verification'));
        const factBlocks = parseCleanEditorialBlocks(this.fact.text);
        for (const fb of factBlocks) {
          factSec.appendChild(h('p', { className: 'yt-readability-p' }, fb.text));
        }
        content.appendChild(factSec);
      }

      if (this.turns && this.turns.length) {
        const qaSec = h('div', { className: 'yt-readability-qa-section' });
        qaSec.appendChild(h('h2', { className: 'yt-readability-h2' }, 'Follow-Up Questions'));
        for (const t of this.turns) {
          const item = h('div', { className: 'yt-readability-qa-item' });
          item.appendChild(h('p', { className: 'yt-readability-q' }, `Q: ${stripInlineMarkdown(t.q)}`));
          item.appendChild(h('p', { className: 'yt-readability-a' }, `A: ${stripInlineMarkdown(t.a)}`));
          qaSec.appendChild(item);
        }
        content.appendChild(qaSec);
      }

      content.appendChild(
        this.buildResponseRatingBar({
          targetType: this.mode === 'transcript' ? 'transcript' : 'summary',
          targetId: 'main',
          label: this.mode === 'transcript' ? 'Was this transcript accurate?' : 'Rate this summary'
        })
      );

      wrap.appendChild(content);
      return wrap;
    }

    openExportMenu(anchorEl) {
      if (this.exportMenuEl) {
        this.exportMenuEl.remove();
        this.exportMenuEl = null;
        return;
      }

      const popover = h('div', {
        className: 'yt-export-popover',
        onclick: (e) => e.stopPropagation()
      });

      const header = h('div', { className: 'yt-export-header' }, 'Export Content');
      popover.appendChild(header);

      const itemTxt = h(
        'button',
        {
          className: 'yt-export-item yt-export-txt-btn',
          title: 'Download formatted plain text file (.txt)',
          onclick: () => {
            popover.remove();
            this.exportMenuEl = null;
            this.exportAsTxt();
          }
        },
        iconFileText(16),
        h(
          'div',
          { className: 'yt-export-item-text' },
          h('div', { className: 'yt-export-item-title' }, 'Export as Formatted Text (.txt)'),
          h('div', { className: 'yt-export-item-sub' }, 'Plain text with full metadata header and timestamps')
        )
      );

      const itemPdf = h(
        'button',
        {
          className: 'yt-export-item yt-export-pdf-btn',
          title: 'Export formatted document as PDF (.pdf)',
          onclick: () => {
            popover.remove();
            this.exportMenuEl = null;
            this.exportAsPdf();
          }
        },
        iconPdf(16),
        h(
          'div',
          { className: 'yt-export-item-text' },
          h('div', { className: 'yt-export-item-title' }, 'Export as PDF Document (.pdf)'),
          h('div', { className: 'yt-export-item-sub' }, 'Clean editorial layout ready for Save to PDF')
        )
      );

      const itemCopy = h(
        'button',
        {
          className: 'yt-export-item yt-export-copy-btn',
          title: 'Copy clean text to clipboard',
          onclick: () => {
            const cleanText = formatAsExportText(this);
            if (typeof GM_setClipboard === 'function') {
              GM_setClipboard(cleanText);
            } else if (navigator.clipboard?.writeText) {
              navigator.clipboard.writeText(cleanText);
            }
            popover.remove();
            this.exportMenuEl = null;
          }
        },
        iconCopy(16),
        h(
          'div',
          { className: 'yt-export-item-text' },
          h('div', { className: 'yt-export-item-title' }, 'Copy Clean Text to Clipboard'),
          h('div', { className: 'yt-export-item-sub' }, 'Formatted text with metadata')
        )
      );

      const itemJson = h(
        'button',
        {
          className: 'yt-export-item yt-export-json-btn',
          title: 'Export transcript summary data as JSON (.json) with metadata',
          onclick: () => {
            popover.remove();
            this.exportMenuEl = null;
            this.exportAsJson();
          }
        },
        iconFileText(16),
        h(
          'div',
          { className: 'yt-export-item-text' },
          h('div', { className: 'yt-export-item-title' }, 'Export as JSON (.json)'),
          h('div', { className: 'yt-export-item-sub' }, 'Structured transcript summary with title, channel, and processing mode metadata')
        )
      );

      popover.appendChild(itemTxt);
      popover.appendChild(itemPdf);
      popover.appendChild(itemJson);
      popover.appendChild(itemCopy);

      const rect = anchorEl.getBoundingClientRect();
      const parentRect = (this.windowBox || document.body).getBoundingClientRect();
      popover.style.top = `${rect.bottom - parentRect.top + 6}px`;
      popover.style.right = `${parentRect.right - rect.right}px`;

      const closeHandler = (e) => {
        if (!popover.contains(e.target) && e.target !== anchorEl) {
          popover.remove();
          this.exportMenuEl = null;
          document.removeEventListener('click', closeHandler, true);
        }
      };
      setTimeout(() => {
        document.addEventListener('click', closeHandler, true);
      }, 50);

      (this.windowBox || modalsContainer).appendChild(popover);
      this.exportMenuEl = popover;
    }

    exportAsTxt() {
      downloadAsTxt(this);
    }

    exportAsPdf() {
      exportAsPdf(this);
    }

    exportAsJson() {
      downloadAsJson(this);
    }

    renderAll() {
      this.renderDockTab();
      if (maximizedWindow === this) {
        this.showModal();
      }
    }
  }

  // --- API KEY MANAGER DIALOG (§14) ---
  function openKeyManagerDialog(onClose = null) {
    const scrim = h('div', {
      className: 'yt-modal-scrim yt-key-dialog-scrim',
      onclick: (e) => {
        if (e.target === scrim) closeDialog();
      }
    });

    function closeDialog() {
      scrim.remove();
      if (onClose) onClose();
    }

    const box = h('div', { className: 'yt-key-dialog-box' });
    const header = h('div', { className: 'yt-dialog-header' });
    header.appendChild(h('h3', {}, 'Manage Google AI Studio API Keys'));
    header.appendChild(
      h('button', { className: 'yt-win-btn', onclick: closeDialog }, iconClose(20))
    );
    box.appendChild(header);

    const info = h(
      'div',
      { className: 'yt-dialog-info' },
      'Keys are stored locally in your userscript manager storage and sent only to generativelanguage.googleapis.com.'
    );
    box.appendChild(info);

    const keysList = h('div', { className: 'yt-keys-list' });

    function renderKeys() {
      clearEl(keysList);
      const keys = getStoredKeys();
      if (keys.length === 0) {
        keysList.appendChild(h('div', { className: 'yt-no-keys' }, 'No API keys stored yet. Add one below:'));
        return;
      }
      for (const k of keys) {
        const row = h('div', { className: 'yt-key-row' });
        const nameInput = h('input', {
          className: 'yt-input yt-key-name-input',
          value: k.name,
          onchange: (e) => {
            k.name = e.target.value.trim() || 'Key';
            saveStoredKeys(keys);
          }
        });
        const last4 = k.key.length >= 4 ? k.key.slice(-4) : k.key;
        const keyMask = h('span', { className: 'yt-key-mask' }, `••••${last4}`);
        const delBtn = h(
          'button',
          {
            className: 'yt-sec-btn yt-del-btn',
            onclick: () => {
              if (confirm(`Delete key "${k.name}"?`)) {
                const idx = keys.indexOf(k);
                if (idx !== -1) {
                  keys.splice(idx, 1);
                  saveStoredKeys(keys);
                  renderKeys();
                }
              }
            }
          },
          'Delete'
        );
        row.appendChild(nameInput);
        row.appendChild(keyMask);
        row.appendChild(delBtn);
        keysList.appendChild(row);
      }
    }

    renderKeys();
    box.appendChild(keysList);

    // Add Key Form
    const form = h('div', { className: 'yt-add-key-form' });
    const nicknameInput = h('input', {
      className: 'yt-input',
      placeholder: 'Key Nickname (e.g. Work or Free Tier)',
      value: ''
    });
    const keyInput = h('input', {
      className: 'yt-input',
      type: 'password',
      placeholder: 'AIzaSy...'
    });
    const addBtn = h(
      'button',
      {
        className: 'yt-primary-btn',
        onclick: () => {
          const rawKey = keyInput.value.trim();
          if (!rawKey) return;
          const name = nicknameInput.value.trim() || `Key ${getStoredKeys().length + 1}`;
          const keys = getStoredKeys();
          keys.push({
            id: 'k_' + Math.random().toString(36).slice(2, 8),
            name: name,
            key: rawKey
          });
          saveStoredKeys(keys);
          nicknameInput.value = '';
          keyInput.value = '';
          renderKeys();
        }
      },
      'Add Key'
    );

    form.appendChild(nicknameInput);
    form.appendChild(keyInput);
    form.appendChild(addBtn);
    box.appendChild(form);

    // Dock & Interface Settings inside Settings dialog
    const settingsSec = h('div', { className: 'yt-add-key-form yt-settings-section' });
    const settingsRow = h('div', { className: 'yt-key-row' });
    settingsRow.appendChild(h('span', { style: 'flex:1;font-size:12px;font-weight:500;' }, 'History dock tab visibility'));
    const histVisSel = h(
      'select',
      {
        className: 'yt-select yt-history-visibility-select',
        'aria-label': 'History tab visibility',
        onchange: (e) => {
          setHistoryTabVisibility(e.target.value);
        }
      },
      h('option', { value: 'always' }, 'Always shown'),
      h('option', { value: 'with_tabs' }, 'Only with open/minimized tabs'),
      h('option', { value: 'never' }, 'Never shown')
    );
    histVisSel.value = getHistoryTabVisibility();
    settingsRow.appendChild(histVisSel);
    settingsSec.appendChild(settingsRow);
    box.appendChild(settingsSec);

    scrim.appendChild(box);
    modalsContainer.appendChild(scrim);
  }

  // --- PREVIOUS SUMMARIES & HISTORY DIALOG ---
  let dockHistoryTab = null;

  function updateDockHistoryTab() {
    if (!dockContainer) return;
    const items = getAllCachedSummaries();
    const shouldShow = shouldShowHistoryTab({
      visibility: getHistoryTabVisibility(),
      cachedCount: items.length,
      activeTabCount: activeWindows.size
    });
    if (!shouldShow) {
      if (dockHistoryTab) {
        dockHistoryTab.remove();
        dockHistoryTab = null;
      }
      return;
    }
    if (!dockHistoryTab) {
      dockHistoryTab = h(
        'div',
        {
          className: 'yt-dock-tab yt-dock-history-tab',
          title: 'Browse previous summaries that were closed',
          onclick: () => openHistoryDialog()
        },
        h('div', { className: 'yt-dock-status-icon' }, iconHistory(14)),
        h('div', { className: 'yt-dock-title yt-dock-history-title' }, `History (${items.length})`),
        h(
          'button',
          {
            className: 'yt-dock-btn yt-dock-open-history-btn',
            title: 'Browse previous summaries',
            onclick: (e) => {
              e.stopPropagation();
              openHistoryDialog();
            }
          },
          iconExternal(12)
        )
      );
      dockContainer.appendChild(dockHistoryTab);
    } else {
      const titleEl = dockHistoryTab.querySelector('.yt-dock-history-title');
      if (titleEl) {
        titleEl.textContent = `History (${items.length})`;
      }
      dockContainer.appendChild(dockHistoryTab);
    }
  }

  function openHistoryDialog() {
    ensureHostAndShadow();
    const existing = modalsContainer?.querySelector('.yt-history-dialog-scrim');
    if (existing) {
      existing.remove();
    }

    const scrim = h('div', {
      className: 'yt-modal-scrim yt-history-dialog-scrim',
      onclick: (e) => {
        if (e.target === scrim) scrim.remove();
      }
    });

    const box = h('div', { className: 'yt-window-box yt-history-dialog-box' });

    // Header
    const header = h('div', { className: 'yt-win-header' });
    const titleCol = h('div', { className: 'yt-win-title-col' });
    const titleText = h('div', { className: 'yt-win-title' }, 'Previous Summaries');
    const subtitle = h('div', { className: 'yt-win-status-line' });
    titleCol.appendChild(titleText);
    titleCol.appendChild(subtitle);

    const closeBtn = h(
      'button',
      {
        className: 'yt-win-btn',
        title: 'Close history',
        onclick: () => scrim.remove()
      },
      iconClose(20)
    );

    header.appendChild(titleCol);
    header.appendChild(closeBtn);
    box.appendChild(header);

    // Search / Filter bar
    const searchBar = h('div', { className: 'yt-history-search-bar' });
    const searchInput = h('input', {
      type: 'text',
      className: 'yt-history-search-input',
      placeholder: 'Search previous summaries by title or content…'
    });
    searchBar.appendChild(searchInput);
    box.appendChild(searchBar);

    // List container
    const listContainer = h('div', { className: 'yt-history-list' });
    box.appendChild(listContainer);

    // Footer actions
    const footer = h('div', { className: 'yt-history-footer' });
    const clearAllBtn = h(
      'button',
      {
        className: 'yt-sec-btn yt-del-btn',
        onclick: () => {
          if (confirm('Clear all cached summaries? (Open windows will remain)')) {
            clearAllCache();
            updateDockHistoryTab();
            renderList();
          }
        }
      },
      'Clear All History'
    );
    const visSelect = h(
      'select',
      {
        className: 'yt-select yt-history-visibility-select',
        title: 'Control when the bottom-right History dock tab is shown',
        'aria-label': 'History tab visibility',
        onchange: (e) => {
          setHistoryTabVisibility(e.target.value);
        }
      },
      h('option', { value: 'always' }, 'History tab: Always shown'),
      h('option', { value: 'with_tabs' }, 'History tab: With open/minimized tabs'),
      h('option', { value: 'never' }, 'History tab: Never shown')
    );
    visSelect.value = getHistoryTabVisibility();
    const doneBtn = h('button', { className: 'yt-primary-btn', onclick: () => scrim.remove() }, 'Close');
    footer.appendChild(clearAllBtn);
    footer.appendChild(visSelect);
    footer.appendChild(h('div', { className: 'yt-spacer' }));
    footer.appendChild(doneBtn);
    box.appendChild(footer);

    function renderList(query = '') {
      clearEl(listContainer);
      const allItems = getAllCachedSummaries();
      const q = query.toLowerCase().trim();
      const filtered = q
        ? allItems.filter(
            (it) => it.title.toLowerCase().includes(q) || (it.text || '').toLowerCase().includes(q)
          )
        : allItems;

      subtitle.textContent = `${allItems.length} previous summar${allItems.length === 1 ? 'y' : 'ies'} saved`;

      if (filtered.length === 0) {
        const empty = h(
          'div',
          { className: 'yt-history-empty' },
          q
            ? `No previous summaries match "${query}".`
            : 'No previous summaries yet. Videos you summarize will be saved here so you can access them even after closing the window.'
        );
        listContainer.appendChild(empty);
        return;
      }

      for (const item of filtered) {
        const card = h('div', { className: 'yt-history-card' });

        // Left: Thumbnail preview
        const thumbWrap = h(
          'div',
          {
            className: 'yt-history-thumb-wrap',
            onclick: () => {
              scrim.remove();
              openForVideo({ videoId: item.videoId, title: item.title });
            }
          },
          h('img', {
            src: `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
            alt: item.title,
            className: 'yt-history-thumb',
            onerror: (e) => {
              e.target.style.display = 'none';
            }
          })
        );

        // Middle: Info & snippet
        const infoCol = h('div', { className: 'yt-history-info' });
        const itemTitle = h(
          'a',
          {
            className: 'yt-history-item-title',
            href: `https://www.youtube.com/watch?v=${item.videoId}`,
            target: '_blank',
            rel: 'noopener noreferrer',
            title: `${item.title} (Open video in new tab)`
          },
          item.title
        );

        const metaRow = h('div', { className: 'yt-history-item-meta' });
        metaRow.appendChild(
          h('span', { className: 'yt-history-badge mode' }, item.mode === 'transcript' ? 'Transcript' : 'Summary')
        );
        if (item.model) {
          metaRow.appendChild(h('span', { className: 'yt-history-badge model' }, item.model));
        }
        metaRow.appendChild(
          h('span', { className: 'yt-history-date' }, new Date(item.ts).toLocaleDateString())
        );

        const snippetText = (item.text || '')
          .replace(/[#*`_\[\]]/g, '')
          .replace(/\s+/g, ' ')
          .trim()
          .slice(0, 160);
        const snippetEl = h('div', { className: 'yt-history-snippet' }, snippetText ? `${snippetText}…` : 'Summary ready.');

        infoCol.appendChild(itemTitle);
        infoCol.appendChild(metaRow);
        infoCol.appendChild(snippetEl);

        // Right: Actions
        const actionsCol = h('div', { className: 'yt-history-actions' });
        const reopenBtn = h(
          'button',
          {
            className: 'yt-primary-btn yt-history-reopen-btn',
            title: 'Re-open this summary in dock',
            onclick: () => {
              scrim.remove();
              openForVideo({ videoId: item.videoId, title: item.title });
            }
          },
          'Open Summary'
        );

        const openVideoBtn = h(
          'a',
          {
            className: 'yt-sec-btn yt-history-video-btn',
            href: `https://www.youtube.com/watch?v=${item.videoId}`,
            target: '_blank',
            rel: 'noopener noreferrer',
            title: 'Open video in new tab'
          },
          iconExternal(12),
          h('span', {}, 'Watch video')
        );

        const delBtn = h(
          'button',
          {
            className: 'yt-sec-btn yt-history-del-btn',
            title: 'Remove from history',
            onclick: () => {
              deleteCachedVideo(item.videoId);
              updateDockHistoryTab();
              renderList(searchInput.value);
            }
          },
          iconClose(12)
        );

        actionsCol.appendChild(reopenBtn);
        actionsCol.appendChild(openVideoBtn);
        actionsCol.appendChild(delBtn);

        card.appendChild(thumbWrap);
        card.appendChild(infoCol);
        card.appendChild(actionsCol);
        listContainer.appendChild(card);
      }
    }

    searchInput.addEventListener('input', (e) => {
      renderList(e.target.value);
    });

    renderList();
    scrim.appendChild(box);
    modalsContainer.appendChild(scrim);
  }

  // --- OPEN FOR VIDEO HELPER (§4) ---
  function openForVideo({ videoId, title }) {
    if (!videoId) return;

    // 1. Existing local window
    if (activeWindows.has(videoId)) {
      const existing = activeWindows.get(videoId);
      existing.maximize();
      return existing;
    }

    // 2. Existing remote registry entry
    const meta = GM_getValue('win:' + videoId, null);
    const win = new SummaryWindow(videoId, title, meta || {});

    // Check cache
    const cached = readCache(videoId, win.mode, win.source);
    if (cached) {
      win.loadFromCache(cached);
      win.commit(true);
      win.maximize();
      return win;
    }

    // Check auto-start
    const keys = getStoredKeys();
    const isAsk = win.modelId.includes('Ask');
    if (getAutoStart() && (keys.length > 0 || isAsk)) {
      win.commit(true);
      win.startJob();
      return win;
    }

    // Otherwise maximize idle
    win.commit(true);
    win.maximize();

    if (keys.length === 0 && !isAsk) {
      openKeyManagerDialog(() => win.renderAll());
    }
    return win;
  }

  // --- 3-DOT MENU INTEGRATION (§5) ---
  let menuPollTimer = null;

  function initMenuIntegration() {
    document.addEventListener(
      'click',
      (e) => {
        const path = e.composedPath();
        if (path.some((el) => el.id === 'yt-ai-summary-host' || el?.dataset?.ytaisItem)) {
          return;
        }

        const card = path.find((el) => {
          if (!el || !el.tagName) return false;
          const tag = el.tagName.toLowerCase();
          return (
            tag.startsWith('yt-lockup-view-model') ||
            tag.startsWith('ytm-shorts-lockup-view-model') ||
            tag === 'ytd-rich-item-renderer' ||
            tag === 'ytd-video-renderer' ||
            tag === 'ytd-compact-video-renderer' ||
            tag === 'ytd-grid-video-renderer' ||
            tag === 'ytd-playlist-video-renderer' ||
            tag === 'ytd-reel-item-renderer'
          );
        });

        if (!card) return;

        // Check if menu button was clicked
        const isMenuClick = path.some((el) => {
          if (!el || !el.getAttribute) return false;
          if (
            el.tagName?.toLowerCase() === 'ytd-menu-renderer' ||
            el.classList?.contains('yt-lockup-metadata-view-model__menu-button')
          ) {
            return true;
          }
          const aria = el.getAttribute('aria-label') || '';
          if (/more actions|action menu/i.test(aria)) return true;
          if (
            (el.tagName?.toLowerCase() === 'button' || el.tagName?.toLowerCase() === 'yt-icon-button') &&
            !el.closest('a[href], ytd-thumbnail, yt-thumbnail-view-model, #hover-overlays, #overlays')
          ) {
            return true;
          }
          return false;
        });

        if (!isMenuClick) return;

        // Extract video ID and Title
        let videoId = card.dataset.ytaisVideoId || '';
        if (!videoId) {
          const link = card.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
          if (link) {
            const href = link.getAttribute('href') || '';
            const matchV = /[?&]v=([^&]+)/.exec(href);
            if (matchV) videoId = matchV[1];
            else {
              const matchS = /\/shorts\/([a-zA-Z0-9_-]{11})/.exec(href);
              if (matchS) videoId = matchS[1];
            }
          }
        }

        if (!videoId) return;

        let title = '';
        const titleEl = card.querySelector('#video-title, .yt-lockup-metadata-view-model__title, h3');
        if (titleEl) {
          title = (titleEl.getAttribute('title') || titleEl.textContent || '').trim();
        }

        // Poll for menu flyout
        if (menuPollTimer) clearInterval(menuPollTimer);
        let ticks = 0;
        menuPollTimer = setInterval(() => {
          ticks++;
          if (ticks > 45) {
            clearInterval(menuPollTimer);
            return;
          }

          const items = Array.from(
            document.querySelectorAll(
              'ytd-menu-service-item-renderer, ytd-menu-navigation-item-renderer, yt-list-item-view-model, tp-yt-paper-item, [role="menuitem"]'
            )
          ).filter((el) => {
            return el.offsetWidth > 0 && el.offsetHeight > 0 && !el.dataset.ytaisItem;
          });

          if (!items.length) return;

          let targetItem = null;
          let insertMode = 'after'; // 'after' or 'before'

          for (const it of items) {
            const label = (it.getAttribute('aria-label') || it.textContent || '').slice(0, 60).trim();
            if (CONFIG.savePattern.test(label)) {
              targetItem = it;
              insertMode = 'after';
              break;
            }
          }
          if (!targetItem) {
            for (const it of items) {
              const label = (it.getAttribute('aria-label') || it.textContent || '').slice(0, 60).trim();
              if (CONFIG.downloadPattern.test(label)) {
                targetItem = it;
                insertMode = 'before';
                break;
              }
            }
          }
          if (!targetItem) {
            for (const it of items) {
              const label = (it.getAttribute('aria-label') || it.textContent || '').slice(0, 60).trim();
              if (CONFIG.watchLaterPattern.test(label)) {
                targetItem = it;
                insertMode = 'after';
                break;
              }
            }
          }

          if (targetItem) {
            clearInterval(menuPollTimer);
            injectMenuItem(targetItem, insertMode, { videoId, title });
          }
        }, 60);
      },
      true
    );
  }

  function injectMenuItem(targetSibling, mode, ctx) {
    const parent = targetSibling.parentNode;
    if (!parent) return;

    // Remove existing injected items in this menu
    const existing = parent.querySelectorAll('[data-ytais-item]');
    for (const ex of existing) ex.remove();

    const item = h(
      'div',
      {
        role: 'menuitem',
        className: 'ytd-menu-service-item-renderer yt-ai-menu-item',
        'data-ytais-item': 'true',
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: '16px',
          fontSize: CONFIG.menuFontSize,
          fontWeight: '500',
          minHeight: `${CONFIG.menuMinHeight}px`,
          padding: '0 16px',
          cursor: 'pointer',
          color: 'var(--yt-spec-text-primary, #f1f1f1)',
          userSelect: 'none'
        },
        onmouseenter: () => {
          item.style.backgroundColor = 'var(--yt-spec-10-percent-layer, rgba(255,255,255,0.1))';
        },
        onmouseleave: () => {
          item.style.backgroundColor = 'transparent';
        },
        onclick: (e) => {
          e.preventDefault();
          e.stopPropagation();
          // Close flyout
          const active = document.activeElement;
          if (active) {
            active.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
          }
          document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', bubbles: true }));
          setTimeout(() => {
            document.body.click();
            openForVideo(ctx);
          }, 150);
        }
      },
      iconSparkle(26),
      h('span', {}, CONFIG.menuLabel)
    );

    if (mode === 'before') {
      parent.insertBefore(item, targetSibling);
    } else {
      parent.insertBefore(item, targetSibling.nextSibling);
    }
  }

  // --- ALTERNATIVE TITLES FOR FEED THUMBNAILS (§16) ---
  function isMusicVideo(cardEl, title = '', channel = '') {
    const t = (title || '').toLowerCase();
    const ch = (channel || '').toLowerCase();

    // Check common music cues and patterns in titles
    const musicPatterns = [
      /official\s*(music\s*)?video/i,
      /official\s*audio/i,
      /official\s*lyric\s*video/i,
      /\(lyric\s*video\)/i,
      /\[official\s*video\]/i,
      /\[mv\]|\(mv\)/i,
      /\[music\s*video\]/i,
      /\b(ft\.|feat\.)\b/i,
      /\bvevo\b/i,
      /\b(remix|acoustic\s*version|live\s*performance)\b/i,
      /\b(full\s*album|soundtrack|ost)\b/i
    ];
    if (musicPatterns.some((p) => p.test(t))) return true;

    // Check channel naming and artist branding
    if (ch.endsWith('- topic') || ch.includes('vevo') || ch.endsWith('records') || ch.endsWith('music')) {
      return true;
    }

    // Check badges or metadata within the YouTube card
    if (cardEl) {
      if (cardEl.closest && cardEl.closest('ytd-rich-shelf-renderer[is-music], ytd-music-carousel-shelf-renderer')) {
        return true;
      }
      const badge = cardEl.querySelector && cardEl.querySelector(
        'ytd-badge-supported-renderer, .badge-style-type-simple, [aria-label*="Official Artist" i], [aria-label*="Music" i]'
      );
      if (badge) {
        const badgeText = (badge.getAttribute('aria-label') || badge.textContent || '').toLowerCase();
        if (badgeText.includes('official artist') || badgeText.includes('music')) return true;
      }
    }
    return false;
  }

  const altTitleInFlight = new Map();

  async function generateAlternativeTitle(videoId, originalTitle = '') {
    if (!videoId) return null;
    const cached = getCachedAltTitle(videoId);
    if (cached) return cached;
    if (altTitleInFlight.has(videoId)) return altTitleInFlight.get(videoId);

    const task = (async () => {
      try {
        let tx = transcriptCache.get(videoId);
        if (!tx && typeof window !== 'undefined' && window.__yt_mock_transcripts?.[videoId]) {
          tx = window.__yt_mock_transcripts[videoId];
          transcriptCache.set(videoId, tx);
        }
        if (!tx) {
          tx = await getTranscriptText(videoId, 1);
        }
        if (!tx || tx.trim().length < 15) return null;

        let generated = '';
        const keyObj = getStoredKeys()[0];
        const flashModel = CONFIG.factPreferred[0] || 'gemini-3.8-flash';

        if (keyObj?.key) {
          const prompt = `You are a factual, concise video title generator. Given this YouTube video transcript, create a single alternative title that:
1. Eliminates all clickbait, hyperbole, sensationalism, and curiosity gaps.
2. Is highly descriptive and factual, summarizing as much of the core subject and key takeaway as possible.
3. Is strictly 150 characters or fewer.
4. Outputs ONLY the plain title text with no markdown, quotes, or brackets.

Original Title: "${originalTitle}"
TRANSCRIPT:
"""
${tx.slice(0, 15000)}
"""`;

          const body = {
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.2,
              maxOutputTokens: 60
            }
          };

          const data = await callGeminiRaw(flashModel, keyObj.key, body, 15000);
          const candidate = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
          generated = candidate.trim().replace(/^["'`]+|["'`]+$/g, '').trim();
        } else {
          // Fallback / offline / mock: extract descriptive key takeaways from transcript
          const cleanLines = tx
            .split('\n')
            .map((l) => l.replace(/^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*/, '').trim())
            .filter((l) => l.length > 15 && !l.startsWith('##') && !l.startsWith('[') && !l.includes('...truncated...'));

          if (cleanLines.length > 0) {
            const combined = cleanLines.slice(0, 3).join('; ').replace(/\s+/g, ' ').trim();
            generated = combined.length > 145 ? combined.slice(0, 142).trim() + '...' : combined;
          } else {
            generated = originalTitle;
          }
        }

        generated = generated.replace(/^["'#*`]+|["'#*`]+$/g, '').replace(/\s+/g, ' ').trim();
        if (generated.length > 150) {
          generated = generated.slice(0, 147).trim() + '...';
        }

        if (generated && generated.length >= 5) {
          setCachedAltTitle(videoId, generated);
          return generated;
        }
      } catch (err) {
        if (CONFIG.debug) console.warn('[YTAIS] Failed to generate alternative title for', videoId, err);
      }
      return null;
    })();

    altTitleInFlight.set(videoId, task);
    try {
      return await task;
    } finally {
      altTitleInFlight.delete(videoId);
    }
  }

  function getCardVideoId(card) {
    if (!card) return null;
    const link = card.querySelector(
      'a#video-title-link, a#video-title, a[href*="/watch?v="], a#thumbnail, a.yt-lockup-metadata-view-model__title'
    );
    if (link) {
      const href = link.getAttribute('href') || '';
      const match = /[?&]v=([a-zA-Z0-9_-]{8,32})/.exec(href);
      if (match) return match[1];
    }
    return null;
  }

  function getCardTitleElement(card) {
    if (!card) return null;
    return (
      card.querySelector('#video-title') ||
      card.querySelector('.yt-lockup-metadata-view-model__title a') ||
      card.querySelector('.yt-lockup-metadata-view-model__title') ||
      card.querySelector('a#video-title-link') ||
      card.querySelector('h3 a') ||
      card.querySelector('h3')
    );
  }

  function getTitleTextTarget(titleEl) {
    if (!titleEl) return null;
    const nested = titleEl.querySelector('yt-formatted-string, .yt-core-attributed-string, span#video-title');
    if (nested && !nested.closest('.yt-alt-title-btn, .cbTitleButtonContainer, .dearrow-title-container')) {
      return nested;
    }
    if (titleEl.tagName?.toLowerCase() === 'a') return titleEl;
    const a = titleEl.querySelector('a');
    if (a) {
      const innerInA = a.querySelector('yt-formatted-string, .yt-core-attributed-string');
      return innerInA || a;
    }
    return titleEl;
  }

  function getTitleCleanText(titleEl) {
    const target = getTitleTextTarget(titleEl);
    return (target?.textContent || titleEl?.textContent || '').trim();
  }

  function getCardChannelName(card) {
    if (!card) return '';
    const chEl = card.querySelector(
      '#channel-name, .ytd-channel-name, [id="text"][title], .yt-lockup-metadata-view-model__sub-title, #metadata #text'
    );
    return chEl ? (chEl.getAttribute('title') || chEl.textContent || '').trim() : '';
  }

  function getDeArrowTitleContainer(card, titleEl) {
    if (!card) return null;
    return (
      card.querySelector('.cbTitleButtonContainer, .dearrow-title-container, [class*="cbTitleButton"], [data-dearrow-title], .dearrow-title-button') ||
      (titleEl && titleEl.parentElement ? titleEl.parentElement.querySelector('.cbTitleButtonContainer, .dearrow-title-container, [class*="cbTitleButton"]') : null)
    );
  }

  function isDeArrowPresent(card, titleEl) {
    if (!card) return false;
    // Strictly scope DeArrow title detection to THIS card/titleEl (never global document/window or thumbnail-only buttons)
    const titleContainer = getDeArrowTitleContainer(card, titleEl);
    if (titleContainer) return true;
    const cardLevelTitleMarker = card.querySelector(
      '[data-dearrow-title], .dearrow-title, [data-dearrow]:not(.cbThumbnailButtonContainer)'
    );
    return Boolean(
      cardLevelTitleMarker ||
      card.hasAttribute('data-dearrow') ||
      card.hasAttribute('data-dearrow-title') ||
      card.dataset?.ytaisDearrow === 'true' ||
      (titleEl && (
        titleEl.hasAttribute('data-dearrow') ||
        titleEl.dataset?.dearrow ||
        titleEl.hasAttribute('data-dearrow-title') ||
        titleEl.classList.contains('dearrow-title')
      ))
    );
  }

  function syncDeArrowState(card) {
    if (!card || card._ytaisMutatingTitle || card.dataset.ytaisMusicExempt === 'true') return;
    const titleEl = getCardTitleElement(card);
    if (!titleEl) return;
    const btnParent = titleEl.parentElement;
    if (!btnParent) return;

    const dearrowContainer = getDeArrowTitleContainer(card, titleEl);
    const dearrowNowPresent = Boolean(dearrowContainer || isDeArrowPresent(card, titleEl));

    if (dearrowNowPresent) {
      const wasDeArrow = card.dataset.ytaisDearrow === 'true';
      card.dataset.ytaisDearrow = 'true';

      const currentTitleText = getTitleCleanText(titleEl);
      if (currentTitleText && currentTitleText !== card._aiTitle) {
        if (!card._dearrowTitle || currentTitleText !== card._originalTitle) {
          card._dearrowTitle = currentTitleText;
        }
      }

      const switchBtn = card.querySelector('.yt-alt-title-btn');
      if (switchBtn) {
        // Ensure switchBtn sits cleanly after dearrowContainer without colliding or nesting inside it
        if (dearrowContainer && dearrowContainer.parentElement === btnParent) {
          if (switchBtn.nextSibling === dearrowContainer || switchBtn.parentElement === dearrowContainer) {
            if (dearrowContainer.nextSibling) {
              btnParent.insertBefore(switchBtn, dearrowContainer.nextSibling);
            } else {
              btnParent.appendChild(switchBtn);
            }
          }
        }

        if ((!wasDeArrow && card._currentTitleMode === 'original') ||
            (!card._userChoseAi && currentTitleText && currentTitleText !== card._aiTitle && card._currentTitleMode === 'ai')) {
          card._currentTitleMode = 'dearrow';
          updateSwitchButtonUI(switchBtn, 'dearrow', true);
        } else {
          updateSwitchButtonUI(switchBtn, card._currentTitleMode || 'dearrow', true);
        }
      }
    }
  }

  function processFeedCard(card) {
    if (!card || processedFeedCards.has(card)) return;
    const videoId = getCardVideoId(card);
    if (!videoId) return;

    const titleEl = getCardTitleElement(card);
    if (!titleEl) return;

    processedFeedCards.add(card);
    card.dataset.ytaisProcessed = 'true';
    card.dataset.ytaisVideoId = videoId;

    const channelName = getCardChannelName(card);
    const originalTitle = titleEl.getAttribute('title') || getTitleCleanText(titleEl);
    card._originalTitle = originalTitle;

    // Check if music video (exempt from replacement)
    const isMusic = isMusicVideo(card, originalTitle, channelName);
    if (isMusic) {
      card.dataset.ytaisMusicExempt = 'true';
      const btnParent = titleEl.parentElement;
      if (btnParent && !card.querySelector('.yt-music-exempt-icon')) {
        const musicBadge = h(
          'span',
          {
            className: 'yt-music-exempt-icon',
            title: 'Music video (exempt from title replacement)'
          },
          iconMusic(14)
        );
        if (titleEl.nextSibling) {
          btnParent.insertBefore(musicBadge, titleEl.nextSibling);
        } else {
          btnParent.appendChild(musicBadge);
        }
      }
      return;
    }

    const dearrowContainer = getDeArrowTitleContainer(card, titleEl);
    const deArrowActive = Boolean(dearrowContainer || isDeArrowPresent(card, titleEl));
    if (deArrowActive) {
      card._dearrowTitle = getTitleCleanText(titleEl) || originalTitle;
      card.dataset.ytaisDearrow = 'true';
    }

    // If no DeArrow title is available, show generated AI title (when enabled)
    const currentMode = deArrowActive ? 'dearrow' : (getAltTitlesEnabled() ? 'ai' : 'original');
    card._currentTitleMode = currentMode;

    const btnParent = titleEl.parentElement;
    if (!btnParent) return;

    let switchBtn = card.querySelector('.yt-alt-title-btn');
    if (!switchBtn) {
      switchBtn = h(
        'button',
        {
          className: 'yt-alt-title-btn',
          'data-video-id': videoId,
          'aria-label': 'Toggle alternative title',
          onmousedown: (e) => e.stopPropagation(),
          onpointerdown: (e) => e.stopPropagation(),
          onclick: async (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleCardTitle(card);
          }
        }
      );
      updateSwitchButtonUI(switchBtn, currentMode, deArrowActive);

      // Safe insertion to avoid clashing with DeArrow's injected container
      if (dearrowContainer && dearrowContainer.parentElement === btnParent) {
        if (dearrowContainer.nextSibling) {
          btnParent.insertBefore(switchBtn, dearrowContainer.nextSibling);
        } else {
          btnParent.appendChild(switchBtn);
        }
      } else if (titleEl.nextSibling) {
        if (titleEl.nextSibling === dearrowContainer && dearrowContainer?.nextSibling) {
          btnParent.insertBefore(switchBtn, dearrowContainer.nextSibling);
        } else if (titleEl.nextSibling === dearrowContainer) {
          btnParent.appendChild(switchBtn);
        } else {
          btnParent.insertBefore(switchBtn, titleEl.nextSibling);
        }
      } else {
        btnParent.appendChild(switchBtn);
      }
    }

    if (getAltTitlesEnabled() && !deArrowActive) {
      applyAiTitleToCard(card);
    }
  }

  function updateSwitchButtonUI(switchBtn, mode, isDeArrow) {
    if (!switchBtn) return;
    clearEl(switchBtn);
    if (mode === 'ai') {
      switchBtn.appendChild(iconSparkle(13));
      switchBtn.className = 'yt-alt-title-btn active';
      switchBtn.title = isDeArrow
        ? 'Showing AI summary title (Click to switch to DeArrow title)'
        : 'Showing AI summary title (Click to switch to original title)';
    } else if (mode === 'dearrow') {
      switchBtn.appendChild(iconBolt(13));
      switchBtn.className = 'yt-alt-title-btn dearrow';
      switchBtn.title = 'Showing DeArrow title (Click to switch to AI summary title)';
    } else {
      switchBtn.appendChild(iconDocument(13));
      switchBtn.className = 'yt-alt-title-btn original';
      switchBtn.title = 'Showing original title (Click to switch to AI summary title)';
    }
  }

  function setCardTitleText(card, titleEl, newText) {
    if (!titleEl) return;
    if (card) card._ytaisMutatingTitle = true;
    try {
      const target = getTitleTextTarget(titleEl);
      if (target) {
        target.textContent = newText;
      } else {
        titleEl.textContent = newText;
      }
    } finally {
      if (card) card._ytaisMutatingTitle = false;
    }
  }

  function revertCardToNonAiTitle(card) {
    if (!card || card.dataset.ytaisMusicExempt === 'true') return;
    const titleEl = getCardTitleElement(card);
    const switchBtn = card.querySelector('.yt-alt-title-btn');
    if (!titleEl) return;
    const isDeArrow = Boolean(card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl));
    if (isDeArrow) card.dataset.ytaisDearrow = 'true';
    const revertTitle = isDeArrow ? (card._dearrowTitle || card._originalTitle) : card._originalTitle;
    if (revertTitle) {
      setCardTitleText(card, titleEl, revertTitle);
      titleEl.title = revertTitle;
    }
    card._userChoseAi = false;
    card._currentTitleMode = isDeArrow ? 'dearrow' : 'original';
    if (switchBtn) {
      updateSwitchButtonUI(switchBtn, card._currentTitleMode, isDeArrow);
    }
  }

  async function applyAiTitleToCard(card, forceManual = false) {
    if (!card || card.dataset.ytaisMusicExempt === 'true') return;
    const videoId = card.dataset.ytaisVideoId;
    if (!videoId) return;

    const titleEl = getCardTitleElement(card);
    if (!titleEl) return;

    if (!forceManual) {
      if (!getAltTitlesEnabled()) return;
      if (card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl)) {
        syncDeArrowState(card);
        return;
      }
      if (card._userManualOriginal) return;
    }

    let aiTitle = card._aiTitle || getCachedAltTitle(videoId);
    if (!aiTitle) {
      const switchBtn = card.querySelector('.yt-alt-title-btn');
      if (switchBtn) switchBtn.classList.add('loading');
      aiTitle = await generateAlternativeTitle(videoId, card._originalTitle || getTitleCleanText(titleEl));
      if (switchBtn) switchBtn.classList.remove('loading');
    }

    // Re-check invariants after async fetch to avoid overriding late DeArrow arrival or disabled setting
    if (!forceManual) {
      if (!getAltTitlesEnabled()) return;
      if (card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl)) {
        syncDeArrowState(card);
        return;
      }
      if (card._userManualOriginal) return;
    }

    if (aiTitle) {
      const isDeArrow = Boolean(card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl));
      card._aiTitle = aiTitle;
      card._currentTitleMode = 'ai';
      if (forceManual) card._userChoseAi = true;
      setCardTitleText(card, titleEl, aiTitle);
      const baseTitle = isDeArrow ? (card._dearrowTitle || card._originalTitle || '') : (card._originalTitle || '');
      titleEl.title = `[AI Summary Title] ${aiTitle} (${isDeArrow ? 'DeArrow' : 'Original'}: ${baseTitle})`;

      const switchBtn = card.querySelector('.yt-alt-title-btn');
      if (switchBtn) {
        updateSwitchButtonUI(switchBtn, 'ai', isDeArrow);
      }
    }
  }

  async function toggleCardTitle(card) {
    if (!card || card.dataset.ytaisMusicExempt === 'true') return;
    const titleEl = getCardTitleElement(card);
    if (!titleEl) return;

    const isDeArrow = Boolean(card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl));
    const currentMode = card._currentTitleMode || (isDeArrow ? 'dearrow' : 'original');

    if (currentMode === 'ai') {
      card._userManualOriginal = true;
      revertCardToNonAiTitle(card);
    } else {
      card._userManualOriginal = false;
      await applyAiTitleToCard(card, true);
    }
  }

  function refreshAllFeedCardTitles() {
    const enabled = getAltTitlesEnabled();
    const cards = document.querySelectorAll('[data-ytais-processed="true"]');
    for (const card of cards) {
      if (card.dataset.ytaisMusicExempt === 'true') continue;
      const titleEl = getCardTitleElement(card);
      const isDeArrow = Boolean(card.dataset.ytaisDearrow === 'true' || isDeArrowPresent(card, titleEl));
      if (enabled) {
        card._userManualOriginal = false;
        if (!isDeArrow && card._currentTitleMode !== 'ai') {
          applyAiTitleToCard(card);
        }
      } else {
        card._userManualOriginal = false;
        if (card._currentTitleMode === 'ai') {
          revertCardToNonAiTitle(card);
        }
      }
    }
  }

  function observeFeedCards() {
    function scan() {
      const cardSelectors = [
        'ytd-rich-item-renderer',
        'ytd-video-renderer',
        'ytd-grid-video-renderer',
        'ytd-compact-video-renderer',
        'yt-lockup-view-model',
        'ytd-reel-item-renderer'
      ];
      const cards = document.querySelectorAll(cardSelectors.join(', '));
      for (const c of cards) {
        if (!processedFeedCards.has(c)) {
          processFeedCard(c);
        } else {
          syncDeArrowState(c);
        }
      }
    }

    scan();

    let debounceTimer = null;
    const observer = new MutationObserver(() => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(scan, 200);
    });

    observer.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['data-dearrow', 'data-dearrow-title']
    });
  }

  const FEED_CSS = `
    .yt-alt-title-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      padding: 0;
      margin-left: 5px;
      margin-right: 2px;
      vertical-align: middle;
      flex-shrink: 0;
      position: relative;
      z-index: 2;
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 4px;
      color: #aaa;
      cursor: pointer;
      transition: all 0.15s ease;
      user-select: none;
      text-decoration: none;
      box-sizing: border-box;
      line-height: normal;
    }
    .yt-alt-title-btn:hover {
      background: rgba(255, 255, 255, 0.2);
      border-color: rgba(255, 255, 255, 0.35);
      color: #fff;
      transform: translateY(-1px);
    }
    .yt-alt-title-btn.active {
      background: linear-gradient(135deg, rgba(62, 166, 255, 0.25), rgba(168, 85, 247, 0.25));
      border-color: rgba(62, 166, 255, 0.6);
      color: #3ea6ff;
    }
    .yt-alt-title-btn.dearrow {
      background: rgba(99, 102, 241, 0.2);
      border-color: rgba(99, 102, 241, 0.5);
      color: #818cf8;
    }
    .yt-alt-title-btn.original {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.16);
      color: #888;
    }
    .yt-alt-title-btn.loading {
      opacity: 0.7;
      pointer-events: none;
    }
    .yt-music-exempt-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      margin-left: 5px;
      vertical-align: middle;
      flex-shrink: 0;
      position: relative;
      z-index: 2;
      color: #f472b6;
      cursor: help;
      opacity: 0.85;
      transition: opacity 0.15s;
    }
    .yt-music-exempt-icon:hover {
      opacity: 1;
    }

    /* DeArrow Interoperability & Zero Clash Rules */
    .cbTitleButtonContainer,
    .dearrow-title-container {
      display: inline-flex !important;
      align-items: center !important;
      vertical-align: middle !important;
      flex-shrink: 0 !important;
      position: relative !important;
      z-index: 2 !important;
    }
    .cbTitleButtonContainer + .yt-alt-title-btn,
    .dearrow-title-container + .yt-alt-title-btn,
    [data-dearrow] + .yt-alt-title-btn {
      margin-left: 4px !important;
    }
    .yt-alt-title-btn + .cbTitleButtonContainer,
    .yt-alt-title-btn + .dearrow-title-container {
      margin-left: 4px !important;
    }
    .cbThumbnailButtonContainer {
      pointer-events: auto !important;
      z-index: 3 !important;
    }
  `;
  if (typeof GM_addStyle === 'function') {
    try {
      GM_addStyle(FEED_CSS);
    } catch (_) {}
  }

  // --- STYLES & SHADOW ROOT SETUP (§2) ---
  const CSS_TEXT = `
  :host {
    all: initial;
    font-family: Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    color-scheme: dark;
  }
  .yt-transcript-processing-panel {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    padding: 2px 6px;
  }
  .yt-tp-label {
    font-size: 11px;
    color: #aaa;
    font-weight: 500;
    margin-right: 2px;
  }
  .yt-tp-btn {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 2px 7px;
    border-radius: 4px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    background: rgba(255, 255, 255, 0.06);
    color: #bbb;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s;
  }
  .yt-tp-btn:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #fff;
  }
  .yt-tp-btn.active {
    background: #065fd4;
    border-color: #3ea6ff;
    color: #fff;
    box-shadow: 0 1px 4px rgba(6, 95, 212, 0.4);
  }
  .yt-dock {
    position: fixed;
    right: 24px;
    bottom: 0;
    z-index: 2147483001;
    display: flex;
    flex-direction: row;
    gap: 8px;
    align-items: flex-end;
    pointer-events: auto;
  }
  .yt-dock-tab {
    flex: 0 1 264px;
    min-width: 150px;
    height: 38px;
    border-radius: 10px 10px 0 0;
    background: #404040;
    color: #fff;
    display: flex;
    align-items: center;
    padding: 0 10px;
    gap: 8px;
    cursor: pointer;
    box-shadow: 0 -2px 8px rgba(0,0,0,0.3);
    user-select: none;
    transition: background 0.2s;
  }
  .yt-dock-tab.error {
    background: #a8201a;
  }
  .yt-dock-tab.unread {
    background: #188038;
    animation: ytPulse 1.5s infinite 3;
    font-weight: 600;
  }
  @keyframes ytPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.03); }
  }
  .yt-dock-status-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }
  .yt-dock-title {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 14px;
    font-weight: 500;
  }
  .yt-dock-btn {
    background: transparent;
    border: none;
    color: #fff;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.8;
  }
  .yt-dock-btn:hover {
    opacity: 1;
    background: rgba(255,255,255,0.15);
  }
  .yt-spinner {
    width: 14px;
    height: 14px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: ytSpin 0.8s linear infinite;
  }
  .yt-big-spinner {
    width: 36px;
    height: 36px;
    border: 3px solid rgba(255,255,255,0.2);
    border-top-color: var(--yt-spec-call-to-action, #3ea6ff);
    border-radius: 50%;
    animation: ytSpin 0.8s linear infinite;
    margin-bottom: 12px;
  }
  @keyframes ytSpin {
    to { transform: rotate(360deg); }
  }
  .yt-modal-scrim {
    position: fixed;
    inset: 0;
    z-index: 2147483050;
    background: rgba(0,0,0,0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    pointer-events: auto;
  }
  .yt-modal-scrim.yt-floating-scrim {
    background: transparent;
    pointer-events: none;
    display: block;
    z-index: 2147483001;
  }
  .yt-window-box {
    width: min(940px, 94vw);
    height: min(calc(100vh - 110px), 900px);
    background: var(--yt-spec-base-background, #0f0f0f);
    color: var(--yt-spec-text-primary, #f1f1f1);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    box-shadow: 0 8px 32px rgba(0,0,0,0.6);
    border: 1px solid rgba(255,255,255,0.1);
  }
  .yt-window-box.yt-floating-window {
    position: fixed;
    pointer-events: auto;
    min-width: 340px;
    min-height: 300px;
    max-width: calc(100vw - 24px);
    max-height: calc(100vh - 64px);
    transition: box-shadow 0.15s ease, border-color 0.15s ease;
  }
  .yt-window-box.yt-floating-window.focused {
    border-color: rgba(62, 166, 255, 0.45);
    box-shadow: 0 12px 44px rgba(0, 0, 0, 0.78);
  }
  .yt-dock-tab.active-focus {
    outline: 1.5px solid #3ea6ff;
    background: #525252;
  }
  .yt-resize-handle {
    position: absolute;
    z-index: 30;
  }
  .yt-resize-handle-e {
    top: 12px;
    right: 0;
    width: 6px;
    bottom: 16px;
    cursor: ew-resize;
  }
  .yt-resize-handle-w {
    top: 12px;
    left: 0;
    width: 6px;
    bottom: 16px;
    cursor: ew-resize;
  }
  .yt-resize-handle-s {
    left: 16px;
    right: 16px;
    bottom: 0;
    height: 6px;
    cursor: ns-resize;
  }
  .yt-resize-handle-se {
    right: 0;
    bottom: 0;
    width: 14px;
    height: 14px;
    cursor: nwse-resize;
    background: radial-gradient(circle at 75% 75%, rgba(255,255,255,0.45) 1.5px, transparent 1.5px);
  }
  .yt-resize-handle-sw {
    left: 0;
    bottom: 0;
    width: 14px;
    height: 14px;
    cursor: nesw-resize;
  }
  .yt-win-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    cursor: grab;
    user-select: none;
  }
  .yt-win-header:active {
    cursor: grabbing;
  }
  .yt-win-overflow-btn {
    display: none;
  }
  .yt-win-overflow-menu {
    position: absolute;
    z-index: 2147483020;
    width: 240px;
    background: #1f1f1f;
    border: 1px solid rgba(255, 255, 255, 0.16);
    border-radius: 12px;
    box-shadow: 0 12px 36px rgba(0, 0, 0, 0.8);
    padding: 6px;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .yt-compact-options-bar {
    display: none;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .yt-options-row.yt-options-collapsed {
    display: none !important;
  }
  .yt-window-box.yt-win-compact .yt-win-header {
    padding: 8px 10px;
  }
  .yt-window-box.yt-win-compact .yt-win-title {
    font-size: 14px;
    -webkit-line-clamp: 1;
  }
  .yt-window-box.yt-win-compact .yt-win-header-btns {
    gap: 2px;
    margin-left: 6px;
  }
  .yt-window-box.yt-win-compact .yt-win-secondary-btn {
    display: none !important;
  }
  .yt-window-box.yt-win-compact .yt-win-overflow-btn {
    display: flex;
  }
  .yt-window-box.yt-win-compact .yt-compact-options-bar {
    display: flex;
  }
  .yt-window-box.yt-win-compact .yt-win-toolbar {
    padding: 6px 10px;
    gap: 6px;
  }
  .yt-window-box.yt-win-compact .yt-tts-shortcuts-hint,
  .yt-window-box.yt-win-medium .yt-tts-shortcuts-hint,
  .yt-window-box.yt-win-compact .yt-tts-rewind-btn span,
  .yt-window-box.yt-win-compact .yt-tts-skip-btn span,
  .yt-window-box.yt-win-compact .yt-tts-stop-btn span,
  .yt-window-box.yt-win-compact .yt-tts-skip-silence-label {
    display: none;
  }
  .yt-window-box.yt-win-compact .yt-tts-group {
    flex-wrap: wrap;
    max-width: 100%;
    border-radius: 10px;
  }
  .yt-window-box.yt-win-compact .yt-tts-speed-btns {
    display: none;
  }
  .yt-window-box.yt-win-compact .yt-adv-panel {
    grid-template-columns: 1fr;
  }
  .yt-window-box.yt-win-compact .yt-composer-wrap {
    flex-wrap: wrap;
    padding: 8px 10px;
  }
  .yt-window-box.yt-win-compact .yt-composer-textarea {
    flex: 1 1 100%;
    min-width: 0;
  }
  .yt-window-box.yt-win-compact .yt-readability-theme-group {
    display: none;
  }
  .yt-window-box.yt-win-compact .yt-readability-theme-select {
    display: inline-block;
  }
  .yt-window-box.yt-win-compact .yt-readability-stats {
    display: none;
  }
  .yt-window-box.yt-win-short .yt-win-header {
    padding: 6px 12px;
  }
  .yt-window-box.yt-win-short .yt-win-toolbar {
    padding: 5px 12px;
    gap: 4px;
  }
  .yt-window-box.yt-win-short .yt-summary-page-bar {
    padding: 5px 8px;
    margin-bottom: 6px;
  }
  .yt-rating-bar {
    margin-top: 14px;
    padding: 8px 12px;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.1);
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .yt-rating-bar.compact {
    margin-top: 8px;
    padding: 5px 8px;
    background: rgba(255, 255, 255, 0.03);
  }
  .yt-rating-left {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }
  .yt-rating-label {
    font-size: 12px;
    color: var(--yt-spec-text-secondary, #aaa);
    font-weight: 500;
  }
  .yt-rating-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 14px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.14);
    color: var(--yt-spec-text-primary, #f1f1f1);
    transition: all 0.15s ease;
  }
  .yt-rating-btn:hover {
    background: rgba(255, 255, 255, 0.14);
  }
  .yt-rating-up-btn.active {
    background: rgba(34, 197, 94, 0.22);
    border-color: #22c55e;
    color: #4ade80;
  }
  .yt-rating-down-btn.active {
    background: rgba(239, 68, 68, 0.22);
    border-color: #ef4444;
    color: #f87171;
  }
  .yt-rating-status {
    font-size: 11px;
    color: #9ca3af;
  }
  .yt-rating-note-wrap {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .yt-rating-note-input {
    flex: 1;
    min-width: 140px;
    background: rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 6px;
    color: #f1f1f1;
    font-size: 11px;
    padding: 4px 8px;
    outline: none;
  }
  .yt-rating-note-save-btn {
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    background: #3ea6ff;
    color: #0f0f0f;
    border: none;
    cursor: pointer;
  }
  .yt-window-box.yt-theme-light .yt-rating-bar {
    background: rgba(0, 0, 0, 0.03);
    border-color: #d0d7de;
  }
  .yt-window-box.yt-theme-light .yt-rating-label,
  .yt-window-box.yt-theme-light .yt-rating-status {
    color: #57606a;
  }
  .yt-window-box.yt-theme-light .yt-rating-btn {
    background: #ffffff;
    border-color: #d0d7de;
    color: #1f2328;
  }
  .yt-window-box.yt-theme-sepia .yt-rating-bar {
    background: rgba(67, 52, 34, 0.05);
    border-color: #d8c8a6;
  }
  .yt-window-box.yt-theme-sepia .yt-rating-label,
  .yt-window-box.yt-theme-sepia .yt-rating-status {
    color: #5c4b37;
  }
  .yt-window-box.yt-theme-sepia .yt-rating-btn {
    background: #efe5cd;
    border-color: #d8c8a6;
    color: #433422;
  }
  .yt-win-title-col {
    flex: 1;
    min-width: 0;
  }
  .yt-win-title {
    font-size: 16px;
    font-weight: 600;
    line-height: 1.3;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .yt-win-status-line {
    font-size: 12px;
    color: var(--yt-spec-text-secondary, #aaa);
    margin-top: 2px;
  }
  .yt-win-header-btns {
    display: flex;
    gap: 8px;
    margin-left: 12px;
  }
  .yt-win-btn {
    background: transparent;
    border: none;
    color: var(--yt-spec-text-primary, #f1f1f1);
    cursor: pointer;
    padding: 6px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .yt-win-btn:hover {
    background: var(--yt-spec-10-percent-layer, rgba(255,255,255,0.1));
  }
  .yt-win-btn.copied {
    color: #81c784 !important;
    background: rgba(129, 199, 132, 0.2) !important;
  }
  .yt-win-toolbar {
    padding: 8px 16px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .yt-toolbar-row {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }
  .yt-segmented-btn {
    display: flex;
    border-radius: 8px;
    background: rgba(255,255,255,0.08);
    overflow: hidden;
  }
  .yt-seg-btn {
    background: transparent;
    border: none;
    color: var(--yt-spec-text-secondary, #aaa);
    font-size: 12px;
    font-weight: 500;
    padding: 6px 12px;
    cursor: pointer;
  }
  .yt-seg-btn.active {
    background: var(--yt-spec-10-percent-layer, rgba(255,255,255,0.15));
    color: var(--yt-spec-text-primary, #f1f1f1);
  }
  .yt-control-wrap {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  :host, .yt-window-box, .yt-select, .yt-adv-select, .yt-key-dialog-box {
    color-scheme: dark;
  }
  .yt-select {
    color-scheme: dark;
    background: #212121;
    color: var(--yt-spec-text-primary, #f1f1f1);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 8px;
    font-size: 12px;
    padding: 6px 8px;
    cursor: pointer;
    max-width: 220px;
  }
  .yt-select option, .yt-select optgroup, .yt-adv-select option, .yt-adv-select optgroup {
    background-color: #212121 !important;
    color: #f1f1f1 !important;
    color-scheme: dark;
  }
  .yt-select optgroup, .yt-adv-select optgroup {
    background-color: #181818 !important;
    color: #3ea6ff !important;
    font-weight: 600;
  }
  .yt-tts-group {
    display: inline-flex;
    align-items: center;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 18px;
    padding: 2px 4px;
    gap: 2px;
  }
  .yt-tts-btn {
    background: transparent;
    border: none;
    color: var(--yt-spec-text-primary, #f1f1f1);
    font-size: 12px;
    font-weight: 500;
    padding: 4px 10px;
    border-radius: 14px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: background 0.15s, color 0.15s;
  }
  .yt-tts-btn:hover:not(:disabled) {
    background: rgba(255,255,255,0.12);
  }
  .yt-tts-btn.active {
    background: #3ea6ff;
    color: #0f0f0f;
    font-weight: 600;
  }
  .yt-tts-btn:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }
  .yt-tts-speed-btn {
    padding: 3px 8px;
    font-family: monospace;
    font-size: 11px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: var(--yt-spec-text-primary, #fff);
  }
  .yt-tts-speed-btn:hover:not(:disabled) {
    background: rgba(255, 255, 255, 0.15);
    border-color: rgba(56, 189, 248, 0.4);
  }
  .yt-tts-speed-indicator {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    display: inline-block;
    flex-shrink: 0;
    transition: all 0.2s ease;
  }
  .yt-tts-speed-indicator.speed-normal {
    background: #38bdf8;
    box-shadow: 0 0 6px rgba(56, 189, 248, 0.8);
  }
  .yt-tts-speed-indicator.speed-boost {
    background: #f59e0b;
    box-shadow: 0 0 6px rgba(245, 158, 11, 0.85);
  }
  .yt-tts-speed-indicator.speed-slow {
    background: #c084fc;
    box-shadow: 0 0 6px rgba(192, 132, 252, 0.85);
  }
  .yt-tts-skip-silence-btn {
    padding: 3px 8px;
    font-size: 11px;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    gap: 4px;
  }
  .yt-tts-skip-silence-btn:hover:not(:disabled) {
    background: rgba(255, 255, 255, 0.1);
  }
  .yt-tts-skip-silence-btn.active {
    background: rgba(56, 189, 248, 0.2);
    border-color: rgba(56, 189, 248, 0.45);
    color: #38bdf8;
    font-weight: 600;
  }
  .yt-tts-waveform-wrap {
    display: inline-flex;
    align-items: center;
    position: relative;
    height: 24px;
    padding: 0 4px;
    background: rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    overflow: hidden;
    vertical-align: middle;
    margin: 0 2px;
    transition: border-color 0.2s ease, background 0.2s ease;
  }
  .yt-tts-waveform-wrap.playing {
    background: rgba(56, 189, 248, 0.08);
    border-color: rgba(56, 189, 248, 0.25);
  }
  .yt-tts-waveform-canvas {
    display: block;
    width: 68px;
    height: 18px;
  }
  .yt-tts-waveform-bars {
    display: none;
    align-items: center;
    gap: 2px;
    height: 18px;
  }
  .yt-tts-waveform-bar {
    width: 3px;
    height: 3px;
    min-height: 2px;
    max-height: 16px;
    background: #38bdf8;
    border-radius: 1.5px;
    transition: height 0.08s ease;
  }
  .yt-tts-volume-wrap {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 0 4px;
    height: 26px;
  }
  .yt-tts-volume-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--yt-spec-text-secondary, #aaa);
    opacity: 0.85;
    flex-shrink: 0;
  }
  .yt-tts-volume-slider {
    -webkit-appearance: none;
    appearance: none;
    width: 58px;
    height: 4px;
    background: rgba(255, 255, 255, 0.25);
    border-radius: 2px;
    outline: none;
    cursor: pointer;
    vertical-align: middle;
    margin: 0;
    transition: background 0.15s;
  }
  .yt-tts-volume-slider:hover {
    background: rgba(255, 255, 255, 0.4);
  }
  .yt-tts-volume-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #3ea6ff;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0,0,0,0.5);
    transition: transform 0.1s;
  }
  .yt-tts-volume-slider::-webkit-slider-thumb:hover {
    transform: scale(1.2);
  }
  .yt-tts-volume-slider::-moz-range-thumb {
    width: 10px;
    height: 10px;
    border: none;
    border-radius: 50%;
    background: #3ea6ff;
    cursor: pointer;
  }
  .yt-tts-volume-label {
    font-size: 10px;
    font-family: monospace;
    color: var(--yt-spec-text-secondary, #aaa);
    min-width: 28px;
    text-align: right;
  }
  .yt-tts-pitch-wrap {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 0 4px;
    height: 26px;
  }
  .yt-tts-pitch-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--yt-spec-text-secondary, #aaa);
    opacity: 0.85;
    flex-shrink: 0;
  }
  .yt-tts-pitch-slider {
    -webkit-appearance: none;
    appearance: none;
    width: 54px;
    height: 4px;
    background: rgba(255, 255, 255, 0.25);
    border-radius: 2px;
    outline: none;
    cursor: pointer;
    vertical-align: middle;
    margin: 0;
    transition: background 0.15s;
  }
  .yt-tts-pitch-slider:hover {
    background: rgba(255, 255, 255, 0.4);
  }
  .yt-tts-pitch-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #a855f7;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0,0,0,0.5);
    transition: transform 0.1s;
  }
  .yt-tts-pitch-slider::-webkit-slider-thumb:hover {
    transform: scale(1.2);
  }
  .yt-tts-pitch-slider::-moz-range-thumb {
    width: 10px;
    height: 10px;
    border: none;
    border-radius: 50%;
    background: #a855f7;
    cursor: pointer;
  }
  .yt-tts-pitch-label {
    font-size: 10px;
    font-family: monospace;
    color: var(--yt-spec-text-secondary, #aaa);
    min-width: 28px;
    text-align: right;
  }
  .yt-readability-export-json-btn {
    border-color: rgba(168, 85, 247, 0.35) !important;
    color: #c084fc !important;
  }
  .yt-readability-export-json-btn:hover {
    background: rgba(168, 85, 247, 0.15) !important;
  }
  .yt-tts-speed-wrap {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    padding: 2px 6px;
  }
  .yt-tts-speed-btns {
    display: inline-flex;
    align-items: center;
    gap: 2px;
  }
  .yt-tts-rate-pill {
    background: transparent;
    border: none;
    color: #aaa;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 5px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.15s, color 0.15s;
    line-height: 1.2;
  }
  .yt-tts-rate-pill:hover {
    background: rgba(255, 255, 255, 0.12);
    color: #fff;
  }
  .yt-tts-rate-pill.active {
    background: #3ea6ff;
    color: #000;
    font-weight: 700;
  }
  .yt-tts-rate-pill:disabled {
    opacity: 0.4;
    cursor: default;
  }
  .yt-tts-slider-row {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border-left: 1px solid rgba(255, 255, 255, 0.08);
    padding-left: 6px;
  }
  .yt-tts-speed-slider {
    -webkit-appearance: none;
    appearance: none;
    width: 44px;
    height: 3px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.25);
    outline: none;
    cursor: pointer;
    vertical-align: middle;
    margin: 0;
    transition: background 0.15s;
  }
  .yt-tts-speed-slider:hover {
    background: rgba(255, 255, 255, 0.4);
  }
  .yt-tts-speed-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #3ea6ff;
    cursor: pointer;
  }
  .yt-tts-speed-slider::-moz-range-thumb {
    width: 10px;
    height: 10px;
    border: none;
    border-radius: 50%;
    background: #3ea6ff;
    cursor: pointer;
  }
  .yt-tts-speed-label {
    font-size: 10px;
    font-family: monospace;
    color: #aaa;
    min-width: 22px;
    text-align: right;
  }
  .yt-tts-voice-select {
    max-width: 175px;
    padding: 3px 8px;
    font-size: 11px;
    height: 26px;
    border-radius: 13px;
    border: 1px solid rgba(255,255,255,0.15);
    background: #212121;
    color: #f1f1f1;
    color-scheme: dark;
  }
  .yt-tts-rewind-btn, .yt-tts-skip-btn {
    padding: 4px 7px;
    font-family: monospace;
    font-size: 11px;
    font-weight: 600;
  }
  .yt-tts-shortcuts-hint {
    display: inline-flex;
    align-items: center;
    font-size: 10px;
    color: var(--yt-spec-text-secondary, #888);
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    padding: 2px 7px;
    margin-left: 2px;
    cursor: help;
    user-select: none;
    letter-spacing: 0.2px;
    transition: color 0.15s, background 0.15s;
  }
  .yt-tts-shortcuts-hint:hover {
    color: #3ea6ff;
    background: rgba(62, 166, 255, 0.1);
    border-color: rgba(62, 166, 255, 0.25);
  }
  .yt-tts-toast {
    position: absolute;
    top: 56px;
    left: 50%;
    transform: translateX(-50%) translateY(-6px);
    background: rgba(18, 18, 22, 0.94);
    color: #f1f1f1;
    border: 1px solid rgba(255, 255, 255, 0.18);
    box-shadow: 0 8px 28px rgba(0, 0, 0, 0.7);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.16s ease, transform 0.16s ease;
    z-index: 2147483010;
    letter-spacing: 0.3px;
    backdrop-filter: blur(8px);
  }
  .yt-tts-toast.yt-tts-toast-show {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
  .yt-transcript-search-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    margin-bottom: 12px;
    flex-wrap: wrap;
  }
  .yt-transcript-input-wrap {
    display: flex;
    align-items: center;
    gap: 6px;
    background: #212121;
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 8px;
    padding: 4px 8px;
    flex: 1;
    min-width: 200px;
  }
  .yt-transcript-search-input {
    background: transparent;
    border: none;
    color: #f1f1f1;
    font-size: 12px;
    outline: none;
    width: 100%;
  }
  .yt-transcript-search-input::placeholder {
    color: #888;
  }
  .yt-transcript-clear-btn {
    background: transparent;
    border: none;
    color: #888;
    cursor: pointer;
    padding: 2px;
    border-radius: 50%;
    display: flex;
    align-items: center;
  }
  .yt-transcript-clear-btn:hover {
    color: #fff;
    background: rgba(255, 255, 255, 0.1);
  }
  .yt-transcript-match-count {
    font-size: 11px;
    color: #aaa;
    font-family: monospace;
    white-space: nowrap;
  }
  .yt-transcript-nav-btn {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #f1f1f1;
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 10px;
    cursor: pointer;
    transition: background 0.15s;
  }
  .yt-transcript-nav-btn:hover:not(:disabled) {
    background: rgba(255, 255, 255, 0.15);
  }
  .yt-transcript-nav-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }
  .yt-transcript-line {
    padding: 4px 6px;
    border-radius: 4px;
    line-height: 1.5;
    transition: background 0.15s;
  }
  .yt-transcript-line:hover {
    background: rgba(255, 255, 255, 0.04);
  }
  .yt-transcript-line.yt-transcript-line-speaking {
    background: rgba(62, 166, 255, 0.16) !important;
    border-left: 3px solid #3ea6ff !important;
    padding-left: 8px !important;
    border-radius: 4px;
    box-shadow: 0 0 10px rgba(62, 166, 255, 0.15);
    transition: all 0.2s ease;
  }
  .yt-transcript-line.yt-transcript-line-speaking .yt-ts-link {
    color: #3ea6ff !important;
    font-weight: 700 !important;
  }
  .yt-transcript-line.yt-transcript-line-speaking .yt-transcript-text {
    color: #ffffff !important;
    font-weight: 500 !important;
  }
  .yt-speaking-indicator {
    display: inline-flex;
    align-items: center;
    vertical-align: middle;
    margin-right: 6px;
    color: #3ea6ff;
    animation: yt-pulse-speaking 1.2s infinite ease-in-out;
  }
  @keyframes yt-pulse-speaking {
    0%, 100% { opacity: 0.7; transform: scale(0.95); }
    50% { opacity: 1; transform: scale(1.1); }
  }
  .yt-transcript-highlight {
    background: #fbc02d;
    color: #000;
    padding: 1px 3px;
    border-radius: 3px;
    font-weight: 600;
  }
  .yt-transcript-highlight.active {
    background: #ff7043;
    color: #fff;
    outline: 2px solid #fff;
  }
  .yt-icon-tool-btn {
    background: transparent;
    border: none;
    color: var(--yt-spec-text-secondary, #aaa);
    padding: 6px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
  }
  .yt-icon-tool-btn:hover {
    background: rgba(255,255,255,0.1);
    color: #fff;
  }
  .yt-spacer {
    flex: 1;
  }
  .yt-primary-btn {
    background: var(--yt-spec-call-to-action, #3ea6ff);
    color: #0f0f0f;
    border: none;
    border-radius: 18px;
    font-size: 13px;
    font-weight: 600;
    padding: 6px 16px;
    cursor: pointer;
    transition: opacity 0.2s;
  }
  .yt-primary-btn:hover {
    opacity: 0.9;
  }
  .yt-sec-btn {
    background: rgba(255,255,255,0.1);
    color: var(--yt-spec-text-primary, #f1f1f1);
    border: none;
    border-radius: 18px;
    font-size: 12px;
    padding: 6px 14px;
    cursor: pointer;
  }
  .yt-sec-btn:hover {
    background: rgba(255,255,255,0.18);
  }
  .yt-ask-fallback-btn {
    background: linear-gradient(135deg, #7c4dff, #3ea6ff) !important;
    color: #fff !important;
    font-weight: 600;
    box-shadow: 0 2px 8px rgba(124, 77, 255, 0.4);
  }
  .yt-ask-fallback-btn:hover {
    filter: brightness(1.1);
  }
  .yt-options-row {
    font-size: 12px;
    color: var(--yt-spec-text-secondary, #aaa);
  }
  .yt-checkbox-label {
    display: flex;
    align-items: center;
    gap: 4px;
    cursor: pointer;
  }
  .yt-checkbox-label.off {
    opacity: 0.4;
    pointer-events: none;
  }
  .yt-link-btn {
    background: transparent;
    border: none;
    color: var(--yt-spec-call-to-action, #3ea6ff);
    font-size: 12px;
    cursor: pointer;
  }
  .yt-adv-panel {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    padding: 12px 16px;
    background: rgba(0,0,0,0.25);
    border-bottom: 1px solid rgba(255,255,255,0.08);
    max-height: 36vh;
    overflow-y: auto;
  }
  .yt-adv-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .yt-adv-title {
    font-size: 12px;
    font-weight: 600;
    color: var(--yt-spec-text-primary, #f1f1f1);
    border-bottom: 1px solid rgba(255,255,255,0.05);
    padding-bottom: 4px;
  }
  .yt-adv-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 11px;
    gap: 8px;
  }
  .yt-adv-select {
    max-width: 130px;
    padding: 2px 4px;
  }
  .yt-player-slot {
    position: relative;
    width: 100%;
    aspect-ratio: 16/9;
    max-height: 280px;
    background: #000;
    border-bottom: 1px solid rgba(255,255,255,0.08);
  }
  .yt-player-iframe {
    width: 100%;
    height: 100%;
    border: none;
  }
  .yt-player-close-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    z-index: 10;
    background: rgba(0,0,0,0.7);
    color: #fff;
    border: none;
    border-radius: 50%;
    padding: 6px;
    cursor: pointer;
  }
  .yt-window-body {
    flex: 1;
    overflow-y: auto;
    overscroll-behavior: contain;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .yt-loading-view {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 48px 16px;
    text-align: center;
  }
  .yt-loading-text {
    font-size: 15px;
    font-weight: 500;
    margin-bottom: 6px;
  }
  .yt-loading-phase {
    font-size: 13px;
    color: var(--yt-spec-call-to-action, #3ea6ff);
    margin-bottom: 12px;
  }
  .yt-loading-tip {
    font-size: 12px;
    color: var(--yt-spec-text-secondary, #aaa);
    max-width: 380px;
  }
  .yt-error-view {
    padding: 24px;
    background: rgba(168, 32, 26, 0.15);
    border: 1px solid rgba(168, 32, 26, 0.4);
    border-radius: 12px;
  }
  .yt-error-title {
    font-size: 15px;
    font-weight: 600;
    color: #ff8580;
    margin-bottom: 8px;
  }
  .yt-error-msg {
    font-size: 13px;
    line-height: 1.5;
    white-space: pre-wrap;
    margin-bottom: 16px;
  }
  .yt-error-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }
  .yt-notes-wrap {
    background: rgba(255,255,255,0.04);
    border-left: 3px solid #fbc02d;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 12px;
    line-height: 1.4;
  }
  .yt-note-line {
    margin: 2px 0;
  }
  .yt-markdown-body {
    font-size: 14px;
    line-height: 1.6;
  }
  .yt-md-h3 {
    font-size: 17px;
    font-weight: 600;
    margin: 16px 0 8px 0;
    color: #fff;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    padding-bottom: 4px;
  }
  .yt-md-h4 {
    font-size: 15px;
    font-weight: 600;
    margin: 12px 0 6px 0;
    color: #eee;
  }
  .yt-md-p {
    margin: 8px 0;
  }
  .yt-md-list {
    margin: 8px 0;
    padding-left: 20px;
  }
  .yt-md-nested-li {
    margin-left: 16px;
    list-style-type: circle;
  }
  .yt-ts-link {
    color: var(--yt-spec-call-to-action, #3ea6ff);
    text-decoration: none;
    font-weight: 500;
    cursor: pointer;
  }
  .yt-ts-link:hover {
    text-decoration: underline;
  }
  .yt-ext-link {
    color: #64b5f6;
    text-decoration: none;
  }
  .yt-ext-link:hover {
    text-decoration: underline;
  }
  .yt-visual-card {
    margin: 12px 0;
    background: rgba(255,255,255,0.05);
    border-radius: 8px;
    overflow: hidden;
    max-width: 420px;
  }
  .yt-frame-preview {
    position: relative;
    cursor: pointer;
    background-color: #111;
  }
  .yt-frame-badge {
    position: absolute;
    bottom: 6px;
    left: 6px;
    background: rgba(0,0,0,0.75);
    color: #fff;
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 4px;
  }
  .yt-visual-caption {
    padding: 6px 10px;
    font-size: 11px;
    color: var(--yt-spec-text-secondary, #aaa);
    line-height: 1.4;
  }
  .yt-commons-img, .yt-ai-img {
    width: 100%;
    display: block;
    cursor: pointer;
  }
  .yt-fact-box {
    margin-top: 16px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    padding: 12px;
  }
  .yt-fact-header {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #81c784;
  }
  .yt-sources-consulted {
    margin-top: 10px;
    font-size: 11px;
    border-top: 1px solid rgba(255,255,255,0.06);
    padding-top: 6px;
  }
  .yt-sources-title {
    font-weight: 600;
    margin-bottom: 4px;
  }
  .yt-source-item {
    margin: 2px 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .yt-fact-recheck-bar {
    margin-top: 8px;
    display: flex;
    justify-content: flex-end;
  }
  .yt-thread-wrap {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-top: 16px;
  }
  .yt-bubble {
    max-width: 80%;
    padding: 10px 14px;
    border-radius: 12px;
    font-size: 13px;
    line-height: 1.4;
  }
  .yt-user-bubble {
    align-self: flex-end;
    background: var(--yt-spec-call-to-action, #3ea6ff);
    color: #0f0f0f;
    font-weight: 500;
    border-bottom-right-radius: 2px;
  }
  .yt-ans-bubble {
    align-self: flex-start;
    background: var(--yt-spec-badge-chip-background, rgba(255,255,255,0.08));
    color: var(--yt-spec-text-primary, #f1f1f1);
    border-bottom-left-radius: 2px;
  }
  .yt-followup-busy {
    font-size: 12px;
    color: var(--yt-spec-call-to-action, #3ea6ff);
    font-style: italic;
    padding: 6px 12px;
  }
  .yt-composer-wrap {
    padding: 10px 16px;
    border-top: 1px solid rgba(255,255,255,0.08);
    display: flex;
    gap: 8px;
    align-items: flex-end;
    background: var(--yt-spec-base-background, #0f0f0f);
  }
  .yt-composer-textarea {
    flex: 1;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 19px;
    padding: 8px 16px;
    color: var(--yt-spec-text-primary, #f1f1f1);
    font-size: 13px;
    resize: none;
    outline: none;
    line-height: 1.4;
  }
  .yt-composer-textarea:focus {
    border-color: var(--yt-spec-call-to-action, #3ea6ff);
  }
  .yt-composer-draft-badge {
    display: none;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    font-size: 10px;
    font-weight: 600;
    color: #fbbf24;
    background: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.35);
    border-radius: 12px;
    white-space: nowrap;
    align-self: center;
  }
  .yt-composer-send-btn {
    background: var(--yt-spec-call-to-action, #3ea6ff);
    color: #0f0f0f;
    border: none;
    border-radius: 18px;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 16px;
    cursor: pointer;
  }
  .yt-composer-mic-btn {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 50%;
    width: 36px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: var(--yt-spec-text-secondary, #aaa);
    cursor: pointer;
    flex-shrink: 0;
    transition: all 0.2s ease;
  }
  .yt-composer-mic-btn:hover:not(:disabled) {
    background: rgba(255,255,255,0.15);
    color: var(--yt-spec-text-primary, #fff);
  }
  .yt-composer-mic-btn.yt-mic-recording {
    background: #ef4444 !important;
    color: #fff !important;
    border-color: #f87171 !important;
    box-shadow: 0 0 10px rgba(239, 68, 68, 0.6);
    animation: yt-pulse-record 1.2s infinite ease-in-out;
  }
  @keyframes yt-pulse-record {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.08); opacity: 0.85; }
  }
  .yt-composer-mic-btn:disabled {
    opacity: 0.4;
    cursor: default;
  }
  .yt-composer-send-btn:disabled {
    opacity: 0.5;
    cursor: default;
  }
  .yt-key-dialog-box {
    width: min(520px, 92vw);
    background: var(--yt-spec-base-background, #0f0f0f);
    color: var(--yt-spec-text-primary, #f1f1f1);
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 10px 32px rgba(0,0,0,0.8);
    border: 1px solid rgba(255,255,255,0.12);
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .yt-dialog-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .yt-dialog-header h3 {
    margin: 0;
    font-size: 16px;
  }
  .yt-dialog-info {
    font-size: 12px;
    color: var(--yt-spec-text-secondary, #aaa);
    line-height: 1.4;
  }
  .yt-keys-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-height: 200px;
    overflow-y: auto;
  }
  .yt-key-row {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,255,255,0.05);
    padding: 6px 10px;
    border-radius: 8px;
  }
  .yt-input {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 12px;
    outline: none;
  }
  .yt-key-name-input {
    flex: 1;
  }
  .yt-key-mask {
    font-size: 12px;
    color: #aaa;
    font-family: monospace;
  }
  .yt-del-btn {
    background: rgba(168, 32, 26, 0.4);
    color: #ff8580;
  }
  .yt-add-key-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
    border-top: 1px solid rgba(255,255,255,0.08);
    padding-top: 12px;
  }

  /* History dock tab */
  .yt-dock-history-tab {
    background: linear-gradient(135deg, rgba(62, 166, 255, 0.15), rgba(168, 85, 247, 0.15));
    border: 1px solid rgba(62, 166, 255, 0.35);
  }
  .yt-dock-history-tab:hover {
    background: linear-gradient(135deg, rgba(62, 166, 255, 0.25), rgba(168, 85, 247, 0.25));
  }
  .yt-dock-history-title {
    font-weight: 600;
    color: #e0e7ff;
  }
  .yt-dock-open-history-btn {
    opacity: 0.8;
  }
  .yt-dock-open-history-btn:hover {
    opacity: 1;
    background: rgba(255,255,255,0.15);
  }

  /* Clickable title anchor */
  .yt-win-title-link {
    text-decoration: none;
    color: inherit;
    cursor: pointer;
    display: inline-block;
    transition: color 0.15s ease;
  }
  .yt-win-title-link:hover {
    color: var(--yt-spec-call-to-action, #3ea6ff);
    text-decoration: underline;
  }

  /* Summary page top bar & Action pills */
  .yt-summary-page-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.07);
    border-radius: 8px;
    margin-bottom: 12px;
    flex-wrap: wrap;
  }
  .yt-action-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 11px;
    border-radius: 14px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.15s ease;
    border: 1px solid rgba(255, 255, 255, 0.12);
    background: rgba(255, 255, 255, 0.06);
    color: var(--yt-spec-text-primary, #f1f1f1);
  }
  .yt-action-pill:hover {
    background: rgba(255, 255, 255, 0.14);
    border-color: rgba(255, 255, 255, 0.25);
    color: #fff;
  }
  .yt-open-video-pill {
    color: #93c5fd;
    border-color: rgba(147, 197, 253, 0.3);
    background: rgba(59, 130, 246, 0.1);
  }
  .yt-open-video-pill:hover {
    background: rgba(59, 130, 246, 0.2);
    border-color: rgba(147, 197, 253, 0.5);
    color: #bfdbfe;
  }
  .yt-history-pill {
    color: #d8b4fe;
    border-color: rgba(216, 180, 254, 0.3);
    background: rgba(168, 85, 247, 0.1);
  }
  .yt-history-pill:hover {
    background: rgba(168, 85, 247, 0.2);
    border-color: rgba(216, 180, 254, 0.5);
    color: #e9d5ff;
  }

  /* History Dialog Modal */
  .yt-history-dialog-box {
    width: min(720px, 94vw);
    max-height: 85vh;
    background: var(--yt-spec-base-background, #0f0f0f);
    color: var(--yt-spec-text-primary, #f1f1f1);
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.85);
    border: 1px solid rgba(255,255,255,0.12);
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .yt-history-search-bar {
    display: flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    padding: 2px 8px;
  }
  .yt-history-search-input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    color: #fff;
    padding: 8px 6px;
    font-size: 13px;
  }
  .yt-history-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    overflow-y: auto;
    max-height: 52vh;
    padding-right: 4px;
  }
  .yt-history-card {
    display: flex;
    align-items: center;
    gap: 12px;
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    padding: 10px;
    transition: background 0.15s ease, border-color 0.15s ease;
  }
  .yt-history-card:hover {
    background: rgba(255, 255, 255, 0.07);
    border-color: rgba(255, 255, 255, 0.15);
  }
  .yt-history-thumb-wrap {
    width: 96px;
    height: 54px;
    flex-shrink: 0;
    border-radius: 6px;
    overflow: hidden;
    background: #1a1a1a;
    cursor: pointer;
  }
  .yt-history-thumb {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
  }
  .yt-history-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .yt-history-item-title {
    font-size: 13px;
    font-weight: 600;
    color: #f1f1f1;
    text-decoration: none;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .yt-history-item-title:hover {
    color: var(--yt-spec-call-to-action, #3ea6ff);
    text-decoration: underline;
  }
  .yt-history-item-meta {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: #888;
  }
  .yt-history-badge {
    padding: 1px 6px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }
  .yt-history-badge.mode {
    background: rgba(62, 166, 255, 0.18);
    color: #70baff;
  }
  .yt-history-badge.model {
    background: rgba(168, 85, 247, 0.18);
    color: #c084fc;
  }
  .yt-history-date {
    color: #888;
  }
  .yt-history-snippet {
    font-size: 12px;
    color: #aaa;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.3;
  }
  .yt-history-actions {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-shrink: 0;
  }
  .yt-history-reopen-btn {
    padding: 6px 12px !important;
    font-size: 12px !important;
  }
  .yt-history-video-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 6px 10px !important;
    font-size: 12px !important;
    text-decoration: none;
  }
  .yt-history-del-btn {
    padding: 6px 8px !important;
    color: #ff8580 !important;
  }
  .yt-history-empty {
    padding: 32px 16px;
    text-align: center;
    color: #888;
    font-size: 13px;
    line-height: 1.5;
  }
  .yt-history-footer {
    display: flex;
    align-items: center;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    padding-top: 12px;
  }

  /* Readability Mode & Distraction-Free Typography Layout */
  .yt-win-btn.yt-win-readability-btn.active {
    color: #3ea6ff !important;
    background: rgba(62, 166, 255, 0.2) !important;
  }
  .yt-window-box.yt-readability-active .yt-win-toolbar,
  .yt-window-box.yt-readability-active .yt-adv-panel,
  .yt-window-box.yt-readability-active .yt-composer-wrap,
  .yt-window-box.yt-readability-active .yt-summary-page-bar {
    display: none !important;
  }
  .yt-window-box.yt-readability-active .yt-window-body {
    padding: 0;
    background: #0f0f0f;
  }
  .yt-readability-container {
    display: flex;
    flex-direction: column;
    min-height: 100%;
    background: #0f0f0f;
  }
  .yt-readability-bar {
    position: sticky;
    top: 0;
    z-index: 20;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 20px;
    background: rgba(18, 18, 18, 0.95);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    flex-wrap: wrap;
  }
  .yt-readability-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #f1f1f1;
    font-size: 12px;
    font-weight: 500;
    padding: 5px 12px;
    border-radius: 14px;
    cursor: pointer;
    transition: background 0.15s, border-color 0.15s;
  }
  .yt-readability-btn:hover {
    background: rgba(255, 255, 255, 0.12);
    border-color: rgba(255, 255, 255, 0.22);
  }
  .yt-readability-exit-btn {
    color: #ff8580;
    border-color: rgba(255, 133, 128, 0.3);
  }
  .yt-readability-exit-btn:hover {
    background: rgba(255, 133, 128, 0.15);
  }
  .yt-readability-sync-theme-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 600;
    padding: 5px 11px;
    border-radius: 14px;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .yt-readability-sync-theme-btn.active {
    background: rgba(14, 165, 233, 0.22) !important;
    border-color: #0ea5e9 !important;
    color: #38bdf8 !important;
    box-shadow: 0 0 8px rgba(14, 165, 233, 0.25);
  }
  .yt-readability-sync-theme-btn svg {
    transition: transform 0.3s ease;
  }
  .yt-readability-sync-theme-btn.active svg {
    transform: rotate(180deg);
  }
  .yt-readability-divider {
    width: 1px;
    height: 18px;
    background: rgba(255, 255, 255, 0.12);
    margin: 0 4px;
  }
  .yt-readability-theme-group {
    display: inline-flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    overflow: hidden;
  }
  .yt-readability-theme-btn {
    background: transparent;
    border: none;
    color: #bbb;
    font-size: 11px;
    font-weight: 600;
    padding: 5px 10px;
    cursor: pointer;
    transition: background 0.15s, color 0.15s;
  }
  .yt-readability-theme-btn:hover {
    background: rgba(255, 255, 255, 0.12);
    color: #fff;
  }
  .yt-readability-theme-btn.active {
    background: #3ea6ff;
    color: #000;
    font-weight: 700;
  }
  .yt-readability-theme-select {
    display: none;
    height: 26px;
    padding: 2px 8px;
    font-size: 11px;
    border-radius: 13px;
    background: rgba(255, 255, 255, 0.08);
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.15);
  }
  @media (max-width: 640px) {
    .yt-readability-theme-group { display: none; }
    .yt-readability-theme-select { display: inline-block; }
  }
  .yt-readability-size-group {
    display: inline-flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 14px;
    overflow: hidden;
  }
  .yt-readability-size-btn {
    background: transparent;
    border: none;
    color: #ddd;
    font-size: 11px;
    font-weight: 700;
    padding: 5px 9px;
    cursor: pointer;
  }
  .yt-readability-size-btn:hover {
    background: rgba(255, 255, 255, 0.14);
    color: #fff;
  }
  .yt-readability-size-label {
    font-size: 11px;
    font-family: monospace;
    color: #aaa;
    padding: 0 4px;
    border-left: 1px solid rgba(255, 255, 255, 0.08);
    border-right: 1px solid rgba(255, 255, 255, 0.08);
  }
  .yt-readability-stats {
    font-size: 12px;
    color: #aaa;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-content {
    max-width: 720px;
    width: 100%;
    margin: 0 auto;
    padding: 40px 24px 80px 24px;
    line-height: 1.85;
    color: #e4e4e7;
    box-sizing: border-box;
  }
  .yt-readability-content.font-serif {
    font-family: Charter, Georgia, "Times New Roman", Cambria, serif;
    letter-spacing: 0.01em;
  }
  .yt-readability-content.font-sans {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    letter-spacing: normal;
  }
  .yt-readability-header {
    margin-bottom: 32px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.12);
  }
  .yt-readability-type-badge {
    display: inline-block;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.75px;
    color: #3ea6ff;
    background: rgba(62, 166, 255, 0.12);
    border: 1px solid rgba(62, 166, 255, 0.25);
    padding: 3px 8px;
    border-radius: 4px;
    margin-bottom: 10px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-title {
    font-size: 1.7em;
    font-weight: 700;
    line-height: 1.3;
    margin: 0 0 10px 0;
    color: #fff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-meta {
    font-size: 12px;
    color: #888;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-h2 {
    font-size: 1.35em;
    font-weight: 700;
    margin: 36px 0 14px 0;
    color: #fff;
    padding-bottom: 6px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-h3 {
    font-size: 1.15em;
    font-weight: 600;
    margin: 24px 0 10px 0;
    color: #f4f4f5;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .yt-readability-p {
    margin: 0 0 18px 0;
    color: #d4d4d8;
  }
  .yt-readability-ul, .yt-readability-ol {
    margin: 0 0 20px 0;
    padding-left: 28px;
  }
  .yt-readability-li {
    margin-bottom: 8px;
    color: #d4d4d8;
  }
  .yt-readability-tx-line {
    margin-bottom: 12px;
    color: #d4d4d8;
  }
  .yt-readability-ts {
    display: inline-block;
    color: #3ea6ff;
    font-family: monospace;
    font-size: 0.9em;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    background: rgba(62, 166, 255, 0.1);
    padding: 1px 6px;
    border-radius: 4px;
    margin-right: 6px;
  }
  .yt-readability-ts:hover {
    background: rgba(62, 166, 255, 0.25);
    text-decoration: underline;
  }
  .yt-readability-fact-box {
    margin-top: 40px;
    padding: 20px;
    background: rgba(34, 197, 94, 0.06);
    border: 1px solid rgba(34, 197, 94, 0.2);
    border-radius: 12px;
  }
  .yt-readability-qa-section {
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  }
  .yt-readability-qa-item {
    margin-bottom: 18px;
    padding-bottom: 14px;
    border-bottom: 1px dashed rgba(255, 255, 255, 0.08);
  }
  .yt-readability-q {
    font-weight: 600;
    color: #93c5fd;
    margin-bottom: 6px;
  }
  .yt-readability-a {
    color: #d4d4d8;
    margin: 0;
  }

  /* --- Readability Themes (System, Light, Sepia, Dark) --- */
  /* Light Theme */
  .yt-readability-container.theme-light,
  .yt-window-box.yt-theme-light .yt-readability-container {
    background: #fdfbf7 !important;
    color: #1f2328 !important;
  }
  .yt-readability-container.theme-light .yt-readability-bar,
  .yt-window-box.yt-theme-light .yt-readability-bar {
    background: rgba(246, 244, 238, 0.96) !important;
    border-bottom: 1px solid #e1ded5 !important;
  }
  .yt-readability-container.theme-light .yt-readability-btn,
  .yt-window-box.yt-theme-light .yt-readability-btn {
    background: #ffffff !important;
    border-color: #d0d7de !important;
    color: #1f2328 !important;
  }
  .yt-readability-container.theme-light .yt-readability-btn:hover,
  .yt-window-box.yt-theme-light .yt-readability-btn:hover {
    background: #f3f4f6 !important;
  }
  .yt-readability-container.theme-light .yt-readability-theme-btn,
  .yt-window-box.yt-theme-light .yt-readability-theme-btn {
    color: #57606a !important;
  }
  .yt-readability-container.theme-light .yt-readability-theme-btn.active,
  .yt-window-box.yt-theme-light .yt-readability-theme-btn.active {
    background: #0969da !important;
    color: #ffffff !important;
  }
  .yt-readability-container.theme-light .yt-readability-theme-select,
  .yt-window-box.yt-theme-light .yt-readability-theme-select {
    background: #ffffff !important;
    border-color: #d0d7de !important;
    color: #1f2328 !important;
    color-scheme: light;
  }
  .yt-readability-container.theme-light .yt-readability-size-group,
  .yt-window-box.yt-theme-light .yt-readability-size-group {
    background: #ffffff !important;
    border-color: #d0d7de !important;
  }
  .yt-readability-container.theme-light .yt-readability-size-btn,
  .yt-window-box.yt-theme-light .yt-readability-size-btn {
    color: #1f2328 !important;
  }
  .yt-readability-container.theme-light .yt-readability-size-label,
  .yt-window-box.yt-theme-light .yt-readability-size-label {
    color: #57606a !important;
    border-color: #d0d7de !important;
  }
  .yt-readability-container.theme-light .yt-readability-stats,
  .yt-window-box.yt-theme-light .yt-readability-stats {
    color: #57606a !important;
  }
  .yt-readability-container.theme-light .yt-readability-title,
  .yt-window-box.yt-theme-light .yt-readability-title {
    color: #0f1419 !important;
  }
  .yt-readability-container.theme-light .yt-readability-meta,
  .yt-window-box.yt-theme-light .yt-readability-meta {
    color: #57606a !important;
  }
  .yt-readability-container.theme-light .yt-readability-header,
  .yt-window-box.yt-theme-light .yt-readability-header {
    border-bottom: 1px solid #e1ded5 !important;
  }
  .yt-readability-container.theme-light .yt-readability-h2,
  .yt-window-box.yt-theme-light .yt-readability-h2 {
    color: #0f1419 !important;
    border-bottom: 1px solid #e1ded5 !important;
  }
  .yt-readability-container.theme-light .yt-readability-h3,
  .yt-window-box.yt-theme-light .yt-readability-h3 {
    color: #1f2328 !important;
  }
  .yt-readability-container.theme-light .yt-readability-p,
  .yt-readability-container.theme-light .yt-readability-li,
  .yt-readability-container.theme-light .yt-readability-tx-line,
  .yt-window-box.yt-theme-light .yt-readability-p,
  .yt-window-box.yt-theme-light .yt-readability-li,
  .yt-window-box.yt-theme-light .yt-readability-tx-line {
    color: #24292f !important;
  }
  .yt-readability-container.theme-light .yt-readability-ts,
  .yt-window-box.yt-theme-light .yt-readability-ts {
    color: #0969da !important;
    background: #ddf4ff !important;
  }
  .yt-readability-container.theme-light .yt-readability-type-badge,
  .yt-window-box.yt-theme-light .yt-readability-type-badge {
    background: #ddf4ff !important;
    color: #0969da !important;
    border-color: #54aeff !important;
  }
  .yt-readability-container.theme-light .yt-readability-fact-box,
  .yt-window-box.yt-theme-light .yt-readability-fact-box {
    background: #f6fdf7 !important;
    border-color: #8fe09b !important;
    color: #1a7f37 !important;
  }

  /* Sepia Theme */
  .yt-readability-container.theme-sepia,
  .yt-window-box.yt-theme-sepia .yt-readability-container {
    background: #f4ecd8 !important;
    color: #433422 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-bar,
  .yt-window-box.yt-theme-sepia .yt-readability-bar {
    background: rgba(234, 224, 200, 0.96) !important;
    border-bottom: 1px solid #d8c8a6 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-btn,
  .yt-window-box.yt-theme-sepia .yt-readability-btn {
    background: #efe5cd !important;
    border-color: #d8c8a6 !important;
    color: #433422 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-btn:hover,
  .yt-window-box.yt-theme-sepia .yt-readability-btn:hover {
    background: #e3d5b8 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-theme-btn,
  .yt-window-box.yt-theme-sepia .yt-readability-theme-btn {
    color: #5c4b37 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-theme-btn.active,
  .yt-window-box.yt-theme-sepia .yt-readability-theme-btn.active {
    background: #7a4d10 !important;
    color: #ffffff !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-theme-select,
  .yt-window-box.yt-theme-sepia .yt-readability-theme-select {
    background: #efe5cd !important;
    border-color: #d8c8a6 !important;
    color: #433422 !important;
    color-scheme: light;
  }
  .yt-readability-container.theme-sepia .yt-readability-size-group,
  .yt-window-box.yt-theme-sepia .yt-readability-size-group {
    background: #efe5cd !important;
    border-color: #d8c8a6 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-size-btn,
  .yt-window-box.yt-theme-sepia .yt-readability-size-btn {
    color: #433422 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-size-label,
  .yt-window-box.yt-theme-sepia .yt-readability-size-label {
    color: #7c6a53 !important;
    border-color: #d8c8a6 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-stats,
  .yt-window-box.yt-theme-sepia .yt-readability-stats {
    color: #7c6a53 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-title,
  .yt-window-box.yt-theme-sepia .yt-readability-title {
    color: #2c1d0c !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-meta,
  .yt-window-box.yt-theme-sepia .yt-readability-meta {
    color: #7c6a53 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-header,
  .yt-window-box.yt-theme-sepia .yt-readability-header {
    border-bottom: 1px solid #d8c8a6 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-h2,
  .yt-window-box.yt-theme-sepia .yt-readability-h2 {
    color: #2c1d0c !important;
    border-bottom: 1px solid #d8c8a6 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-h3,
  .yt-window-box.yt-theme-sepia .yt-readability-h3 {
    color: #382715 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-p,
  .yt-readability-container.theme-sepia .yt-readability-li,
  .yt-readability-container.theme-sepia .yt-readability-tx-line,
  .yt-window-box.yt-theme-sepia .yt-readability-p,
  .yt-window-box.yt-theme-sepia .yt-readability-li,
  .yt-window-box.yt-theme-sepia .yt-readability-tx-line {
    color: #433422 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-ts,
  .yt-window-box.yt-theme-sepia .yt-readability-ts {
    color: #7a4d10 !important;
    background: #e5d7b5 !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-type-badge,
  .yt-window-box.yt-theme-sepia .yt-readability-type-badge {
    background: #e9dec2 !important;
    color: #7a4d10 !important;
    border-color: #c9b48c !important;
  }
  .yt-readability-container.theme-sepia .yt-readability-fact-box,
  .yt-window-box.yt-theme-sepia .yt-readability-fact-box {
    background: #e8eed9 !important;
    border-color: #b8cb98 !important;
    color: #325016 !important;
  }

  /* Dark Theme (High Contrast) */
  .yt-readability-container.theme-dark,
  .yt-window-box.yt-theme-dark .yt-readability-container {
    background: #0a0a0c !important;
    color: #f4f4f5 !important;
  }
  .yt-readability-container.theme-dark .yt-readability-bar,
  .yt-window-box.yt-theme-dark .yt-readability-bar {
    background: rgba(14, 14, 18, 0.96) !important;
    border-bottom: 1px solid #27272a !important;
  }
  .yt-readability-container.theme-dark .yt-readability-theme-btn.active,
  .yt-window-box.yt-theme-dark .yt-readability-theme-btn.active {
    background: #3ea6ff !important;
    color: #000000 !important;
  }

  /* System Theme: Automatically adjusts based on user preference */
  @media (prefers-color-scheme: light) {
    .yt-readability-container.theme-system,
    .yt-window-box.yt-theme-system .yt-readability-container {
      background: #fdfbf7 !important;
      color: #1f2328 !important;
    }
    .yt-readability-container.theme-system .yt-readability-bar,
    .yt-window-box.yt-theme-system .yt-readability-bar {
      background: rgba(246, 244, 238, 0.96) !important;
      border-bottom: 1px solid #e1ded5 !important;
    }
    .yt-readability-container.theme-system .yt-readability-btn,
    .yt-window-box.yt-theme-system .yt-readability-btn {
      background: #ffffff !important;
      border-color: #d0d7de !important;
      color: #1f2328 !important;
    }
    .yt-readability-container.theme-system .yt-readability-theme-select,
    .yt-window-box.yt-theme-system .yt-readability-theme-select {
      background: #ffffff !important;
      border-color: #d0d7de !important;
      color: #1f2328 !important;
    }
    .yt-readability-container.theme-system .yt-readability-title,
    .yt-readability-container.theme-system .yt-readability-h2 {
      color: #0f1419 !important;
    }
    .yt-readability-container.theme-system .yt-readability-p,
    .yt-readability-container.theme-system .yt-readability-li {
      color: #24292f !important;
    }
  }

  /* Export Popover Dropdown */
  .yt-export-popover {
    position: absolute;
    z-index: 2147483010;
    width: 290px;
    background: #1f1f1f;
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 12px;
    box-shadow: 0 12px 36px rgba(0, 0, 0, 0.75);
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    animation: ytPopIn 0.15s ease-out;
  }
  @keyframes ytPopIn {
    from { opacity: 0; transform: translateY(-4px) scale(0.97); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }
  .yt-export-header {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #888;
    padding: 6px 10px 4px 10px;
  }
  .yt-export-item {
    display: flex;
    align-items: center;
    gap: 10px;
    background: transparent;
    border: none;
    color: #f1f1f1;
    text-align: left;
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.12s ease;
  }
  .yt-export-item:hover {
    background: rgba(255, 255, 255, 0.08);
  }
  .yt-export-item-text {
    flex: 1;
    min-width: 0;
  }
  .yt-export-item-title {
    font-size: 13px;
    font-weight: 500;
    color: #f1f1f1;
    line-height: 1.3;
  }
  .yt-export-item-sub {
    font-size: 11px;
    color: #888;
    margin-top: 1px;
  }
  `;

  function ensureHostAndShadow() {
    if (!document.documentElement) return false;
    let host = document.getElementById('yt-ai-summary-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'yt-ai-summary-host';
      document.documentElement.appendChild(host);
    }
    if (!shadowRoot) {
      shadowRoot = host.attachShadow({ mode: 'open' });
      const styleEl = document.createElement('style');
      styleEl.textContent = CSS_TEXT;
      shadowRoot.appendChild(styleEl);

      dockContainer = h('div', { className: 'yt-dock' });
      modalsContainer = h('div', { className: 'yt-modals' });
      shadowRoot.appendChild(dockContainer);
      shadowRoot.appendChild(modalsContainer);
      updateDockHistoryTab();
    }
    return true;
  }

  // --- KEYBOARD & GLOBAL EVENTS (§2) ---
  function setupKeyboardListeners() {
    window.addEventListener(
      'keydown',
      (e) => {
        if (!e.isTrusted && !window.__yt_test_allow_untrusted_events) return;
        const path = e.composedPath();
        const host = document.getElementById('yt-ai-summary-host');
        const inHost = host && path.includes(host);

        const keyDialog = modalsContainer?.querySelector('.yt-key-dialog-scrim');
        const historyDialog = modalsContainer?.querySelector('.yt-history-dialog-scrim');
        const hasActiveModal = keyDialog || historyDialog || maximizedWindow;

        if (inHost || hasActiveModal) {
          if (inHost) {
            e.stopImmediatePropagation();
          }

          // Escape key handler: close dialog if open, else minimize window
          if (e.key === 'Escape') {
            if (keyDialog) {
              e.stopImmediatePropagation();
              keyDialog.remove();
              return;
            }
            if (historyDialog) {
              e.stopImmediatePropagation();
              historyDialog.remove();
              return;
            }
            if (maximizedWindow) {
              e.stopImmediatePropagation();
              maximizedWindow.minimize();
              return;
            }
          }

          // Enter in follow-up textarea sends
          if (inHost && e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
            const active = shadowRoot?.activeElement;
            if (active && active.classList.contains('yt-composer-textarea')) {
              e.preventDefault();
              e.stopImmediatePropagation();
              if (maximizedWindow) {
                maximizedWindow.sendFollowUp();
              }
              return;
            }
          }

          // Global TTS Keyboard Shortcuts for Active Summary Window
          if (maximizedWindow && !keyDialog && !historyDialog) {
            const activeEl = shadowRoot?.activeElement || document.activeElement;
            const isEditable = activeEl && (
              activeEl.tagName === 'INPUT' ||
              activeEl.tagName === 'TEXTAREA' ||
              activeEl.tagName === 'SELECT' ||
              Boolean(activeEl.isContentEditable) ||
              activeEl.getAttribute?.('contenteditable') === 'true'
            );

            if (!isEditable) {
              // Space or K: Toggle Play / Pause
              if (e.code === 'Space' || e.key === ' ' || e.key === 'k' || e.key === 'K') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                maximizedWindow.toggleTts();
                return;
              }

              // Left Arrow or J: Rewind (5s or 10s)
              if (e.key === 'ArrowLeft' || e.key === 'j' || e.key === 'J') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const sec = (e.key === 'j' || e.key === 'J') ? 10 : 5;
                maximizedWindow.rewindTts(sec);
                return;
              }

              // Right Arrow or L: Skip (5s or 10s)
              if (e.key === 'ArrowRight' || e.key === 'l' || e.key === 'L') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const sec = (e.key === 'l' || e.key === 'L') ? 10 : 5;
                maximizedWindow.skipTts(sec);
                return;
              }

              // Up Arrow: Volume Up (+10%)
              if (e.key === 'ArrowUp') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const newVol = Math.min(1.0, Math.round((maximizedWindow.ttsVolume + 0.1) * 10) / 10);
                maximizedWindow.setTtsVolume(newVol);
                maximizedWindow.showTtsFeedback(`🔊 Volume: ${Math.round(newVol * 100)}%`);
                return;
              }

              // Down Arrow: Volume Down (-10%)
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const newVol = Math.max(0.0, Math.round((maximizedWindow.ttsVolume - 0.1) * 10) / 10);
                maximizedWindow.setTtsVolume(newVol);
                maximizedWindow.showTtsFeedback(`🔉 Volume: ${Math.round(newVol * 100)}%`);
                return;
              }

              // [ or ]: Playback Speed Down or Up
              if (e.key === '[' || e.key === ']') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                maximizedWindow.stepTtsRate(e.key === ']' ? 1 : -1);
                return;
              }

              // { or }: Voice Pitch Down or Up (0.05 step)
              if (e.key === '{' || e.key === '}') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const delta = e.key === '}' ? 0.05 : -0.05;
                const nextPitch = clampPitch(Math.round(((maximizedWindow.ttsPitch || 1.0) + delta) * 100) / 100);
                maximizedWindow.setTtsPitch(nextPitch);
                maximizedWindow.showTtsFeedback(`🎵 Pitch: ${nextPitch.toFixed(2)}x`);
                return;
              }

              // M or m: Mute / Unmute
              if (e.key === 'm' || e.key === 'M') {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                maximizedWindow.toggleTtsMute();
                return;
              }
            }
          }
        }
      },
      true
    );

    window.addEventListener(
      'keyup',
      (e) => {
        if (!e.isTrusted) return;
        const host = document.getElementById('yt-ai-summary-host');
        if (host && e.composedPath().includes(host)) {
          e.stopImmediatePropagation();
        }
      },
      true
    );

    window.addEventListener(
      'keypress',
      (e) => {
        if (!e.isTrusted) return;
        const host = document.getElementById('yt-ai-summary-host');
        if (host && e.composedPath().includes(host)) {
          e.stopImmediatePropagation();
        }
      },
      true
    );
  }

  // --- CROSS-TAB SYNC & DOM RESTORATION (§4) ---
  function syncFromStorage(videoId) {
    if (!videoId) return;
    const meta = GM_getValue('win:' + videoId, null);
    if (!meta) {
      if (activeWindows.has(videoId)) {
        const win = activeWindows.get(videoId);
        win.close(true);
      }
      return;
    }

    if (activeWindows.has(videoId)) {
      const win = activeWindows.get(videoId);
      win.status = meta.status;
      win.busy = meta.busy;
      win.owner = meta.owner;
      win.hb = meta.hb;
      win.jobId = meta.jobId;
      win.errMsg = meta.errMsg;
      win.errCode = meta.errCode;
      win.modelId = meta.modelId;
      win.keyId = meta.keyId;
      win.opts = meta.opts;
      win.notes = meta.notes || [];

      // Check if remote job done, reload cache
      if (meta.status === 'done') {
        const cached = readCache(videoId, win.mode, win.source, true);
        if (cached) win.loadFromCache(cached);
      }

      if (meta.status === 'done' && (maximizedWindow !== win || document.hidden)) {
        win.unread = true;
      } else {
        win.unread = Boolean(meta.unread);
      }

      win.renderAll();
    } else {
      const win = new SummaryWindow(videoId, meta.title, meta);
      const cached = readCache(videoId, win.mode, win.source, true);
      if (cached) win.loadFromCache(cached);
      win.renderDockTab();
    }
  }

  function resyncAllWindows() {
    const all = GM_listValues();
    const winKeys = all.filter((k) => k.startsWith('win:'));
    const ids = winKeys.map((k) => k.slice(4));

    for (const id of ids) {
      syncFromStorage(id);
    }
    for (const [id, win] of activeWindows) {
      if (!ids.includes(id)) {
        win.close(true);
      }
    }
  }

  function setupCrossTabSync() {
    GM_addValueChangeListener('sync_ping', (k, oldV, newV, remote) => {
      if (!newV || newV.tab === TAB_ID) return;
      if (newV.id === '*') {
        resyncAllWindows();
      } else {
        syncFromStorage(newV.id);
      }
    });

    GM_addValueChangeListener('keys', () => {
      if (maximizedWindow) maximizedWindow.renderAll();
    });

    GM_addValueChangeListener('history_tab_visibility', () => {
      updateDockHistoryTab();
    });

    GM_addValueChangeListener('response_ratings', () => {
      for (const win of getOpenWindows()) {
        win.renderBody();
      }
    });

    GM_addValueChangeListener('alt_titles_enabled', (_k, _oldV, newV) => {
      const enabled = Boolean(newV !== false);
      if (shadowRoot) {
        const altCheckboxes = shadowRoot.querySelectorAll('.yt-alt-titles-setting-checkbox');
        for (const cb of altCheckboxes) {
          cb.checked = enabled;
        }
      }
      if (typeof refreshAllFeedCardTitles === 'function') {
        refreshAllFeedCardTitles();
      }
    });

    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        resyncAllWindows();
      }
    });

    // 1-second timer to monitor heartbeats and stale jobs
    setInterval(() => {
      const now = Date.now();
      for (const [id, win] of activeWindows) {
        if (win.owner === TAB_ID && (win.status === 'loading' || win.busy)) {
          win.hb = now;
          win.commit(true); // quiet commit
        } else if (win.owner !== TAB_ID && (win.status === 'loading' || win.busy)) {
          if (now - (win.hb || 0) > CONFIG.staleMs) {
            win.status = 'error';
            win.busy = false;
            win.errCode = 'INTERRUPTED';
            win.errMsg = 'Operation was interrupted (tab closed or froze)';
            win.commit(false);
            win.renderAll();
          }
        }
      }
    }, 1000);

    // Pagehide handler
    window.addEventListener('pagehide', () => {
      for (const [id, win] of activeWindows) {
        if (win.owner === TAB_ID && (win.status === 'loading' || win.busy)) {
          win.status = 'error';
          win.errCode = 'INTERRUPTED';
          win.errMsg = 'Interrupted (tab closed)';
          win.commit(false);
        }
      }
    });
  }

  // --- TAMPERMONKEY MENU COMMANDS (§4) ---
  function registerMenuCommands() {
    GM_registerMenuCommand('Manage Gemini API keys', () => {
      openKeyManagerDialog();
    });
    GM_registerMenuCommand('Re-check available Gemini models', async () => {
      const keys = getStoredKeys();
      for (const k of keys) {
        await checkModelsForKey(k, true);
      }
      alert('Model check complete!');
      if (maximizedWindow) maximizedWindow.renderAll();
    });
    GM_registerMenuCommand('Clear cached summaries (keeps open windows)', () => {
      clearAllCache();
      alert('Cached summaries cleared.');
    });
    GM_registerMenuCommand('Close all summary windows', () => {
      for (const [id, win] of Array.from(activeWindows.entries())) {
        win.close();
      }
    });
    GM_registerMenuCommand('Browse previous summaries (History)', () => {
      openHistoryDialog();
    });
    GM_registerMenuCommand(
      `History dock tab visibility (currently: ${getHistoryTabVisibility()})`,
      () => {
        const order = ['always', 'with_tabs', 'never'];
        const next = order[(order.indexOf(getHistoryTabVisibility()) + 1) % order.length];
        setHistoryTabVisibility(next);
      }
    );
    GM_registerMenuCommand(
      `Toggle Alternative AI Titles for Thumbnails (currently ${getAltTitlesEnabled() ? 'ON' : 'OFF'})`,
      () => {
        setAltTitlesEnabled(!getAltTitlesEnabled());
        alert(`Alternative AI Titles for Thumbnails: ${getAltTitlesEnabled() ? 'ENABLED' : 'DISABLED'}`);
      }
    );
  }

  // --- INITIALIZATION ---
  ensureHostAndShadow();
  setupKeyboardListeners();
  setupCrossTabSync();
  registerMenuCommands();

  function onDomReady() {
    ensureHostAndShadow();
    initMenuIntegration();
    observeFeedCards();

    // Restore existing windows from storage
    const all = GM_listValues();
    const winKeys = all.filter((k) => k.startsWith('win:'));
    const metas = [];
    for (const k of winKeys) {
      const meta = GM_getValue(k, null);
      if (meta) metas.push(meta);
    }
    metas.sort((a, b) => (a.created || 0) - (b.created || 0));

    for (const meta of metas) {
      if (!activeWindows.has(meta.videoId)) {
        const win = new SummaryWindow(meta.videoId, meta.title, meta);
        const cached = readCache(meta.videoId, win.mode, win.source);
        if (cached) win.loadFromCache(cached);
        win.renderDockTab();
      }
    }

    // Run model availability check in background for stored keys
    const keys = getStoredKeys();
    for (const k of keys) {
      checkModelsForKey(k, false);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onDomReady);
  } else {
    onDomReady();
  }

  window.addEventListener('pagehide', () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  });

  // Expose test helper if window.__yt_summariser_test_hook is requested
  window.__yt_summariser_test = {
    openForVideo,
    activeWindows,
    getActiveWindows: () => activeWindows,
    getOpenWindows,
    getTopZIndex: () => topWindowZIndex,
    CONFIG,
    SummaryWindow,
    readCache,
    writeCache,
    cleanTextForSpeech,
    formatMathSymbolsInText,
    parseTranscriptCues,
    findActiveCueByCharIndex,
    findActiveCueByTime,
    openHistoryDialog,
    getAllCachedSummaries,
    deleteCachedVideo,
    updateDockHistoryTab,
    getHistoryTabVisibility,
    setHistoryTabVisibility,
    shouldShowHistoryTab,
    getResponseRating,
    setResponseRating,
    getResponseRatings,
    clampWindowBounds,
    computeDefaultWindowBounds,
    classifyWindowSizeTier,
    getAdaptiveWindowFlags,
    formatAsExportText,
    downloadAsTxt,
    exportAsPdf,
    formatAsExportJson,
    downloadAsJson,
    parseCleanEditorialBlocks,
    stripInlineMarkdown,
    getLastTtsRate,
    setLastTtsRate,
    clampPitch,
    createBoundedMap,
    computeWaveformAmplitudes,
    getLastTtsPitch,
    setLastTtsPitch,
    getLastReadabilityTheme,
    setLastReadabilityTheme,
    detectYouTubeTheme,
    getLastSyncYouTubeTheme,
    setLastSyncYouTubeTheme,
    getAltTitlesEnabled,
    setAltTitlesEnabled,
    isMusicVideo,
    generateAlternativeTitle,
    getDeArrowTitleContainer,
    isDeArrowPresent,
    syncDeArrowState,
    processFeedCard,
    toggleCardTitle,
    getCachedAltTitle,
    setCachedAltTitle,
    getDraftFollowUp,
    setDraftFollowUp,
    clearDraftFollowUp,
    refreshAllFeedCardTitles,
    revertCardToNonAiTitle,
    observeFeedCards,
    getMaximizedWindow: () => maximizedWindow
  };
})();
