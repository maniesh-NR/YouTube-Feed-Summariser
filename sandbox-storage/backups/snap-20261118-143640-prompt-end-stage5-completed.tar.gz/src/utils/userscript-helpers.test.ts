import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import {
  formatSecondsToTimestamp,
  parseTimestampToSeconds,
  getCacheKeyPrefix,
  resolveNextModelDown,
  resolveAskFallbackPlan,
  cleanTextForSpeech,
  parseTranscriptCues,
  findActiveCueByCharIndex,
  findActiveCueByTime,
  detectYouTubeTheme,
  resolveReaderTheme,
  BoundedMemoryCache,
  getDraftStorageKey,
  getGranularTtsRates,
  getSpeedIndicatorType,
  clampPitch,
  formatSummaryExportJson,
  computeWaveformAmplitudes,
  normalizeHistoryTabVisibility,
  shouldShowHistoryTab,
  normalizeResponseRating,
  buildResponseRatingKey,
  applyResponseRating,
  formatMathSymbolsInText,
  clampWindowBounds,
  computeDefaultWindowBounds,
  classifyWindowSizeTier,
  getAdaptiveWindowFlags,
  normalizeAltTitlesEnabled,
  resolveFeedCardTitleMode,
  sanitizeGeneratedAltTitle,
  shouldCacheGeneratedAltTitle,
  normalizeCompactOptionsMap,
  extractVideoIdFromHref,
  pruneTimestampIndex,
  computeDecorrelatedJitterDelay,
  isRelevantMutationSignal,
  applyKeyboardWindowAdjustment,
  findTranscriptCueIndexForSeconds,
  normalizeChannelRuleKey,
  normalizeChannelTitleRules,
  setChannelTitleRuleInMap,
  resolveAutoTitleDecision,
  normalizeSummaryPersona,
  resolveSummaryPersonaInstruction,
  resolveSummaryPersonaPromptSuffix,
  parseVideoChaptersFromDescription,
  extractSummaryChapters,
  buildLongVideoTranscriptChunks,
  buildChunkMapPrompt,
  buildChunkReducePrompt,
  formatSummaryExportMarkdown
} from './userscript-helpers';

test('formatSecondsToTimestamp formats correctly below and above 1 hour', () => {
  assert.equal(formatSecondsToTimestamp(5), '00:05');
  assert.equal(formatSecondsToTimestamp(75), '01:15');
  assert.equal(formatSecondsToTimestamp(3665), '1:01:05');
});

test('parseTimestampToSeconds parses standard and hour-long timestamps', () => {
  assert.equal(parseTimestampToSeconds('00:05'), 5);
  assert.equal(parseTimestampToSeconds('01:15'), 75);
  assert.equal(parseTimestampToSeconds('1:01:05'), 3665);
});

test('getCacheKeyPrefix selects the four designated cache slots', () => {
  assert.equal(getCacheKeyPrefix('summary', 'video'), 'sum:');
  assert.equal(getCacheKeyPrefix('transcript', 'video'), 'trn:');
  assert.equal(getCacheKeyPrefix('summary', 'text'), 'sut:');
  assert.equal(getCacheKeyPrefix('transcript', 'text'), 'trt:');
});

test('resolveNextModelDown traverses fallback ladder and respects key availability', () => {
  const ladder = [
    'gemini-3.1-pro-preview',
    'gemini-3.8-flash',
    'gemini-3.7-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash',
    'gemini-2.0-flash'
  ];
  const available = ['gemini-3.1-pro-preview', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.0-flash'];

  const next = resolveNextModelDown('gemini-3.8-flash', ladder, available);
  assert.equal(next, 'gemini-3.6-flash', 'Skips 3.7-flash because key lacks it and picks 3.6-flash');

  // When Ask fails, starts from index 0 of the fallback ladder
  assert.equal(
    resolveNextModelDown('YouTube Ask (Gemini in the page)', ladder, available),
    'gemini-3.1-pro-preview',
    'Selects top eligible ladder model (gemini-3.1-pro-preview) when Ask fails with full key'
  );
  assert.equal(
    resolveNextModelDown('YouTube Ask (Gemini in the page)', ladder, ['gemini-3.8-flash', 'gemini-3.6-flash']),
    'gemini-3.8-flash',
    'Selects first available non-pro ladder model when free key lacks pro'
  );
  assert.equal(
    resolveNextModelDown('Ask', ladder, []),
    'gemini-3.1-pro-preview',
    'Selects first model on ladder when availableModels list is empty'
  );
});

test('resolveAskFallbackPlan handles cancelled jobs, missing keys, and eligible ladder fallback', () => {
  const ladder = [
    'gemini-3.1-pro-preview',
    'gemini-3.8-flash',
    'gemini-3.7-flash',
    'gemini-3.6-flash'
  ];

  const cancelledPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.8-flash'],
    hasApiKey: true,
    cancelled: true,
    errorMessage: 'Ask job was cancelled'
  });
  assert.equal(cancelledPlan.shouldFallback, false);
  assert.equal(cancelledPlan.reason, 'cancelled');

  const noKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: [],
    hasApiKey: false,
    errorMessage: "YouTube's Ask button didn't appear"
  });
  assert.equal(noKeyPlan.shouldFallback, false);
  assert.equal(noKeyPlan.reason, 'no_key');

  const paidKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.1-pro-preview', 'gemini-3.8-flash'],
    hasApiKey: true,
    errorMessage: "YouTube's Ask button didn't appear\nExtra details"
  });
  assert.equal(paidKeyPlan.shouldFallback, true);
  assert.equal(paidKeyPlan.reason, 'ladder_fallback');
  assert.equal(paidKeyPlan.nextModel, 'gemini-3.1-pro-preview');
  assert.ok(paidKeyPlan.note?.includes('Automatically proceeding with gemini-3.1-pro-preview'));

  const freeKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.8-flash', 'gemini-3.6-flash'],
    hasApiKey: true,
    errorMessage: 'Ask answer generation timed out'
  });
  assert.equal(freeKeyPlan.shouldFallback, true);
  assert.equal(freeKeyPlan.nextModel, 'gemini-3.8-flash');

  const exhaustedPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['unrelated-model-only'],
    hasApiKey: true,
    errorMessage: 'Ask failed'
  });
  assert.equal(exhaustedPlan.shouldFallback, false);
  assert.equal(exhaustedPlan.reason, 'no_eligible_model');
});

test('cleanTextForSpeech strips visual markers and prepares natural spoken text', () => {
  const rawMarkdown = `## TL;DR
**Sodium batteries** achieve *great* results!
### [01:15] Cell Chemistry
[[FRAME 01:15 | diagram of cathode]]
Researchers found 90% retention at [1:05:30].
<script>alert("test")</script>
- Point 1: Read [Research Paper](https://example.com/paper).`;

  const spoken = cleanTextForSpeech(rawMarkdown);
  assert.ok(!spoken.includes('FRAME'), 'Visual markers stripped');
  assert.ok(!spoken.includes('script'), 'Script tags stripped');
  assert.ok(!spoken.includes('##'), 'Markdown heading hashes stripped');
  assert.ok(!spoken.includes('**'), 'Markdown bold asterisks stripped');
  assert.ok(!spoken.includes('https://'), 'URLs stripped');
  assert.ok(spoken.includes('at 1 minute 15 seconds'), 'Timestamp converted to spoken words');
  assert.ok(spoken.includes('at 1 hour 5 minutes 30 seconds'), 'Hour timestamp converted to spoken words');
});

test('parseTranscriptCues extracts cues, offsets, and spoken text correctly', () => {
  const sampleTranscript = `## Transcript (YouTube captions)

[00:00] First segment introduction.
[01:15] Second segment discussing architecture.
[05:30] Third segment covering benchmarks.`;

  const { cues, fullSpokenText } = parseTranscriptCues(sampleTranscript);
  assert.equal(cues.length, 3, 'Found 3 timestamped cues');
  assert.equal(cues[0].tsStr, '[00:00]');
  assert.equal(cues[0].startSec, 0);
  assert.equal(cues[1].tsStr, '[01:15]');
  assert.equal(cues[1].startSec, 75);
  assert.equal(cues[2].tsStr, '[05:30]');
  assert.equal(cues[2].startSec, 330);

  assert.ok(fullSpokenText.includes('First segment introduction'), 'Includes first segment text');
  assert.ok(fullSpokenText.includes('Second segment discussing architecture'), 'Includes second segment text');

  // Test character lookup
  const midFirst = cues[0].charStart + 5;
  const active1 = findActiveCueByCharIndex(cues, midFirst);
  assert.equal(active1?.tsStr, '[00:00]', 'Char index in cue 0 returns cue 0');

  const midSecond = cues[1].charStart + 10;
  const active2 = findActiveCueByCharIndex(cues, midSecond);
  assert.equal(active2?.tsStr, '[01:15]', 'Char index in cue 1 returns cue 1');

  // Test time lookup
  const timeActiveEarly = findActiveCueByTime(cues, 1, 100);
  assert.equal(timeActiveEarly?.tsStr, '[00:00]', 'Early progress maps to cue 0');

  const timeActiveMid = findActiveCueByTime(cues, 50, 100);
  assert.ok(timeActiveMid?.tsStr === '[01:15]' || timeActiveMid?.tsStr === '[05:30]', 'Mid progress maps to cue 1 or 2');
});

test('detectYouTubeTheme detects dark and light mode from DOM hierarchy', () => {
  // Test 1: html[dark] attribute present
  const mockDocDarkHtml = {
    documentElement: {
      hasAttribute: (attr: string) => attr === 'dark',
      getAttribute: (attr: string) => (attr === 'dark' ? '' : null),
      classList: { contains: () => false }
    },
    querySelector: () => null
  };
  assert.equal(detectYouTubeTheme(mockDocDarkHtml), 'dark', 'HTML element with dark attribute detected as dark');

  // Test 2: ytd-app[dark] present
  const mockDocDarkYtd = {
    documentElement: {
      hasAttribute: () => false,
      getAttribute: () => null,
      classList: { contains: () => false }
    },
    querySelector: (sel: string) => (sel === 'ytd-app[dark]' ? {} : null)
  };
  assert.equal(detectYouTubeTheme(mockDocDarkYtd), 'dark', 'ytd-app with dark attribute detected as dark');

  // Test 3: Standard light mode (no dark attributes)
  const mockDocLight = {
    documentElement: {
      hasAttribute: () => false,
      getAttribute: () => null,
      classList: { contains: () => false }
    },
    querySelector: () => null,
    body: { hasAttribute: () => false }
  };
  assert.equal(detectYouTubeTheme(mockDocLight), 'light', 'Document without dark attributes detected as light');
});

test('resolveReaderTheme respects sync toggle and manual fallback', () => {
  // When sync is ON, always matches detected YouTube theme
  assert.equal(resolveReaderTheme('sepia', true, 'dark'), 'dark', 'Sync ON overrides manual sepia with dark');
  assert.equal(resolveReaderTheme('sepia', true, 'light'), 'light', 'Sync ON overrides manual sepia with light');
  assert.equal(resolveReaderTheme('system', true, 'dark'), 'dark', 'Sync ON matches dark');

  // When sync is OFF, retains user manual choice
  assert.equal(resolveReaderTheme('sepia', false, 'dark'), 'sepia', 'Sync OFF retains sepia');
  assert.equal(resolveReaderTheme('light', false, 'dark'), 'light', 'Sync OFF retains light even if YouTube is dark');
  assert.equal(resolveReaderTheme('dark', false, 'light'), 'dark', 'Sync OFF retains dark even if YouTube is light');
});

test('BoundedMemoryCache respects capacity limit and evicts least-recently-used items', () => {
  const cache = new BoundedMemoryCache<string, string>(3);
  cache.set('a', 'alpha');
  cache.set('b', 'beta');
  cache.set('c', 'gamma');
  assert.equal(cache.size, 3);

  // Access 'a' to make it recently used: order is now b, c, a
  assert.equal(cache.get('a'), 'alpha');

  // Insert 'd': capacity 3 exceeded, 'b' is evicted
  cache.set('d', 'delta');
  assert.equal(cache.size, 3);
  assert.equal(cache.has('b'), false, 'Key "b" was evicted as LRU');
  assert.equal(cache.has('a'), true, 'Key "a" retained because it was accessed');
  assert.equal(cache.has('c'), true, 'Key "c" retained');
  assert.equal(cache.has('d'), true, 'Key "d" added');

  // Verify iteration and keys
  const keys = Array.from(cache.keys());
  assert.deepEqual(keys, ['c', 'a', 'd'], 'Keys preserve LRU-to-MRU iteration order');
  const values = Array.from(cache.values());
  assert.deepEqual(values, ['gamma', 'alpha', 'delta'], 'Values preserve iteration order');

  const iterated: string[] = [];
  cache.forEach((v, k) => {
    iterated.push(`${k}:${v}`);
  });
  assert.deepEqual(iterated, ['c:gamma', 'a:alpha', 'd:delta']);
});

test('getDraftStorageKey returns consistent namespaced draft key', () => {
  assert.equal(getDraftStorageKey('vid_123'), 'draft:vid_123');
  assert.equal(getDraftStorageKey('abc'), 'draft:abc');
});

test('getGranularTtsRates provides strictly 0.25x steps', () => {
  const rates = getGranularTtsRates();
  assert.deepEqual(rates, [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]);
  for (let i = 1; i < rates.length; i++) {
    const diff = Math.round((rates[i] - rates[i - 1]) * 100) / 100;
    assert.equal(diff, 0.25, `Step between ${rates[i - 1]} and ${rates[i]} is exactly 0.25x`);
  }
});

test('getSpeedIndicatorType classifies speed presets accurately', () => {
  assert.equal(getSpeedIndicatorType(1.0), 'speed-normal');
  assert.equal(getSpeedIndicatorType(1.25), 'speed-boost');
  assert.equal(getSpeedIndicatorType(2.0), 'speed-boost');
  assert.equal(getSpeedIndicatorType(0.75), 'speed-slow');
  assert.equal(getSpeedIndicatorType(0.5), 'speed-slow');
});

test('clampPitch validates and bounds voice pitch within 0.5x to 2.0x', () => {
  assert.equal(clampPitch(1.0), 1.0, 'Baseline pitch is 1.0');
  assert.equal(clampPitch(0.5), 0.5, 'Minimum pitch boundary is 0.5');
  assert.equal(clampPitch(2.0), 2.0, 'Maximum pitch boundary is 2.0');
  assert.equal(clampPitch(0.2), 0.5, 'Sub-minimum pitch clamps to 0.5');
  assert.equal(clampPitch(3.5), 2.0, 'Super-maximum pitch clamps to 2.0');
  assert.equal(clampPitch(NaN), 1.0, 'NaN defaults safely to 1.0');
  assert.equal(clampPitch(Infinity), 1.0, 'Infinity defaults safely to 1.0');
  assert.equal(clampPitch(-Infinity), 1.0, '-Infinity defaults safely to 1.0');
  assert.equal(clampPitch(null), 1.0, 'Null defaults safely to 1.0');
  assert.equal(clampPitch(undefined), 1.0, 'Undefined defaults safely to 1.0');
  assert.equal(clampPitch('1.75'), 1.75, 'String representations parse and clamp accurately');
});

test('formatSummaryExportJson generates valid JSON with video title, channel, and processing mode', () => {
  const jsonStr = formatSummaryExportJson({
    videoId: 'abc123xyz',
    videoTitle: 'Quantum Computing Deep Dive',
    channel: 'Tech Architecture Network',
    mode: 'transcript',
    processingMode: 'deep',
    model: 'gemini-3.8-flash',
    text: '## Detailed Summary\nChronological overview of quantum gate latency.',
    factCheck: 'All quantum telemetry claims verified against peer reviews.',
    citations: [{ uri: 'https://arxiv.org/abs/2301.00000', title: 'Quantum Telemetry Preprint' }],
    followUpQuestions: [
      {
        question: 'What is the coherence time?',
        answer: 'Measured coherence time exceeds 120 microseconds [04:12].',
        sources: [{ uri: 'https://arxiv.org/abs/2301.00000', title: 'Paper Citation' }]
      }
    ],
    ttsRate: 1.25,
    ttsVolume: 0.85,
    ttsPitch: 1.15,
    ttsVoice: 'ai:Zephyr'
  });

  const parsed = JSON.parse(jsonStr);
  assert.equal(parsed.generator, 'YouTube Feed Summariser (Gemini)');
  assert.equal(parsed.metadata.videoId, 'abc123xyz');
  assert.equal(parsed.metadata.videoTitle, 'Quantum Computing Deep Dive');
  assert.equal(parsed.metadata.channel, 'Tech Architecture Network');
  assert.equal(parsed.metadata.processingMode, 'deep');
  assert.equal(parsed.metadata.mode, 'transcript');
  assert.equal(parsed.metadata.model, 'gemini-3.8-flash');
  assert.equal(parsed.metadata.ttsSettings.pitch, 1.15);
  assert.equal(parsed.metadata.ttsSettings.rate, 1.25);
  assert.equal(parsed.metadata.ttsSettings.volume, 0.85);
  assert.equal(parsed.metadata.ttsSettings.voice, 'ai:Zephyr');
  assert.equal(parsed.content.factCheck, 'All quantum telemetry claims verified against peer reviews.');
  assert.equal(parsed.content.citations.length, 1);
  assert.equal(parsed.content.followUpQuestions.length, 1);
  assert.equal(parsed.content.followUpQuestions[0].question, 'What is the coherence time?');
});

test('computeWaveformAmplitudes generates dynamic voice frequency bands and responds to playback state', () => {
  // Test 1: Idle or stopped speech returns resting flatline
  const idleAmps = computeWaveformAmplitudes({ isPlaying: false, barCount: 8 });
  assert.equal(idleAmps.length, 8, 'Returns requested bar count');
  assert.ok(idleAmps.every((a) => a === 0.08), 'All bars return resting baseline (0.08) when idle');

  // Test 2: Muted speech (volume = 0) returns resting flatline even if isPlaying is true
  const mutedAmps = computeWaveformAmplitudes({ isPlaying: true, volume: 0, barCount: 8 });
  assert.ok(mutedAmps.every((a) => a === 0.08), 'All bars return flatline when volume is zero');

  // Test 3: Active playback produces modulated positive amplitudes
  const activeAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 1.0,
    rate: 1.0,
    timestamp: 1000,
    barCount: 12
  });
  assert.equal(activeAmps.length, 12);
  assert.ok(activeAmps.some((a) => a > 0.15), 'Active speech produces elevated amplitudes above baseline');
  assert.ok(activeAmps.every((a) => a >= 0.08 && a <= 1.0), 'All amplitudes remain strictly clamped in [0.08, 1.0]');

  // Test 4: Pitch shift elevates relative high-frequency formant energy
  const lowPitchAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 0.5,
    rate: 1.0,
    timestamp: 2500,
    barCount: 10
  });
  const highPitchAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 2.0,
    rate: 1.0,
    timestamp: 2500,
    barCount: 10
  });
  // Upper frequencies (last 3 bars) have higher relative formant resonance with high pitch
  const lowTrebleEnergy = lowPitchAmps.slice(-3).reduce((acc, v) => acc + v, 0);
  const highTrebleEnergy = highPitchAmps.slice(-3).reduce((acc, v) => acc + v, 0);
  assert.ok(highTrebleEnergy > lowTrebleEnergy, 'High pitch shifts formant resonance towards upper frequency bands');

  // Test 5: Syllable pulse increases immediate speech attack
  const normalAmp = computeWaveformAmplitudes({ isPlaying: true, timestamp: 3000, boundaryPulse: 0, barCount: 6 });
  const pulsedAmp = computeWaveformAmplitudes({ isPlaying: true, timestamp: 3000, boundaryPulse: 0.8, barCount: 6 });
  const normalSum = normalAmp.reduce((a, b) => a + b, 0);
  const pulsedSum = pulsedAmp.reduce((a, b) => a + b, 0);
  assert.ok(pulsedSum > normalSum, 'Syllable boundary pulse increases speech amplitude attack');
});

test('normalizeHistoryTabVisibility and shouldShowHistoryTab enforce visibility modes', () => {
  assert.equal(normalizeHistoryTabVisibility('always'), 'always');
  assert.equal(normalizeHistoryTabVisibility('with_tabs'), 'with_tabs');
  assert.equal(normalizeHistoryTabVisibility('never'), 'never');
  assert.equal(normalizeHistoryTabVisibility('invalid'), 'always');

  // Always mode: shown when cached summaries exist regardless of active tab count
  assert.equal(shouldShowHistoryTab({ visibility: 'always', cachedCount: 3, activeTabCount: 0 }), true);
  assert.equal(shouldShowHistoryTab({ visibility: 'always', cachedCount: 0, activeTabCount: 2 }), false);

  // With_tabs mode: shown ONLY when other tabs are open or minimized
  assert.equal(shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 0 }), false);
  assert.equal(shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 1 }), true);

  // Never mode: never shown even with cached summaries and open tabs
  assert.equal(shouldShowHistoryTab({ visibility: 'never', cachedCount: 5, activeTabCount: 3 }), false);
});

test('response rating helpers toggle, switch, and preserve notes cleanly', () => {
  assert.equal(normalizeResponseRating('up'), 'up');
  assert.equal(normalizeResponseRating('down'), 'down');
  assert.equal(normalizeResponseRating('other'), null);
  assert.equal(buildResponseRatingKey('vid_1', 'summary'), 'vid_1:summary:main');
  assert.equal(buildResponseRatingKey('vid_1', 'followup', 'turn_2'), 'vid_1:followup:turn_2');

  let map: Record<string, any> = {};
  const upRes = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'up', timestamp: 100 });
  assert.equal(upRes.record?.rating, 'up');
  map = upRes.nextMap;
  assert.equal(Object.keys(map).length, 1);

  // Switching from up to down replaces rating
  const downRes = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'down', note: 'Inaccurate', timestamp: 200 });
  assert.equal(downRes.record?.rating, 'down');
  assert.equal(downRes.record?.note, 'Inaccurate');
  map = downRes.nextMap;

  // Clicking the same rating again without note toggles it off
  const toggleOff = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'down' });
  assert.equal(toggleOff.record, null);
  assert.equal(Object.keys(toggleOff.nextMap).length, 0);
});

test('formatMathSymbolsInText converts LaTeX scientific symbols without breaking currency', () => {
  const boilingSample =
    'At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of $100^\\circ\\text{C}$ to approximately $87^\\circ\\text{C}$.';
  const formatted = formatMathSymbolsInText(boilingSample);
  assert.equal(
    formatted,
    'At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of 100°C to approximately 87°C.'
  );

  // Superscripts, subscripts, Greek letters, operators
  assert.equal(formatMathSymbolsInText('$E = mc^2$ and $\\text{H}_2\\text{O}$ at $\\approx 25^\\circ\\text{C}$'), 'E = mc² and H₂O at ≈ 25°C');
  assert.equal(formatMathSymbolsInText('$\\alpha \\le \\beta \\pm 0.5$ and $\\frac{a}{b}$'), 'α ≤ β ± 0.5 and a/b');

  // Currency preservation
  assert.equal(
    formatMathSymbolsInText('Sodium cells cost $0.30/kg vs $18/kg, saving between $100 and $200 per pack.'),
    'Sodium cells cost $0.30/kg vs $18/kg, saving between $100 and $200 per pack.'
  );

  // Parenthesized inline LaTeX \(...\)
  assert.equal(formatMathSymbolsInText('Cooling curve \\( f(T) = (100^\\circ\\text{C}) - 13^\\circ\\text{C} \\)'), 'Cooling curve f(T) = (100°C) - 13°C');

  // cleanTextForSpeech also converts LaTeX symbols
  const spoken = cleanTextForSpeech('Standard boiling point is $100^\\circ\\text{C}$ to $87^\\circ\\text{C}$.');
  assert.ok(spoken.includes('100°C') && spoken.includes('87°C') && !spoken.includes('\\circ'));
});

test('window bounds clamping, cascading defaults, and adaptive size tiers behave consistently', () => {
  const clamped = clampWindowBounds({ left: -50, top: 2000, width: 120, height: 1500 }, { width: 1280, height: 800 });
  assert.equal(clamped.width, 340, 'Enforces minWidth 340');
  assert.equal(clamped.height, 736, 'Clamps height to viewport - 64');
  assert.equal(clamped.left, 12, 'Clamps negative left inside viewport margin');
  assert.ok(clamped.top <= 800 - clamped.height - 52, 'Keeps window above bottom dock');

  const win0 = computeDefaultWindowBounds({ width: 1440, height: 900 }, 0);
  const win1 = computeDefaultWindowBounds({ width: 1440, height: 900 }, 1);
  assert.notEqual(win0.left, win1.left, 'Cascades consecutive windows horizontally');
  assert.notEqual(win0.top, win1.top, 'Cascades consecutive windows vertically');

  assert.equal(classifyWindowSizeTier(420), 'compact');
  assert.equal(classifyWindowSizeTier(539), 'compact');
  assert.equal(classifyWindowSizeTier(540), 'medium');
  assert.equal(classifyWindowSizeTier(779), 'medium');
  assert.equal(classifyWindowSizeTier(780), 'wide');

  const compactFlags = getAdaptiveWindowFlags(460, 420);
  assert.equal(compactFlags.tier, 'compact');
  assert.equal(compactFlags.useOverflowHeaderMenu, true);
  assert.equal(compactFlags.collapseOptionsRow, true);
  assert.equal(compactFlags.isShort, true);
  assert.equal(compactFlags.singleColumnAdvPanel, true);

  const wideFlags = getAdaptiveWindowFlags(900, 720);
  assert.equal(wideFlags.tier, 'wide');
  assert.equal(wideFlags.useOverflowHeaderMenu, false);
  assert.equal(wideFlags.collapseOptionsRow, false);
  assert.equal(wideFlags.compactTtsBar, false);
  assert.equal(wideFlags.isShort, false);
});

test('auto-title replacement defaults to enabled, respects settings off, and yields to DeArrow', () => {
  assert.equal(normalizeAltTitlesEnabled(undefined), true);
  assert.equal(normalizeAltTitlesEnabled(null), true);
  assert.equal(normalizeAltTitlesEnabled(true), true);
  assert.equal(normalizeAltTitlesEnabled(false), false);
  assert.equal(normalizeAltTitlesEnabled('false'), false);

  // Enabled by default on normal non-DeArrow cards
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: false, altTitlesEnabled: true }),
    'ai'
  );
  // Disabled in settings keeps original title on non-DeArrow cards
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: false, altTitlesEnabled: false }),
    'original'
  );
  // DeArrow always takes precedence when present on a card
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: true, altTitlesEnabled: true }),
    'dearrow'
  );
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: true, altTitlesEnabled: false }),
    'dearrow'
  );
  // Music videos remain exempt regardless of setting
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: true, hasDeArrowTitle: true, altTitlesEnabled: true }),
    'music'
  );

  // Title sanitization strips quotes/markdown and caps at 150 chars
  assert.equal(sanitizeGeneratedAltTitle('**"Clean Title Here"**'), 'Clean Title Here');
  const overlong = 'A'.repeat(180);
  const capped = sanitizeGeneratedAltTitle(overlong);
  assert.equal(capped.length, 150);
  assert.ok(capped.endsWith('...'));
});

test('shouldCacheGeneratedAltTitle blocks clickbait self-caching on empty/fallback titles', () => {
  assert.equal(
    shouldCacheGeneratedAltTitle('THIS CHANGES EVERYTHING!', 'THIS CHANGES EVERYTHING!', false),
    false
  );
  assert.equal(
    shouldCacheGeneratedAltTitle('THIS CHANGES EVERYTHING!', 'this changes everything!', true),
    false
  );
  assert.equal(shouldCacheGeneratedAltTitle('Too', 'Original Title', true), false);
  assert.equal(
    shouldCacheGeneratedAltTitle(
      'Benchmark comparison of 3nm ARM cores vs x86 efficiency',
      'THIS CHANGES EVERYTHING!',
      true
    ),
    true
  );
});

test('normalizeCompactOptionsMap validates stored compact options disclosure preferences', () => {
  assert.deepEqual(normalizeCompactOptionsMap(null), {});
  assert.deepEqual(normalizeCompactOptionsMap(['bad']), {});
  assert.deepEqual(
    normalizeCompactOptionsMap({ vid1: true, vid2: false, vid3: 'yes', '': true }),
    { vid1: true, vid2: false }
  );
  const polluted = JSON.parse('{"__proto__":true,"constructor":true,"vid1":true}');
  assert.deepEqual(normalizeCompactOptionsMap(polluted), { vid1: true });
});

test('extractVideoIdFromHref parses /watch?v=, /shorts/, and /live/ video IDs cleanly', () => {
  assert.equal(extractVideoIdFromHref('/watch?v=dQw4w9WgXcQ&t=15s'), 'dQw4w9WgXcQ');
  assert.equal(extractVideoIdFromHref('https://www.youtube.com/shorts/S_shortVid_01?feature=share'), 'S_shortVid_01');
  assert.equal(extractVideoIdFromHref('/live/LiveStream_9988'), 'LiveStream_9988');
  assert.equal(extractVideoIdFromHref('/channel/UC12345'), null);
});

test('pruneTimestampIndex evicts oldest unprotected entries cleanly while preserving protected IDs', () => {
  const input = { a: 10, b: 20, c: 30, d: 40, e: 50 };
  const protectedIds = new Set(['a', 'b']);
  const { kept, evicted } = pruneTimestampIndex(input, 3, protectedIds);
  assert.deepEqual(evicted, ['c', 'd']);
  assert.deepEqual(Object.keys(kept).sort(), ['a', 'b', 'e']);
});

test('computeDecorrelatedJitterDelay honors bounds and Retry-After cooldowns', () => {
  assert.equal(computeDecorrelatedJitterDelay(2000, 2000, 60000, 0, 0), 2000);
  assert.equal(computeDecorrelatedJitterDelay(4000, 2000, 60000, 0, 1), 12000);
  assert.equal(computeDecorrelatedJitterDelay(4000, 2000, 60000, 25000, 0), 25000);
  assert.equal(computeDecorrelatedJitterDelay(40000, 2000, 60000, 90000, 1), 60000);
});

test('isRelevantMutationSignal filters player/live-chat noise while passing card & DeArrow updates', () => {
  assert.equal(
    isRelevantMutationSignal({ type: 'characterData', inNoiseSubtree: true, inTitleOrDeArrowSubtree: false }),
    false
  );
  assert.equal(
    isRelevantMutationSignal({ type: 'childList', inNoiseSubtree: true, inTitleOrDeArrowSubtree: false, hasFeedOrDeArrowNodes: false }),
    false
  );
  assert.equal(
    isRelevantMutationSignal({ type: 'characterData', inNoiseSubtree: false, inTitleOrDeArrowSubtree: true }),
    true
  );
  assert.equal(
    isRelevantMutationSignal({ type: 'attributes', inNoiseSubtree: false, inTitleOrDeArrowSubtree: false, attributeName: 'data-dearrow-title' }),
    true
  );
});

test('userscript contains zero Trusted-Types-unsafe innerHTML/outerHTML/insertAdjacentHTML sinks', () => {
  const userscriptPath = path.resolve(process.cwd(), 'youtube-feed-summariser.user.js');
  const source = fs.readFileSync(userscriptPath, 'utf8');
  const unsafeMatch = source.match(/\.(?:innerHTML|outerHTML)\s*=|insertAdjacentHTML\s*\(|document\.write\s*\(/g);
  assert.equal(unsafeMatch, null, `Found unsafe DOM sink(s): ${unsafeMatch?.join(', ')}`);
});

test('applyKeyboardWindowAdjustment handles move, north/corner resize, shift boost, and mobile <400px clamping', () => {
  const desktop = { width: 1440, height: 900 };
  const initial = { left: 200, top: 150, width: 640, height: 500 };

  // Move right & Shift+Down
  const movedRight = applyKeyboardWindowAdjustment(initial, 'move', null, 'ArrowRight', false, desktop);
  assert.equal(movedRight.handled, true);
  assert.equal(movedRight.bounds.left, 216);
  assert.equal(movedRight.bounds.top, 150);

  const movedFastDown = applyKeyboardWindowAdjustment(initial, 'move', null, 'ArrowDown', true, desktop);
  assert.equal(movedFastDown.bounds.top, 198);

  // North resize upward grows height and moves top up, keeping bottom edge fixed
  const resizedNorth = applyKeyboardWindowAdjustment(initial, 'resize', 'n', 'ArrowUp', true, desktop);
  assert.equal(resizedNorth.bounds.top, 102);
  assert.equal(resizedNorth.bounds.height, 548);
  assert.equal(resizedNorth.bounds.top + resizedNorth.bounds.height, initial.top + initial.height);

  // North-West corner resize upward & left
  const nwUp = applyKeyboardWindowAdjustment(initial, 'resize', 'nw', 'ArrowUp', false, desktop);
  assert.equal(nwUp.bounds.top, 134);
  assert.equal(nwUp.bounds.height, 516);
  const nwLeft = applyKeyboardWindowAdjustment(nwUp.bounds, 'resize', 'nw', 'ArrowLeft', true, desktop);
  assert.equal(nwLeft.bounds.left, 152);
  assert.equal(nwLeft.bounds.width, 688);

  // North-East corner resize right
  const neRight = applyKeyboardWindowAdjustment(initial, 'resize', 'ne', 'ArrowRight', false, desktop);
  assert.equal(neRight.bounds.left, 200);
  assert.equal(neRight.bounds.width, 656);

  // Non-arrow key returns handled=false
  const ignored = applyKeyboardWindowAdjustment(initial, 'resize', 'se', 'Enter', false, desktop);
  assert.equal(ignored.handled, false);
  assert.deepEqual(ignored.bounds, initial);

  // Mobile narrow viewports (<400px) clamp width inside viewport with marginX = 8
  const mobile375 = clampWindowBounds({ left: -20, top: 10, width: 520, height: 600 }, { width: 375, height: 812 });
  assert.ok(mobile375.left >= 8 && mobile375.left + mobile375.width <= 375 - 8, '375px viewport fits without horizontal overflow');

  const ultraNarrow320 = clampWindowBounds({ left: 0, top: 0, width: 420, height: 500 }, { width: 320, height: 568 });
  assert.equal(ultraNarrow320.left, 8);
  assert.equal(ultraNarrow320.width, 304, '320px viewport adapts effective minWidth cleanly without overflowing 320px');
});

test('AUD-07: userscript contains zero blocking alert() dialogs', () => {
  const userscriptPath = path.resolve(process.cwd(), 'youtube-feed-summariser.user.js');
  const source = fs.readFileSync(userscriptPath, 'utf8');
  const blockingAlerts = source.match(/\b(?:window\.)?alert\s*\(/g);
  assert.equal(blockingAlerts, null, `Found blocking alert() call(s): ${blockingAlerts?.join(', ')}`);
});

test('FEAT-01: findTranscriptCueIndexForSeconds maps seek seconds to nearest preceding cue', () => {
  const cues = [
    { startSec: 0 },
    { startSec: 75 },
    { startSec: 260 },
    { startSec: 585 }
  ];
  assert.equal(findTranscriptCueIndexForSeconds([], 120), -1);
  assert.equal(findTranscriptCueIndexForSeconds(cues, 0), 0);
  assert.equal(findTranscriptCueIndexForSeconds(cues, 70), 0);
  assert.equal(findTranscriptCueIndexForSeconds(cues, 75), 1);
  assert.equal(findTranscriptCueIndexForSeconds(cues, 300), 2);
  assert.equal(findTranscriptCueIndexForSeconds(cues, 999), 3);
});

test('FEAT-02: per-channel auto-title rule normalization, updates, and priority precedence', () => {
  assert.equal(normalizeChannelRuleKey('  Tech   Frontier '), 'tech frontier');
  assert.equal(normalizeChannelRuleKey('__proto__'), '');
  assert.deepEqual(
    normalizeChannelTitleRules({ ' Tech Frontier ': 'exempt', 'Veritasium': 'force_ai', bad: 'other', constructor: 'exempt' }),
    { 'tech frontier': 'exempt', veritasium: 'force_ai' }
  );

  let rules = setChannelTitleRuleInMap({}, 'Tech Frontier', 'exempt');
  assert.deepEqual(rules, { 'tech frontier': 'exempt' });
  rules = setChannelTitleRuleInMap(rules, 'Astro Science', 'force_ai');
  assert.deepEqual(rules, { 'tech frontier': 'exempt', 'astro science': 'force_ai' });
  rules = setChannelTitleRuleInMap(rules, 'Tech Frontier', 'default');
  assert.deepEqual(rules, { 'astro science': 'force_ai' });

  // Exempt channel skips AI title and prefers DeArrow or original
  const exemptRes = resolveAutoTitleDecision({
    altTitlesEnabled: true,
    isMusic: false,
    hasDeArrowTitle: false,
    channelName: 'Tech Frontier',
    channelRules: { 'tech frontier': 'exempt' }
  });
  assert.equal(exemptRes.mode, 'original');
  assert.equal(exemptRes.shouldAutoFetchAi, false);

  // force_ai overrides DeArrow when global auto-titles enabled
  const forceAiRes = resolveAutoTitleDecision({
    altTitlesEnabled: true,
    isMusic: false,
    hasDeArrowTitle: true,
    channelName: 'Astro Science',
    channelRules: { 'astro science': 'force_ai' }
  });
  assert.equal(forceAiRes.mode, 'ai');
  assert.equal(forceAiRes.shouldAutoFetchAi, true);

  // Global kill switch altTitlesEnabled=false always disables AI auto-titles even for force_ai
  const disabledGlobal = resolveAutoTitleDecision({
    altTitlesEnabled: false,
    isMusic: false,
    hasDeArrowTitle: true,
    channelName: 'Astro Science',
    channelRules: { 'astro science': 'force_ai' }
  });
  assert.equal(disabledGlobal.mode, 'dearrow');
  assert.equal(disabledGlobal.shouldAutoFetchAi, false);
});

test('FEAT-03: summary persona presets normalize and shape instructions & prompt suffixes', () => {
  assert.equal(normalizeSummaryPersona('technical'), 'technical');
  assert.equal(normalizeSummaryPersona('quiz'), 'quiz');
  assert.equal(normalizeSummaryPersona('chronological'), 'chronological');
  assert.equal(normalizeSummaryPersona('unknown-preset'), 'executive');

  const execFast = resolveSummaryPersonaInstruction('executive', 'fast');
  const techFast = resolveSummaryPersonaInstruction('technical', 'fast');
  const quizDeep = resolveSummaryPersonaInstruction('quiz', 'deep');
  assert.ok(!execFast.includes('Principal Systems Engineer'));
  assert.ok(techFast.includes('Principal Systems Engineer'));
  assert.ok(quizDeep.includes('exhaustive, deep') && quizDeep.includes('Interactive Tutor'));
  assert.equal(resolveSummaryPersonaPromptSuffix('executive'), '');
  assert.ok(resolveSummaryPersonaPromptSuffix('chronological').includes('[MM:SS]'));
});

test('AUD-08: Zero-Drift Parity between youtube-feed-summariser.user.js and src/utils/userscript-helpers.ts', () => {
  const userscriptPath = path.resolve(process.cwd(), 'youtube-feed-summariser.user.js');
  const source = fs.readFileSync(userscriptPath, 'utf8');

  const makeMockEl = (tag: string): any => {
    const attrs: Record<string, string> = {};
    const children: any[] = [];
    const el: any = {
      tagName: String(tag || 'div').toUpperCase(),
      style: {},
      dataset: {},
      className: '',
      textContent: '',
      children,
      childNodes: children,
      isConnected: true,
      classList: {
        add: () => {},
        remove: () => {},
        contains: () => false,
        toggle: () => false
      },
      setAttribute: (k: string, v: string) => { attrs[k] = String(v); },
      getAttribute: (k: string) => (k in attrs ? attrs[k] : null),
      hasAttribute: (k: string) => k in attrs,
      removeAttribute: (k: string) => { delete attrs[k]; },
      appendChild: (c: any) => { children.push(c); return c; },
      insertBefore: (c: any) => { children.unshift(c); return c; },
      remove: () => {},
      addEventListener: () => {},
      removeEventListener: () => {},
      querySelector: () => null,
      querySelectorAll: () => [],
      closest: () => null,
      attachShadow: () => {
        const sr = makeMockEl('shadow-root');
        el.shadowRoot = sr;
        return sr;
      }
    };
    return el;
  };

  const docEl = makeMockEl('html');
  const headEl = makeMockEl('head');
  const bodyEl = makeMockEl('body');
  const gmStore = new Map<string, any>();

  const mockDocument: any = {
    readyState: 'complete',
    documentElement: docEl,
    head: headEl,
    body: bodyEl,
    createElement: (tag: string) => makeMockEl(tag),
    createTextNode: (txt: string) => ({ nodeType: 3, textContent: String(txt || '') }),
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
    removeEventListener: () => {}
  };

  const mockWindow: any = {
    location: { href: 'https://www.youtube.com/', pathname: '/', search: '', origin: 'https://www.youtube.com' },
    innerWidth: 1440,
    innerHeight: 900,
    localStorage: {
      getItem: () => null,
      setItem: () => {},
      removeItem: () => {}
    },
    addEventListener: () => {},
    removeEventListener: () => {},
    navigator: { userAgent: 'node-vm', clipboard: { writeText: async () => {} } },
    speechSynthesis: { getVoices: () => [], cancel: () => {} },
    document: mockDocument
  };

  const context: Record<string, any> = {
    window: mockWindow,
    self: mockWindow,
    globalThis: mockWindow,
    document: mockDocument,
    navigator: mockWindow.navigator,
    location: mockWindow.location,
    localStorage: mockWindow.localStorage,
    console,
    setTimeout: (fn: (...a: any[]) => void, ms?: number, ...rest: any[]) => {
      const h = setTimeout(fn, ms, ...rest);
      h?.unref?.();
      return h;
    },
    clearTimeout,
    setInterval: (fn: (...a: any[]) => void, ms?: number, ...rest: any[]) => {
      const h = setInterval(fn, ms, ...rest);
      h?.unref?.();
      return h;
    },
    clearInterval,
    URL,
    Blob,
    Promise,
    JSON,
    Math,
    Date,
    RegExp,
    Error,
    Map,
    Set,
    Array,
    Object,
    String,
    Number,
    Boolean,
    CSS: { escape: (s: string) => String(s) },
    MutationObserver: class { observe() {} disconnect() {} },
    ResizeObserver: class { observe() {} disconnect() {} },
    SpeechSynthesisUtterance: class {},
    Event: class { constructor(public type: string) {} },
    CustomEvent: class { constructor(public type: string, public detail?: any) {} },
    GM_getValue: (k: string, d: any) => (gmStore.has(k) ? gmStore.get(k) : d),
    GM_setValue: (k: string, v: any) => { gmStore.set(k, v); },
    GM_deleteValue: (k: string) => { gmStore.delete(k); },
    GM_listValues: () => Array.from(gmStore.keys()),
    GM_addValueChangeListener: () => 1,
    GM_registerMenuCommand: () => 1,
    GM_addStyle: () => {},
    GM_setClipboard: () => {},
    GM_xmlhttpRequest: () => {}
  };
  mockWindow.window = mockWindow;

  vm.createContext(context);
  vm.runInContext(source, context, { filename: 'youtube-feed-summariser.user.js' });
  const u = mockWindow.__yt_summariser_test;
  assert.ok(u, 'Userscript exposes window.__yt_summariser_test in VM execution');

  // 1. Formatters & math/speech cleaning parity
  assert.equal(u.formatSecondsToTimestamp(5), formatSecondsToTimestamp(5));
  assert.equal(u.formatSecondsToTimestamp(3665), formatSecondsToTimestamp(3665));
  assert.equal(u.clampPitch(0.2), clampPitch(0.2));
  assert.equal(u.clampPitch(2.9), clampPitch(2.9));

  const sampleMath = 'At 4,300m boiling drops from $100^\\circ\\text{C}$ to $87^\\circ\\text{C}$ ($0.30/kg).';
  assert.equal(u.formatMathSymbolsInText(sampleMath), formatMathSymbolsInText(sampleMath));
  assert.equal(u.cleanTextForSpeech(sampleMath), cleanTextForSpeech(sampleMath));

  // 2. Transcript cues & FEAT-01 cue search parity
  const sampleTx = '[00:00] Intro section.\n[01:15] Core thesis.\n[04:20] Benchmarks.';
  const uParsed = u.parseTranscriptCues(sampleTx);
  const hParsed = parseTranscriptCues(sampleTx);
  assert.equal(uParsed.fullSpokenText, hParsed.fullSpokenText);
  assert.equal(uParsed.cues.length, hParsed.cues.length);
  assert.equal(
    u.findTranscriptCueIndexForSeconds(JSON.parse(JSON.stringify(uParsed.cues)), 95),
    findTranscriptCueIndexForSeconds(hParsed.cues, 95)
  );

  // 3. FEAT-02 per-channel auto-title rule parity
  assert.equal(u.normalizeChannelRuleKey('  Tech   Frontier '), normalizeChannelRuleKey('  Tech   Frontier '));
  const decisionArgs = {
    altTitlesEnabled: true,
    isMusic: false,
    hasDeArrowTitle: true,
    channelName: 'Tech Frontier',
    channelRules: { 'tech frontier': 'force_ai' as const }
  };
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.resolveAutoTitleDecision(decisionArgs))),
    resolveAutoTitleDecision(decisionArgs)
  );

  // 4. FEAT-03 summary persona parity
  for (const p of ['executive', 'technical', 'quiz', 'chronological', 'invalid'] as const) {
    assert.equal(u.normalizeSummaryPersona(p), normalizeSummaryPersona(p));
    assert.equal(u.resolveSummaryPersonaInstruction(p, 'fast'), resolveSummaryPersonaInstruction(p, 'fast'));
    assert.equal(u.resolveSummaryPersonaInstruction(p, 'deep'), resolveSummaryPersonaInstruction(p, 'deep'));
    assert.equal(u.resolveSummaryPersonaPromptSuffix(p), resolveSummaryPersonaPromptSuffix(p));
  }

  // 5. Window geometry & adaptive breakpoints parity
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.computeDefaultWindowBounds({ width: 1440, height: 900 }, 1))),
    computeDefaultWindowBounds({ width: 1440, height: 900 }, 1)
  );
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.clampWindowBounds({ left: -20, top: 10, width: 520, height: 600 }, { width: 375, height: 812 }))),
    clampWindowBounds({ left: -20, top: 10, width: 520, height: 600 }, { width: 375, height: 812 })
  );
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.getAdaptiveWindowFlags(460, 420))),
    getAdaptiveWindowFlags(460, 420)
  );
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.applyKeyboardWindowAdjustment({ left: 200, top: 150, width: 640, height: 500 }, 'resize', 'n', 'ArrowUp', true, { width: 1440, height: 900 }))),
    applyKeyboardWindowAdjustment({ left: 200, top: 150, width: 640, height: 500 }, 'resize', 'n', 'ArrowUp', true, { width: 1440, height: 900 })
  );

  // 6. Jitter delay & history tab parity
  assert.equal(u.computeDecorrelatedJitterDelay(4000, 2000, 60000, 25000, 0), computeDecorrelatedJitterDelay(4000, 2000, 60000, 25000, 0));
  assert.equal(
    u.shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 0 }),
    shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 0 })
  );

  // 7. FEAT-04 Chapter-aware chunking & FEAT-06 Markdown bundle export parity
  const parityChaptersDesc = '00:00 Intro\n14:20 Leader Election\n31:10 Safety Proofs\n48:05 ReadIndex';
  assert.deepEqual(
    JSON.parse(JSON.stringify(u.parseVideoChaptersFromDescription(parityChaptersDesc, 3500))),
    parseVideoChaptersFromDescription(parityChaptersDesc, 3500)
  );
  const parityLongTx = '[00:00] Intro\n[14:20] Election\n[31:10] Safety\n[48:05] ReadIndex\n[56:00] Outro';
  const uPlan = JSON.parse(JSON.stringify(u.buildLongVideoTranscriptChunks(parityLongTx, { totalDurationSec: 3500 })));
  const hPlan = buildLongVideoTranscriptChunks(parityLongTx, { totalDurationSec: 3500 });
  assert.deepEqual(uPlan, hPlan);
  assert.equal(
    u.buildChunkMapPrompt('Consensus Lecture', uPlan.chunks[0], uPlan.chunks.length, 'technical'),
    buildChunkMapPrompt('Consensus Lecture', hPlan.chunks[0], hPlan.chunks.length, 'technical')
  );
  assert.equal(
    u.buildChunkReducePrompt('Consensus Lecture', [{ title: 'Intro', tsStr: '[00:00]', summary: 'S1' }], 'technical', 'deep'),
    buildChunkReducePrompt('Consensus Lecture', [{ title: 'Intro', tsStr: '[00:00]', summary: 'S1' }], 'technical', 'deep')
  );
  const mdPayload = {
    videoId: 'PARITY_MD',
    videoTitle: 'Raft Consensus',
    channel: 'Systems Lab',
    duration: '58:30',
    mode: 'summary',
    persona: 'technical',
    model: 'gemini-3.8-flash',
    text: '## TL;DR\nBoiling drops from $100^\\circ\\text{C}$ [14:20]. Cost is $0.30/kg.',
    chapters: hPlan.chapters,
    followUpQuestions: [{ question: 'Why ReadIndex?', answer: 'Linearizable reads [48:05].', model: 'gemini-4-argon' }],
    ratings: { main: { videoId: 'PARITY_MD', targetType: 'summary' as const, targetId: 'main', rating: 'up' as const, updatedAt: 1700000000000, note: 'Clear proof' }, followUps: {} },
    exportedAt: '2026-11-17T12:00:00.000Z'
  };
  assert.equal(u.formatSummaryExportMarkdown(mdPayload), formatSummaryExportMarkdown(mdPayload));
});

test('35. FEAT-04 parseVideoChaptersFromDescription & extractSummaryChapters extract sorted timestamps cleanly', () => {
  const desc = [
    'Lecture Notes:',
    '14:20 - Leader Election & Split Votes',
    '00:00 Course Intro',
    '31:10: Safety Proofs & Invariants',
    '1:02:15 Production Chaos'
  ].join('\n');
  const chaps = parseVideoChaptersFromDescription(desc, 4000);
  assert.equal(chaps.length, 4);
  assert.equal(chaps[0].tsStr, '[00:00]');
  assert.equal(chaps[0].endSec, 860);
  assert.equal(chaps[1].title, 'Leader Election & Split Votes');
  assert.equal(chaps[3].startSec, 3735);
  assert.equal(chaps[3].endSec, 4000);

  const fromSummary = extractSummaryChapters(
    '## TL;DR\nSummary.\n### [00:00] Intro\nA\n### [14:20] Raft\nB\n### [31:10] Proofs\nC',
    [],
    3500
  );
  assert.equal(fromSummary.length, 3);
  assert.equal(fromSummary[1].tsStr, '[14:20]');
});

test('36. FEAT-04 buildLongVideoTranscriptChunks skips chunking <=45m and partitions >45m by chapter or 20m fallback', () => {
  const shortTx = '[00:00] Start\n[15:00] Middle\n[30:00] End';
  const shortPlan = buildLongVideoTranscriptChunks(shortTx, { totalDurationSec: 1850 });
  assert.equal(shortPlan.isLongVideoChunked, false);
  assert.equal(shortPlan.chunks.length, 1);

  const longTx = '[00:00] Intro\n[14:20] Election\n[31:10] Safety\n[48:05] ReadIndex\n[56:00] Wrap up';
  const chapters = parseVideoChaptersFromDescription('00:00 Intro\n14:20 Election\n31:10 Safety\n48:05 ReadIndex', 3500);
  const chapterPlan = buildLongVideoTranscriptChunks(longTx, { chapters, totalDurationSec: 3500 });
  assert.equal(chapterPlan.isLongVideoChunked, true);
  assert.equal(chapterPlan.chunks.length, 4);
  assert.ok(chapterPlan.chunks[2].text.includes('[31:10] Safety'));

  const windowFallbackPlan = buildLongVideoTranscriptChunks(longTx, { totalDurationSec: 3500 });
  assert.equal(windowFallbackPlan.isLongVideoChunked, true);
  assert.ok(windowFallbackPlan.chunks.length >= 2);
});

test('37. FEAT-06 formatSummaryExportMarkdown creates self-contained Obsidian bundle with frontmatter, math, deep links, Q&A and ratings', () => {
  const md = formatSummaryExportMarkdown({
    videoId: 'OBS_TEST_01',
    videoTitle: 'Raft Consensus Proof',
    channel: 'Systems Engineering Lab',
    duration: '58:30',
    mode: 'summary',
    processingMode: 'deep',
    persona: 'technical',
    model: 'gemini-3.8-flash',
    text: '## TL;DR\nRack burns at $100^\\circ\\text{C}$ [14:20]. Node cost $0.30/kg.',
    chapters: [
      { index: 0, title: 'Intro', startSec: 0, endSec: 860, tsStr: '[00:00]' },
      { index: 1, title: 'Leader Election', startSec: 860, endSec: 3510, tsStr: '[14:20]' }
    ],
    factCheck: 'Verified against Ongaro thesis [14:20].',
    citations: [{ uri: 'https://raft.github.io', title: 'Raft Paper' }],
    followUpQuestions: [
      {
        question: 'Draw state diagram?',
        answer: 'See state flow [48:05].',
        model: 'gemini-4-argon',
        imageUri: 'data:image/svg+xml;charset=utf-8,mock',
        sources: [{ uri: 'https://example.org/raft', title: 'Raft Ref' }]
      }
    ],
    ratings: {
      main: { videoId: 'OBS_TEST_01', targetType: 'summary', targetId: 'main', rating: 'up', updatedAt: 1700000000000, note: 'Strong invariant walkthrough' },
      followUps: {
        turn_0: { videoId: 'OBS_TEST_01', targetType: 'followup', targetId: 'turn_0', rating: 'down', updatedAt: 1700000001000, note: 'Add split-vote timeout bound' }
      }
    },
    exportedAt: '2026-11-17T12:00:00.000Z'
  });

  assert.ok(md.startsWith('---\n'), 'Starts with YAML frontmatter');
  assert.ok(md.includes('persona: "technical"'), 'Frontmatter records persona');
  assert.ok(md.includes('  - youtube-summary'), 'Frontmatter records Obsidian tags');
  assert.ok(md.includes('## Chapters'), 'Includes ## Chapters index');
  assert.ok(md.includes('[14:20](https://www.youtube.com/watch?v=OBS_TEST_01&t=860s)'), 'Links timestamps deeply to YouTube seconds');
  assert.ok(md.includes('100°C') && md.includes('$0.30/kg'), 'Formats LaTeX math to Unicode while preserving currency');
  assert.ok(md.includes('## Fact-Check & Verification'), 'Includes fact-check section');
  assert.ok(md.includes('## Follow-Up Q&A') && md.includes('![Generated Diagram]'), 'Includes follow-up Q&A and diagrams');
  assert.ok(md.includes('## Quality Ratings & Notes') && md.includes('Strong invariant walkthrough') && md.includes('Add split-vote timeout bound'), 'Preserves ratings & notes');
});

test('38. Backup CLI --diff and --restore --file verify snapshots and block path traversal', () => {
  const scriptPath = path.resolve(process.cwd(), 'scripts/sandbox-backup.mjs');
  const diffRaw = execFileSync('node', [scriptPath, '--diff', 'latest'], { encoding: 'utf8' });
  const diffJson = JSON.parse(diffRaw);
  assert.equal(diffJson.mode, 'snapshot-to-workspace');
  assert.ok(diffJson.baseSnapshot.startsWith('snap-'));
  assert.ok(typeof diffJson.summary?.unchanged === 'number' && diffJson.totalCompared > 0);

  const dryRestoreRaw = execFileSync(
    'node',
    [scriptPath, '--restore', 'latest', '--file=package.json', '--dry-run'],
    { encoding: 'utf8' }
  );
  const dryRestoreJson = JSON.parse(dryRestoreRaw);
  assert.equal(dryRestoreJson.dryRun, true);
  assert.equal(dryRestoreJson.selectiveRestore, true);
  assert.equal(dryRestoreJson.file, 'package.json');

  assert.throws(
    () => execFileSync('node', [scriptPath, '--restore', 'latest', '--file=../../etc/passwd', '--dry-run'], { stdio: 'pipe' }),
    /Command failed/,
    'Rejects parent directory traversal in --file'
  );
});





