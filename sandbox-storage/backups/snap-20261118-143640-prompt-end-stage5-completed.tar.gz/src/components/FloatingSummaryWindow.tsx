import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  Copy,
  Check,
  Terminal,
  Play,
  Volume2,
  ShieldAlert,
  FileCode,
  ExternalLink,
  RefreshCw,
  X,
  Minus,
  Search,
  ChevronUp,
  ChevronDown,
  BookOpen,
  Download,
  FileText,
  Printer,
  Mic,
  MicOff,
  Send,
  Globe,
  MapPin,
  Bot,
  Image as ImageIcon,
  MoreHorizontal,
  GripVertical,
  Clock,
  Lock,
  Unlock
} from 'lucide-react';
import {
  formatMathSymbolsInText,
  resolveSummaryPersonaInstruction,
  normalizeSummaryPersona,
  extractSummaryChapters,
  buildLongVideoTranscriptChunks,
  parseTimestampToSeconds,
  SUMMARY_PERSONA_PRESETS,
  type AdaptiveWindowFlags,
  type ResizeDirection,
  type ResponseRatingRecord,
  type SummaryPersona,
  type WindowBounds
} from '../utils/userscript-helpers';
import {
  type ActiveSeekState,
  type ChatTurn,
  type MockVideo
} from './SimulatorTypes';
import { TimestampText } from './TimestampText';
import { ResponseRatingBar } from './ResponseRatingBar';
import { TtsControlBar } from './TtsControlBar';
import { ReadabilityModal } from './ReadabilityModal';

interface FloatingSummaryWindowProps {
  video: MockVideo;
  winState: { minimized: boolean; mode: 'summary' | 'transcript'; source: 'video' | 'text' };
  bounds: WindowBounds;
  zIndex: number;
  isFocused: boolean;
  adaptive: AdaptiveWindowFlags;
  showOptionsRow: boolean;
  compactOptionsExpanded: boolean;
  setContainerRef: (el: HTMLDivElement | null) => void;
  onFocus: () => void;
  onStartDrag: (e: React.MouseEvent) => void;
  onStartResize: (dir: ResizeDirection) => (e: React.MouseEvent) => void;
  onResizeKeyDown: (dir: ResizeDirection) => (e: React.KeyboardEvent) => void;
  onGripKeyDown: (e: React.KeyboardEvent) => void;
  toast?: { message: string; visible: boolean };
  readabilityMode: boolean;
  readabilityTheme: 'system' | 'light' | 'sepia' | 'dark';
  readabilityFont: 'serif' | 'sans';
  readabilitySize: number;
  syncYouTubeTheme: boolean;
  simulatedYouTubeTheme: 'dark' | 'light';
  onToggleReadabilityMode: () => void;
  onExitReadability: () => void;
  onToggleSyncYouTubeTheme: () => void;
  onSelectReadabilityTheme: (theme: 'system' | 'light' | 'sepia' | 'dark') => void;
  onToggleReadabilityFont: () => void;
  onChangeReadabilitySize: (delta: number) => void;
  exportMenuOpen: boolean;
  onToggleExportMenu: () => void;
  headerOverflowOpen: boolean;
  onToggleHeaderOverflow: (e: React.MouseEvent) => void;
  onCloseHeaderOverflow: () => void;
  copiedVideoUrl: boolean;
  onCopyVideoUrl: () => void;
  onOpenHistory: () => void;
  onMinimize: () => void;
  onClose: () => void;
  onExportTxt: () => void;
  onExportPdf: () => void;
  onExportJson: () => void;
  onExportMarkdown: () => void;
  onChangeWinMode: (mode: 'summary' | 'transcript') => void;
  onChangeWinSource: (source: 'video' | 'text') => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  simAskFailure: boolean;
  onToggleSimAskFailure: (val: boolean) => void;
  fallbackNote: string | null;
  onRegenerate: () => void;
  onToggleCompactOptions: () => void;
  transcriptMode: 'fast' | 'deep';
  onSetTranscriptMode: (mode: 'fast' | 'deep') => void;
  persona: SummaryPersona;
  onSelectPersona: (persona: SummaryPersona) => void;
  altTitlesEnabled: boolean;
  onSetAltTitlesEnabled: (enabled: boolean) => void;
  // TTS Props
  tts: { status: 'idle' | 'playing' | 'paused'; rate: number };
  currentVol: number;
  currentPitch: number;
  skipSilence: boolean;
  selectedVoice: string;
  browserVoices: SpeechSynthesisVoice[];
  activeTtsLine: number | null;
  activeTtsTs: string | null;
  onSelectVoice: (voice: string) => void;
  onToggleTts: (contentText: string) => void;
  onRewindTts: (contentText: string) => void;
  onSkipTts: (contentText: string) => void;
  onStopTts: () => void;
  onSetTtsRate: (rate: number) => void;
  onCycleTtsRate: (contentText: string) => void;
  onSetTtsVolume: (vol: number) => void;
  onSetTtsPitch: (pitch: number) => void;
  onToggleSkipSilence: (contentText: string) => void;
  // FEAT-01 Seek & Follow-Along
  activeSeek: ActiveSeekState | null;
  followAlong: boolean;
  onToggleFollowAlong: () => void;
  onSeekTimestamp: (tsStr: string, seconds: number) => void;
  // Transcript Search
  transcriptSearchQuery: string;
  onChangeTranscriptSearch: (q: string) => void;
  transcriptFilterOnly: boolean;
  onChangeTranscriptFilterOnly: (checked: boolean) => void;
  activeMatchIndex: number;
  onSetActiveMatchIndex: (idx: number) => void;
  // Ratings
  closedSummariesCount: number;
  responseRatings: Record<string, ResponseRatingRecord>;
  openRatingNoteKey: string | null;
  setOpenRatingNoteKey: React.Dispatch<React.SetStateAction<string | null>>;
  onRateResponse: (
    videoId: string,
    targetType: 'summary' | 'transcript' | 'followup',
    rating: 'up' | 'down',
    targetId: string,
    note?: string
  ) => void;
  onShowToast: (msg: string, targetVideoId?: string | null) => void;
  // Conversation
  turns: ChatTurn[];
  isAnsweringFollowUp: boolean;
  composerText: string;
  onChangeComposerText: (txt: string) => void;
  composerModel: 'gemini-4-argon' | 'gemini-3.8-flash' | 'gemini-3.1-flash-lite';
  onSelectComposerModel: (m: 'gemini-4-argon' | 'gemini-3.8-flash' | 'gemini-3.1-flash-lite') => void;
  composerGSearch: boolean;
  onToggleComposerGSearch: () => void;
  composerGMaps: boolean;
  onToggleComposerGMaps: () => void;
  isRecordingVoice: boolean;
  onToggleVoiceInput: () => void;
  onSendFollowUp: () => void;
}

const RESIZE_HANDLE_META: Array<{
  dir: ResizeDirection;
  orientation: 'horizontal' | 'vertical';
  label: string;
  title: string;
  cls: string;
}> = [
  {
    dir: 'n',
    orientation: 'horizontal',
    label: 'Resize height from top',
    title: 'Drag or press Arrow keys to resize height from top',
    cls: 'left-3 right-3 top-0 h-1.5 cursor-ns-resize z-30 hover:bg-sky-500/30 yt-resize-n'
  },
  {
    dir: 'e',
    orientation: 'vertical',
    label: 'Resize width',
    title: 'Drag or press Arrow keys to resize width',
    cls: 'top-3 bottom-3 right-0 w-1.5 cursor-ew-resize z-30 hover:bg-sky-500/30 yt-resize-e'
  },
  {
    dir: 'w',
    orientation: 'vertical',
    label: 'Resize width from left',
    title: 'Drag or press Arrow keys to resize width from left',
    cls: 'top-3 bottom-3 left-0 w-1.5 cursor-ew-resize z-30 hover:bg-sky-500/30 yt-resize-w'
  },
  {
    dir: 's',
    orientation: 'horizontal',
    label: 'Resize height',
    title: 'Drag or press Arrow keys to resize height',
    cls: 'left-3 right-3 bottom-0 h-1.5 cursor-ns-resize z-30 hover:bg-sky-500/30 yt-resize-s'
  },
  {
    dir: 'nw',
    orientation: 'horizontal',
    label: 'Resize corner top-left',
    title: 'Drag or press Arrow keys to resize top-left corner',
    cls: 'left-0 top-0 w-3.5 h-3.5 cursor-nwse-resize z-40 yt-resize-nw'
  },
  {
    dir: 'ne',
    orientation: 'horizontal',
    label: 'Resize corner top-right',
    title: 'Drag or press Arrow keys to resize top-right corner',
    cls: 'right-0 top-0 w-3.5 h-3.5 cursor-nesw-resize z-40 yt-resize-ne'
  },
  {
    dir: 'se',
    orientation: 'horizontal',
    label: 'Resize summary window',
    title: 'Drag or press Arrow keys to resize bottom-right corner',
    cls: 'right-0 bottom-0 w-3.5 h-3.5 cursor-nwse-resize z-40 yt-resize-se'
  },
  {
    dir: 'sw',
    orientation: 'horizontal',
    label: 'Resize corner bottom-left',
    title: 'Drag or press Arrow keys to resize bottom-left corner',
    cls: 'left-0 bottom-0 w-3.5 h-3.5 cursor-nesw-resize z-40 yt-resize-sw'
  }
];

export const FloatingSummaryWindow: React.FC<FloatingSummaryWindowProps> = ({
  video,
  winState,
  bounds,
  zIndex,
  isFocused,
  adaptive,
  showOptionsRow,
  setContainerRef,
  onFocus,
  onStartDrag,
  onStartResize,
  onResizeKeyDown,
  onGripKeyDown,
  toast,
  readabilityMode,
  readabilityTheme,
  readabilityFont,
  readabilitySize,
  syncYouTubeTheme,
  simulatedYouTubeTheme,
  onToggleReadabilityMode,
  onExitReadability,
  onToggleSyncYouTubeTheme,
  onSelectReadabilityTheme,
  onToggleReadabilityFont,
  onChangeReadabilitySize,
  exportMenuOpen,
  onToggleExportMenu,
  headerOverflowOpen,
  onToggleHeaderOverflow,
  onCloseHeaderOverflow,
  copiedVideoUrl,
  onCopyVideoUrl,
  onOpenHistory,
  onMinimize,
  onClose,
  onExportTxt,
  onExportPdf,
  onExportJson,
  onExportMarkdown,
  onChangeWinMode,
  onChangeWinSource,
  selectedModel,
  onSelectModel,
  simAskFailure,
  onToggleSimAskFailure,
  fallbackNote,
  onRegenerate,
  onToggleCompactOptions,
  transcriptMode,
  onSetTranscriptMode,
  persona,
  onSelectPersona,
  altTitlesEnabled,
  onSetAltTitlesEnabled,
  tts,
  currentVol,
  currentPitch,
  skipSilence,
  selectedVoice,
  browserVoices,
  activeTtsLine,
  activeTtsTs,
  onSelectVoice,
  onToggleTts,
  onRewindTts,
  onSkipTts,
  onStopTts,
  onSetTtsRate,
  onCycleTtsRate,
  onSetTtsVolume,
  onSetTtsPitch,
  onToggleSkipSilence,
  activeSeek,
  followAlong,
  onToggleFollowAlong,
  onSeekTimestamp,
  transcriptSearchQuery,
  onChangeTranscriptSearch,
  transcriptFilterOnly,
  onChangeTranscriptFilterOnly,
  activeMatchIndex,
  onSetActiveMatchIndex,
  closedSummariesCount,
  responseRatings,
  openRatingNoteKey,
  setOpenRatingNoteKey,
  onRateResponse,
  onShowToast,
  turns,
  isAnsweringFollowUp,
  composerText,
  onChangeComposerText,
  composerModel,
  onSelectComposerModel,
  composerGSearch,
  onToggleComposerGSearch,
  composerGMaps,
  onToggleComposerGMaps,
  isRecordingVoice,
  onToggleVoiceInput,
  onSendFollowUp
}) => {
  const videoId = video.id;
  const contentText = winState.mode === 'summary' ? video.summary : video.transcript;
  const personaPreset = SUMMARY_PERSONA_PRESETS[persona];
  const effectiveSystemInstruction = resolveSummaryPersonaInstruction(persona, transcriptMode);
  const totalDurationSec = React.useMemo(
    () => parseTimestampToSeconds(video.duration || '0:00'),
    [video.duration]
  );
  const chapters = React.useMemo(
    () => extractSummaryChapters(video.summary, [], totalDurationSec),
    [video.summary, totalDurationSec]
  );
  const chunkPlan = React.useMemo(
    () => buildLongVideoTranscriptChunks(video.transcript, { chapters, totalDurationSec }),
    [video.transcript, chapters, totalDurationSec]
  );

  return (
    <div
      ref={setContainerRef}
      style={{
        left: `${bounds.left}px`,
        top: `${bounds.top}px`,
        width: `${bounds.width}px`,
        height: `${bounds.height}px`,
        zIndex
      }}
      data-size-tier={adaptive.tier}
      data-video-id={videoId}
      onMouseDown={onFocus}
      className={`fixed bg-[#0f0f0f] border rounded-2xl shadow-2xl flex flex-col overflow-hidden text-zinc-100 yt-window-box yt-floating-window ${
        isFocused ? 'border-sky-500/60 ring-1 ring-sky-500/20' : 'border-zinc-700/80'
      } ${adaptive.isCompact ? 'yt-win-compact' : adaptive.isMedium ? 'yt-win-medium' : 'yt-win-wide'} ${
        adaptive.isShort ? 'yt-win-short' : ''
      }`}
    >
      {/* 8-Direction Resize Handles */}
      {RESIZE_HANDLE_META.map((h) => (
        <div
          key={h.dir}
          role="separator"
          tabIndex={0}
          data-resize-dir={h.dir}
          aria-orientation={h.orientation}
          aria-label={h.label}
          onMouseDown={onStartResize(h.dir)}
          onKeyDown={onResizeKeyDown(h.dir)}
          title={h.title}
          className={`absolute focus-visible:outline focus-visible:outline-2 focus-visible:outline-sky-400 focus-visible:bg-sky-500/30 transition-colors yt-resize-handle ${h.cls}`}
        />
      ))}

      {/* Scoped Per-Window Toast */}
      {toast?.visible && (
        <div
          data-toast-video-id={videoId}
          className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-zinc-900/95 text-white text-xs font-semibold px-3.5 py-1.5 rounded-full shadow-2xl border border-zinc-700/80 backdrop-blur-md flex items-center gap-1.5 pointer-events-none yt-tts-toast"
        >
          {toast.message}
        </div>
      )}

      {/* Draggable Header */}
      <div
        onMouseDown={onStartDrag}
        className={`${
          adaptive.isCompact ? 'px-3.5 py-2.5' : 'px-6 py-4'
        } border-b border-zinc-800 flex items-center justify-between gap-2 bg-[#141414] cursor-move select-none yt-win-header`}
        title="Drag header to move window"
      >
        <button
          type="button"
          tabIndex={0}
          onKeyDown={onGripKeyDown}
          onClick={(e) => e.stopPropagation()}
          className="flex items-center justify-center text-zinc-500 hover:text-zinc-300 p-1 rounded flex-shrink-0 cursor-grab active:cursor-grabbing focus-visible:outline focus-visible:outline-2 focus-visible:outline-sky-400 yt-win-drag-grip"
          title="Drag or press Arrow keys (Shift for larger steps) to move window"
          aria-label="Move summary window with arrow keys"
        >
          <GripVertical className="w-4 h-4" />
        </button>

        <div className="min-w-0 pr-2 flex-1">
          <a
            href={`https://www.youtube.com/watch?v=${videoId}`}
            target="_blank"
            rel="noopener noreferrer"
            className={`font-semibold ${
              adaptive.isCompact ? 'text-sm' : 'text-base'
            } text-zinc-100 hover:text-sky-400 transition-colors truncate inline-block max-w-full yt-win-title-link`}
            title={`${video.title} (Open video in new tab)`}
          >
            {video.title}
          </a>
          <p className="text-xs text-zinc-400 mt-0.5 flex items-center gap-2 truncate">
            {!adaptive.isCompact && (
              <>
                <span className="truncate">{video.channel}</span>
                <span aria-hidden="true">&middot;</span>
              </>
            )}
            <span className="text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{adaptive.isCompact ? 'Completed' : `Completed (${personaPreset.shortLabel})`}</span>
            </span>
          </p>
        </div>

        <div className="flex items-center gap-1 relative flex-shrink-0">
          <button
            type="button"
            onClick={onToggleReadabilityMode}
            className={`p-1.5 rounded-lg transition-colors flex items-center gap-1 text-xs yt-win-readability-btn cursor-pointer ${
              readabilityMode
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40 active'
                : 'hover:bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
            title={
              readabilityMode
                ? 'Exit Readability Mode (Return to standard interactive view)'
                : 'Readability Mode (Clean, centered distraction-free reader)'
            }
            aria-label="Toggle Readability Mode"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          {!adaptive.useOverflowHeaderMenu ? (
            <>
              <div className="relative">
                <button
                  type="button"
                  onClick={onToggleExportMenu}
                  className={`p-1.5 rounded-lg transition-colors flex items-center gap-1 text-xs yt-win-export-btn cursor-pointer ${
                    exportMenuOpen ? 'bg-zinc-700 text-white' : 'hover:bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                  title="Export summary / transcript (.txt, .pdf, .json, or .md)"
                  aria-label="Export summary"
                >
                  <Download className="w-4 h-4" />
                </button>

                {exportMenuOpen && (
                  <div className="absolute right-0 top-9 w-64 bg-[#1f1f1f] border border-zinc-700/80 rounded-xl shadow-2xl p-2 z-50 text-xs text-zinc-200 yt-export-popover space-y-1">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-2 py-1">
                      Export Content
                    </div>
                    <button
                      type="button"
                      onClick={onExportTxt}
                      className="w-full text-left p-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2.5 transition-colors yt-export-item cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-sky-400 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-zinc-200">Export as Text (.txt)</div>
                        <div className="text-[10px] text-zinc-400">Formatted plain text with metadata</div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={onExportPdf}
                      className="w-full text-left p-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2.5 transition-colors yt-export-item cursor-pointer"
                    >
                      <Printer className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-zinc-200">Export as PDF (.pdf)</div>
                        <div className="text-[10px] text-zinc-400">Printable serif document layout</div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={onExportJson}
                      className="w-full text-left p-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2.5 transition-colors yt-export-item yt-export-json-btn cursor-pointer"
                    >
                      <FileCode className="w-4 h-4 text-purple-400 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-zinc-200">Export as JSON (.json)</div>
                        <div className="text-[10px] text-zinc-400">Structured data with persona &amp; metadata</div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={onExportMarkdown}
                      className="w-full text-left p-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2.5 transition-colors yt-export-item yt-export-md-btn cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-zinc-200">Export Markdown / Obsidian (.md)</div>
                        <div className="text-[10px] text-zinc-400">Frontmatter, Q&amp;A, ratings &amp; chapters</div>
                      </div>
                    </button>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={onOpenHistory}
                className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors yt-history-btn cursor-pointer"
                title="Browse previous summaries (History)"
                aria-label="Browse previous summaries"
              >
                <Clock className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onCopyVideoUrl}
                className={`p-1.5 rounded-lg transition-colors flex items-center gap-1 text-xs yt-win-copy-btn cursor-pointer ${
                  copiedVideoUrl
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'hover:bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
                title={copiedVideoUrl ? 'Copied video link!' : 'Copy original video URL'}
                aria-label="Copy video URL"
              >
                {copiedVideoUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <a
                href={`https://www.youtube.com/watch?v=${videoId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors yt-win-open-btn"
                title="Open video in new tab"
                aria-label="Open video in new tab"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </>
          ) : (
            <div className="relative">
              <button
                type="button"
                onClick={onToggleHeaderOverflow}
                className={`p-1.5 rounded-lg transition-colors yt-win-overflow-btn cursor-pointer ${
                  headerOverflowOpen ? 'bg-zinc-700 text-white' : 'hover:bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
                title="More actions"
                aria-label="More window actions"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {headerOverflowOpen && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute right-0 top-9 w-56 bg-[#1f1f1f] border border-zinc-700/80 rounded-xl shadow-2xl p-1.5 z-50 text-xs text-zinc-200 yt-win-overflow-menu space-y-1"
                >
                  <button
                    type="button"
                    onClick={() => {
                      onCloseHeaderOverflow();
                      onExportTxt();
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-sky-400" />
                    <span>Export as Text (.txt)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onCloseHeaderOverflow();
                      onExportJson();
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2 cursor-pointer"
                  >
                    <FileCode className="w-3.5 h-3.5 text-purple-400" />
                    <span>Export as JSON (.json)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onCloseHeaderOverflow();
                      onExportMarkdown();
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2 cursor-pointer yt-overflow-export-md-btn"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-400" />
                    <span>Export Markdown (.md)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onCloseHeaderOverflow();
                      onOpenHistory();
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5 text-zinc-400" />
                    <span>History</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onCloseHeaderOverflow();
                      onCopyVideoUrl();
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Copy video URL</span>
                  </button>
                  <a
                    href={`https://www.youtube.com/watch?v=${videoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={onCloseHeaderOverflow}
                    className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-zinc-800 flex items-center gap-2"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Open video in new tab</span>
                  </a>
                </div>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={onMinimize}
            className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            title="Minimize to dock"
            aria-label="Minimize window"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            title="Close"
            aria-label="Close window"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {readabilityMode ? (
        <ReadabilityModal
          video={video}
          mode={winState.mode}
          persona={persona}
          theme={readabilityTheme}
          font={readabilityFont}
          fontSize={readabilitySize}
          syncYouTubeTheme={syncYouTubeTheme}
          simulatedYouTubeTheme={simulatedYouTubeTheme}
          activeSeek={activeSeek}
          onExit={onExitReadability}
          onToggleSyncYouTubeTheme={onToggleSyncYouTubeTheme}
          onSelectTheme={onSelectReadabilityTheme}
          onToggleFont={onToggleReadabilityFont}
          onChangeFontSize={onChangeReadabilitySize}
          onExportTxt={onExportTxt}
          onExportPdf={onExportPdf}
          onExportJson={onExportJson}
          onExportMarkdown={onExportMarkdown}
          onSeekTimestamp={onSeekTimestamp}
        />
      ) : (
        <>
          {/* Toolbar */}
          <div
            className={`${
              adaptive.isCompact ? 'px-3 py-2 gap-1.5' : 'px-6 py-3 gap-3'
            } border-b border-zinc-800/80 bg-[#121212] flex items-center flex-wrap text-xs yt-win-toolbar`}
          >
            <div className="flex rounded-lg bg-zinc-800 p-0.5 border border-zinc-700">
              <button
                type="button"
                onClick={() => onChangeWinMode('summary')}
                className={`px-3 py-1 rounded-md font-medium cursor-pointer ${
                  winState.mode === 'summary' ? 'bg-zinc-900 text-white shadow-xs' : 'text-zinc-400'
                }`}
              >
                Summarize
              </button>
              <button
                type="button"
                onClick={() => onChangeWinMode('transcript')}
                className={`px-3 py-1 rounded-md font-medium cursor-pointer ${
                  winState.mode === 'transcript' ? 'bg-zinc-900 text-white shadow-xs' : 'text-zinc-400'
                }`}
              >
                Transcribe
              </button>
            </div>

            <div className="flex rounded-lg bg-zinc-800 p-0.5 border border-zinc-700">
              <button
                type="button"
                onClick={() => onChangeWinSource('video')}
                className={`px-3 py-1 rounded-md font-medium cursor-pointer ${
                  winState.source === 'video' ? 'bg-zinc-900 text-white shadow-xs' : 'text-zinc-400'
                }`}
              >
                Video
              </button>
              <button
                type="button"
                onClick={() => onChangeWinSource('text')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                  winState.source === 'text' ? 'bg-zinc-900 text-white shadow-xs' : 'text-zinc-400'
                }`}
              >
                Transcript
              </button>
            </div>

            <select
              aria-label="Gemini Model Selector"
              className="bg-[#212121] text-zinc-100 border border-zinc-700 rounded-lg px-2.5 py-1 text-xs focus:outline-none cursor-pointer max-w-full min-w-0"
              style={{ colorScheme: 'dark' }}
              value={selectedModel}
              onChange={(e) => onSelectModel(e.target.value)}
            >
              <option value="Ask" className="bg-[#212121] text-zinc-100">
                YouTube Ask (Gemini in the page) — Free, no API limit
              </option>
              <optgroup label="Recommended models" className="bg-[#181818] text-sky-400 font-semibold">
                <option value="gemini-3.8-flash" className="bg-[#212121] text-zinc-100">gemini-3.8-flash (Recommended)</option>
                <option value="gemini-3.7-flash" className="bg-[#212121] text-zinc-100">gemini-3.7-flash</option>
                <option value="gemini-3.5-flash" className="bg-[#212121] text-zinc-100">gemini-3.5-flash</option>
                <option value="gemini-3.1-pro-preview" className="bg-[#212121] text-zinc-100">gemini-3.1-pro-preview</option>
              </optgroup>
            </select>

            {/* FEAT-03 Persona Preset Selector */}
            <select
              aria-label="Summary Persona"
              className="bg-[#212121] text-zinc-100 border border-zinc-700 rounded-lg px-2.5 py-1 text-xs focus:outline-none cursor-pointer max-w-full min-w-0 yt-persona-select"
              style={{ colorScheme: 'dark' }}
              value={persona}
              onChange={(e) => onSelectPersona(normalizeSummaryPersona(e.target.value))}
              title={`Summary Persona: ${personaPreset.description}`}
            >
              {(Object.keys(SUMMARY_PERSONA_PRESETS) as SummaryPersona[]).map((key) => (
                <option key={key} value={key} className="bg-[#212121] text-zinc-100">
                  {SUMMARY_PERSONA_PRESETS[key].label}
                </option>
              ))}
            </select>

            {adaptive.collapseOptionsRow && (
              <button
                type="button"
                onClick={onToggleCompactOptions}
                className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-medium yt-compact-options-btn cursor-pointer"
              >
                {showOptionsRow ? 'Options ▴' : 'Options ▾'}
              </button>
            )}

            {selectedModel === 'Ask' && showOptionsRow && (
              <label
                className="flex items-center gap-1.5 text-[11px] text-amber-300 bg-amber-950/30 border border-amber-700/40 px-2 py-1 rounded-lg cursor-pointer"
                title="Simulate YouTube Ask failing so Regenerate automatically falls back to the next model on the ladder"
              >
                <input
                  type="checkbox"
                  checked={simAskFailure}
                  onChange={(e) => onToggleSimAskFailure(e.target.checked)}
                  className="accent-amber-400 cursor-pointer"
                />
                <span>Simulate Ask failure</span>
              </label>
            )}

            {showOptionsRow && (
              <>
                <select
                  aria-label="API Key Selector"
                  className="bg-[#212121] text-zinc-100 border border-zinc-700 rounded-lg px-2 py-1 text-xs focus:outline-none cursor-pointer max-w-[160px]"
                  style={{ colorScheme: 'dark' }}
                  defaultValue="key1"
                >
                  <option value="key1" className="bg-[#212121] text-zinc-100">Primary Key (&hellip;9a2f)</option>
                  <option value="key2" className="bg-[#212121] text-zinc-100">Backup Pro (&hellip;4b1c)</option>
                  <option value="manage" className="bg-[#212121] text-zinc-100">Add / manage keys&hellip;</option>
                </select>

                <div
                  className="flex items-center gap-1.5 bg-zinc-800/80 px-2 py-1 rounded-lg border border-zinc-700/80 yt-transcript-processing-panel"
                  title="Transcript Processing: Choose between Fast (Concise executive brief) and Deep (Detailed exhaustive breakdown)"
                >
                  {!adaptive.isCompact && (
                    <span className="text-[11px] font-medium text-zinc-400 yt-tp-label">Processing:</span>
                  )}
                  <div className="inline-flex rounded-md bg-zinc-900 p-0.5 border border-zinc-700">
                    <button
                      type="button"
                      onClick={() => onSetTranscriptMode('fast')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all yt-tp-btn yt-tp-fast-btn cursor-pointer ${
                        transcriptMode === 'fast'
                          ? 'bg-sky-500 text-zinc-950 font-bold shadow-xs active'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                      title="Fast (Concise): Rapid executive takeaways (< 2 min read)"
                    >
                      Fast
                    </button>
                    <button
                      type="button"
                      onClick={() => onSetTranscriptMode('deep')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all yt-tp-btn yt-tp-deep-btn cursor-pointer ${
                        transcriptMode === 'deep'
                          ? 'bg-indigo-500 text-white font-bold shadow-xs active'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                      title="Deep (Detailed): Exhaustive chronological analysis"
                    >
                      Deep
                    </button>
                  </div>
                </div>
              </>
            )}

            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={onRegenerate}
                className="px-3 py-1 rounded-lg bg-sky-500 hover:bg-sky-400 text-zinc-950 font-semibold text-xs cursor-pointer"
              >
                Regenerate
              </button>
            </div>

            <div className="w-full">
              <TtsControlBar
                videoId={videoId}
                mode={winState.mode}
                contentText={contentText}
                tts={tts}
                currentVol={currentVol}
                currentPitch={currentPitch}
                skipSilence={skipSilence}
                selectedVoice={selectedVoice}
                browserVoices={browserVoices}
                activeTtsTs={activeTtsTs}
                adaptive={adaptive}
                onSelectVoice={onSelectVoice}
                onToggleTts={() => onToggleTts(contentText)}
                onRewindTts={() => onRewindTts(contentText)}
                onSkipTts={() => onSkipTts(contentText)}
                onStopTts={onStopTts}
                onSetRate={onSetTtsRate}
                onCycleRate={() => onCycleTtsRate(contentText)}
                onSetVolume={onSetTtsVolume}
                onSetPitch={onSetTtsPitch}
                onToggleSkipSilence={() => onToggleSkipSilence(contentText)}
              />
            </div>
          </div>

          {/* FEAT-01 Active Seek Status Strip (pinned visibly above scroll container) */}
          {activeSeek && (
            <div
              data-seek-banner={activeSeek.tsStr}
              className={`flex flex-wrap items-center justify-between gap-2 ${
                adaptive.isCompact ? 'px-3 py-1.5' : 'px-6 py-2'
              } bg-sky-950/60 border-b border-sky-500/40 text-sky-200 text-xs yt-seek-banner flex-shrink-0`}
            >
              <div className="flex items-center gap-2 font-mono tabular-nums">
                <Play className="w-3.5 h-3.5 text-sky-400 fill-current flex-shrink-0" />
                <span>
                  Player seeked to <strong>{activeSeek.tsStr}</strong> ({activeSeek.seconds}s) · Cue #{activeSeek.cueIndex + 1}
                </span>
              </div>
              {winState.mode !== 'transcript' && (
                <button
                  type="button"
                  onClick={() => onChangeWinMode('transcript')}
                  className="text-sky-300 hover:text-white underline font-sans font-medium cursor-pointer"
                >
                  View cue in Transcript
                </button>
              )}
            </div>
          )}

          {/* Scrollable Content Body */}
          <div
            className={`${
              adaptive.isCompact ? 'p-3.5' : 'p-6'
            } flex-1 min-h-0 overflow-y-auto space-y-4 text-sm leading-relaxed text-zinc-200 yt-win-body`}
          >
            {fallbackNote && (
              <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs yt-note-line">
                <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>{fallbackNote}</span>
              </div>
            )}

            {/* Quick Window Action Bar */}
            <div className="flex items-center gap-2 p-2.5 bg-zinc-900/80 border border-zinc-800/80 rounded-xl text-xs flex-wrap yt-summary-page-bar">
              <a
                href={`https://www.youtube.com/watch?v=${videoId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 transition-colors font-medium yt-open-video-pill"
                title="Open this YouTube video in a new tab"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open video in new tab</span>
              </a>
              <button
                type="button"
                onClick={onToggleReadabilityMode}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 transition-colors font-medium yt-readability-pill cursor-pointer"
                title="Clean typography readability view"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Readability view</span>
              </button>
              <button
                type="button"
                onClick={onToggleExportMenu}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors font-medium yt-export-pill cursor-pointer"
                title="Export formatted summary or transcript"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
              </button>
              <button
                type="button"
                onClick={onOpenHistory}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 transition-colors font-medium yt-history-pill tabular-nums cursor-pointer"
                title="Browse previous summaries that were closed"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Previous summaries ({closedSummariesCount})</span>
              </button>
            </div>

            {/* Settings & Live System Prompt Inspector */}
            <div className="bg-zinc-900/90 rounded-xl p-4 border border-zinc-700/80 space-y-3 yt-transcript-processing-panel-settings">
              <div className="flex items-center justify-between flex-wrap gap-2.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-semibold text-zinc-100">Transcript Processing &amp; Persona</span>
                  <span className="text-xs text-zinc-400">
                    {transcriptMode === 'fast' ? 'Fast (Concise)' : 'Deep (Detailed)'} &middot; {personaPreset.label}
                  </span>
                </div>

                <div className="inline-flex rounded-lg bg-zinc-950 p-1 border border-zinc-700">
                  <button
                    type="button"
                    onClick={() => onSetTranscriptMode('fast')}
                    className={`px-3 py-1 rounded-md text-xs font-medium transition-all yt-tp-fast-btn cursor-pointer ${
                      transcriptMode === 'fast'
                        ? 'bg-sky-500 text-zinc-950 font-bold shadow-xs active'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    Fast (Concise)
                  </button>
                  <button
                    type="button"
                    onClick={() => onSetTranscriptMode('deep')}
                    className={`px-3 py-1 rounded-md text-xs font-medium transition-all yt-tp-deep-btn cursor-pointer ${
                      transcriptMode === 'deep'
                        ? 'bg-indigo-500 text-white font-bold shadow-xs active'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    Deep (Detailed)
                  </button>
                </div>
              </div>

              <div className="bg-black/50 rounded-lg p-3 border border-zinc-800 text-[11px] font-mono text-zinc-300 space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-1.5 text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
                  <span className="flex items-center gap-1.5 text-sky-400 whitespace-nowrap">
                    <Terminal className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>System Prompt Passed to Gemini</span>
                  </span>
                  <span className="text-zinc-500 font-normal font-sans lowercase truncate max-w-full">
                    systemInstruction.parts[0]
                  </span>
                </div>
                <p className="text-zinc-300 leading-relaxed font-sans text-xs italic bg-zinc-900/60 p-2 rounded border border-zinc-800/80 yt-system-prompt-preview whitespace-pre-line">
                  &ldquo;{effectiveSystemInstruction}&rdquo;
                </p>
                <div className="text-[11px] text-zinc-400 font-sans">
                  Active persona directive: {personaPreset.description}
                </div>
              </div>

              <label className="flex items-center justify-between gap-3 pt-2 border-t border-zinc-800/80 cursor-pointer text-xs text-zinc-300">
                <span className="font-medium">Auto-replace clickbait feed titles with AI titles (yields to DeArrow)</span>
                <input
                  type="checkbox"
                  checked={altTitlesEnabled}
                  onChange={(e) => onSetAltTitlesEnabled(e.target.checked)}
                  aria-label="Window Alternative AI Titles Setting"
                  className="rounded bg-zinc-800 border-zinc-700 text-sky-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer yt-window-alt-titles-setting"
                />
              </label>
            </div>

            {chapters.length >= 2 && (
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 space-y-2 yt-chapter-bar">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-semibold text-zinc-200">
                    Chapters ({chapters.length})
                  </span>
                  {chunkPlan.isLongVideoChunked && (
                    <span className="text-[11px] text-sky-400 font-medium tabular-nums yt-chapter-meta">
                      Chapter-Aware Chunked (&gt;45m) &middot; {chunkPlan.chunks.length} segments
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5 yt-chapter-list">
                  {chapters.map((ch) => {
                    const isActive =
                      activeSeek != null &&
                      activeSeek.seconds >= ch.startSec &&
                      (ch.endSec == null || activeSeek.seconds < ch.endSec);
                    return (
                      <button
                        key={ch.index}
                        type="button"
                        data-chapter-sec={ch.startSec}
                        data-chapter-ts={ch.tsStr}
                        onClick={() => onSeekTimestamp(ch.tsStr, ch.startSec)}
                        className={`yt-chapter-btn inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border text-xs transition-colors cursor-pointer whitespace-nowrap max-w-full ${
                          isActive
                            ? 'active bg-sky-500/20 text-sky-200 border-sky-400/60 font-semibold'
                            : 'bg-zinc-950/70 hover:bg-zinc-800 text-zinc-300 border-zinc-700/80'
                        }`}
                        title={`Jump to ${ch.tsStr} ${ch.title}`}
                      >
                        <span className="yt-chapter-ts font-mono tabular-nums text-sky-400 flex-shrink-0">
                          {ch.tsStr}
                        </span>
                        <span className="yt-chapter-title truncate max-w-[200px]">
                          {ch.title}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {winState.mode === 'summary' ? (
              <div className="space-y-4 prose prose-invert max-w-none">
                <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800/80">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-sky-400 tracking-wide uppercase">
                      {personaPreset.label} &middot; {transcriptMode === 'fast' ? 'Fast Brief' : 'Deep Breakdown'}
                    </span>
                    <span className="text-[10px] text-zinc-500 font-mono tabular-nums">
                      {transcriptMode === 'fast' ? '~1.5 min read' : '~5.0 min read'}
                    </span>
                  </div>
                  <div className="text-sm text-zinc-200 whitespace-pre-line leading-relaxed yt-summary-text-body">
                    <TimestampText
                      text={formatMathSymbolsInText(video.summary)}
                      onSeek={onSeekTimestamp}
                      activeSeekSec={activeSeek?.seconds ?? null}
                    />
                  </div>
                </div>

                <div className="bg-emerald-950/20 border border-emerald-900/40 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs uppercase tracking-wide">
                    <CheckCircle2 className="w-4 h-4" />
                    Fact-Check &amp; Google Search Grounding
                  </div>
                  <p className="text-xs text-zinc-300">
                    Verified against authoritative engineering papers and peer-reviewed telemetry. All claims supported.
                  </p>
                </div>

                <ResponseRatingBar
                  videoId={videoId}
                  targetType="summary"
                  targetId="main"
                  label="Rate this summary"
                  compact={adaptive.isCompact}
                  responseRatings={responseRatings}
                  openRatingNoteKey={openRatingNoteKey}
                  setOpenRatingNoteKey={setOpenRatingNoteKey}
                  onRateResponse={onRateResponse}
                  onShowToast={onShowToast}
                />
              </div>
            ) : (
              /* Transcript View with Search, Follow-Along Lock & Clickable Cues */
              <div className="space-y-3">
                {(() => {
                  const query = transcriptSearchQuery.trim();
                  const lines = formatMathSymbolsInText(video.transcript).split('\n');
                  const matches: { lineIdx: number; start: number; end: number }[] = [];
                  if (query) {
                    const qLower = query.toLowerCase();
                    lines.forEach((line, lineIdx) => {
                      const lineLower = line.toLowerCase();
                      let pos = lineLower.indexOf(qLower);
                      while (pos !== -1) {
                        matches.push({ lineIdx, start: pos, end: pos + qLower.length });
                        pos = lineLower.indexOf(qLower, pos + 1);
                      }
                    });
                  }

                  const totalMatches = matches.length;
                  const curActive = totalMatches > 0 ? activeMatchIndex % totalMatches : -1;

                  const jumpMatch = (delta: number) => {
                    if (totalMatches === 0) return;
                    onSetActiveMatchIndex((curActive + delta + totalMatches) % totalMatches);
                  };

                  const displayedLines =
                    transcriptFilterOnly && query
                      ? lines
                          .map((l, i) => ({ text: l, idx: i }))
                          .filter((item) => item.text.toLowerCase().includes(query.toLowerCase()))
                      : lines.map((l, i) => ({ text: l, idx: i }));

                  return (
                    <>
                      <div className="bg-[#181818] border border-zinc-700/80 rounded-xl p-2.5 flex flex-wrap items-center gap-2 text-xs">
                        <div className="relative flex-1 min-w-[160px] flex items-center">
                          <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5" />
                          <input
                            type="text"
                            value={transcriptSearchQuery}
                            onChange={(e) => {
                              onChangeTranscriptSearch(e.target.value);
                              onSetActiveMatchIndex(0);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                jumpMatch(e.shiftKey ? -1 : 1);
                              }
                            }}
                            placeholder="Search transcript (press Enter for next)..."
                            className="w-full bg-[#121212] border border-zinc-700 rounded-lg pl-8 pr-7 py-1 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-sky-500"
                          />
                          {query && (
                            <button
                              type="button"
                              onClick={() => {
                                onChangeTranscriptSearch('');
                                onSetActiveMatchIndex(0);
                              }}
                              className="absolute right-2 text-zinc-400 hover:text-white cursor-pointer"
                              title="Clear search"
                              aria-label="Clear transcript search"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 text-zinc-400 font-mono tabular-nums text-[11px] px-1">
                          {query ? (
                            totalMatches > 0 ? (
                              <span className="text-zinc-300 font-medium">
                                {curActive + 1} of {totalMatches}
                              </span>
                            ) : (
                              <span className="text-zinc-500">0 matches</span>
                            )
                          ) : (
                            <span className="text-zinc-500">Search keywords</span>
                          )}
                        </div>

                        <div className="flex items-center gap-0.5 border-l border-zinc-700 pl-2">
                          <button
                            type="button"
                            onClick={() => jumpMatch(-1)}
                            disabled={totalMatches === 0}
                            className="p-1 rounded hover:bg-zinc-700 text-zinc-300 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                            title="Previous match (Shift+Enter)"
                            aria-label="Previous match"
                          >
                            <ChevronUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => jumpMatch(1)}
                            disabled={totalMatches === 0}
                            className="p-1 rounded hover:bg-zinc-700 text-zinc-300 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                            title="Next match (Enter)"
                            aria-label="Next match"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <label className="flex items-center gap-1.5 text-zinc-400 hover:text-zinc-200 cursor-pointer border-l border-zinc-700 pl-2 select-none">
                          <input
                            type="checkbox"
                            checked={transcriptFilterOnly}
                            onChange={(e) => onChangeTranscriptFilterOnly(e.target.checked)}
                            className="rounded bg-zinc-800 border-zinc-700 text-sky-500 focus:ring-0"
                          />
                          <span className="text-[11px]">Filter lines</span>
                        </label>

                        {/* FEAT-01 Follow-Along Auto-Scroll Lock */}
                        <button
                          type="button"
                          onClick={onToggleFollowAlong}
                          aria-pressed={followAlong}
                          title={
                            followAlong
                              ? 'Follow-Along Lock ON: Auto-scrolls transcript to active TTS/seek cue'
                              : 'Follow-Along Lock OFF: Manual scroll preserved without auto-jumping'
                          }
                          className={`yt-follow-along-btn inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer ${
                            followAlong
                              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 active'
                              : 'bg-zinc-900 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                          }`}
                        >
                          {followAlong ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                          <span>{followAlong ? 'Follow-Along: ON' : 'Follow-Along: OFF'}</span>
                        </button>
                      </div>

                      <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800/80 font-mono text-xs space-y-2 text-zinc-300 max-h-96 overflow-y-auto yt-transcript-lines-container">
                        {displayedLines.length === 0 ? (
                          <div className="text-zinc-500 italic py-4 text-center font-sans">
                            No transcript lines match &ldquo;{query}&rdquo;
                          </div>
                        ) : (
                          displayedLines.map(({ text: line, idx: originalIdx }) => {
                            const isTtsSpeaking =
                              (tts.status === 'playing' || tts.status === 'paused') &&
                              activeTtsLine === originalIdx;
                            const isSeekTarget = activeSeek !== null && activeSeek.cueIndex === originalIdx;
                            const isHighlighted = isTtsSpeaking || isSeekTarget;

                            const attachScrollRef = (el: HTMLDivElement | null) => {
                              if (el && isHighlighted && followAlong) {
                                el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                              }
                            };

                            if (!query) {
                              return (
                                <div
                                  key={originalIdx}
                                  ref={isHighlighted ? attachScrollRef : undefined}
                                  data-line-idx={originalIdx}
                                  data-scroll-synced={isHighlighted ? (followAlong ? 'true' : 'paused') : 'false'}
                                  className={`yt-transcript-line flex items-start gap-2 py-1.5 px-2.5 rounded-lg transition-colors border ${
                                    isHighlighted
                                      ? 'yt-transcript-line-speaking bg-sky-500/15 border-sky-400/50 text-zinc-100 font-semibold'
                                      : 'border-transparent hover:bg-zinc-800/40'
                                  }`}
                                >
                                  {isTtsSpeaking && (
                                    <span className="yt-speaking-indicator inline-flex items-center gap-1 text-[10px] font-mono text-sky-400 bg-sky-950/70 px-1.5 py-0.5 rounded border border-sky-500/40 flex-shrink-0">
                                      <Volume2 className="w-3 h-3 text-sky-400" />
                                      <span>Speaking</span>
                                    </span>
                                  )}
                                  <span className="flex-1">
                                    <TimestampText
                                      text={line}
                                      onSeek={onSeekTimestamp}
                                      activeSeekSec={activeSeek?.seconds ?? null}
                                      compact
                                    />
                                  </span>
                                </div>
                              );
                            }

                            const lineLower = line.toLowerCase();
                            const qLower = query.toLowerCase();
                            const parts: React.ReactNode[] = [];
                            let lastIdx = 0;
                            let matchOccurrence = 0;

                            while (lastIdx < line.length) {
                              const foundIdx = lineLower.indexOf(qLower, lastIdx);
                              if (foundIdx === -1) {
                                parts.push(line.slice(lastIdx));
                                break;
                              }
                              if (foundIdx > lastIdx) {
                                parts.push(line.slice(lastIdx, foundIdx));
                              }
                              const globalMatchIdx = matches.findIndex(
                                (m) => m.lineIdx === originalIdx && m.start === foundIdx
                              );
                              const isActive = globalMatchIdx === curActive;

                              parts.push(
                                <mark
                                  key={`${foundIdx}-${matchOccurrence++}`}
                                  className={`rounded px-1 py-0.5 transition-all ${
                                    isActive
                                      ? 'bg-amber-400 text-zinc-950 font-bold ring-2 ring-sky-400 shadow-sm'
                                      : 'bg-amber-500/30 text-amber-200 font-medium'
                                  }`}
                                >
                                  {line.slice(foundIdx, foundIdx + qLower.length)}
                                </mark>
                              );
                              lastIdx = foundIdx + qLower.length;
                            }

                            return (
                              <div
                                key={originalIdx}
                                ref={isHighlighted ? attachScrollRef : undefined}
                                data-line-idx={originalIdx}
                                data-scroll-synced={isHighlighted ? (followAlong ? 'true' : 'paused') : 'false'}
                                className={`yt-transcript-line flex items-start gap-2 py-1.5 px-2.5 rounded-lg transition-colors border ${
                                  isHighlighted
                                    ? 'yt-transcript-line-speaking bg-sky-500/15 border-sky-400/50 text-zinc-100 font-semibold'
                                    : line.toLowerCase().includes(query.toLowerCase())
                                    ? 'border-transparent bg-zinc-800/40 hover:bg-zinc-800/60'
                                    : 'border-transparent hover:bg-zinc-800/40'
                                }`}
                              >
                                {isTtsSpeaking && (
                                  <span className="yt-speaking-indicator inline-flex items-center gap-1 text-[10px] font-mono text-sky-400 bg-sky-950/70 px-1.5 py-0.5 rounded border border-sky-500/40 flex-shrink-0">
                                    <Volume2 className="w-3 h-3 text-sky-400" />
                                    <span>Speaking</span>
                                  </span>
                                )}
                                <span className="flex-1">{parts}</span>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </>
                  );
                })()}

                <ResponseRatingBar
                  videoId={videoId}
                  targetType="transcript"
                  targetId="main"
                  label="Rate this transcript"
                  compact={adaptive.isCompact}
                  responseRatings={responseRatings}
                  openRatingNoteKey={openRatingNoteKey}
                  setOpenRatingNoteKey={setOpenRatingNoteKey}
                  onRateResponse={onRateResponse}
                  onShowToast={onShowToast}
                />
              </div>
            )}

            {/* Follow-up Discussion Thread */}
            {turns.length > 0 && (
              <div className="mt-6 pt-5 border-t border-zinc-800/80 space-y-4 yt-thread-wrap">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                  <Bot className="w-3.5 h-3.5 text-sky-400" />
                  <span>Follow-up Discussion</span>
                </div>
                {turns.map((turn, tIdx) => (
                  <div key={tIdx} className="space-y-2">
                    <div className="flex justify-end">
                      <div className="bg-sky-600 text-white rounded-2xl rounded-tr-xs px-4 py-2 text-xs max-w-[85%] shadow-xs flex items-center gap-1.5 yt-user-bubble">
                        {turn.isVoice && <Mic className="w-3 h-3 text-sky-200" />}
                        <span>{formatMathSymbolsInText(turn.q)}</span>
                      </div>
                    </div>
                    <div className="flex justify-start">
                      <div className="bg-zinc-800/90 border border-zinc-700/60 rounded-2xl rounded-tl-xs p-3 text-xs text-zinc-200 max-w-[92%] space-y-2 shadow-xs yt-ans-bubble">
                        <div className="flex items-center justify-between gap-2 border-b border-zinc-700/40 pb-1.5 text-[10px] text-zinc-400">
                          <span className="font-mono text-sky-400 font-semibold">{turn.model}</span>
                          {turn.sources && turn.sources.length > 0 && (
                            <span className="inline-flex items-center gap-1 text-emerald-400">
                              <Globe className="w-2.5 h-2.5" />
                              <span>Grounded</span>
                            </span>
                          )}
                        </div>
                        <div className="leading-relaxed whitespace-pre-line">
                          <TimestampText
                            text={formatMathSymbolsInText(turn.a)}
                            onSeek={onSeekTimestamp}
                            activeSeekSec={activeSeek?.seconds ?? null}
                            compact
                          />
                        </div>
                        {turn.imageUri && (
                          <div className="mt-2 rounded-lg overflow-hidden border border-zinc-700/60 bg-zinc-900">
                            <img
                              src={turn.imageUri}
                              referrerPolicy="no-referrer"
                              alt="Generated Structural Diagram"
                              className="w-full h-36 object-cover"
                            />
                            <div className="p-1.5 bg-zinc-950 text-[10px] text-zinc-400 flex items-center gap-1 font-mono">
                              <ImageIcon className="w-3 h-3 text-purple-400" />
                              <span>gemini-nano-banana-2.1 &middot; Structural Diagram</span>
                            </div>
                          </div>
                        )}
                        {turn.sources && turn.sources.length > 0 && (
                          <div className="pt-1 border-t border-zinc-700/30 flex flex-wrap gap-1.5">
                            {turn.sources.map((s, sIdx) => (
                              <a
                                key={sIdx}
                                href={s.uri}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[10px] text-sky-400 hover:text-sky-300 bg-sky-950/40 px-2 py-0.5 rounded border border-sky-500/20 truncate max-w-full inline-flex items-center gap-1"
                              >
                                <ExternalLink className="w-2.5 h-2.5 flex-shrink-0" />
                                <span className="truncate">{s.title}</span>
                              </a>
                            ))}
                          </div>
                        )}
                        <ResponseRatingBar
                          videoId={videoId}
                          targetType="followup"
                          targetId={`turn_${tIdx}`}
                          label="Rate answer"
                          compact
                          responseRatings={responseRatings}
                          openRatingNoteKey={openRatingNoteKey}
                          setOpenRatingNoteKey={setOpenRatingNoteKey}
                          onRateResponse={onRateResponse}
                          onShowToast={onShowToast}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {isAnsweringFollowUp && (
              <div className="mt-3 p-3 bg-zinc-800/40 border border-zinc-700/40 rounded-xl text-xs text-sky-300 flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-sky-400" />
                <span>Gemini is generating verified response with Google Search grounding&hellip;</span>
              </div>
            )}
          </div>

          {/* Bottom Composer */}
          <div className="p-3 border-t border-zinc-800 bg-[#121212] space-y-2 yt-composer-wrap">
            <div className="flex flex-wrap items-center justify-between gap-1.5 text-[11px] text-zinc-400 px-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-mono text-zinc-500">MODEL:</span>
                {(['gemini-4-argon', 'gemini-3.8-flash', 'gemini-3.1-flash-lite'] as const).map((mId) => {
                  const isSel = composerModel === mId;
                  const label =
                    mId === 'gemini-4-argon'
                      ? 'Argon (Complex)'
                      : mId === 'gemini-3.8-flash'
                      ? 'Flash (General)'
                      : 'Lite (Fast)';
                  return (
                    <button
                      key={mId}
                      type="button"
                      onClick={() => onSelectComposerModel(mId)}
                      className={`px-2 py-0.5 rounded-full text-[10px] transition-colors cursor-pointer ${
                        isSel
                          ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-semibold'
                          : 'hover:bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {adaptive.isCompact ? label.split(' ')[0] : label}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {Boolean(composerText.trim()) && (
                  <span
                    className="yt-composer-draft-badge inline-flex items-center gap-1 text-[10px] text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full font-medium"
                    title="Unfinished question draft auto-saved to local storage"
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>Draft auto-saved</span>
                  </span>
                )}
                <button
                  type="button"
                  onClick={onToggleComposerGSearch}
                  title="Toggle Google Search Grounding tool"
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] transition-colors cursor-pointer ${
                    composerGSearch
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-medium'
                      : 'hover:bg-zinc-800 text-zinc-500 border border-transparent'
                  }`}
                >
                  <Globe className="w-2.5 h-2.5" />
                  <span>{adaptive.isCompact ? 'Search' : 'Google Search'}</span>
                </button>
                <button
                  type="button"
                  onClick={onToggleComposerGMaps}
                  title="Toggle Google Maps Grounding tool"
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] transition-colors cursor-pointer ${
                    composerGMaps
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-medium'
                      : 'hover:bg-zinc-800 text-zinc-500 border border-transparent'
                  }`}
                >
                  <MapPin className="w-2.5 h-2.5" />
                  <span>{adaptive.isCompact ? 'Maps' : 'Google Maps'}</span>
                </button>
              </div>
            </div>

            <div className="flex gap-2 items-center">
              <input
                type="text"
                value={composerText}
                onChange={(e) => onChangeComposerText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    onSendFollowUp();
                  }
                }}
                placeholder="Ask follow-up, request diagram, or use mic (Enter to send)..."
                className="flex-1 min-w-0 bg-zinc-900 border border-zinc-700/80 rounded-full px-4 py-2 text-xs text-zinc-200 focus:outline-none focus:border-sky-500 placeholder:text-zinc-500 yt-composer-textarea"
              />
              <button
                type="button"
                onClick={onToggleVoiceInput}
                title={
                  isRecordingVoice
                    ? 'Listening... click to stop'
                    : 'Voice input (gemini-3.5-transcribe / Web Speech)'
                }
                aria-label="Voice input"
                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all yt-composer-mic-btn cursor-pointer ${
                  isRecordingVoice
                    ? 'bg-red-500 text-white ring-2 ring-red-400/60 shadow-lg yt-mic-recording'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                }`}
              >
                {isRecordingVoice ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={onSendFollowUp}
                disabled={isAnsweringFollowUp || !composerText.trim()}
                className="px-3.5 py-2 bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:hover:bg-sky-500 text-zinc-950 font-semibold rounded-full text-xs transition-colors flex items-center gap-1.5 flex-shrink-0 yt-composer-send-btn cursor-pointer"
              >
                <Send className="w-3 h-3" />
                <span>Send</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
