import React from 'react';
import {
  Sparkles,
  Play,
  Layers,
  Clock,
  Zap,
  Sun,
  Moon,
  RefreshCw,
  FileText,
  Music,
  Shield,
  SlidersHorizontal
} from 'lucide-react';
import {
  normalizeHistoryTabVisibility,
  normalizeSummaryPersona,
  resolveAutoTitleDecision,
  SUMMARY_PERSONA_PRESETS,
  type ChannelTitleRule,
  type HistoryTabVisibility,
  type SummaryPersona
} from '../utils/userscript-helpers';
import type { MockVideo } from './SimulatorTypes';

interface FeedSimulatorGridProps {
  videos: MockVideo[];
  altTitlesEnabled: boolean;
  onSetAltTitlesEnabled: (enabled: boolean) => void;
  dearrowSimulated: boolean;
  onSetDearrowSimulated: (enabled: boolean) => void;
  simulatedYouTubeTheme: 'dark' | 'light';
  onSetSimulatedYouTubeTheme: (theme: 'dark' | 'light') => void;
  historyTabVisibility: HistoryTabVisibility;
  onSetHistoryTabVisibility: (vis: HistoryTabVisibility) => void;
  summaryPersona: SummaryPersona;
  onSetSummaryPersona: (persona: SummaryPersona) => void;
  channelTitleRules: Record<string, 'exempt' | 'force_ai'>;
  onSetChannelTitleRule: (channelName: string, rule: ChannelTitleRule) => void;
  ruleMenuOpenId: string | null;
  setRuleMenuOpenId: React.Dispatch<React.SetStateAction<string | null>>;
  dearrowToggledOriginal: Record<string, boolean>;
  setDearrowToggledOriginal: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  cardTitleModes: Record<string, 'original' | 'dearrow' | 'ai'>;
  onToggleCardTitle: (videoId: string, video: MockVideo) => void;
  activeMenuId: string | null;
  setActiveMenuId: React.Dispatch<React.SetStateAction<string | null>>;
  onOpenVideoWindow: (video: MockVideo) => void;
}

export const FeedSimulatorGrid: React.FC<FeedSimulatorGridProps> = ({
  videos,
  altTitlesEnabled,
  onSetAltTitlesEnabled,
  dearrowSimulated,
  onSetDearrowSimulated,
  simulatedYouTubeTheme,
  onSetSimulatedYouTubeTheme,
  historyTabVisibility,
  onSetHistoryTabVisibility,
  summaryPersona,
  onSetSummaryPersona,
  channelTitleRules,
  onSetChannelTitleRule,
  ruleMenuOpenId,
  setRuleMenuOpenId,
  dearrowToggledOriginal,
  setDearrowToggledOriginal,
  cardTitleModes,
  onToggleCardTitle,
  activeMenuId,
  setActiveMenuId,
  onOpenVideoWindow
}) => {
  const resolveCardState = (video: MockVideo) => {
    const hasDearrow = Boolean(dearrowSimulated && video.dearrowTitle);
    const decision = resolveAutoTitleDecision({
      altTitlesEnabled,
      isMusic: video.isMusic,
      hasDeArrowTitle: hasDearrow,
      channelName: video.channel,
      channelRules: channelTitleRules,
      manualOverride: cardTitleModes[video.id] || null
    });

    let displayTitle = video.originalTitle || video.title;
    if (decision.mode === 'music') {
      displayTitle = video.title;
    } else if (decision.mode === 'ai') {
      displayTitle = video.aiTitle || video.title;
    } else if (decision.mode === 'dearrow') {
      displayTitle = dearrowToggledOriginal[video.id]
        ? (video.originalTitle || video.title)
        : (video.dearrowTitle || video.title);
    }

    return { decision, displayTitle, hasDearrow };
  };

  return (
    <>
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-lg font-semibold text-white">Interactive YouTube Feed Simulator</h2>
            <span className="text-xs text-emerald-400 font-medium">
              Userscript v2.11.0 Active
            </span>
          </div>
          <p className="text-xs text-zinc-400 max-w-2xl">
            Click the 3-dot menu on any video card to test the injected{' '}
            <strong className="text-zinc-200">Summarize</strong> action, inspect per-channel title rules next to any title, or jump directly to timestamped sections inside floating windows.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs text-zinc-400 bg-zinc-950/90 px-3.5 py-2 rounded-xl border border-zinc-800 whitespace-nowrap">
          <span>Dockable Tabs</span>
          <span aria-hidden="true">·</span>
          <span>Zero-Click Summary</span>
          <span aria-hidden="true">·</span>
          <span>Trusted Types Clean</span>
        </div>
      </div>

      {/* Alternative AI Titles, DeArrow & Global Simulator Controls */}
      <div className="bg-[#11151d] border border-zinc-800 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-400 border border-sky-500/25 flex items-center justify-center flex-shrink-0 mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-white">Alternative Non-Clickbait AI Titles</span>
              <span className="text-xs text-zinc-400">
                ON by default · Yields to DeArrow · Per-channel rules persisted
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 max-w-2xl">
              Generates concise factual titles (strictly &le; 150 chars). Use the shield button next to any card title to configure per-channel Exempt or Always AI rules.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Global Auto-Title Setting */}
          <label className="flex items-center gap-2 cursor-pointer bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-700/80 hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={altTitlesEnabled}
              onChange={(e) => onSetAltTitlesEnabled(e.target.checked)}
              aria-label="Alternative AI Titles Setting"
              className="rounded bg-zinc-800 border-zinc-700 text-sky-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer yt-alt-titles-setting-toggle"
            />
            <span className="text-xs font-medium text-zinc-200 whitespace-nowrap">Alternative AI Titles Setting</span>
          </label>

          {/* DeArrow Simulation Toggle */}
          <label className="flex items-center gap-2 cursor-pointer bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-700/80 hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={dearrowSimulated}
              onChange={(e) => onSetDearrowSimulated(e.target.checked)}
              className="rounded bg-zinc-800 border-zinc-700 text-indigo-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer"
            />
            <span className="text-xs font-medium text-zinc-200 whitespace-nowrap">Simulate DeArrow Installed</span>
          </label>

          {/* YouTube Theme Simulation Toggle */}
          <button
            type="button"
            onClick={() => onSetSimulatedYouTubeTheme(simulatedYouTubeTheme === 'dark' ? 'light' : 'dark')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              simulatedYouTubeTheme === 'dark'
                ? 'bg-zinc-900 text-zinc-200 border-zinc-700 hover:border-zinc-500 hover:bg-zinc-800'
                : 'bg-amber-500/15 text-amber-300 border-amber-500/40 hover:bg-amber-500/25'
            }`}
            title="Toggle YouTube theme between Dark and Light mode to test automatic Reader View synchronization"
          >
            {simulatedYouTubeTheme === 'dark' ? (
              <>
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span>YouTube: Dark Mode</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>YouTube: Light Mode</span>
              </>
            )}
          </button>

          {/* Summary Persona Default */}
          <label className="flex items-center gap-2 bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-700/80 text-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
            <span className="text-zinc-300 font-medium whitespace-nowrap">Persona:</span>
            <select
              aria-label="Default Summary Persona"
              value={summaryPersona}
              onChange={(e) => onSetSummaryPersona(normalizeSummaryPersona(e.target.value))}
              className="bg-[#212121] text-zinc-100 border border-zinc-700 rounded-lg px-2 py-0.5 text-xs focus:outline-none cursor-pointer yt-global-persona-select"
              style={{ colorScheme: 'dark' }}
            >
              {(Object.keys(SUMMARY_PERSONA_PRESETS) as SummaryPersona[]).map((key) => (
                <option key={key} value={key} className="bg-[#212121] text-zinc-100">
                  {SUMMARY_PERSONA_PRESETS[key].label}
                </option>
              ))}
            </select>
          </label>

          {/* History Dock Tab Visibility Setting */}
          <label className="flex items-center gap-2 bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-700/80 text-xs">
            <Clock className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
            <span className="text-zinc-300 font-medium whitespace-nowrap">History tab:</span>
            <select
              aria-label="History dock tab visibility"
              value={historyTabVisibility}
              onChange={(e) => onSetHistoryTabVisibility(normalizeHistoryTabVisibility(e.target.value))}
              className="bg-[#212121] text-zinc-100 border border-zinc-700 rounded-lg px-2 py-0.5 text-xs focus:outline-none cursor-pointer yt-history-visibility-select"
              style={{ colorScheme: 'dark' }}
            >
              <option value="always" className="bg-[#212121] text-zinc-100">Always shown</option>
              <option value="with_tabs" className="bg-[#212121] text-zinc-100">Only with open/minimized tabs</option>
              <option value="never" className="bg-[#212121] text-zinc-100">Never shown</option>
            </select>
          </label>
        </div>
      </div>

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video) => {
          const { decision, displayTitle, hasDearrow } = resolveCardState(video);
          const ruleMenuOpen = ruleMenuOpenId === video.id;

          return (
            <div
              key={video.id}
              data-card-video-id={video.id}
              data-channel-name={video.channel}
              className="bg-[#181818] border border-zinc-800/80 rounded-2xl hover:border-zinc-700 transition-colors flex flex-col group relative"
            >
              {/* Thumbnail */}
              <div className="w-full aspect-video bg-gradient-to-br from-zinc-800 to-zinc-900 relative flex items-center justify-center rounded-t-2xl overflow-hidden">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                <div className="w-12 h-12 rounded-full bg-black/60 flex items-center justify-center text-zinc-300 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all shadow-lg">
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                </div>
                <span className="absolute bottom-2.5 right-2.5 bg-black/80 text-white text-[11px] font-medium font-mono tabular-nums px-1.5 py-0.5 rounded">
                  {video.duration}
                </span>
                <span className="absolute top-2.5 left-2.5 bg-black/75 text-zinc-200 border border-zinc-700/70 text-[10px] font-medium px-2 py-0.5 rounded">
                  {video.badge}
                </span>
                {hasDearrow && !video.isMusic && (
                  <div
                    className="cbThumbnailButtonContainer absolute top-2.5 right-2.5 z-10 flex items-center gap-1 bg-black/75 backdrop-blur-sm border border-indigo-500/40 rounded-md px-1.5 py-0.5 text-indigo-300 text-[10px]"
                    title="DeArrow: Thumbnail overlay (no collision with summariser)"
                  >
                    <Zap className="w-3 h-3 text-indigo-400 fill-indigo-400/20" />
                    <span>DeArrow</span>
                  </div>
                )}
              </div>

              {/* Metadata & 3-Dot Menu */}
              <div className="p-4 flex gap-3 flex-1">
                <div className="w-9 h-9 rounded-full bg-zinc-700 flex-shrink-0 flex items-center justify-center text-xs font-semibold text-zinc-300">
                  {video.channel[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start gap-1.5 flex-wrap relative">
                    <h3 className="font-medium text-sm text-zinc-100 line-clamp-2 leading-snug group-hover:text-sky-400 transition-colors inline yt-card-display-title">
                      {displayTitle}
                    </h3>

                    {/* DeArrow Native Title Button Container */}
                    {hasDearrow && !video.isMusic && (
                      <div className="cbTitleButtonContainer inline-flex items-center gap-1 flex-shrink-0" title="DeArrow: Show original title / Submit title">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDearrowToggledOriginal((prev) => ({
                              ...prev,
                              [video.id]: !prev[video.id]
                            }));
                          }}
                          className="cbButton cbTitleButton inline-flex items-center justify-center p-1 rounded transition-colors border bg-zinc-800 text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/20 hover:border-indigo-500/50 cursor-pointer"
                          title={dearrowToggledOriginal[video.id] ? 'DeArrow: Show DeArrow title' : 'DeArrow: Show original title'}
                          aria-label="DeArrow title toggle"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Alternative Title Toggle + Per-Channel Rule Selector */}
                    {!video.isMusic ? (
                      <>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleCardTitle(video.id, video);
                          }}
                          className={`inline-flex items-center justify-center p-1 rounded transition-colors border yt-alt-title-btn flex-shrink-0 cursor-pointer ${
                            decision.mode === 'ai'
                              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 hover:bg-sky-500/30'
                              : decision.mode === 'dearrow'
                              ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 hover:bg-indigo-500/30'
                              : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-zinc-200 hover:bg-zinc-700'
                          }`}
                          title={
                            decision.mode === 'ai'
                              ? (hasDearrow
                                  ? 'Showing AI summary title (Click to switch to DeArrow title)'
                                  : 'Showing AI summary title (Click to switch to original title)')
                              : decision.mode === 'dearrow'
                              ? 'Showing DeArrow title (Click to switch to AI summary title)'
                              : 'Showing original title (Click to switch to AI summary title)'
                          }
                          aria-label={`Switch title mode for ${video.channel}`}
                        >
                          {decision.mode === 'ai' ? (
                            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                          ) : decision.mode === 'dearrow' ? (
                            <Zap className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20" />
                          ) : (
                            <FileText className="w-3.5 h-3.5 text-zinc-400" />
                          )}
                        </button>

                        {/* FEAT-02 Per-Channel Auto-Title Rule Button & Inline Menu */}
                        <div className="relative inline-flex">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveMenuId(null);
                              setRuleMenuOpenId((prev) => (prev === video.id ? null : video.id));
                            }}
                            data-channel-rule={decision.rule}
                            aria-expanded={ruleMenuOpen}
                            aria-label={`Channel title rule for ${video.channel}`}
                            title={
                              decision.rule === 'exempt'
                                ? `Channel rule: Exempt (${video.channel} keeps original / DeArrow)`
                                : decision.rule === 'force_ai'
                                ? `Channel rule: Always AI (${video.channel} prefers AI title)`
                                : `Channel title rule for ${video.channel}: Default (click to configure)`
                            }
                            className={`inline-flex items-center justify-center p-1 rounded transition-colors border yt-channel-rule-btn flex-shrink-0 cursor-pointer ${
                              decision.rule === 'exempt'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                                : decision.rule === 'force_ai'
                                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                                : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-zinc-200 hover:bg-zinc-700'
                            }`}
                          >
                            <Shield className="w-3.5 h-3.5" />
                          </button>

                          {ruleMenuOpen && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              role="menu"
                              aria-label={`Auto-title rule options for ${video.channel}`}
                              className="yt-channel-rule-menu absolute right-0 top-7 w-60 bg-[#222222] border border-zinc-700 rounded-xl shadow-2xl p-1.5 z-50 text-xs text-zinc-200 space-y-0.5"
                            >
                              <div className="px-2.5 py-1 text-[11px] font-semibold text-zinc-400 border-b border-zinc-800 mb-1 truncate">
                                Channel rule: {video.channel}
                              </div>
                              {(
                                [
                                  { id: 'default', label: 'Default (yields to DeArrow)' },
                                  { id: 'exempt', label: 'Exempt (keep original / DeArrow)' },
                                  { id: 'force_ai', label: 'Always AI title' }
                                ] as const
                              ).map((opt) => (
                                <button
                                  key={opt.id}
                                  type="button"
                                  role="menuitemradio"
                                  aria-checked={decision.rule === opt.id}
                                  data-rule-option={opt.id}
                                  onClick={() => onSetChannelTitleRule(video.channel, opt.id)}
                                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                                    decision.rule === opt.id
                                      ? 'bg-sky-500/20 text-sky-300 font-semibold'
                                      : 'hover:bg-zinc-800 text-zinc-300'
                                  }`}
                                >
                                  <span>{opt.label}</span>
                                  {decision.rule === opt.id && <span aria-hidden="true">✓</span>}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </>
                    ) : (
                      <span
                        className="inline-flex items-center justify-center p-1 rounded text-pink-400 bg-pink-500/10 border border-pink-500/20 cursor-help yt-music-exempt-icon flex-shrink-0"
                        title="Music video (exempt from title replacement)"
                      >
                        <Music className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-1">
                    <span>{video.channel}</span>
                    {decision.rule !== 'default' && !video.isMusic && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className={decision.rule === 'exempt' ? 'text-amber-400 font-medium' : 'text-emerald-400 font-medium'}>
                          {decision.rule === 'exempt' ? 'Rule: Exempt' : 'Rule: Always AI'}
                        </span>
                      </>
                    )}
                  </div>
                  <p className="text-[11px] text-zinc-500 tabular-nums">{video.views}</p>
                </div>

                {/* 3-Dot Action Button */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setRuleMenuOpenId(null);
                      setActiveMenuId(activeMenuId === video.id ? null : video.id);
                    }}
                    className="p-1.5 rounded-full hover:bg-zinc-700/60 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                    title="Action menu"
                  >
                    <span className="text-lg leading-none font-bold">⋮</span>
                  </button>

                  {activeMenuId === video.id && (
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="absolute right-0 top-8 w-56 bg-[#282828] border border-zinc-700/80 rounded-xl shadow-2xl py-1.5 z-40 text-xs text-zinc-200"
                    >
                      <div className="px-3.5 py-2 hover:bg-zinc-700/50 cursor-pointer flex items-center gap-2.5">
                        <Layers className="w-4 h-4 text-zinc-400" />
                        <span>Save to playlist</span>
                      </div>

                      <div
                        onClick={() => onOpenVideoWindow(video)}
                        className="px-3.5 py-2.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 font-medium cursor-pointer flex items-center gap-2.5 border-y border-sky-500/20 transition-colors"
                      >
                        <Sparkles className="w-5 h-5 text-sky-400 fill-sky-400/20" />
                        <span className="text-[15px] font-medium tracking-tight">Summarize</span>
                        <span className="ml-auto text-[10px] bg-sky-400/20 text-sky-300 px-1.5 py-0.2 rounded font-mono">
                          Gemini
                        </span>
                      </div>

                      <div className="px-3.5 py-2 hover:bg-zinc-700/50 cursor-pointer flex items-center gap-2.5">
                        <span className="text-sm">↓</span>
                        <span>Download</span>
                      </div>
                      <div className="px-3.5 py-2 hover:bg-zinc-700/50 cursor-pointer flex items-center gap-2.5">
                        <Clock className="w-4 h-4 text-zinc-400" />
                        <span>Watch later</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
};
