import React from 'react';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import {
  buildResponseRatingKey,
  type ResponseRatingRecord
} from '../utils/userscript-helpers';

interface ResponseRatingBarProps {
  videoId: string;
  targetType: 'summary' | 'transcript' | 'followup';
  targetId?: string;
  label?: string;
  compact?: boolean;
  theme?: 'system' | 'light' | 'sepia' | 'dark';
  responseRatings: Record<string, ResponseRatingRecord>;
  openRatingNoteKey: string | null;
  setOpenRatingNoteKey: React.Dispatch<React.SetStateAction<string | null>>;
  onRateResponse: (
    videoId: string,
    targetType: 'summary' | 'transcript' | 'followup',
    rating: 'up' | 'down',
    targetId: string,
    note?: string
  ) => void;
  onShowToast: (msg: string, targetVideoId?: string | null) => void;
}

export const ResponseRatingBar: React.FC<ResponseRatingBarProps> = ({
  videoId,
  targetType,
  targetId = 'main',
  label = 'Rate this summary',
  compact = false,
  theme = 'dark',
  responseRatings,
  openRatingNoteKey,
  setOpenRatingNoteKey,
  onRateResponse,
  onShowToast
}) => {
  const key = buildResponseRatingKey(videoId, targetType, targetId);
  const current = responseRatings[key];
  const isLight = theme === 'light' || theme === 'sepia';

  const containerCls = isLight
    ? 'border-black/10 bg-black/[0.03] text-zinc-700'
    : 'border-zinc-800/80 bg-zinc-900/50 text-zinc-400';

  const btnIdleCls = isLight
    ? 'bg-black/[0.04] hover:bg-black/[0.08] border-black/10 text-zinc-700'
    : 'bg-zinc-800/70 hover:bg-zinc-700/80 border-zinc-700/80 text-zinc-300';

  return (
    <div
      className={`flex flex-wrap items-center justify-between gap-2 rounded-xl border yt-rating-bar ${
        compact ? 'px-2.5 py-1.5 text-[11px] mt-1.5 compact' : 'px-3.5 py-2.5 text-xs mt-4'
      } ${containerCls}`}
      data-rating-target={targetType}
      data-rating-id={targetId}
    >
      <div className="flex items-center gap-2 flex-wrap">
        <span className="font-medium yt-rating-label">{label}</span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => onRateResponse(videoId, targetType, 'up', targetId)}
            aria-pressed={current?.rating === 'up'}
            data-rating="up"
            title="Helpful response (Thumbs Up)"
            className={`inline-flex items-center gap-1 rounded-lg border font-medium transition-colors cursor-pointer yt-rating-btn yt-rating-up ${
              compact ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
            } ${
              current?.rating === 'up'
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 active'
                : btnIdleCls
            }`}
          >
            <ThumbsUp className={compact ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
            <span>Helpful</span>
          </button>
          <button
            type="button"
            onClick={() => onRateResponse(videoId, targetType, 'down', targetId)}
            aria-pressed={current?.rating === 'down'}
            data-rating="down"
            title="Needs improvement (Thumbs Down)"
            className={`inline-flex items-center gap-1 rounded-lg border font-medium transition-colors cursor-pointer yt-rating-btn yt-rating-down ${
              compact ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
            } ${
              current?.rating === 'down'
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/50 active'
                : btnIdleCls
            }`}
          >
            <ThumbsDown className={compact ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
            <span>Not helpful</span>
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {current && (
          <span className="text-[11px] font-medium text-sky-400 yt-rating-status">
            {current.rating === 'up' ? 'Rated Helpful' : 'Feedback saved'}
          </span>
        )}
        <button
          type="button"
          onClick={() => setOpenRatingNoteKey((prev) => (prev === key ? null : key))}
          className="text-[11px] text-zinc-400 hover:text-zinc-200 underline cursor-pointer yt-rating-note-toggle"
        >
          {openRatingNoteKey === key ? 'Hide note' : current?.note ? 'Edit note' : 'Add note'}
        </button>
      </div>

      {openRatingNoteKey === key && (
        <div className="w-full flex items-center gap-2 pt-1.5 border-t border-zinc-800/60">
          <input
            type="text"
            defaultValue={current?.note || ''}
            placeholder="Optional feedback note..."
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                const val = (e.currentTarget as HTMLInputElement).value.trim();
                onRateResponse(videoId, targetType, current?.rating || 'up', targetId, val);
                setOpenRatingNoteKey(null);
                onShowToast('✓ Rating feedback saved', videoId);
              }
            }}
            onBlur={(e) => {
              const val = e.currentTarget.value.trim();
              if (val || current?.note) {
                onRateResponse(videoId, targetType, current?.rating || 'up', targetId, val);
              }
            }}
            className="flex-1 bg-zinc-950/70 border border-zinc-700/80 rounded-lg px-2.5 py-1 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-sky-500 yt-rating-note-input"
          />
        </div>
      )}
    </div>
  );
};
