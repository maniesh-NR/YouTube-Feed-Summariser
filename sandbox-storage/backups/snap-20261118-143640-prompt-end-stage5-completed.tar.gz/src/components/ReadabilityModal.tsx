import React from 'react';
import {
  X,
  RefreshCw,
  Download,
  Printer,
  FileCode
} from 'lucide-react';
import {
  parseEditorialBlocks,
  parseTimestampStringToSeconds,
  type ActiveSeekState,
  type MockVideo
} from './SimulatorTypes';
import { TimestampText } from './TimestampText';
import { SUMMARY_PERSONA_PRESETS, type SummaryPersona } from '../utils/userscript-helpers';

interface ReadabilityModalProps {
  video: MockVideo;
  mode: 'summary' | 'transcript';
  persona: SummaryPersona;
  theme: 'system' | 'light' | 'sepia' | 'dark';
  font: 'serif' | 'sans';
  fontSize: number;
  syncYouTubeTheme: boolean;
  simulatedYouTubeTheme: 'dark' | 'light';
  activeSeek?: ActiveSeekState | null;
  onExit: () => void;
  onToggleSyncYouTubeTheme: () => void;
  onSelectTheme: (theme: 'system' | 'light' | 'sepia' | 'dark') => void;
  onToggleFont: () => void;
  onChangeFontSize: (delta: number) => void;
  onExportTxt: () => void;
  onExportPdf: () => void;
  onExportJson: () => void;
  onExportMarkdown: () => void;
  onSeekTimestamp: (tsStr: string, seconds: number) => void;
}

export const ReadabilityModal: React.FC<ReadabilityModalProps> = ({
  video,
  mode,
  persona,
  theme,
  font,
  fontSize,
  syncYouTubeTheme,
  simulatedYouTubeTheme,
  activeSeek,
  onExit,
  onToggleSyncYouTubeTheme,
  onSelectTheme,
  onToggleFont,
  onChangeFontSize,
  onExportTxt,
  onExportPdf,
  onExportJson,
  onExportMarkdown,
  onSeekTimestamp
}) => {
  const themeContainerBg =
    theme === 'light'
      ? 'bg-[#fdfbf7] text-[#1f2328]'
      : theme === 'sepia'
      ? 'bg-[#f4ecd8] text-[#433422]'
      : 'bg-[#0a0a0c] text-zinc-100';
  const themeBarBg =
    theme === 'light'
      ? 'bg-[#f6f4ee]/95 border-[#e1ded5] text-[#1f2328]'
      : theme === 'sepia'
      ? 'bg-[#eae0c8]/95 border-[#d8c8a6] text-[#433422]'
      : 'bg-[#121215]/95 border-zinc-800 text-zinc-200';
  const themeContentColor =
    theme === 'light'
      ? 'text-[#24292f]'
      : theme === 'sepia'
      ? 'text-[#433422]'
      : 'text-zinc-200';
  const themeHeadingColor =
    theme === 'light'
      ? 'text-[#0f1419]'
      : theme === 'sepia'
      ? 'text-[#2c1d0c]'
      : 'text-white';
  const themeBorderColor =
    theme === 'light'
      ? 'border-[#e1ded5]'
      : theme === 'sepia'
      ? 'border-[#d8c8a6]'
      : 'border-zinc-800';

  const text = mode === 'transcript' ? video.transcript : video.summary;
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const mins = Math.max(1, Math.ceil(words / 220));
  const personaLabel = SUMMARY_PERSONA_PRESETS[persona].label;

  return (
    <div
      className={`flex-1 overflow-y-auto flex flex-col yt-readability-container theme-${theme} yt-readability-theme-${theme} ${themeContainerBg}`}
    >
      {/* Sticky Reader Controls Bar */}
      <div
        className={`sticky top-0 z-20 flex items-center gap-2 px-6 py-2.5 backdrop-blur-md border-b flex-wrap text-xs yt-readability-bar ${themeBarBg}`}
      >
        <button
          type="button"
          onClick={onExit}
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 font-medium transition-colors yt-readability-exit-btn cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
          <span>Exit Reader</span>
        </button>
        <div className="w-px h-4 bg-zinc-700/40 mx-1 yt-readability-divider" />

        <button
          type="button"
          onClick={onToggleSyncYouTubeTheme}
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all border yt-readability-btn yt-readability-sync-theme-btn cursor-pointer ${
            syncYouTubeTheme
              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 active shadow-xs'
              : 'bg-zinc-800/80 text-zinc-300 border-zinc-700/80 hover:text-white hover:bg-zinc-700/80'
          }`}
          title={
            syncYouTubeTheme
              ? `YouTube Theme Sync: ON (Detected: ${simulatedYouTubeTheme.toUpperCase()} mode — auto-matching YouTube)`
              : "YouTube Theme Sync: OFF (Click to automatically synchronize Reader view with YouTube's Dark/Light mode)"
          }
        >
          <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${syncYouTubeTheme ? 'rotate-180' : ''}`} />
          <span className="yt-sync-label">
            {syncYouTubeTheme ? `Sync YouTube (${simulatedYouTubeTheme})` : 'Sync YouTube'}
          </span>
        </button>

        {/* Theme Selector */}
        <div
          className="inline-flex items-center bg-zinc-800/80 border border-zinc-700/80 rounded-full overflow-hidden yt-readability-theme-group"
          title="Select reading theme: System, Light, Sepia, Dark"
        >
          {(
            [
              { id: 'system', label: 'System' },
              { id: 'light', label: 'Light' },
              { id: 'sepia', label: 'Sepia' },
              { id: 'dark', label: 'Dark' }
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onSelectTheme(t.id)}
              className={`px-2.5 py-1 text-xs font-semibold transition-all yt-readability-theme-btn cursor-pointer ${
                theme === t.id
                  ? 'bg-sky-500 text-zinc-950 font-bold active shadow-xs'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-700/60'
              }`}
              data-theme={t.id}
            >
              {t.label}
            </button>
          ))}
        </div>

        <select
          aria-label="Readability theme"
          value={theme}
          onChange={(e) => onSelectTheme(e.target.value as 'system' | 'light' | 'sepia' | 'dark')}
          className="bg-zinc-800 text-zinc-200 border border-zinc-700 rounded-full px-2 py-0.5 text-xs hidden yt-readability-theme-select"
        >
          <option value="system">System</option>
          <option value="light">Light</option>
          <option value="sepia">Sepia</option>
          <option value="dark">Dark</option>
        </select>

        <div className="w-px h-4 bg-zinc-700/40 mx-1 yt-readability-divider" />

        <button
          type="button"
          onClick={onToggleFont}
          className="px-3 py-1 rounded-full bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-200 border border-zinc-700/80 text-xs font-medium transition-colors yt-readability-font-btn cursor-pointer"
        >
          {font === 'serif' ? 'Serif font' : 'Sans font'}
        </button>

        <div className="inline-flex items-center bg-zinc-800/80 border border-zinc-700/80 rounded-full overflow-hidden yt-readability-size-group">
          <button
            type="button"
            onClick={() => onChangeFontSize(-1)}
            className="px-2.5 py-1 text-xs font-bold text-zinc-300 hover:bg-zinc-700 hover:text-white yt-readability-size-dec cursor-pointer"
            title="Decrease font size"
          >
            A-
          </button>
          <span className="px-2 text-[11px] font-mono tabular-nums text-zinc-400 border-x border-zinc-700/80 yt-readability-size-label">
            {fontSize}px
          </span>
          <button
            type="button"
            onClick={() => onChangeFontSize(1)}
            className="px-2.5 py-1 text-xs font-bold text-zinc-300 hover:bg-zinc-700 hover:text-white yt-readability-size-inc cursor-pointer"
            title="Increase font size"
          >
            A+
          </button>
        </div>

        <div className="ml-auto flex items-center gap-3 flex-wrap">
          <span className="text-xs text-zinc-400 yt-readability-stats tabular-nums">
            {words.toLocaleString()} words · ~{mins} min read
          </span>
          <button
            type="button"
            onClick={onExportTxt}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs font-medium transition-colors yt-readability-export-btn cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export .txt</span>
          </button>
          <button
            type="button"
            onClick={onExportPdf}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-medium transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Export PDF</span>
          </button>
          <button
            type="button"
            onClick={onExportJson}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 text-xs font-medium transition-colors yt-readability-export-json-btn cursor-pointer"
            title="Export transcript summary as JSON (.json) with metadata"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
          <button
            type="button"
            onClick={onExportMarkdown}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-medium transition-colors yt-readability-export-md-btn cursor-pointer"
            title="Export offline Markdown / Obsidian bundle (.md)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export .md</span>
          </button>
        </div>
      </div>

      {/* Centered Editorial Canvas */}
      <div
        className={`max-w-[720px] w-full mx-auto px-6 py-10 leading-relaxed yt-readability-content ${themeContentColor} ${
          font === 'serif' ? 'font-serif' : 'font-sans'
        }`}
        style={{ fontSize: `${fontSize}px` }}
      >
        <div className={`border-b pb-5 mb-8 yt-readability-header ${themeBorderColor}`}>
          <div className="flex items-center gap-2 text-[11px] font-bold text-sky-400 uppercase tracking-wider mb-2 font-sans yt-readability-type-badge">
            <span>{mode === 'transcript' ? 'YouTube Transcript' : 'Video Summary'}</span>
            <span aria-hidden="true">·</span>
            <span>{personaLabel}</span>
          </div>
          <h1 className={`text-2xl font-bold tracking-tight leading-snug font-sans yt-readability-title ${themeHeadingColor}`}>
            {video.title}
          </h1>
          <div className="text-xs text-zinc-500 mt-2 font-sans yt-readability-meta">
            Channel: {video.channel} · Views: {video.views} · Persona: {personaLabel} · Video ID: {video.id}
          </div>
          {activeSeek && (
            <div
              data-seek-banner={activeSeek.tsStr}
              className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-mono tabular-nums font-sans"
            >
              Player positioned at {activeSeek.tsStr} (cue #{activeSeek.cueIndex + 1})
            </div>
          )}
        </div>

        <div className="space-y-5">
          {parseEditorialBlocks(text).map((block, i) => {
            if (block.type === 'heading') {
              return (
                <h2
                  key={i}
                  className={`text-xl font-bold pt-4 pb-1 border-b font-sans yt-readability-h2 ${themeHeadingColor} ${themeBorderColor}`}
                >
                  <TimestampText text={block.text} onSeek={onSeekTimestamp} activeSeekSec={activeSeek?.seconds ?? null} />
                </h2>
              );
            }
            if (block.type === 'subheading') {
              return (
                <h3
                  key={i}
                  className={`text-lg font-semibold pt-2 font-sans yt-readability-h3 ${themeHeadingColor}`}
                >
                  <TimestampText text={block.text} onSeek={onSeekTimestamp} activeSeekSec={activeSeek?.seconds ?? null} />
                </h3>
              );
            }
            if (block.type === 'bullet') {
              return (
                <div key={i} className={`flex items-start gap-2 pl-4 yt-readability-li ${themeContentColor}`}>
                  <span className="text-sky-400 font-bold">&bull;</span>
                  <span>
                    <TimestampText text={block.text} onSeek={onSeekTimestamp} activeSeekSec={activeSeek?.seconds ?? null} />
                  </span>
                </div>
              );
            }
            if (block.type === 'tx') {
              const sec = parseTimestampStringToSeconds(block.ts || '');
              return (
                <div key={i} className={`flex items-start gap-2 yt-readability-tx-line ${themeContentColor}`}>
                  <button
                    type="button"
                    data-seek-sec={sec ?? 0}
                    data-seek-ts={block.ts}
                    onClick={() => {
                      if (block.ts && sec !== null) onSeekTimestamp(block.ts, sec);
                    }}
                    className="text-sky-400 hover:text-sky-200 font-mono tabular-nums text-sm px-1.5 py-0.5 rounded bg-sky-950/40 hover:bg-sky-900/60 border border-sky-900/40 flex-shrink-0 yt-readability-ts yt-ts-jump-btn cursor-pointer transition-colors"
                    title={`Seek to ${block.ts}`}
                  >
                    {block.ts}
                  </button>
                  <span>{block.text}</span>
                </div>
              );
            }
            return (
              <p key={i} className={`yt-readability-p ${themeContentColor}`}>
                <TimestampText text={block.text} onSeek={onSeekTimestamp} activeSeekSec={activeSeek?.seconds ?? null} />
              </p>
            );
          })}
        </div>
      </div>
    </div>
  );
};
