import React, { useEffect, useRef } from 'react';
import { computeWaveformAmplitudes } from '../utils/userscript-helpers';

export function TtsWaveformVisualizer({
  isPlaying,
  volume,
  pitch,
  rate
}: {
  isPlaying: boolean;
  volume: number;
  pitch: number;
  rate: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let animId: number;
    let boundaryPulse = 0;

    const render = () => {
      const cvs = canvasRef.current;
      if (cvs) {
        const ctx = cvs.getContext('2d');
        if (ctx) {
          const w = cvs.width || 68;
          const h = cvs.height || 18;
          ctx.clearRect(0, 0, w, h);

          const amps = computeWaveformAmplitudes({
            isPlaying,
            volume,
            pitch,
            rate,
            timestamp: Date.now(),
            barCount: 12,
            boundaryPulse
          });

          if (boundaryPulse > 0.05) {
            boundaryPulse *= 0.88;
          } else {
            boundaryPulse = 0;
          }

          const numBars = amps.length;
          const gap = 2;
          const barW = Math.max(2, (w - gap * (numBars - 1)) / numBars);

          const grad = ctx.createLinearGradient(0, h, 0, 0);
          grad.addColorStop(0, '#0284c7');
          grad.addColorStop(0.5, '#38bdf8');
          grad.addColorStop(1, '#c084fc');

          for (let i = 0; i < numBars; i++) {
            const a = amps[i];
            const barH = Math.max(2, a * (h - 2));
            const x = i * (barW + gap);
            const y = (h - barH) / 2;

            ctx.fillStyle = isPlaying ? grad : 'rgba(255, 255, 255, 0.18)';
            ctx.beginPath();
            if (ctx.roundRect) {
              ctx.roundRect(x, y, barW, barH, 1.5);
            } else {
              ctx.rect(x, y, barW, barH);
            }
            ctx.fill();
          }
        }
      }

      if (isPlaying) {
        animId = requestAnimationFrame(render);
      }
    };

    if (isPlaying) {
      animId = requestAnimationFrame(render);
    } else {
      render();
    }

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [isPlaying, volume, pitch, rate]);

  return (
    <div
      className={`inline-flex items-center px-1.5 py-0.5 rounded-md border transition-all yt-tts-waveform-wrap ${
        isPlaying
          ? 'border-sky-500/40 bg-sky-950/20 shadow-xs'
          : 'border-zinc-700/60 bg-zinc-900/60 opacity-60'
      }`}
      title={isPlaying ? 'Dynamic audio waveform: Active speech synthesis amplitude' : 'Dynamic audio waveform: Speech idle'}
    >
      <canvas
        ref={canvasRef}
        width={68}
        height={18}
        className="w-[68px] h-[18px] block yt-tts-waveform-canvas"
      />
    </div>
  );
}
