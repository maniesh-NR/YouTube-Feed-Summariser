import React from 'react';
import { X, Sun, Moon, Monitor, SlidersHorizontal, RotateCcw, Type } from 'lucide-react';
import {
  DEFAULT_GENERATED_TEXT_PREFS,
  DEFAULT_UI_FORMATTING_PREFS,
  type AppThemeMode,
  type EffectiveTheme,
  type GeneratedFontFamily,
  type GeneratedParagraphSpacing,
  type GeneratedTextFormattingPrefs,
  type HistoryTabVisibility,
  type UiDensity,
  type UiFontFamily,
  type UiFormattingPrefs
} from '../utils/userscript-helpers';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  appThemeMode: AppThemeMode;
  effectiveTheme: EffectiveTheme;
  onSetAppThemeMode: (mode: AppThemeMode) => void;
  uiFormatting: UiFormattingPrefs;
  onChangeUiFormatting: (patch: Partial<UiFormattingPrefs>) => void;
  genFormatting: GeneratedTextFormattingPrefs;
  onChangeGenFormatting: (patch: Partial<GeneratedTextFormattingPrefs>) => void;
  onResetFormattingDefaults: () => void;
  historyTabVisibility: HistoryTabVisibility;
  onSetHistoryTabVisibility: (vis: HistoryTabVisibility) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  onClose,
  appThemeMode,
  effectiveTheme,
  onSetAppThemeMode,
  uiFormatting,
  onChangeUiFormatting,
  genFormatting,
  onChangeGenFormatting,
  onResetFormattingDefaults,
  historyTabVisibility,
  onSetHistoryTabVisibility
}) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[9999] bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 yt-key-dialog-scrim"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Settings and Appearance"
    >
      <div
        className="w-full max-w-2xl max-h-[88vh] bg-[var(--md-sys-color-surface-container-low)] border border-[var(--md-sys-color-outline-variant)] rounded-[24px] shadow-2xl flex flex-col overflow-hidden text-[var(--md-sys-color-on-surface)] yt-key-dialog-box"
        style={{
          fontFamily: 'var(--yt-ui-font, var(--font-sans))',
          fontSize: 'var(--yt-ui-font-size, 14px)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Titlebar — first .yt-win-btn is close button for E2E parity */}
        <div className="px-6 py-4 border-b border-[var(--md-sys-color-outline-variant)] flex items-center justify-between gap-3 bg-[var(--md-sys-color-surface-container)]">
          <div className="min-w-0">
            <h2 className="font-display font-semibold text-base text-[var(--md-sys-color-on-surface)] flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-[var(--md-sys-color-primary)] flex-shrink-0" />
              <span>Settings &amp; Appearance</span>
            </h2>
            <p className="text-xs text-[var(--md-sys-color-on-surface-variant)] mt-0.5">
              Material You theme ({effectiveTheme}), interface typography, and generated summary styling
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-highest)] text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)] transition-colors yt-win-btn yt-win-close-btn cursor-pointer"
            title="Close settings"
            aria-label="Close settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6">
          {/* 1. Material You Theme Mode */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--md-sys-color-primary)]">
                Material You Theme
              </h3>
              <span className="text-[11px] text-[var(--md-sys-color-on-surface-variant)] tabular-nums">
                Active: {effectiveTheme === 'dark' ? 'Dark' : 'Light'}
              </span>
            </div>
            <div
              className="inline-flex items-center bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-full p-1 gap-1"
              role="group"
              aria-label="Settings Material You theme selector"
            >
              {(
                [
                  { id: 'system', label: 'System', Icon: Monitor },
                  { id: 'light', label: 'Light', Icon: Sun },
                  { id: 'dark', label: 'Dark', Icon: Moon }
                ] as const
              ).map(({ id, label, Icon }) => {
                const active = appThemeMode === id;
                return (
                  <button
                    key={id}
                    type="button"
                    data-app-theme={id}
                    aria-pressed={active}
                    onClick={() => onSetAppThemeMode(id)}
                    className={`yt-app-theme-btn inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      active
                        ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] font-semibold'
                        : 'text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container-high)]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </section>

          <div className="h-px bg-[var(--md-sys-color-outline-variant)]" />

          {/* 2. UI Formatting */}
          <section className="space-y-3">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--md-sys-color-primary)]">
                Interface (UI) Formatting
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium">UI Font Family</span>
                <select
                  aria-label="UI Font Family"
                  data-setting="ui-font-family"
                  value={uiFormatting.fontFamily}
                  onChange={(e) => onChangeUiFormatting({ fontFamily: e.target.value as UiFontFamily })}
                  className="m3-select bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-xl px-3 py-2 text-xs text-[var(--md-sys-color-on-surface)] focus:outline-none focus:border-[var(--md-sys-color-primary)]"
                >
                  <option value="system">System Default (DM Sans)</option>
                  <option value="dm-sans">DM Sans / Geometric</option>
                  <option value="serif">Editorial Serif</option>
                  <option value="mono">Monospace Technical</option>
                </select>
              </label>

              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium flex items-center justify-between">
                  <span>UI Font Size</span>
                  <span className="font-mono tabular-nums text-[var(--md-sys-color-primary)] font-semibold">
                    {uiFormatting.fontSizePx}px
                  </span>
                </span>
                <input
                  type="range"
                  aria-label="UI Font Size"
                  data-setting="ui-font-size"
                  min={11}
                  max={18}
                  step={1}
                  value={uiFormatting.fontSizePx}
                  onChange={(e) => onChangeUiFormatting({ fontSizePx: Number(e.target.value) })}
                  className="accent-[var(--md-sys-color-primary)] cursor-pointer mt-2"
                />
              </label>

              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium">UI Density</span>
                <select
                  aria-label="UI Density"
                  data-setting="ui-density"
                  value={uiFormatting.density}
                  onChange={(e) => onChangeUiFormatting({ density: e.target.value as UiDensity })}
                  className="m3-select bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-xl px-3 py-2 text-xs text-[var(--md-sys-color-on-surface)] focus:outline-none focus:border-[var(--md-sys-color-primary)]"
                >
                  <option value="compact">Compact (8px pad)</option>
                  <option value="comfortable">Comfortable (12px pad)</option>
                  <option value="relaxed">Relaxed (16px pad)</option>
                </select>
              </label>
            </div>
          </section>

          <div className="h-px bg-[var(--md-sys-color-outline-variant)]" />

          {/* 3. Generated Text Formatting */}
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--md-sys-color-primary)]">
              Generated Text Formatting
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium">Summary Font</span>
                <select
                  aria-label="Generated Summary Font"
                  data-setting="gen-font-family"
                  value={genFormatting.fontFamily}
                  onChange={(e) => onChangeGenFormatting({ fontFamily: e.target.value as GeneratedFontFamily })}
                  className="m3-select bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-xl px-3 py-2 text-xs text-[var(--md-sys-color-on-surface)] focus:outline-none focus:border-[var(--md-sys-color-primary)]"
                >
                  <option value="sans">Modern Sans (DM Sans)</option>
                  <option value="serif">Reading Serif (Georgia)</option>
                  <option value="mono">Fixed Code (JetBrains Mono)</option>
                </select>
              </label>

              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium">Paragraph Spacing</span>
                <select
                  aria-label="Generated Paragraph Spacing"
                  data-setting="gen-paragraph-spacing"
                  value={genFormatting.paragraphSpacing}
                  onChange={(e) =>
                    onChangeGenFormatting({ paragraphSpacing: e.target.value as GeneratedParagraphSpacing })
                  }
                  className="m3-select bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-xl px-3 py-2 text-xs text-[var(--md-sys-color-on-surface)] focus:outline-none focus:border-[var(--md-sys-color-primary)]"
                >
                  <option value="compact">Compact (6px gap)</option>
                  <option value="normal">Normal (11px gap)</option>
                  <option value="relaxed">Relaxed (18px gap)</option>
                </select>
              </label>

              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium flex items-center justify-between">
                  <span>Text Size</span>
                  <span className="font-mono tabular-nums text-[var(--md-sys-color-primary)] font-semibold">
                    {genFormatting.fontSizePx}px
                  </span>
                </span>
                <input
                  type="range"
                  aria-label="Generated Text Size"
                  data-setting="gen-font-size"
                  min={12}
                  max={22}
                  step={1}
                  value={genFormatting.fontSizePx}
                  onChange={(e) => onChangeGenFormatting({ fontSizePx: Number(e.target.value) })}
                  className="accent-[var(--md-sys-color-primary)] cursor-pointer mt-1"
                />
              </label>

              <label className="flex flex-col gap-1.5 text-xs">
                <span className="text-[var(--md-sys-color-on-surface-variant)] font-medium flex items-center justify-between">
                  <span>Line Height</span>
                  <span className="font-mono tabular-nums text-[var(--md-sys-color-primary)] font-semibold">
                    {genFormatting.lineHeight.toFixed(2)}
                  </span>
                </span>
                <input
                  type="range"
                  aria-label="Generated Line Height"
                  data-setting="gen-line-height"
                  min={1.3}
                  max={2.0}
                  step={0.05}
                  value={genFormatting.lineHeight}
                  onChange={(e) => onChangeGenFormatting({ lineHeight: Number(e.target.value) })}
                  className="accent-[var(--md-sys-color-primary)] cursor-pointer mt-1"
                />
              </label>
            </div>

            <label className="flex items-center gap-2.5 pt-1 text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                data-setting="gen-rich-formatting"
                checked={genFormatting.richFormatting}
                onChange={(e) => onChangeGenFormatting({ richFormatting: e.target.checked })}
                className="rounded accent-[var(--md-sys-color-primary)]"
              />
              <span className="text-[var(--md-sys-color-on-surface)] font-medium">
                Rich Markdown formatting (uncheck for clean plain-text paragraphs)
              </span>
            </label>
          </section>

          <div className="h-px bg-[var(--md-sys-color-outline-variant)]" />

          {/* 4. History Dock Tab Visibility */}
          <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--md-sys-color-primary)]">
                History Dock Tab
              </h3>
              <p className="text-xs text-[var(--md-sys-color-on-surface-variant)] mt-0.5">
                Control when the bottom-right History dock pill appears
              </p>
            </div>
            <select
              aria-label="History dock visibility setting"
              data-setting="history-tab-visibility"
              value={historyTabVisibility}
              onChange={(e) => onSetHistoryTabVisibility(e.target.value as HistoryTabVisibility)}
              className="m3-select bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] rounded-xl px-3 py-2 text-xs text-[var(--md-sys-color-on-surface)] focus:outline-none focus:border-[var(--md-sys-color-primary)]"
            >
              <option value="always">Always show when saved</option>
              <option value="with_tabs">Only when other tabs are open</option>
              <option value="never">Hidden (launcher &amp; windows only)</option>
            </select>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container)] flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onResetFormattingDefaults}
            disabled={
              uiFormatting.fontFamily === DEFAULT_UI_FORMATTING_PREFS.fontFamily &&
              uiFormatting.fontSizePx === DEFAULT_UI_FORMATTING_PREFS.fontSizePx &&
              uiFormatting.density === DEFAULT_UI_FORMATTING_PREFS.density &&
              genFormatting.fontFamily === DEFAULT_GENERATED_TEXT_PREFS.fontFamily &&
              genFormatting.fontSizePx === DEFAULT_GENERATED_TEXT_PREFS.fontSizePx &&
              genFormatting.lineHeight === DEFAULT_GENERATED_TEXT_PREFS.lineHeight &&
              genFormatting.paragraphSpacing === DEFAULT_GENERATED_TEXT_PREFS.paragraphSpacing &&
              genFormatting.richFormatting === DEFAULT_GENERATED_TEXT_PREFS.richFormatting
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[var(--md-sys-color-outline-variant)] text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container-highest)] disabled:opacity-40 transition-colors cursor-pointer yt-reset-formatting-btn"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Formatting Defaults</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-full bg-[var(--md-sys-color-primary)] hover:opacity-90 text-[var(--md-sys-color-on-primary)] text-xs font-semibold transition-opacity cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
