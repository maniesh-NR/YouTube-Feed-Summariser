import {
  formatMathSymbolsInText,
  parseTimestampToSeconds,
  type SummaryPersona
} from '../utils/userscript-helpers';

export interface MockVideo {
  id: string;
  title: string;
  originalTitle?: string;
  dearrowTitle?: string;
  aiTitle?: string;
  channel: string;
  views: string;
  duration: string;
  badge: string;
  summary: string;
  transcript: string;
  isMusic?: boolean;
}

export interface HistoryItem {
  id: string;
  title: string;
  channel: string;
  views: string;
  duration: string;
  mode: 'summary' | 'transcript' | 'podcast';
  model: string;
  persona?: SummaryPersona;
  summary: string;
  transcript: string;
  timestamp: number;
}

export interface ChatTurn {
  q: string;
  a: string;
  model: string;
  isVoice?: boolean;
  sources?: Array<{ uri: string; title: string }>;
  imageUri?: string;
}

export interface ActiveSeekState {
  seconds: number;
  tsStr: string;
  cueIndex: number;
  updatedAt: number;
}

export interface EditorialBlock {
  type: 'heading' | 'subheading' | 'bullet' | 'p' | 'tx';
  text: string;
  ts?: string;
}

export const MOCK_VIDEOS: MockVideo[] = [
  {
    id: 'D_clickbait_chip',
    title: 'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱',
    originalTitle: 'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱',
    dearrowTitle: 'New RISC-V 128-Core Server Processor Announced',
    aiTitle: 'Next-gen RISC-V server chip benchmarks show 2x energy efficiency over x86 in datacenter workloads',
    channel: 'Tech Frontier',
    views: '1.2M views • 1 day ago',
    duration: '16:24',
    badge: 'Hardware',
    summary: `## TL;DR
A comprehensive architectural deep-dive into the newly announced 128-core RISC-V server platform [00:00]. Benchmarks demonstrate double the efficiency of current x86 servers on sparse linear algebra and neural inference tasks [02:15].

## Key takeaways
- 128 custom out-of-order RISC-V cores on 3nm node [02:15].
- Fully hardware-virtualized vector extensions [08:45].
- Open ISA avoids licensing and geopolitical supply restrictions.`,
    transcript: `[00:00] Today we are benchmarking the world's first 128-core server-grade RISC-V processor.
[02:15] Across datacenter AI workloads, the chip delivers double the performance per watt of legacy x86 CPUs.
[08:45] The vector extensions provide native FP8 and INT8 precision acceleration.`
  },
  {
    id: 'D_space_webb',
    title: "NASA's Webb Telescope Just Found Something TERRIFYING In Deep Space!!",
    originalTitle: "NASA's Webb Telescope Just Found Something TERRIFYING In Deep Space!!",
    dearrowTitle: 'JWST Detects Methane and Carbon Dioxide in Atmosphere of Exoplanet K2-18b',
    aiTitle: 'James Webb Telescope identifies carbon-bearing molecules in sub-Neptune exoplanet atmosphere',
    channel: 'Astro Science',
    views: '2.4M views • 4 days ago',
    duration: '11:50',
    badge: 'Astrophysics',
    summary: `## TL;DR
Transmission spectroscopy observations from the James Webb Space Telescope detect methane and carbon dioxide in the atmosphere of K2-18b [00:00], supporting models of a water-rich ocean world under a hydrogen atmosphere [03:20].

## Key takeaways
- Spectral absorption confirmed at 2.3 and 3.3 microns [03:20].
- Carbon chemistry indicates potential Hycean world conditions [09:10].
- At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of $100^\\circ\\text{C}$ to approximately $87^\\circ\\text{C}$.
- Follow-up observations scheduled for dimethyl sulfide verification.`,
    transcript: `[00:00] The James Webb Space Telescope has captured definitive spectral signatures from exoplanet K2-18b.
[03:20] The detection of atmospheric methane and carbon dioxide points to a deep water ocean beneath a hydrogen-rich atmosphere.
[09:10] These findings represent our most detailed chemical characterization of a habitable zone exoplanet to date.`
  },
  {
    id: 'D_music_exempt',
    title: 'Dua Lipa - Levitating (Official Music Video)',
    originalTitle: 'Dua Lipa - Levitating (Official Music Video)',
    dearrowTitle: 'Dua Lipa - Levitating (Official Music Video)',
    aiTitle: 'Dua Lipa performs studio disco-pop dance track Levitating with 1980s synthesizer production',
    channel: 'Dua Lipa VEVO',
    views: '820M views • 2 years ago',
    duration: '3:48',
    badge: 'Official Artist Channel',
    isMusic: true,
    summary: `## TL;DR
Official music video for "Levitating" by Dua Lipa. Music videos keep their original title on load, and clicking the music icon manually generates an AI descriptive summary title.`,
    transcript: `[00:00] If you wanna run away with me, I know a galaxy and I can take you for a ride.
[01:10] I got you, moonlight, you're my starlight, I need you all night, come on dance with me, I'm levitating.`
  },
  {
    id: 'D_quantum_101',
    title: 'Advanced Quantum Computing & Topological Qubits Explained',
    originalTitle: 'Advanced Quantum Computing & Topological Qubits Explained',
    aiTitle: 'Topological quantum computing architecture using non-Abelian anyon braids for hardware error protection',
    channel: 'Quantum Tech Insights',
    views: '452K views • 2 days ago',
    duration: '18:42',
    badge: 'Quantum Physics',
    summary: `## TL;DR
This video explains the transition from fragile superconducting transmons to non-Abelian anyon topological qubits, potentially reducing quantum error correction overhead by orders of magnitude.

## Detailed summary

### [00:15] The Quantum Coherence Dilemma
Current NISQ processors struggle with phase decoherence and thermal crosstalk. Error correction requires thousands of physical qubits per logical qubit.

### [04:20] Non-Abelian Anyons & Braiding
Topological quantum computers encode quantum information in geometric braid trajectories rather than isolated atomic energy states, protecting data from local magnetic turbulence.

### [09:45] Experimental Validation & Major Milestones
Recent interferometry experiments at ultra-low dilution refrigerator temperatures show clear non-local phase shifts consistent with Majorana zero modes.

## Key takeaways
- Topological protection eliminates the need for 90% of brute-force redundancy.
- Coherence time increases exponentially with braid distance.
- High-fidelity two-qubit logic gates demonstrated in laboratory prototypes.

## Worth your time?
Essential viewing for systems engineers and computer scientists looking past NISQ marketing to actual fault-tolerant quantum architecture.`,
    transcript: `[00:05] Welcome everyone. Today we are breaking down quantum hardware.
[01:15] The central bottleneck of modern quantum systems is decoherence.
[04:20] To fix this, researchers are turning to topological states of matter.
[09:45] By braiding anyons in two dimensions, we create topologically protected gates.`
  },
  {
    id: 'D_fusion_breakthrough',
    title: 'Solid-State Sodium Batteries: Replacing Lithium at Scale',
    originalTitle: 'Solid-State Sodium Batteries: Replacing Lithium at Scale',
    dearrowTitle: 'Solid-State Sodium Battery Tech and Manufacturing Viability',
    aiTitle: 'Solid-state sodium battery chemistry cuts cell cost by 60% while sustaining 4,500 continuous cycles',
    channel: 'Energy Frontiers',
    views: '890K views • 1 week ago',
    duration: '14:05',
    badge: 'Materials Science',
    summary: `## TL;DR
A comprehensive analysis of next-generation sodium-ion solid electrolyte cells. They cut raw material costs by 60% compared to lithium-ion while matching LFP energy densities for grid storage and budget electric vehicles.

## Detailed summary

### [00:30] The Geopolitics of Lithium Supply
Lithium extraction concentrates heavily in specific geographic bottlenecks. Sodium is universally accessible and inexpensive.

### [03:15] Solid Electrolyte Chemistry
The prototype uses a novel sulfide-based ceramic membrane that suppresses dendrite penetration even during 4C ultrafast charging.

### [08:50] Manufacturing & Factory Retooling
Existing gigafactory roll-to-roll electrode coating lines require less than 10% modification to switch from lithium to sodium slurry.

## Key takeaways
- Sodium raw materials cost $0.30/kg vs $18/kg for battery-grade lithium.
- Dendrite-free cycling demonstrated over 4,500 continuous cycles.
- Mass production expected within 18 months.

## Worth your time?
Highly recommended for anyone tracking clean energy transition economics and battery chemistry.`,
    transcript: `[00:10] Sodium batteries have officially moved from theoretical labs to commercial pilots.
[03:15] The key breakthrough is in solid ceramic electrolytes that stop dendrite growth.
[08:50] Existing battery factories can produce these with minor tooling tweaks.`
  },
  {
    id: 'D_long_lecture',
    title: 'Distributed Consensus & Raft Under Byzantine Faults (Full Lecture)',
    originalTitle: 'Distributed Consensus & Raft Under Byzantine Faults (Full Lecture)',
    dearrowTitle: 'Distributed Consensus and Raft Fault Tolerance Lecture (58 min)',
    aiTitle: 'Full 58m systems lecture deriving Raft safety invariants and linearizable read proofs',
    channel: 'Systems Engineering Lab',
    views: '610K views • 3 weeks ago',
    duration: '58:30',
    badge: 'Distributed Systems',
    summary: `## TL;DR
A complete 58-minute graduate lecture on crash-fault and Byzantine consensus protocols [00:00], proving Raft leader completeness and showing how read-index leases preserve linearizability with bounded election timeouts $T_{election} \\approx 150\\text{ms}$ [48:05].

## Detailed summary

### [00:00] Course Intro & FLP Impossibility
Reviews why asynchronous consensus cannot guarantee deterministic termination with even one unannounced crash failure, motivating randomized and partial-synchrony timeouts.

### [14:20] Raft Leader Election & Split Votes
Derives randomized election timeout bounds $150\\text{ms} \\le T_{election} \\le 300\\text{ms}$ and majority quorum intersection guarantees across candidate terms.

### [31:10] Log Replication & Term Safety Proofs
Walks through the Leader Append-Only invariant, Log Matching inductive proof, and why leaders must never commit entries from previous terms by counting replicas alone.

### [48:05] Linearizable Reads & Production Chaos
Explains ReadIndex heartbeat confirmation vs. clock-bounded leader leases, plus latency spikes observed at $100^\\circ\\text{C}$ rack burn-in tests.

## Key takeaways
- Leader completeness relies on up-to-date log checks during RequestVote RPCs [14:20].
- Current-term commits implicitly commit all preceding log entries safely [31:10].
- Read leases avoid disk fsync on read paths while preserving strict serializability [48:05].

## Worth your time?
Essential reference lecture for distributed database engineers building fault-tolerant state machines.`,
    transcript: `[00:00] Welcome to Lecture 9 on Distributed Consensus and Fault-Tolerant State Machines.
[05:10] Under the FLP impossibility theorem, no deterministic asynchronous protocol tolerates even one crash fault.
[14:20] Raft decomposes consensus into leader election, log replication, and safety invariants.
[22:45] Randomized timeouts between 150ms and 300ms break symmetric split votes rapidly.
[31:10] Now let us prove the Log Matching and Leader Completeness properties by induction on term number.
[40:30] Never commit entries from prior terms strictly by replica count; commit an entry from your current term first.
[48:05] For linearizable reads without writing to disk, leaders issue ReadIndex or monotonic clock leases.
[56:40] In summary, Raft achieves Paxos-equivalent safety with an explicit single-leader decomposition.`
  }
];

export function stripMarkdown(text: string): string {
  if (!text) return '';
  return formatMathSymbolsInText(text)
    .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '$1')
    .replace(/^[-*•]\s+/gm, '• ')
    .trim();
}

export function parseEditorialBlocks(text: string): EditorialBlock[] {
  if (!text) return [];
  const clean = formatMathSymbolsInText(text)
    .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
    .replace(/^[-*_]{3,}\s*$/gm, '');
  const lines = clean.split('\n');
  const blocks: EditorialBlock[] = [];

  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    if (!trimmed) continue;

    if (trimmed.startsWith('#')) {
      const level = (trimmed.match(/^#+/) || [''])[0].length;
      blocks.push({
        type: level <= 2 ? 'heading' : 'subheading',
        text: stripMarkdown(trimmed.slice(level))
      });
      continue;
    }

    const bulletMatch = /^[-*•]\s+(.+)$/.exec(trimmed);
    if (bulletMatch) {
      blocks.push({
        type: 'bullet',
        text: stripMarkdown(bulletMatch[1])
      });
      continue;
    }

    const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
    if (tsMatch) {
      const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
      const rest = trimmed.slice(tsStr.length).trim();
      blocks.push({
        type: 'tx',
        ts: tsStr,
        text: stripMarkdown(rest)
      });
      continue;
    }

    blocks.push({
      type: 'p',
      text: stripMarkdown(trimmed)
    });
  }
  return blocks;
}

export function parseTimestampStringToSeconds(tsStr: string): number | null {
  const clean = String(tsStr || '').replace(/[\[\]]/g, '').trim();
  if (!clean) return null;
  const sec = parseTimestampToSeconds(clean);
  return Number.isFinite(sec) ? sec : null;
}

export function getLocalThumbnailDataUri(label: string, accent = '#38bdf8'): string {
  const safeLabel = (label || 'Summary').slice(0, 18).replace(/[<>&"']/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="135" viewBox="0 0 240 135">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#1e293b"/>
      </linearGradient>
    </defs>
    <rect width="240" height="135" fill="url(#bg)"/>
    <path d="M0 95 Q60 70 120 92 T240 80 L240 135 L0 135 Z" fill="${accent}" fill-opacity="0.16"/>
    <circle cx="120" cy="60" r="18" fill="#020617" fill-opacity="0.7" stroke="${accent}" stroke-opacity="0.6" stroke-width="1.5"/>
    <polygon points="116,52 128,60 116,68" fill="${accent}"/>
    <text x="12" y="120" fill="#cbd5e1" font-family="ui-sans-serif,system-ui,sans-serif" font-size="11" font-weight="600">${safeLabel}</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export function getLocalDiagramDataUri(topic: string): string {
  const safeTopic = (topic || 'System Architecture').slice(0, 34).replace(/[<>&"']/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="220" viewBox="0 0 600 220">
    <rect width="600" height="220" fill="#090d16"/>
    <g stroke="#1e293b" stroke-width="1">
      <line x1="0" y1="55" x2="600" y2="55"/>
      <line x1="0" y1="110" x2="600" y2="110"/>
      <line x1="0" y1="165" x2="600" y2="165"/>
      <line x1="150" y1="0" x2="150" y2="220"/>
      <line x1="300" y1="0" x2="300" y2="220"/>
      <line x1="450" y1="0" x2="450" y2="220"/>
    </g>
    <rect x="44" y="68" width="132" height="64" rx="10" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
    <text x="110" y="104" text-anchor="middle" fill="#e2e8f0" font-family="ui-monospace,monospace" font-size="12">INPUT STREAM</text>
    <line x1="176" y1="100" x2="234" y2="100" stroke="#38bdf8" stroke-width="2"/>
    <rect x="234" y="56" width="142" height="88" rx="10" fill="#172554" stroke="#60a5fa" stroke-width="1.5"/>
    <text x="305" y="96" text-anchor="middle" fill="#f8fafc" font-family="ui-monospace,monospace" font-size="12" font-weight="700">VECTOR CORE</text>
    <text x="305" y="116" text-anchor="middle" fill="#93c5fd" font-family="ui-monospace,monospace" font-size="10">3nm / FP8</text>
    <line x1="376" y1="100" x2="432" y2="100" stroke="#34d399" stroke-width="2"/>
    <rect x="432" y="68" width="126" height="64" rx="10" fill="#064e3b" stroke="#34d399" stroke-width="1.5"/>
    <text x="495" y="104" text-anchor="middle" fill="#ecfdf5" font-family="ui-monospace,monospace" font-size="12">2.1x EFF.</text>
    <text x="20" y="28" fill="#94a3b8" font-family="ui-monospace,monospace" font-size="11">SCHEMA // ${safeTopic}</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
