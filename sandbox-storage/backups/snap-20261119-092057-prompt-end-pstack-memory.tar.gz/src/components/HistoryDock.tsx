import React from 'react';
import { Clock, Search, X, ExternalLink, Maximize2 } from 'lucide-react';
import {
  shouldShowHistoryTab,
  type HistoryTabVisibility
} from '../utils/userscript-helpers';
import {
  getLocalThumbnailDataUri,
  type HistoryItem,
  type MockVideo
} from './SimulatorTypes';

interface HistoryDockProps {
  historyOpen: boolean;
  setHistoryOpen: (open: boolean) => void;
  historySearch: string;
  setHistorySearch: (search: string) => void;
  closedSummaries: HistoryItem[];
  onReopenSummary: (item: HistoryItem) => void;
  onDeleteFromHistory: (id: string) => void;
  onClearAllHistory: () => void;
  historyTabVisibility: HistoryTabVisibility;
  openWindows: Record<string, { minimized: boolean; mode: 'summary' | 'transcript' | 'podcast'; source: 'video' | 'text' }>;
  focusedVideoId: string | null;
  videos: MockVideo[];
  onMaximizeWindow: (id: string) => void;
  onCloseWindow: (id: string) => void;
}

export const HistoryDock: React.FC<HistoryDockProps> = ({
  historyOpen,
  setHistoryOpen,
  historySearch,
  setHistorySearch,
  closedSummaries,
  onReopenSummary,
  onDeleteFromHistory,
  onClearAllHistory,
  historyTabVisibility,
  openWindows,
  focusedVideoId,
  videos,
  onMaximizeWindow,
  onCloseWindow
}) => {
  const q = historySearch.toLowerCase().trim();
  const filtered = q
    ? closedSummaries.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.summary.toLowerCase().includes(q) ||
          s.channel.toLowerCase().includes(q)
      )
    : closedSummaries;

  return (
    <>
      {historyOpen && (
        <div
          className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in duration-150 yt-history-dialog-scrim"
          onClick={() => setHistoryOpen(false)}
        >
          <div
            className="w-full max-w-3xl max-h-[85vh] bg-[#0f0f0f] border border-zinc-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-zinc-100 yt-history-dialog-box"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-[#141414]">
              <div>
                <h2 className="font-semibold text-base text-zinc-100 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-sky-400" />
                  <span>Previous Summaries</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5 tabular-nums">
                  {closedSummaries.length} saved summar{closedSummaries.length === 1 ? 'y' : 'ies'} from your browsing sessions
                </p>
              </div>
              <button
                type="button"
                onClick={() => setHistoryOpen(false)}
                className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                title="Close"
                aria-label="Close history dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Bar */}
            <div className="px-6 py-3 border-b border-zinc-800/80 bg-[#121212]">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  placeholder="Search previous summaries by title or content..."
                  className="w-full bg-[#181818] border border-zinc-700 rounded-xl pl-9 pr-8 py-2 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-sky-500 yt-history-search-input"
                />
                {historySearch && (
                  <button
                    type="button"
                    onClick={() => setHistorySearch('')}
                    className="absolute right-2.5 text-zinc-400 hover:text-white cursor-pointer"
                    title="Clear search"
                    aria-label="Clear history search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* History List */}
            <div className="p-6 overflow-y-auto space-y-3 max-h-[50vh] yt-history-list">
              {filtered.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 text-xs yt-history-empty">
                  {q
                    ? `No previous summaries match "${historySearch}".`
                    : 'No previous summaries yet. Summaries you create will be saved here so you can access them after closing.'}
                </div>
              ) : (
                filtered.map((item) => (
                  <div
                    key={item.id}
                    className="bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800/80 hover:border-zinc-700 rounded-xl p-3.5 flex items-center gap-4 transition-colors yt-history-card"
                  >
                    <div
                      onClick={() => onReopenSummary(item)}
                      className="w-24 h-14 bg-zinc-800 rounded-lg overflow-hidden flex-shrink-0 cursor-pointer relative group yt-history-thumb-wrap"
                      title="Click to re-open summary"
                    >
                      <img
                        src={getLocalThumbnailDataUri(item.channel)}
                        referrerPolicy="no-referrer"
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform yt-history-thumb"
                      />
                      <span className="absolute bottom-1 right-1 bg-black/80 text-[10px] px-1 rounded text-zinc-300 font-mono tabular-nums">
                        {item.duration}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0 yt-history-info">
                      <a
                        href={`https://www.youtube.com/watch?v=${item.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-xs text-zinc-100 hover:text-sky-400 truncate block transition-colors yt-history-item-title"
                        title={`${item.title} (Open video in new tab)`}
                      >
                        {item.title}
                      </a>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400 yt-history-item-meta flex-wrap">
                        <span className="text-sky-400 font-medium uppercase text-[10px] yt-history-badge mode">
                          {item.mode}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="text-purple-400 font-medium text-[10px] yt-history-badge model">
                          {item.model}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{item.channel}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-zinc-500 yt-history-date tabular-nums">
                          {new Date(item.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 line-clamp-1 mt-1 yt-history-snippet">
                        {item.summary.replace(/[#*`]/g, '').slice(0, 140)}...
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0 yt-history-actions">
                      <button
                        type="button"
                        onClick={() => onReopenSummary(item)}
                        className="px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-zinc-950 font-semibold text-xs transition-colors yt-history-reopen-btn cursor-pointer"
                        title="Re-open summary window"
                      >
                        Open Summary
                      </button>
                      <a
                        href={`https://www.youtube.com/watch?v=${item.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors flex items-center gap-1 text-xs yt-history-video-btn"
                        title="Open original video in new tab"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Watch</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => onDeleteFromHistory(item.id)}
                        className="p-1.5 rounded-lg border border-zinc-800 hover:border-red-900/50 hover:bg-red-500/10 text-zinc-500 hover:text-red-400 transition-colors yt-history-del-btn cursor-pointer"
                        title="Remove from history"
                        aria-label={`Remove ${item.title} from history`}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-zinc-800 flex items-center justify-between bg-[#141414] text-xs yt-history-footer">
              <button
                type="button"
                onClick={onClearAllHistory}
                disabled={closedSummaries.length === 0}
                className="text-red-400 hover:text-red-300 hover:underline disabled:opacity-30 disabled:no-underline cursor-pointer"
              >
                Clear All History
              </button>
              <button
                type="button"
                onClick={() => setHistoryOpen(false)}
                className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-zinc-200 font-medium cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Right Dock */}
      <div className="fixed bottom-0 left-2 right-2 sm:left-auto sm:right-6 z-40 flex items-end justify-start sm:justify-end gap-2 max-w-[calc(100vw-16px)] overflow-x-auto pointer-events-auto">
        {shouldShowHistoryTab({
          visibility: historyTabVisibility,
          cachedCount: closedSummaries.length,
          activeTabCount: Object.keys(openWindows).length
        }) && (
          <div
            onClick={() => setHistoryOpen(true)}
            className="h-10 bg-zinc-900 hover:bg-zinc-800 text-white rounded-t-xl px-3 flex items-center justify-between gap-2 shadow-xl border border-sky-500/40 cursor-pointer transition-colors border-b-0 yt-dock-tab yt-dock-history-tab"
            title="Browse previous summaries that were closed"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-xs font-semibold text-sky-200 tabular-nums whitespace-nowrap">
                History ({closedSummaries.length})
              </span>
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setHistoryOpen(true);
              }}
              className="p-1 hover:bg-white/10 rounded text-sky-300 yt-dock-btn yt-dock-open-history-btn cursor-pointer"
              title="Browse previous summaries"
              aria-label="Open summary history"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {Object.entries(openWindows).map(([videoId, winState]) => {
          const video = videos.find((v) => v.id === videoId);
          if (!video) return null;
          const isOpenAndFocused = !winState.minimized && focusedVideoId === videoId;

          return (
            <div
              key={videoId}
              onClick={() => onMaximizeWindow(videoId)}
              className={`min-w-[140px] flex-1 max-w-[230px] sm:flex-none sm:w-64 h-10 text-white rounded-t-xl px-3 flex items-center justify-between gap-2 shadow-xl border cursor-pointer transition-colors border-b-0 ${
                isOpenAndFocused
                  ? 'bg-[#2a3441] border-sky-500/60'
                  : 'bg-[#262626] hover:bg-[#333333] border-zinc-700/60'
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    winState.minimized ? 'bg-emerald-400' : 'bg-sky-400'
                  }`}
                />
                <span className="text-xs font-medium truncate">{video.title}</span>
              </div>

              <div className="flex items-center gap-1 text-zinc-400 hover:text-white flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  onClick={() => onMaximizeWindow(videoId)}
                  className="p-1 hover:bg-zinc-700 rounded cursor-pointer"
                  title={winState.minimized ? 'Restore window' : 'Focus window'}
                  aria-label={winState.minimized ? 'Restore window' : 'Focus window'}
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onCloseWindow(videoId)}
                  className="p-1 hover:bg-zinc-700 rounded cursor-pointer"
                  title="Close"
                  aria-label="Close docked window"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
};
