export function formatSecondsToTimestamp(seconds: number): string {
  const s = Math.floor(seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  if (hrs > 0) {
    return `${hrs}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export function parseTimestampToSeconds(tsStr: string): number {
  const parts = tsStr.trim().split(':').map(Number);
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  return 0;
}

export function getCacheKeyPrefix(mode: 'summary' | 'transcript', source: 'video' | 'text'): string {
  if (mode === 'transcript') {
    return source === 'text' ? 'trt:' : 'trn:';
  }
  return source === 'text' ? 'sut:' : 'sum:';
}

export function resolveNextModelDown(currentModel: string, fallbackLadder: string[], availableModels: string[]): string | null {
  const isAsk = String(currentModel || '').toLowerCase().includes('ask');
  let startIdx = 0;
  if (!isAsk) {
    let idx = fallbackLadder.indexOf(currentModel);
    if (idx === -1) {
      idx = fallbackLadder.findIndex((m) => !m.includes('pro'));
      if (idx === -1) idx = 0;
    }
    startIdx = idx + 1;
  }
  for (let i = startIdx; i < fallbackLadder.length; i++) {
    const candidate = fallbackLadder[i];
    if (availableModels.length === 0 || availableModels.includes(candidate) || availableModels.includes(candidate + '-preview')) {
      return candidate;
    }
  }
  return null;
}

export interface AskFallbackDecision {
  shouldFallback: boolean;
  nextModel: string | null;
  reason: 'cancelled' | 'no_key' | 'no_eligible_model' | 'ladder_fallback';
  note?: string;
}

export function resolveAskFallbackPlan(options: {
  currentModel: string;
  fallbackLadder: string[];
  availableModels: string[];
  hasApiKey: boolean;
  cancelled?: boolean;
  errorMessage?: string;
}): AskFallbackDecision {
  if (options.cancelled) {
    return { shouldFallback: false, nextModel: null, reason: 'cancelled' };
  }
  if (!options.hasApiKey) {
    return { shouldFallback: false, nextModel: null, reason: 'no_key' };
  }
  const nextModel = resolveNextModelDown(
    options.currentModel,
    options.fallbackLadder,
    options.availableModels
  );
  if (!nextModel) {
    return { shouldFallback: false, nextModel: null, reason: 'no_eligible_model' };
  }
  const firstLine = (options.errorMessage || 'YouTube Ask failed').split('\n')[0];
  return {
    shouldFallback: true,
    nextModel,
    reason: 'ladder_fallback',
    note: `⚠ YouTube Ask failed (${firstLine}). Automatically proceeding with ${nextModel}.`
  };
}

export function cleanTextForSpeech(
  text: string,
  options: { skipSilence?: boolean } = { skipSilence: true }
): string {
  if (!text) return '';
  const skipSilence = options?.skipSilence !== false;
  let clean = text;

  if (skipSilence) {
    // 1. Filter out lines that are purely silence / pause / music / applause markers
    const silenceLineRegex = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,}|[-_—]{2,})\s*$/gim;
    clean = clean.replace(silenceLineRegex, '');

    // 2. Filter out standalone silence / pause markers without timestamps
    const standaloneSilenceRegex = /^\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,})\s*$/gim;
    clean = clean.replace(standaloneSilenceRegex, '');

    // 3. Remove inline silence / pause tokens
    clean = clean.replace(/\[(?:silence|pause|long pause|music|applause|laughter|no audio|blank)\]/gi, '');
    clean = clean.replace(/\((?:silence|pause|long pause|music|applause|laughter|no audio|blank)\)/gi, '');

    // 4. Collapse extended pause punctuation (e.g. ".....", "---")
    clean = clean.replace(/\.{3,}/g, '. ');
    clean = clean.replace(/[-_—]{2,}/g, ', ');

    // 5. Detect timestamp gaps > 3 seconds between consecutive timestamped transcript lines
    const lines = clean.split('\n');
    const processedLines: string[] = [];
    let prevTsSec = -1;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(line);
      if (tsMatch) {
        const hrs = tsMatch[1] ? parseInt(tsMatch[1], 10) : 0;
        const mins = parseInt(tsMatch[2], 10);
        const secs = parseInt(tsMatch[3], 10);
        const currentTsSec = hrs * 3600 + mins * 60 + secs;
        const rest = tsMatch[4].trim();

        // If line has no meaningful words (just filler/empty), skip it
        if (!rest || /^(?:\[.*?\]|\(.*?\)|[-_.\s]+)$/.test(rest)) {
          continue;
        }

        prevTsSec = currentTsSec;
        processedLines.push(line);
      } else {
        processedLines.push(line);
      }
    }
    clean = processedLines.join('\n');
  }

  // Strip visual markers
  clean = clean.replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]+\]\]/gi, '');
  // Strip HTML / script tags
  clean = clean.replace(/<[^>]+>/g, '');
  // Convert timestamps like [01:15] or [1:02:30] to spoken phrases
  clean = clean.replace(/\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]/g, (_match, h, m, s) => {
    const hrs = h ? parseInt(h, 10) : 0;
    const mins = parseInt(m, 10);
    const secs = parseInt(s, 10);
    const parts: string[] = [];
    if (hrs > 0) parts.push(`${hrs} hour${hrs > 1 ? 's' : ''}`);
    if (mins > 0) parts.push(`${mins} minute${mins > 1 ? 's' : ''}`);
    if (secs > 0) parts.push(`${secs} second${secs > 1 ? 's' : ''}`);
    return parts.length ? `at ${parts.join(' ')}` : '';
  });
  // Format LaTeX/scientific symbols (e.g., $100^\circ\text{C}$ -> 100°C)
  clean = formatMathSymbolsInText(clean);
  // Strip markdown formatting symbols
  clean = clean.replace(/#{1,6}\s+/g, '');
  clean = clean.replace(/\*\*([^*]+)\*\*/g, '$1');
  clean = clean.replace(/\*([^*]+)\*/g, '$1');
  clean = clean.replace(/`([^`]+)`/g, '$1');
  clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  clean = clean.replace(/https?:\/\/\S+/g, '');
  clean = clean.replace(/^[-*•]\s+/gm, '');
  return clean.replace(/\s+/g, ' ').trim();
}

export interface TranscriptCue {
  lineIndex: number;
  rawLine: string;
  tsStr: string;
  startSec: number;
  text: string;
  spokenText: string;
  charStart: number;
  charEnd: number;
}

export function parseTranscriptCues(
  transcriptText: string,
  options: { skipSilence?: boolean } = { skipSilence: true }
): { cues: TranscriptCue[]; fullSpokenText: string } {
  if (!transcriptText) return { cues: [], fullSpokenText: '' };
  const lines = transcriptText.split('\n');
  const cues: TranscriptCue[] = [];
  const spokenParts: string[] = [];
  let currentOffset = 0;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();
    if (!trimmed) continue;

    // Matches timestamp format: [01:15] or [1:02:30]
    const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
    if (!tsMatch) continue;

    const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
    const restText = trimmed.slice(tsStr.length).trim();
    const startSec = parseTimestampToSeconds(tsStr.slice(1, -1));

    const spokenLine = cleanTextForSpeech(trimmed, options);
    if (!spokenLine) continue;

    const charStart = currentOffset;
    const charEnd = currentOffset + spokenLine.length;
    currentOffset = charEnd + 1; // plus space separator
    spokenParts.push(spokenLine);

    cues.push({
      lineIndex: i,
      rawLine,
      tsStr,
      startSec,
      text: restText,
      spokenText: spokenLine,
      charStart,
      charEnd
    });
  }

  const fullSpokenText = spokenParts.join(' ');
  return { cues, fullSpokenText };
}

export function findActiveCueByCharIndex(cues: TranscriptCue[], charIndex: number): TranscriptCue | null {
  if (!cues || cues.length === 0) return null;
  if (charIndex <= 0) return cues[0];

  for (let i = 0; i < cues.length; i++) {
    const cue = cues[i];
    if (charIndex >= cue.charStart && charIndex <= cue.charEnd) {
      return cue;
    }
    if (i < cues.length - 1 && charIndex > cue.charEnd && charIndex < cues[i + 1].charStart) {
      return cue;
    }
  }

  if (charIndex > cues[cues.length - 1].charEnd) {
    return cues[cues.length - 1];
  }
  return cues[0];
}

export function findActiveCueByTime(
  cues: TranscriptCue[],
  currentTimeSec: number,
  totalDurationSec: number
): TranscriptCue | null {
  if (!cues || cues.length === 0) return null;
  if (totalDurationSec <= 0 || currentTimeSec <= 0) return cues[0];

  const progress = Math.min(1, Math.max(0, currentTimeSec / totalDurationSec));
  const totalChars = cues[cues.length - 1].charEnd;
  const targetChar = Math.round(progress * totalChars);

  return findActiveCueByCharIndex(cues, targetChar);
}

/**
 * Detects whether YouTube is currently rendering in Dark or Light mode.
 * Checks YouTube's root <html> attribute (html[dark]), ytd-app[dark],
 * theme attributes, and body attributes.
 */
export function detectYouTubeTheme(doc?: any): 'dark' | 'light' {
  const targetDoc = doc || (typeof document !== 'undefined' ? document : null);
  if (!targetDoc) return 'dark';

  const docEl = targetDoc.documentElement;
  if (docEl) {
    if (typeof docEl.hasAttribute === 'function' && docEl.hasAttribute('dark')) return 'dark';
    if (typeof docEl.getAttribute === 'function') {
      const darkAttr = docEl.getAttribute('dark');
      if (darkAttr !== null && darkAttr !== 'false') return 'dark';
      const themeAttr = docEl.getAttribute('theme');
      if (themeAttr === 'dark') return 'dark';
    }
    if (docEl.classList && docEl.classList.contains && (docEl.classList.contains('dark') || docEl.classList.contains('yt-dark'))) {
      return 'dark';
    }
  }

  if (typeof targetDoc.querySelector === 'function') {
    if (targetDoc.querySelector('html[dark]')) return 'dark';
    if (targetDoc.querySelector('ytd-app[dark]')) return 'dark';
    const ytdApp = targetDoc.querySelector('ytd-app');
    if (ytdApp && typeof ytdApp.hasAttribute === 'function' && ytdApp.hasAttribute('dark')) return 'dark';
    if (targetDoc.body && typeof targetDoc.body.hasAttribute === 'function' && targetDoc.body.hasAttribute('dark')) return 'dark';
  }

  return 'light';
}

/**
 * Resolves the effective reader view theme based on user's manual selection,
 * sync toggle state, and detected YouTube theme.
 */
export function resolveReaderTheme(
  manualTheme: 'system' | 'light' | 'sepia' | 'dark' | string,
  syncWithYouTube: boolean,
  detectedYtTheme: 'dark' | 'light'
): 'light' | 'sepia' | 'dark' | 'system' {
  if (syncWithYouTube) {
    return detectedYtTheme;
  }
  if (['light', 'sepia', 'dark', 'system'].includes(manualTheme)) {
    return manualTheme as 'light' | 'sepia' | 'dark' | 'system';
  }
  return 'system';
}

/**
 * Bounded memory cache with LRU eviction to prevent runaway memory usage
 * in long-lived YouTube SPA sessions.
 */
export class BoundedMemoryCache<K, V> {
  private map = new Map<K, V>();
  private readonly maxCapacity: number;

  constructor(maxCapacity = 500) {
    this.maxCapacity = Math.max(1, maxCapacity);
  }

  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key)!;
    // Refresh access order (delete and re-insert)
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  set(key: K, value: V): this {
    if (this.map.has(key)) {
      this.map.delete(key);
    } else if (this.map.size >= this.maxCapacity) {
      const oldestKey = this.map.keys().next().value;
      if (oldestKey !== undefined) {
        this.map.delete(oldestKey);
      }
    }
    this.map.set(key, value);
    return this;
  }

  has(key: K): boolean {
    return this.map.has(key);
  }

  delete(key: K): boolean {
    return this.map.delete(key);
  }

  clear(): void {
    this.map.clear();
  }

  get size(): number {
    return this.map.size;
  }

  keys(): IterableIterator<K> {
    return this.map.keys();
  }

  values(): IterableIterator<V> {
    return this.map.values();
  }

  entries(): IterableIterator<[K, V]> {
    return this.map.entries();
  }

  forEach(callbackfn: (value: V, key: K, map: Map<K, V>) => void, thisArg?: any): void {
    this.map.forEach(callbackfn, thisArg);
  }

  [Symbol.iterator](): IterableIterator<[K, V]> {
    return this.map[Symbol.iterator]();
  }
}

/**
 * Returns the storage key for auto-saved follow-up chat drafts.
 */
export function getDraftStorageKey(videoId: string): string {
  return 'draft:' + videoId;
}

/**
 * Returns granular TTS playback speed presets with 0.25x steps.
 */
export function getGranularTtsRates(): number[] {
  return [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
}

/**
 * Determines the visual indicator style type based on playback speed setting.
 */
export function getSpeedIndicatorType(rate: number): 'speed-normal' | 'speed-boost' | 'speed-slow' {
  if (Math.abs(rate - 1.0) < 0.01) return 'speed-normal';
  if (rate > 1.0) return 'speed-boost';
  return 'speed-slow';
}

/**
 * Validates and clamps voice pitch within [0.5, 2.0], defaulting to 1.0.
 */
export function clampPitch(val: unknown): number {
  const num = typeof val === 'number' ? val : parseFloat(String(val));
  if (isNaN(num) || !isFinite(num)) return 1.0;
  const clamped = Math.max(0.5, Math.min(2.0, num));
  return Math.round(clamped * 100) / 100;
}

export interface SummaryExportPayload {
  generator: string;
  version: string;
  exportedAt: string;
  metadata: {
    videoId: string;
    videoTitle: string;
    channel: string;
    videoUrl: string;
    mode: 'summary' | 'transcript' | string;
    source: 'video' | 'text' | string;
    processingMode: 'fast' | 'deep' | string;
    persona?: SummaryPersona | string;
    model: string;
    ttsSettings?: {
      rate: number;
      volume: number;
      pitch: number;
      voice: string;
    };
  };
  content: {
    rawText: string;
    formattedText?: string;
    factCheck?: string | null;
    citations?: Array<{ uri: string; title: string }>;
    followUpQuestions?: Array<{ question: string; answer: string; sources?: Array<{ uri: string; title: string }> }>;
    ratings?: {
      main: ResponseRatingRecord | null;
      followUps: Record<string, ResponseRatingRecord>;
    };
  };
}

/**
 * Formats a transcript summary and rich metadata into an indented JSON file string.
 */
export function formatSummaryExportJson(data: {
  videoId: string;
  videoTitle?: string;
  channel?: string;
  mode?: string;
  source?: string;
  processingMode?: string;
  persona?: SummaryPersona | string;
  model?: string;
  text?: string;
  formattedText?: string;
  factCheck?: string | null;
  citations?: Array<{ uri: string; title: string }>;
  followUpQuestions?: Array<{ question: string; answer: string; sources?: Array<{ uri: string; title: string }> }>;
  ttsRate?: number;
  ttsVolume?: number;
  ttsPitch?: number;
  ttsVoice?: string;
  ratings?: {
    main: ResponseRatingRecord | null;
    followUps: Record<string, ResponseRatingRecord>;
  };
}): string {
  const payload: SummaryExportPayload = {
    generator: 'YouTube Feed Summariser (Gemini)',
    version: '2.12.0',
    exportedAt: new Date().toISOString(),
    metadata: {
      videoId: data.videoId,
      videoTitle: data.videoTitle || data.videoId || 'Untitled Video',
      channel: data.channel || 'YouTube Creator',
      videoUrl: `https://www.youtube.com/watch?v=${data.videoId}`,
      mode: data.mode || 'summary',
      source: data.source || 'video',
      processingMode: data.processingMode || 'fast',
      persona: normalizeSummaryPersona(data.persona),
      model: data.model || 'gemini-3.8-flash',
      ttsSettings: {
        rate: typeof data.ttsRate === 'number' ? data.ttsRate : 1.0,
        volume: typeof data.ttsVolume === 'number' ? data.ttsVolume : 1.0,
        pitch: clampPitch(data.ttsPitch),
        voice: data.ttsVoice || 'ai:Kore'
      }
    },
    content: {
      rawText: data.text || '',
      formattedText: data.formattedText,
      factCheck: data.factCheck || null,
      citations: data.citations || [],
      followUpQuestions: data.followUpQuestions || [],
      ...(data.ratings ? { ratings: data.ratings } : {})
    }
  };

  return JSON.stringify(payload, null, 2);
}

/**
 * Calculates normalized amplitudes (0.0 to 1.0) for a dynamic speech waveform visualizer.
 * Models human voice frequency spectrum, pitch shifting, playback speed cadence,
 * and syllable attack pulses.
 */
export function computeWaveformAmplitudes(options: {
  isPlaying: boolean;
  volume?: number;
  pitch?: number;
  rate?: number;
  timestamp?: number;
  barCount?: number;
  boundaryPulse?: number;
}): number[] {
  const barCount = Math.max(4, options.barCount || 12);
  const volume = options.volume !== undefined ? Math.max(0, Math.min(1, options.volume)) : 1.0;
  const pitch = options.pitch !== undefined ? clampPitch(options.pitch) : 1.0;
  const rate = options.rate !== undefined ? Math.max(0.25, Math.min(3, options.rate)) : 1.0;
  const t = (options.timestamp !== undefined ? options.timestamp : Date.now()) / 1000;
  const pulse = Math.max(0, Math.min(1, options.boundaryPulse || 0));

  if (!options.isPlaying || volume === 0) {
    // Resting flatline
    return new Array(barCount).fill(0.08);
  }

  const bars: number[] = [];
  const baseFreq = 3.2 * rate;

  for (let i = 0; i < barCount; i++) {
    const normIdx = i / (barCount - 1); // 0 (bass) to 1 (treble)

    // Speech formant model: Human speech has formant energy peaks around low-mid frequencies
    // Shift formant peaks up or down according to pitch
    const formantCenter = 0.35 * Math.sqrt(pitch);
    const formantWidth = 0.28;
    const formantDist = Math.abs(normIdx - formantCenter);
    const formantWeight = Math.exp(-Math.pow(formantDist / formantWidth, 2));

    // Dynamic wave oscillations representing voice harmonics & prosody
    const harmonic1 = Math.sin(t * baseFreq * 2.1 + i * 0.8) * 0.5 + 0.5;
    const harmonic2 = Math.sin(t * baseFreq * 4.3 - i * 1.2) * 0.3 + 0.3;
    const harmonic3 = Math.cos(t * baseFreq * 1.1 + i * 0.4) * 0.2 + 0.2;

    // Boundary pulse creates syllable attack
    const attackBoost = pulse * (0.3 + 0.7 * Math.sin(i * 0.5));

    // Combine formants, harmonics, rhythm, and syllable pulse
    let amp = (formantWeight * 0.5 + 0.25) * (harmonic1 * 0.45 + harmonic2 * 0.35 + harmonic3 * 0.2) + attackBoost;

    // Apply speech volume and clamp
    amp = Math.max(0.08, Math.min(1.0, amp * volume));
    bars.push(Math.round(amp * 100) / 100);
  }

  return bars;
}

export type HistoryTabVisibility = 'always' | 'with_tabs' | 'never';

export function normalizeHistoryTabVisibility(val: unknown): HistoryTabVisibility {
  if (val === 'always' || val === 'with_tabs' || val === 'never') {
    return val;
  }
  return 'always';
}

export function shouldShowHistoryTab(options: {
  visibility: unknown;
  cachedCount: number;
  activeTabCount: number;
}): boolean {
  const visibility = normalizeHistoryTabVisibility(options.visibility);
  if (options.cachedCount <= 0) return false;
  if (visibility === 'never') return false;
  if (visibility === 'with_tabs') return options.activeTabCount > 0;
  return true;
}

export type ResponseRatingValue = 'up' | 'down' | null;

export interface ResponseRatingRecord {
  videoId: string;
  targetType: 'summary' | 'transcript' | 'followup';
  targetId: string;
  rating: 'up' | 'down';
  note?: string;
  updatedAt: number;
}

export function normalizeResponseRating(val: unknown): ResponseRatingValue {
  if (val === 'up' || val === 'down') return val;
  return null;
}

export function buildResponseRatingKey(
  videoId: string,
  targetType: 'summary' | 'transcript' | 'followup' | string,
  targetId = 'main'
): string {
  return `${videoId}:${targetType}:${targetId || 'main'}`;
}

export function applyResponseRating(
  ratingsMap: Record<string, ResponseRatingRecord>,
  options: {
    videoId: string;
    targetType: 'summary' | 'transcript' | 'followup';
    targetId?: string;
    rating: 'up' | 'down';
    note?: string;
    timestamp?: number;
  }
): {
  nextMap: Record<string, ResponseRatingRecord>;
  record: ResponseRatingRecord | null;
} {
  const targetId = options.targetId || 'main';
  const key = buildResponseRatingKey(options.videoId, options.targetType, targetId);
  const existing = ratingsMap[key];
  const nextMap = { ...ratingsMap };

  if (existing && existing.rating === options.rating && options.note === undefined) {
    delete nextMap[key];
    return { nextMap, record: null };
  }

  const record: ResponseRatingRecord = {
    videoId: options.videoId,
    targetType: options.targetType,
    targetId,
    rating: options.rating,
    note: options.note !== undefined ? options.note : existing?.note,
    updatedAt: options.timestamp ?? Date.now()
  };
  nextMap[key] = record;
  return { nextMap, record };
}

const SUPERSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
  'n': 'ⁿ', 'i': 'ⁱ'
};

const SUBSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
  '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎',
  'a': 'ₐ', 'e': 'ₑ', 'o': 'ₒ', 'x': 'ₓ', 'h': 'ₕ',
  'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ', 'n': 'ₙ', 'p': 'ₚ',
  's': 'ₛ', 't': 'ₜ'
};

const LATEX_COMMAND_REPLACEMENTS: Array<[RegExp, string]> = [
  [/\\(?:text|mathrm|textbf|textit|mathbf|mathit|mathsf|mathtt|ce|units|operatorname)\{([^{}]*)\}/g, '$1'],
  [/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, '$1/$2'],
  [/\\sqrt\{([^{}]+)\}/g, '√$1'],
  [/\\(?:approx|asymp)\b/g, '≈'],
  [/\\simeq\b/g, '≃'],
  [/\\cong\b/g, '≅'],
  [/\\equiv\b/g, '≡'],
  [/\\sim\b/g, '~'],
  [/\\pm\b/g, '±'],
  [/\\mp\b/g, '∓'],
  [/\\times\b/g, '×'],
  [/\\cdot\b/g, '·'],
  [/\\div\b/g, '÷'],
  [/\\(?:leq|le)\b/g, '≤'],
  [/\\(?:geq|ge)\b/g, '≥'],
  [/\\(?:neq|ne)\b/g, '≠'],
  [/\\ll\b/g, '≪'],
  [/\\gg\b/g, '≫'],
  [/\\(?:rightarrow|to)\b/g, '→'],
  [/\\(?:leftarrow|gets)\b/g, '←'],
  [/\\leftrightarrow\b/g, '↔'],
  [/\\(?:Rightarrow|implies)\b/g, '⇒'],
  [/\\(?:Leftrightarrow|iff)\b/g, '⇔'],
  [/\\infty\b/g, '∞'],
  [/\\partial\b/g, '∂'],
  [/\\nabla\b/g, '∇'],
  [/\\sum\b/g, '∑'],
  [/\\prod\b/g, '∏'],
  [/\\int\b/g, '∫'],
  [/\\propto\b/g, '∝'],
  [/\\in\b/g, '∈'],
  [/\\notin\b/g, '∉'],
  [/\\subseteq\b/g, '⊆'],
  [/\\subset\b/g, '⊂'],
  [/\\cup\b/g, '∪'],
  [/\\cap\b/g, '∩'],
  [/\\emptyset\b/g, '∅'],
  [/\\forall\b/g, '∀'],
  [/\\exists\b/g, '∃'],
  [/\\therefore\b/g, '∴'],
  [/\\because\b/g, '∵'],
  [/\\angle\b/g, '∠'],
  [/\\triangle\b/g, '△'],
  [/\\(?:degree|deg|circ)\b/g, '°'],
  [/\\alpha\b/g, 'α'],
  [/\\beta\b/g, 'β'],
  [/\\gamma\b/g, 'γ'],
  [/\\delta\b/g, 'δ'],
  [/\\(?:varepsilon|epsilon)\b/g, 'ε'],
  [/\\zeta\b/g, 'ζ'],
  [/\\eta\b/g, 'η'],
  [/\\(?:vartheta|theta)\b/g, 'θ'],
  [/\\iota\b/g, 'ι'],
  [/\\kappa\b/g, 'κ'],
  [/\\lambda\b/g, 'λ'],
  [/\\(?:mu|micro)\b/g, 'μ'],
  [/\\nu\b/g, 'ν'],
  [/\\xi\b/g, 'ξ'],
  [/\\pi\b/g, 'π'],
  [/\\rho\b/g, 'ρ'],
  [/\\sigma\b/g, 'σ'],
  [/\\tau\b/g, 'τ'],
  [/\\upsilon\b/g, 'υ'],
  [/\\(?:varphi|phi)\b/g, 'φ'],
  [/\\chi\b/g, 'χ'],
  [/\\psi\b/g, 'ψ'],
  [/\\omega\b/g, 'ω'],
  [/\\Gamma\b/g, 'Γ'],
  [/\\Delta\b/g, 'Δ'],
  [/\\Theta\b/g, 'Θ'],
  [/\\Lambda\b/g, 'Λ'],
  [/\\Xi\b/g, 'Ξ'],
  [/\\Pi\b/g, 'Π'],
  [/\\Sigma\b/g, 'Σ'],
  [/\\Phi\b/g, 'Φ'],
  [/\\Psi\b/g, 'Ψ'],
  [/\\Omega\b/g, 'Ω'],
  [/\\hbar\b/g, 'ℏ'],
  [/\\ell\b/g, 'ℓ'],
  [/\\AA\b/g, 'Å'],
  [/\\%/g, '%'],
  [/\\\$/g, '$'],
  [/\\&/g, '&'],
  [/\\(?:left|right)\b/g, ''],
  [/\\[,;:! ]/g, ' ']
];

function mapUnicodeScript(raw: string, map: Record<string, string>, fallbackPrefix: string): string {
  const chars = Array.from(raw);
  if (chars.length > 0 && chars.every((ch) => map[ch] !== undefined)) {
    return chars.map((ch) => map[ch]).join('');
  }
  return raw.length > 1 ? `${fallbackPrefix}(${raw})` : `${fallbackPrefix}${raw}`;
}

function convertLatexFragment(fragment: string): string {
  let out = fragment.trim();
  // Degree shortcuts first
  out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
  out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
  // Apply command replacements iteratively for nested \text{} / \frac{}
  for (let pass = 0; pass < 3; pass++) {
    const prev = out;
    for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
      out = out.replace(re, rep);
    }
    if (out === prev) break;
  }
  // Superscripts & subscripts
  out = out.replace(/\^\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUPERSCRIPT_CHAR_MAP, '^'));
  out = out.replace(/\^([0-9+\-=ni])/g, (_m, ch) => SUPERSCRIPT_CHAR_MAP[ch] || `^${ch}`);
  out = out.replace(/_\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUBSCRIPT_CHAR_MAP, '_'));
  out = out.replace(/_([0-9+\-=aehklmnopstx])/g, (_m, ch) => SUBSCRIPT_CHAR_MAP[ch] || `_${ch}`);
  // Clean remaining empty/redundant grouping braces inside math
  out = out.replace(/\{([^{}]*)\}/g, '$1');
  out = out.replace(/\s*°\s*/g, '°');
  out = out.replace(/\s{2,}/g, ' ').trim();
  return out;
}

/**
 * Formats inline/display LaTeX math & scientific symbols (such as $100^\circ\text{C}$ -> 100°C)
 * into clean Unicode text while preserving currency amounts like "$100 to $200".
 */
export function formatMathSymbolsInText(text: string): string {
  if (!text) return '';
  let out = String(text);

  // 1. Display math $$...$$ and \[...\]
  out = out.replace(/\$\$([\s\S]+?)\$\$/g, (_m, inner) => convertLatexFragment(inner));
  out = out.replace(/\\\[([\s\S]+?)\\\]/g, (_m, inner) => convertLatexFragment(inner));

  // 2. Inline math \(...\)
  out = out.replace(/\\\(([^\n]+?)\\\)/g, (_m, inner) => convertLatexFragment(inner));

  // 3. Inline math $...$ (guard against currency amounts like "$100 to $200")
  out = out.replace(/\$([^$\n]+?)\$/g, (match, inner) => {
    if (!inner || /^\s|\s$/.test(inner)) return match;
    const hasMathSignal =
      /[\\^{}_=<>~±×÷≈≠≤≥°]/.test(inner) ||
      /^[A-Za-z](?:\d+|['’])?$/.test(inner);
    if (!hasMathSignal) return match;
    return convertLatexFragment(inner);
  });

  // 4. Bare LaTeX scientific symbols outside $...$ (e.g., 100^\circ\text{C}, \approx, \pm)
  out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
  out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
  if (/\\(?:text|mathrm|textbf|textit|ce|approx|pm|times|div|leq|geq|neq|degree|circ|alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|omega|Delta|Sigma|Omega)\b/.test(out)) {
    for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
      out = out.replace(re, rep);
    }
    out = out.replace(/\s*°\s*/g, '°');
  }

  return out;
}

export interface WindowBounds {
  left: number;
  top: number;
  width: number;
  height: number;
}

export type WindowSizeTier = 'compact' | 'medium' | 'wide';

export type ResizeDirection = 'n' | 's' | 'e' | 'w' | 'nw' | 'ne' | 'sw' | 'se';

export function clampWindowBounds(
  bounds: WindowBounds,
  viewport: { width: number; height: number },
  minWidth = 340,
  minHeight = 300
): WindowBounds {
  const vw = Math.max(280, viewport.width || 1280);
  const vh = Math.max(320, viewport.height || 800);
  const marginX = vw < 400 ? 8 : 12;
  const effMinW = Math.min(minWidth, Math.max(240, vw - marginX * 2));
  const effMinH = Math.min(minHeight, Math.max(220, vh - 64));
  const maxW = Math.max(effMinW, vw - marginX * 2);
  const maxH = Math.max(effMinH, vh - 64);

  const width = Math.round(Math.max(effMinW, Math.min(maxW, bounds.width)));
  const height = Math.round(Math.max(effMinH, Math.min(maxH, bounds.height)));
  const maxLeft = Math.max(marginX, vw - width - marginX);
  const maxTop = Math.max(12, vh - height - 52);
  const left = Math.round(Math.max(marginX, Math.min(maxLeft, bounds.left)));
  const top = Math.round(Math.max(12, Math.min(maxTop, bounds.top)));

  return { left, top, width, height };
}

export function computeDefaultWindowBounds(
  viewport: { width: number; height: number },
  cascadeIndex = 0,
  preferred?: Partial<WindowBounds> | null
): WindowBounds {
  const vw = Math.max(280, viewport.width || 1280);
  const vh = Math.max(320, viewport.height || 800);
  const marginX = vw < 400 ? 8 : 16;
  const maxDefaultW = Math.max(240, vw - marginX * 2);
  const minDefaultW = Math.min(360, maxDefaultW);
  const defaultWidth = preferred?.width ?? Math.min(920, Math.max(minDefaultW, vw - (vw < 400 ? 16 : 64)));
  const defaultHeight = preferred?.height ?? Math.min(760, Math.max(Math.min(380, vh - 72), vh - 110));
  const step = vw < 400 ? (Math.max(0, cascadeIndex) % 4) * 12 : (Math.max(0, cascadeIndex) % 5) * 28;
  const baseLeft = preferred?.left ?? Math.max(marginX, Math.round((vw - defaultWidth) / 2) + (vw < 400 ? 0 : step - 28));
  const baseTop = preferred?.top ?? Math.max(12, Math.round((vh - defaultHeight - 44) / 2) + step - (vw < 400 ? 0 : 28));

  return clampWindowBounds(
    { left: baseLeft, top: baseTop, width: defaultWidth, height: defaultHeight },
    { width: vw, height: vh }
  );
}

export function applyKeyboardWindowAdjustment(
  bounds: WindowBounds,
  mode: 'move' | 'resize',
  dir: ResizeDirection | null,
  key: string,
  shiftKey: boolean,
  viewport: { width: number; height: number },
  minWidth = 340,
  minHeight = 300
): { handled: boolean; bounds: WindowBounds } {
  const step = shiftKey ? 48 : 16;
  let dx = 0;
  let dy = 0;
  if (key === 'ArrowLeft') dx = -step;
  else if (key === 'ArrowRight') dx = step;
  else if (key === 'ArrowUp') dy = -step;
  else if (key === 'ArrowDown') dy = step;
  else return { handled: false, bounds };

  const vw = Math.max(280, viewport.width || 1280);
  const vh = Math.max(320, viewport.height || 800);
  const marginX = vw < 400 ? 8 : 12;
  const effMinW = Math.min(minWidth, Math.max(240, vw - marginX * 2));
  const effMinH = Math.min(minHeight, Math.max(220, vh - 64));

  if (mode === 'move') {
    return {
      handled: true,
      bounds: clampWindowBounds(
        {
          left: bounds.left + dx,
          top: bounds.top + dy,
          width: bounds.width,
          height: bounds.height
        },
        viewport,
        minWidth,
        minHeight
      )
    };
  }

  const edge = dir || 'se';
  const next: WindowBounds = { ...bounds };

  if (edge.includes('e')) {
    next.width = bounds.width + dx;
  }
  if (edge.includes('s')) {
    next.height = bounds.height + dy;
  }
  if (edge.includes('w')) {
    const maxWFromLeft = bounds.width + Math.max(0, bounds.left - marginX);
    const proposedW = Math.max(effMinW, Math.min(maxWFromLeft, bounds.width - dx));
    next.left = bounds.left + (bounds.width - proposedW);
    next.width = proposedW;
  }
  if (edge.includes('n')) {
    const maxHFromTop = bounds.height + Math.max(0, bounds.top - 12);
    const proposedH = Math.max(effMinH, Math.min(maxHFromTop, bounds.height - dy));
    next.top = bounds.top + (bounds.height - proposedH);
    next.height = proposedH;
  }

  return {
    handled: true,
    bounds: clampWindowBounds(next, viewport, minWidth, minHeight)
  };
}

export function classifyWindowSizeTier(width: number): WindowSizeTier {
  if (width < 540) return 'compact';
  if (width < 780) return 'medium';
  return 'wide';
}

export function getAdaptiveWindowFlags(width: number, height: number) {
  const tier = classifyWindowSizeTier(width);
  return {
    tier,
    isCompact: tier === 'compact',
    isMedium: tier === 'medium',
    isWide: tier === 'wide',
    isShort: height < 460,
    useOverflowHeaderMenu: width < 540,
    collapseOptionsRow: width < 540,
    compactTtsBar: width < 780,
    singleColumnAdvPanel: width < 580
  };
}

export type AdaptiveWindowFlags = ReturnType<typeof getAdaptiveWindowFlags>;

export type FeedCardTitleMode = 'ai' | 'dearrow' | 'original' | 'music';

export function normalizeAltTitlesEnabled(val: unknown): boolean {
  if (val === false || val === 'false' || val === 0) return false;
  return true;
}

export function resolveFeedCardTitleMode(options: {
  isMusic?: boolean;
  hasDeArrowTitle?: boolean;
  altTitlesEnabled?: boolean;
  manualOverride?: 'ai' | 'dearrow' | 'original' | null;
}): FeedCardTitleMode {
  if (options.isMusic) return 'music';
  if (options.manualOverride === 'ai') return 'ai';
  if (options.manualOverride === 'dearrow') {
    return options.hasDeArrowTitle ? 'dearrow' : 'original';
  }
  if (options.manualOverride === 'original') {
    return options.hasDeArrowTitle ? 'dearrow' : 'original';
  }
  if (options.hasDeArrowTitle) return 'dearrow';
  return options.altTitlesEnabled !== false ? 'ai' : 'original';
}

export function sanitizeGeneratedAltTitle(rawTitle: string, fallbackTitle = ''): string {
  const cleaned = String(rawTitle || '')
    .replace(/^["'#*`]+|["'#*`]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const candidate = cleaned || String(fallbackTitle || '').replace(/\s+/g, ' ').trim();
  if (!candidate) return '';
  if (candidate.length > 150) {
    return candidate.slice(0, 147).trim() + '...';
  }
  return candidate;
}

export function shouldCacheGeneratedAltTitle(
  generated: string,
  originalTitle: string,
  generatedFromContent: boolean
): boolean {
  if (!generatedFromContent) return false;
  const cleanGen = String(generated || '').replace(/\s+/g, ' ').trim();
  const cleanOrig = String(originalTitle || '').replace(/\s+/g, ' ').trim();
  if (!cleanGen || cleanGen.length < 5) return false;
  if (cleanOrig && cleanGen.toLowerCase() === cleanOrig.toLowerCase()) return false;
  return true;
}

export function normalizeCompactOptionsMap(raw: unknown): Record<string, boolean> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: Record<string, boolean> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (k && k !== '__proto__' && k !== 'constructor' && k !== 'prototype' && typeof v === 'boolean') {
      out[k] = v;
    }
  }
  return out;
}

export function extractVideoIdFromHref(href: string): string | null {
  if (!href || typeof href !== 'string') return null;
  const watchMatch = /[?&]v=([a-zA-Z0-9_-]{8,32})/.exec(href);
  if (watchMatch) return watchMatch[1];
  const shortsMatch = /\/shorts\/([a-zA-Z0-9_-]{8,32})(?:[?&#/]|$)/.exec(href);
  if (shortsMatch) return shortsMatch[1];
  const liveMatch = /\/live\/([a-zA-Z0-9_-]{8,32})(?:[?&#/]|$)/.exec(href);
  if (liveMatch) return liveMatch[1];
  return null;
}

export function pruneTimestampIndex(
  index: Record<string, number>,
  maxEntries: number,
  protectedKeys: Set<string> = new Set()
): { kept: Record<string, number>; evicted: string[] } {
  const safeMax = Math.max(1, Math.floor(maxEntries));
  const cleaned: Record<string, number> = {};
  for (const [k, v] of Object.entries(index || {})) {
    if (k && k !== '__proto__' && k !== 'constructor' && k !== 'prototype' && typeof v === 'number' && Number.isFinite(v)) {
      cleaned[k] = v;
    }
  }
  const entries = Object.entries(cleaned).sort((a, b) => a[1] - b[1]);
  const evicted: string[] = [];
  if (entries.length > safeMax) {
    let remainingCount = entries.length;
    for (const [key] of entries) {
      if (remainingCount <= safeMax) break;
      if (protectedKeys.has(key)) continue;
      delete cleaned[key];
      evicted.push(key);
      remainingCount--;
    }
  }
  return { kept: cleaned, evicted };
}

export function computeDecorrelatedJitterDelay(
  prevDelayMs: number,
  baseMs = 2000,
  maxMs = 60000,
  retryAfterMs = 0,
  randomSample = Math.random()
): number {
  const safeBase = Math.max(250, baseMs);
  const safePrev = Math.max(safeBase, prevDelayMs || safeBase);
  const safeMax = Math.max(safeBase, maxMs);
  const upper = Math.min(safeMax, safePrev * 3);
  const sample = Math.max(0, Math.min(1, Number.isFinite(randomSample) ? randomSample : 0.5));
  const jittered = Math.round(safeBase + sample * Math.max(0, upper - safeBase));
  if (retryAfterMs > 0) {
    return Math.min(safeMax, Math.max(jittered, Math.round(retryAfterMs)));
  }
  return jittered;
}

export interface MutationSignalInput {
  type: 'childList' | 'characterData' | 'attributes';
  inNoiseSubtree: boolean;
  inTitleOrDeArrowSubtree: boolean;
  attributeName?: string | null;
  hasFeedOrDeArrowNodes?: boolean;
}

export function isRelevantMutationSignal(sig: MutationSignalInput): boolean {
  if (!sig) return false;
  if (sig.type === 'attributes') {
    return sig.attributeName === 'data-dearrow' || sig.attributeName === 'data-dearrow-title';
  }
  if (sig.inNoiseSubtree && !sig.inTitleOrDeArrowSubtree) {
    return false;
  }
  if (sig.type === 'characterData') {
    return Boolean(sig.inTitleOrDeArrowSubtree);
  }
  if (sig.type === 'childList') {
    return Boolean(sig.hasFeedOrDeArrowNodes || (sig.inTitleOrDeArrowSubtree && !sig.inNoiseSubtree));
  }
  return false;
}

// --- FEAT-01: Interactive Timestamp Cue Sync Lookup ---
export function findTranscriptCueIndexForSeconds(
  cues: Array<{ startSec: number }>,
  targetSec: number
): number {
  if (!Array.isArray(cues) || cues.length === 0 || !Number.isFinite(targetSec)) return -1;
  const clamped = Math.max(0, Math.floor(targetSec));
  let bestIdx = 0;
  for (let i = 0; i < cues.length; i++) {
    if (cues[i].startSec <= clamped) {
      bestIdx = i;
    } else {
      break;
    }
  }
  return bestIdx;
}

// --- FEAT-02: Per-Channel Auto-Title Rules ---
export type ChannelTitleRule = 'default' | 'exempt' | 'force_ai';

export function normalizeChannelRuleKey(channelName: string): string {
  const cleaned = String(channelName || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
  if (!cleaned || cleaned === '__proto__' || cleaned === 'constructor' || cleaned === 'prototype') {
    return '';
  }
  return cleaned;
}

export function normalizeChannelTitleRules(raw: unknown): Record<string, 'exempt' | 'force_ai'> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: Record<string, 'exempt' | 'force_ai'> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const key = normalizeChannelRuleKey(k);
    if (!key) continue;
    if (v === 'exempt' || v === 'force_ai') {
      out[key] = v;
    }
  }
  return out;
}

export function setChannelTitleRuleInMap(
  rules: Record<string, 'exempt' | 'force_ai'>,
  channelName: string,
  rule: ChannelTitleRule
): Record<string, 'exempt' | 'force_ai'> {
  const next = normalizeChannelTitleRules(rules);
  const key = normalizeChannelRuleKey(channelName);
  if (!key) return next;
  if (rule === 'exempt' || rule === 'force_ai') {
    next[key] = rule;
  } else {
    delete next[key];
  }
  return next;
}

export function resolveAutoTitleDecision(options: {
  altTitlesEnabled?: boolean;
  isMusic?: boolean;
  hasDeArrowTitle?: boolean;
  channelName?: string;
  channelRules?: Record<string, 'exempt' | 'force_ai'>;
  manualOverride?: 'ai' | 'dearrow' | 'original' | null;
}): {
  mode: FeedCardTitleMode;
  rule: ChannelTitleRule;
  shouldAutoFetchAi: boolean;
} {
  const key = normalizeChannelRuleKey(options.channelName || '');
  const rule: ChannelTitleRule = (key && options.channelRules?.[key]) || 'default';

  if (options.manualOverride === 'ai') {
    return { mode: 'ai', rule, shouldAutoFetchAi: true };
  }
  if (options.manualOverride === 'dearrow') {
    return { mode: options.hasDeArrowTitle ? 'dearrow' : 'original', rule, shouldAutoFetchAi: false };
  }
  if (options.manualOverride === 'original') {
    return { mode: options.hasDeArrowTitle ? 'dearrow' : 'original', rule, shouldAutoFetchAi: false };
  }

  if (rule === 'exempt') {
    if (options.isMusic) return { mode: 'music', rule, shouldAutoFetchAi: false };
    return { mode: options.hasDeArrowTitle ? 'dearrow' : 'original', rule, shouldAutoFetchAi: false };
  }

  if (rule === 'force_ai' && options.altTitlesEnabled !== false) {
    return { mode: 'ai', rule, shouldAutoFetchAi: true };
  }

  if (options.isMusic) {
    return { mode: 'music', rule, shouldAutoFetchAi: false };
  }
  if (options.hasDeArrowTitle) {
    return { mode: 'dearrow', rule, shouldAutoFetchAi: false };
  }
  const enabled = options.altTitlesEnabled !== false;
  return { mode: enabled ? 'ai' : 'original', rule, shouldAutoFetchAi: enabled };
}

const CACHE_KEY_PREFIXES = ['sum:', 'sut:', 'trn:', 'trt:'];
const SCOPED_PERSONA_KEY_SEGMENTS = ['technical:', 'quiz:', 'chronological:', 'executive:'];

export function extractVideoIdFromCacheKey(key: string): string {
  if (!key || typeof key !== 'string') return '';
  if (!CACHE_KEY_PREFIXES.some((p) => key.startsWith(p))) return '';
  const rest = key.slice(4);
  for (const seg of SCOPED_PERSONA_KEY_SEGMENTS) {
    if (rest.startsWith(seg)) {
      return rest.slice(seg.length);
    }
  }
  return rest;
}

export function countUniqueCachedVideoIds(
  allKeys: string[],
  cacheIndexKeys: string[] = []
): number {
  const seenIds = new Set<string>();
  const combined = [...(Array.isArray(cacheIndexKeys) ? cacheIndexKeys : []), ...(Array.isArray(allKeys) ? allKeys : [])];
  for (let i = 0; i < combined.length; i++) {
    const id = extractVideoIdFromCacheKey(combined[i]);
    if (id) seenIds.add(id);
  }
  return seenIds.size;
}

export function shouldDeferBackgroundAltTitleFetch(options: {
  isExplicitCall?: boolean;
  hasCachedAltTitle?: boolean;
  hasTranscriptInMemoryOrMock?: boolean;
  pageLoadSettled?: boolean;
  isIntersectingViewport?: boolean;
}): {
  action: 'fetch_now' | 'defer_until_load' | 'observe_visibility';
  reason: string;
} {
  if (options.hasCachedAltTitle || options.hasTranscriptInMemoryOrMock || options.isExplicitCall) {
    return { action: 'fetch_now', reason: options.isExplicitCall ? 'explicit' : 'zero_network_cache' };
  }
  if (!options.pageLoadSettled) {
    return { action: 'defer_until_load', reason: 'page_loading' };
  }
  if (options.isIntersectingViewport === false) {
    return { action: 'observe_visibility', reason: 'offscreen' };
  }
  return { action: 'fetch_now', reason: 'visible_after_load' };
}

// --- FEAT-03: Summary Persona & Output Format Presets ---
export type SummaryPersona = 'executive' | 'technical' | 'quiz' | 'chronological';

export interface SummaryPersonaPreset {
  id: SummaryPersona;
  label: string;
  shortLabel: string;
  description: string;
  systemDirective: string;
  promptAppendix: string;
}

export const SUMMARY_PERSONA_PRESETS: Record<SummaryPersona, SummaryPersonaPreset> = {
  executive: {
    id: 'executive',
    label: 'Executive Brief',
    shortLabel: 'Executive',
    description: 'High-signal thesis, core takeaways, and concise bottom-line verdict.',
    systemDirective:
      'Adopt an Executive Brief persona: lead with the bottom-line thesis, eliminate filler, and isolate the top 3-5 high-leverage insights.',
    promptAppendix: ''
  },
  technical: {
    id: 'technical',
    label: 'Deep Technical / Code',
    shortLabel: 'Technical',
    description: 'Architecture mechanics, APIs/commands, equations, benchmarks, and edge cases.',
    systemDirective:
      'Adopt a Principal Systems Engineer persona: preserve exact formulas, metrics, code/CLI patterns, architecture trade-offs, and quantitative bounds without oversimplification.',
    promptAppendix:
      '\nFormat emphasis (Deep Technical / Code): Include "## Technical architecture & mechanics" with concrete formulas, parameters, code or protocol specifics, and trade-offs.'
  },
  quiz: {
    id: 'quiz',
    label: 'Study Quiz & Flashcards',
    shortLabel: 'Study Quiz',
    description: 'Concept recap plus active-recall self-test questions with concise answers.',
    systemDirective:
      'Adopt an Interactive Tutor persona: explain core mental models clearly and finish with active-recall flashcards and conceptual check questions.',
    promptAppendix:
      '\nFormat emphasis (Study Quiz & Flashcards): Include a "## Study Flashcards & Self-Test" section with 4 focused Q&A pairs covering the hardest concepts in the video.'
  },
  chronological: {
    id: 'chronological',
    label: 'Chronological Timeline',
    shortLabel: 'Timeline',
    description: 'Strict time-indexed walkthrough with [MM:SS] markers for rapid chapter navigation.',
    systemDirective:
      'Adopt a Chronological Indexer persona: trace the video sequentially from opening premise to conclusion with explicit [MM:SS] markers on every topic shift.',
    promptAppendix:
      '\nFormat emphasis (Chronological Timeline): Structure the walkthrough strictly in chronological [MM:SS] order so every transition has an accurate clickable timestamp.'
  }
};

export function normalizeSummaryPersona(raw: unknown): SummaryPersona {
  if (raw === 'technical' || raw === 'quiz' || raw === 'chronological' || raw === 'executive') {
    return raw;
  }
  return 'executive';
}

export function resolveSummaryPersonaInstruction(
  persona: SummaryPersona | string,
  transcriptMode: 'fast' | 'deep' = 'fast'
): string {
  const safePersona = normalizeSummaryPersona(persona);
  const preset = SUMMARY_PERSONA_PRESETS[safePersona];
  const base =
    transcriptMode === 'deep'
      ? `You are an expert analytical researcher. Produce an exhaustive, deep, and highly detailed summary in English.\nProvide a thorough chronological walkthrough with precise timestamps [MM:SS] for every distinct topic change.\nDelve deeply into specific claims, quantitative figures, underlying mechanics, formulas, and arguments.\nInclude rich context, nuance, technical distinctions, and direct quotes where significant.\nEnsure comprehensive coverage so no important insight is omitted.`
      : `You are an expert executive summarizer. Produce an ultra-fast, high-signal, concise summary in English.\nPrioritize brevity, punchy takeaways, and rapid consumption (< 2 minutes reading time).\nFocus strictly on the core thesis and top 3-5 crucial insights.\nEliminate all filler, pleasantries, and tangential elaboration.\nDeliver maximum information density in the shortest reading time.`;
  if (safePersona === 'executive' && transcriptMode === 'fast') {
    return base;
  }
  return `${base}\n${preset.systemDirective}`;
}

export function resolveSummaryPersonaPromptSuffix(persona: SummaryPersona | string): string {
  const safePersona = normalizeSummaryPersona(persona);
  return SUMMARY_PERSONA_PRESETS[safePersona].promptAppendix;
}

// --- FEAT-04: Chapter-Aware Long-Video Synthesis Chunking (>45 min) ---
export interface VideoChapter {
  index: number;
  title: string;
  startSec: number;
  endSec: number | null;
  tsStr: string;
}

export interface TranscriptChunk {
  index: number;
  title: string;
  startSec: number;
  endSec: number;
  tsStr: string;
  text: string;
  estimatedChars: number;
  lineCount: number;
}

export interface LongVideoChunkPlan {
  isLongVideoChunked: boolean;
  totalDurationSec: number;
  thresholdSec: number;
  chapters: VideoChapter[];
  chunks: TranscriptChunk[];
}

export function parseVideoChaptersFromDescription(
  descriptionText: string,
  totalDurationSec = 0
): VideoChapter[] {
  if (!descriptionText || typeof descriptionText !== 'string') return [];
  const rawList: Array<{ startSec: number; title: string }> = [];
  const seenSec = new Set<number>();
  const lines = descriptionText.split('\n');

  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    if (!trimmed) continue;
    const m =
      /^(?:#{1,4}\s*)?(?:[-*•]\s*)?\[?((?:\d{1,2}:)?\d{1,2}:\d{2})\]?\s*(?:[-–—:|]\s*|\s+)(.+)$/.exec(
        trimmed
      );
    if (!m) continue;
    const rawTs = m[1];
    const startSec = parseTimestampToSeconds(rawTs);
    if (!Number.isFinite(startSec) || startSec < 0) continue;
    const cleanTitle = m[2]
      .replace(/^#{1,6}\s*/, '')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/\s+/g, ' ')
      .trim();
    if (!cleanTitle || cleanTitle.length > 140) continue;
    if (seenSec.has(startSec)) continue;
    seenSec.add(startSec);
    rawList.push({ startSec, title: cleanTitle });
  }

  rawList.sort((a, b) => a.startSec - b.startSec);
  return rawList.map((item, idx) => {
    const next = rawList[idx + 1];
    const endSec = next
      ? next.startSec
      : totalDurationSec > item.startSec
      ? Math.floor(totalDurationSec)
      : null;
    return {
      index: idx,
      title: item.title,
      startSec: item.startSec,
      endSec,
      tsStr: `[${formatSecondsToTimestamp(item.startSec)}]`
    };
  });
}

export function extractSummaryChapters(
  summaryText: string,
  descriptionChapters: VideoChapter[] = [],
  totalDurationSec = 0
): VideoChapter[] {
  if (Array.isArray(descriptionChapters) && descriptionChapters.length >= 2) {
    return descriptionChapters.map((ch, idx) => ({ ...ch, index: idx }));
  }
  if (!summaryText || typeof summaryText !== 'string') return [];
  const headingLines = summaryText
    .split('\n')
    .filter((line) => /^\s*#{2,4}\s*\[?(?:(?:\d{1,2}:)?\d{1,2}:\d{2})\]?/.test(line));
  if (headingLines.length >= 2) {
    return parseVideoChaptersFromDescription(headingLines.join('\n'), totalDurationSec);
  }
  return Array.isArray(descriptionChapters) ? descriptionChapters.slice() : [];
}

export function buildLongVideoTranscriptChunks(
  transcriptText: string,
  options: {
    thresholdSec?: number;
    maxChunkSec?: number;
    chapters?: VideoChapter[];
    totalDurationSec?: number;
  } = {}
): LongVideoChunkPlan {
  const thresholdSec = Math.max(60, Math.floor(options.thresholdSec ?? 2700)); // Default 45 minutes
  const maxChunkSec = Math.max(120, Math.floor(options.maxChunkSec ?? 1200)); // Default 20-min windows
  const text = String(transcriptText || '');
  const lines = text.split('\n').filter((l) => l.trim().length > 0);

  let maxLineSec = 0;
  const parsedLines: Array<{ sec: number; line: string }> = [];
  let lastSec = 0;

  for (const rawLine of lines) {
    const m = /^\[((?:\d{1,2}:)?\d{1,2}:\d{2})\]/.exec(rawLine.trim());
    if (m) {
      const sec = parseTimestampToSeconds(m[1]);
      if (Number.isFinite(sec) && sec >= 0) {
        lastSec = sec;
        if (sec > maxLineSec) maxLineSec = sec;
      }
    }
    parsedLines.push({ sec: lastSec, line: rawLine });
  }

  const totalDurationSec = Math.max(
    Math.floor(options.totalDurationSec || 0),
    maxLineSec
  );

  const providedChapters = Array.isArray(options.chapters)
    ? [...options.chapters].sort((a, b) => a.startSec - b.startSec).map((ch, idx, arr) => ({
        index: idx,
        title: ch.title,
        startSec: ch.startSec,
        endSec: arr[idx + 1]
          ? arr[idx + 1].startSec
          : totalDurationSec > ch.startSec
          ? totalDurationSec
          : ch.endSec,
        tsStr: ch.tsStr || `[${formatSecondsToTimestamp(ch.startSec)}]`
      }))
    : [];

  if (totalDurationSec <= thresholdSec) {
    const singleChapter: VideoChapter[] =
      providedChapters.length > 0
        ? providedChapters
        : [];
    return {
      isLongVideoChunked: false,
      totalDurationSec,
      thresholdSec,
      chapters: singleChapter,
      chunks: [
        {
          index: 0,
          title: providedChapters[0]?.title || 'Full Transcript',
          startSec: 0,
          endSec: totalDurationSec,
          tsStr: providedChapters[0]?.tsStr || '[00:00]',
          text,
          estimatedChars: text.length,
          lineCount: lines.length
        }
      ]
    };
  }

  // Long video (> thresholdSec): use chapters when >= 2, else uniform maxChunkSec windows
  let effectiveChapters: VideoChapter[] = providedChapters;
  if (effectiveChapters.length < 2) {
    effectiveChapters = [];
    const windowCount = Math.max(2, Math.ceil((totalDurationSec + 1) / maxChunkSec));
    for (let i = 0; i < windowCount; i++) {
      const startSec = i * maxChunkSec;
      const endSec = Math.min(totalDurationSec, (i + 1) * maxChunkSec);
      if (startSec > totalDurationSec && i > 0) break;
      effectiveChapters.push({
        index: i,
        title: `Segment ${i + 1} (${formatSecondsToTimestamp(startSec)}–${formatSecondsToTimestamp(endSec)})`,
        startSec,
        endSec,
        tsStr: `[${formatSecondsToTimestamp(startSec)}]`
      });
    }
  }

  const buckets: string[][] = effectiveChapters.map(() => []);
  for (const item of parsedLines) {
    let targetIdx = 0;
    for (let i = 0; i < effectiveChapters.length; i++) {
      if (item.sec >= effectiveChapters[i].startSec) {
        targetIdx = i;
      } else {
        break;
      }
    }
    buckets[targetIdx].push(item.line);
  }

  const chunks: TranscriptChunk[] = [];
  for (let i = 0; i < effectiveChapters.length; i++) {
    const ch = effectiveChapters[i];
    const bucketLines = buckets[i];
    if (bucketLines.length === 0 && parsedLines.length > 0) continue;
    const chunkText = bucketLines.join('\n');
    chunks.push({
      index: chunks.length,
      title: ch.title,
      startSec: ch.startSec,
      endSec: ch.endSec ?? totalDurationSec,
      tsStr: ch.tsStr,
      text: chunkText,
      estimatedChars: chunkText.length,
      lineCount: bucketLines.length
    });
  }

  if (chunks.length === 0) {
    chunks.push({
      index: 0,
      title: effectiveChapters[0]?.title || 'Segment 1',
      startSec: 0,
      endSec: totalDurationSec,
      tsStr: '[00:00]',
      text,
      estimatedChars: text.length,
      lineCount: lines.length
    });
  }

  return {
    isLongVideoChunked: true,
    totalDurationSec,
    thresholdSec,
    chapters: effectiveChapters,
    chunks
  };
}

export function buildChunkMapPrompt(
  videoTitle: string,
  chunk: TranscriptChunk,
  totalChunks: number,
  persona: SummaryPersona | string = 'executive'
): string {
  const safePersona = normalizeSummaryPersona(persona);
  const preset = SUMMARY_PERSONA_PRESETS[safePersona];
  return [
    `Analyze chapter ${chunk.index + 1} of ${totalChunks} for "${videoTitle}": "${chunk.title}" starting at ${chunk.tsStr}.`,
    `Persona focus: ${preset.label} — ${preset.description}`,
    `Extract the exact claims, arguments, equations, metrics, and concrete takeaways from this segment with accurate [MM:SS] or [H:MM:SS] timestamps.`,
    `Do not invent timestamps or omit technical specifics. Keep output under 350 words.`,
    `\nCHAPTER TRANSCRIPT (${chunk.tsStr}):\n${chunk.text}`
  ].join('\n');
}

export function buildChunkReducePrompt(
  videoTitle: string,
  chunkSummaries: Array<{ title: string; tsStr: string; summary: string }>,
  persona: SummaryPersona | string = 'executive',
  transcriptMode: 'fast' | 'deep' = 'fast'
): string {
  const safePersona = normalizeSummaryPersona(persona);
  const sectionsText = chunkSummaries
    .map((cs, idx) => `### Chapter ${idx + 1}: ${cs.tsStr} ${cs.title}\n${cs.summary}`)
    .join('\n\n');
  const suffix = resolveSummaryPersonaPromptSuffix(safePersona);
  const detailLabel = transcriptMode === 'deep' ? 'thorough, exhaustive synthesis' : 'crisp executive synthesis';

  return [
    `Synthesize these ${chunkSummaries.length} chapter analyses of the long video "${videoTitle}" into a single coherent ${detailLabel}.`,
    `Preserve exact chapter timestamps using "### [MM:SS] Chapter Title" headings under "## Detailed summary", plus "## TL;DR", "## Key takeaways", "## Notable details", and "## Worth your time?".`,
    suffix ? suffix.trim() : '',
    `\nCHAPTER ANALYSES:\n${sectionsText}`
  ]
    .filter(Boolean)
    .join('\n');
}

// --- FEAT-06: Offline Obsidian / Markdown Bundle Export ---
function linkifyTimestampsForObsidian(text: string, videoId: string): string {
  if (!text) return '';
  const baseUrl = `https://www.youtube.com/watch?v=${videoId}`;
  return text.replace(/\[((?:\d{1,2}:)?\d{1,2}:\d{2})\](?!\()/g, (_m, ts) => {
    const sec = parseTimestampToSeconds(ts);
    return `[${ts}](${baseUrl}&t=${sec}s)`;
  });
}

export function formatSummaryExportMarkdown(data: {
  videoId: string;
  videoTitle?: string;
  channel?: string;
  duration?: string;
  mode?: string;
  source?: string;
  processingMode?: string;
  persona?: SummaryPersona | string;
  model?: string;
  text?: string;
  chapters?: VideoChapter[];
  factCheck?: string | null;
  citations?: Array<{ uri: string; title: string }>;
  followUpQuestions?: Array<{
    question: string;
    answer: string;
    model?: string;
    sources?: Array<{ uri: string; title: string }>;
    imageUri?: string;
  }>;
  ratings?: {
    main: ResponseRatingRecord | null;
    followUps: Record<string, ResponseRatingRecord>;
  };
  exportedAt?: string;
}): string {
  const videoId = data.videoId || 'unknown';
  const title = data.videoTitle || videoId || 'Untitled Video';
  const channel = data.channel || 'YouTube Creator';
  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const mode = data.mode || 'summary';
  const source = data.source || 'video';
  const processingMode = data.processingMode || 'fast';
  const persona = normalizeSummaryPersona(data.persona);
  const model = data.model || 'gemini-3.8-flash';
  const exportedAt = data.exportedAt || new Date().toISOString();

  const lines: string[] = [
    '---',
    `title: ${JSON.stringify(title)}`,
    `channel: ${JSON.stringify(channel)}`,
    `video_id: ${JSON.stringify(videoId)}`,
    `url: ${JSON.stringify(videoUrl)}`,
    ...(data.duration ? [`duration: ${JSON.stringify(data.duration)}`] : []),
    `mode: ${JSON.stringify(mode)}`,
    `source: ${JSON.stringify(source)}`,
    `processing_mode: ${JSON.stringify(processingMode)}`,
    `persona: ${JSON.stringify(persona)}`,
    `model: ${JSON.stringify(model)}`,
    `exported_at: ${JSON.stringify(exportedAt)}`,
    'tags:',
    '  - youtube-summary',
    `  - persona-${persona}`,
    `  - mode-${mode}`,
    '---',
    '',
    `# ${title}`,
    '',
    `> **Channel:** ${channel} | **Source:** [Watch on YouTube](${videoUrl}) | **Persona:** ${SUMMARY_PERSONA_PRESETS[persona].label} | **Model:** \`${model}\``,
    ''
  ];

  const cleanBody = linkifyTimestampsForObsidian(
    formatMathSymbolsInText(String(data.text || ''))
      .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
      .trim(),
    videoId
  );

  const chapters =
    Array.isArray(data.chapters) && data.chapters.length > 0
      ? data.chapters
      : extractSummaryChapters(String(data.text || ''));

  if (chapters.length > 0) {
    lines.push('## Chapters', '');
    for (const ch of chapters) {
      const cleanTs = ch.tsStr.replace(/[\[\]]/g, '');
      lines.push(`- [${cleanTs}](${videoUrl}&t=${ch.startSec}s) — ${formatMathSymbolsInText(ch.title)}`);
    }
    lines.push('');
  }

  if (cleanBody) {
    lines.push(cleanBody, '');
  }

  if (data.factCheck && data.factCheck.trim()) {
    lines.push('## Fact-Check & Verification', '');
    lines.push(linkifyTimestampsForObsidian(formatMathSymbolsInText(data.factCheck.trim()), videoId), '');
  }

  if (data.citations && data.citations.length > 0) {
    lines.push('## Sources & Citations', '');
    for (const c of data.citations) {
      const label = (c.title || c.uri).replace(/[\[\]]/g, '');
      lines.push(`- [${label}](${c.uri})`);
    }
    lines.push('');
  }

  if (data.followUpQuestions && data.followUpQuestions.length > 0) {
    lines.push('## Follow-Up Q&A', '');
    data.followUpQuestions.forEach((turn, idx) => {
      lines.push(`### Q${idx + 1}: ${formatMathSymbolsInText(turn.question)}`, '');
      if (turn.model) {
        lines.push(`*Model:* \`${turn.model}\``, '');
      }
      lines.push(linkifyTimestampsForObsidian(formatMathSymbolsInText(turn.answer), videoId), '');
      if (turn.imageUri) {
        lines.push(`![Generated Diagram](${turn.imageUri})`, '');
      }
      if (turn.sources && turn.sources.length > 0) {
        lines.push('**Grounded Sources:**');
        for (const s of turn.sources) {
          lines.push(`- [${(s.title || s.uri).replace(/[\[\]]/g, '')}](${s.uri})`);
        }
        lines.push('');
      }
    });
  }

  const mainRating = data.ratings?.main || null;
  const followUpEntries = Object.entries(data.ratings?.followUps || {});
  if (mainRating || followUpEntries.length > 0) {
    lines.push('## Quality Ratings & Notes', '');
    if (mainRating) {
      const badge = mainRating.rating === 'up' ? '👍 Helpful' : '👎 Needs improvement';
      lines.push(`- **Main ${mode}:** ${badge}${mainRating.note ? ` — "${formatMathSymbolsInText(mainRating.note)}"` : ''}`);
    }
    for (const [turnKey, r] of followUpEntries) {
      const badge = r.rating === 'up' ? '👍 Helpful' : '👎 Needs improvement';
      lines.push(`- **Follow-up (${turnKey}):** ${badge}${r.note ? ` — "${formatMathSymbolsInText(r.note)}"` : ''}`);
    }
    lines.push('');
  }

  lines.push('---', `*Exported by YouTube Feed Summariser (Gemini) on ${exportedAt}*`, '');
  return lines.join('\n');
}

// --- FEAT-07: Interactive Multi-Host Podcast Studio (NotebookLM-Style) ---
export type GeminiPrebuiltVoice = 'Kore' | 'Puck' | 'Zephyr' | 'Fenrir' | 'Charon';

export interface PodcastHost {
  id: string;
  name: string;
  role: string;
  voiceName: GeminiPrebuiltVoice;
  pitch: number;
  style: string;
  color: string;
}

export interface PodcastTurn {
  id: string;
  speaker: string;
  role: string;
  voiceName: string;
  pitch: number;
  text: string;
  isUser?: boolean;
  isResponse?: boolean;
  isVoiceInput?: boolean;
  timestampSec?: number | null;
}

export interface PodcastEpisode {
  title: string;
  hostCount: number;
  hosts: PodcastHost[];
  turns: PodcastTurn[];
  createdAt: number;
}

const DEFAULT_PODCAST_HOST_POOL: Array<Omit<PodcastHost, 'id'>> = [
  {
    name: 'Alex',
    role: 'Lead Moderator',
    voiceName: 'Kore',
    pitch: 1.04,
    style: 'Warm, articulate, curious podcast host keeping pacing crisp',
    color: '#38bdf8'
  },
  {
    name: 'Sam',
    role: 'Deep-Dive Analyst',
    voiceName: 'Puck',
    pitch: 0.94,
    style: 'Analytical co-host translating complex mechanics into clear analogies',
    color: '#a855f7'
  },
  {
    name: 'Maya',
    role: 'Critical Skeptic',
    voiceName: 'Zephyr',
    pitch: 1.12,
    style: 'Sharp investigative voice probing assumptions, benchmarks, and edge cases',
    color: '#34d399'
  },
  {
    name: 'Jordan',
    role: 'Applied Strategist',
    voiceName: 'Fenrir',
    pitch: 0.86,
    style: 'Grounded practitioner connecting insights to real-world workflows',
    color: '#fbbf24'
  },
  {
    name: 'Priya',
    role: 'Systems Synthesizer',
    voiceName: 'Charon',
    pitch: 1.0,
    style: 'Calm synthesizer highlighting broader context and long-term implications',
    color: '#f472b6'
  },
  {
    name: 'Leo',
    role: 'Counterpoint Producer',
    voiceName: 'Puck',
    pitch: 0.9,
    style: 'Energetic producer surfacing listener questions and practical takeaways',
    color: '#fb7185'
  }
];

export function normalizePodcastHostCount(raw: unknown, min = 2, max = 6): number {
  const safeMin = Math.max(2, Math.floor(min));
  const safeMax = Math.max(safeMin, Math.floor(max));
  const n = typeof raw === 'number' ? raw : parseInt(String(raw ?? ''), 10);
  if (!Number.isFinite(n)) return safeMin;
  return Math.max(safeMin, Math.min(safeMax, Math.floor(n)));
}

export function buildDefaultPodcastHosts(
  hostCount: unknown,
  customHosts?: Array<Partial<PodcastHost>>
): PodcastHost[] {
  const count = normalizePodcastHostCount(hostCount);
  const hosts: PodcastHost[] = [];
  for (let i = 0; i < count; i++) {
    const preset = DEFAULT_PODCAST_HOST_POOL[i % DEFAULT_PODCAST_HOST_POOL.length];
    const suffix = i >= DEFAULT_PODCAST_HOST_POOL.length ? ` ${Math.floor(i / DEFAULT_PODCAST_HOST_POOL.length) + 1}` : '';
    const custom = Array.isArray(customHosts) ? customHosts[i] : undefined;
    const validVoice: GeminiPrebuiltVoice =
      custom?.voiceName && ['Kore', 'Puck', 'Zephyr', 'Fenrir', 'Charon'].includes(custom.voiceName)
        ? (custom.voiceName as GeminiPrebuiltVoice)
        : preset.voiceName;
    const cleanName = typeof custom?.name === 'string' && custom.name.trim()
      ? custom.name.trim().slice(0, 32)
      : `${preset.name}${suffix}`;
    const cleanRole = typeof custom?.role === 'string' && custom.role.trim()
      ? custom.role.trim().slice(0, 48)
      : preset.role;
    hosts.push({
      id: `host_${i + 1}`,
      name: cleanName,
      role: cleanRole,
      voiceName: validVoice,
      pitch: clampPitch(typeof custom?.pitch === 'number' ? custom.pitch : preset.pitch),
      style: preset.style,
      color: custom?.color || preset.color
    });
  }
  return hosts;
}

export function buildPodcastScriptPrompt(options: {
  videoTitle: string;
  summaryText: string;
  hosts: PodcastHost[];
}): string {
  const hosts = Array.isArray(options.hosts) && options.hosts.length >= 2
    ? options.hosts
    : buildDefaultPodcastHosts(2);
  const rosterDesc = hosts
    .map((h, idx) => `${idx + 1}. ${h.name} (${h.role}) — ${h.style}`)
    .join('\n');
  const turnTarget = Math.max(8, Math.min(18, hosts.length * 4));

  return [
    `Create an engaging, deeply informed NotebookLM-style podcast episode discussing the video "${options.videoTitle || 'Untitled Video'}".`,
    `Use ALL ${hosts.length} hosts below so every single host contributes distinct, balanced turns:`,
    rosterDesc,
    '',
    `Guidelines:`,
    `- Write ${turnTarget} natural spoken dialogue turns grounded strictly in the provided video summary.`,
    `- Keep each turn crisp (2–4 sentences), conversational, and reactive (hosts agree, build analogies, probe caveats, and reference timestamps like [MM:SS] naturally without reading brackets robotically).`,
    `- Include every host by exact first name: ${hosts.map((h) => h.name).join(', ')}.`,
    `- Return valid JSON only (no extra prose) matching this exact schema:`,
    `{"title":"Episode title","turns":[{"speaker":"${hosts[0].name}","text":"Spoken dialogue...","timestampSec":0}]}`,
    '',
    `VIDEO SUMMARY:`,
    `"""`,
    String(options.summaryText || '').slice(0, 12000),
    `"""`
  ].join('\n');
}

export function buildPodcastInteractionPrompt(options: {
  videoTitle: string;
  summaryText: string;
  hosts: PodcastHost[];
  recentTurns: PodcastTurn[];
  listenerQuery: string;
  isVoice?: boolean;
}): string {
  const hosts = Array.isArray(options.hosts) && options.hosts.length >= 2
    ? options.hosts
    : buildDefaultPodcastHosts(2);
  const recentCtx = (options.recentTurns || [])
    .slice(-5)
    .map((t) => `${t.speaker}: ${t.text}`)
    .join('\n');

  return [
    `You are hosting a live interactive NotebookLM-style podcast about "${options.videoTitle || 'Untitled Video'}".`,
    `Active Host Panel (${hosts.length} hosts):`,
    ...hosts.map((h) => `- ${h.name} (${h.role})`),
    '',
    `RECENT SHOW CONTEXT:`,
    recentCtx || '(Beginning of episode)',
    '',
    `LISTENER ${options.isVoice ? 'VOICE ' : ''}INTERRUPTION / QUESTION:`,
    `"${String(options.listenerQuery || '').trim()}"`,
    '',
    `Instructions:`,
    `- Respond immediately as 2 to ${Math.min(hosts.length, 3)} of the active hosts acknowledging the listener directly ("Great question from our listener…") and answering accurately using the video summary.`,
    `- Keep it natural, conversational, and concise (2–4 dialogue turns total).`,
    `- Return valid JSON only matching:`,
    `{"turns":[{"speaker":"${hosts[0].name}","text":"Spoken answer..."}]}`,
    '',
    `VIDEO SUMMARY:`,
    `"""`,
    String(options.summaryText || '').slice(0, 10000),
    `"""`
  ].join('\n');
}

function matchPodcastHost(speakerRaw: string, hosts: PodcastHost[], fallbackIdx: number): PodcastHost {
  const cleaned = String(speakerRaw || '').replace(/[\[\]:*]/g, '').trim().toLowerCase();
  if (cleaned) {
    const exact = hosts.find((h) => h.name.toLowerCase() === cleaned);
    if (exact) return exact;
    const partial = hosts.find(
      (h) => cleaned.includes(h.name.toLowerCase()) || h.name.toLowerCase().includes(cleaned)
    );
    if (partial) return partial;
    const hostNumMatch = /^host\s*#?\s*(\d+)$/i.exec(cleaned);
    if (hostNumMatch) {
      const idx = parseInt(hostNumMatch[1], 10) - 1;
      if (idx >= 0 && idx < hosts.length) return hosts[idx];
    }
  }
  return hosts[fallbackIdx % hosts.length];
}

function extractTimestampSecFromText(text: string): number | null {
  const m = /\[((?:\d{1,2}:)?\d{1,2}:\d{2})\]/.exec(String(text || ''));
  if (!m) return null;
  const sec = parseTimestampToSeconds(m[1]);
  return Number.isFinite(sec) ? sec : null;
}

function sanitizeSpokenTurnText(raw: string): string {
  return formatMathSymbolsInText(String(raw || ''))
    .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
    .replace(/^\s*(?:\*{1,2})?[A-Za-z][A-Za-z0-9 _.-]{0,28}(?:\*{1,2})?\s*:\s*/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parsePodcastScriptResponse(
  rawText: string,
  hosts: PodcastHost[],
  options: { episodeTitle?: string; markAsResponse?: boolean } = {}
): { title: string; turns: PodcastTurn[] } {
  const safeHosts = Array.isArray(hosts) && hosts.length >= 2 ? hosts : buildDefaultPodcastHosts(2);
  const raw = String(rawText || '').trim();
  const defaultTitle = options.episodeTitle || 'Audio Deep Dive';

  if (!raw) {
    return { title: defaultTitle, turns: [] };
  }

  // 1. Try JSON parsing (raw or extracted fenced block / outermost object)
  let jsonCandidate = raw;
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(raw);
  if (fenced) {
    jsonCandidate = fenced[1].trim();
  } else {
    const firstBrace = raw.indexOf('{');
    const lastBrace = raw.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace > firstBrace) {
      jsonCandidate = raw.slice(firstBrace, lastBrace + 1);
    }
  }

  try {
    const parsed = JSON.parse(jsonCandidate);
    const rawTurns = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.turns) ? parsed.turns : null;
    if (rawTurns && rawTurns.length > 0) {
      const turns: PodcastTurn[] = [];
      rawTurns.forEach((item: any, idx: number) => {
        const text = sanitizeSpokenTurnText(item?.text || item?.line || item?.content || '');
        if (!text) return;
        const host = matchPodcastHost(item?.speaker || item?.host || '', safeHosts, idx);
        const tsSec =
          typeof item?.timestampSec === 'number' && Number.isFinite(item.timestampSec)
            ? Math.max(0, Math.floor(item.timestampSec))
            : extractTimestampSecFromText(item?.text || '');
        turns.push({
          id: `pod_turn_${idx + 1}_${Date.now().toString(36)}`,
          speaker: host.name,
          role: host.role,
          voiceName: host.voiceName,
          pitch: host.pitch,
          text,
          isResponse: Boolean(options.markAsResponse),
          timestampSec: tsSec
        });
      });
      if (turns.length > 0) {
        return {
          title: typeof parsed?.title === 'string' && parsed.title.trim() ? parsed.title.trim() : defaultTitle,
          turns
        };
      }
    }
  } catch (_) {}

  // 2. Fallback: labeled lines ("Alex: ...", "**Sam:** ...", "[Maya]: ...")
  const turns: PodcastTurn[] = [];
  const lines = raw.split('\n').map((l) => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (line.startsWith('{') || line.startsWith('}') || line.startsWith('```')) continue;
    const m = /^\[?([A-Za-z][A-Za-z0-9 _.-]{0,28})\]?\s*:\s*(.+)$/.exec(line.replace(/\*\*/g, ''));
    const rawSpeaker = m ? m[1] : '';
    const rawSpeech = m ? m[2] : line;
    const cleanSpeech = formatMathSymbolsInText(rawSpeech).replace(/\s+/g, ' ').trim();
    if (!cleanSpeech || cleanSpeech.length < 4) continue;
    const host = matchPodcastHost(rawSpeaker, safeHosts, turns.length);
    turns.push({
      id: `pod_turn_${turns.length + 1}`,
      speaker: host.name,
      role: host.role,
      voiceName: host.voiceName,
      pitch: host.pitch,
      text: cleanSpeech,
      isResponse: Boolean(options.markAsResponse),
      timestampSec: extractTimestampSecFromText(cleanSpeech)
    });
  }

  return { title: defaultTitle, turns };
}

function stripInlineMarkdown(str: string): string {
  if (!str) return '';
  return formatMathSymbolsInText(str)
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '$1')
    .replace(/__([^_]+)__/g, '$1')
    .replace(/_([^_]+)_/g, '$1')
    .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '')
    .trim();
}

function extractSummaryKeyInsights(summaryText: string): Array<{ text: string; timestampSec: number | null }> {
  const formatted = formatMathSymbolsInText(String(summaryText || ''))
    .replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]*\]\]/gi, '');
  const lines = formatted
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  const insights: Array<{ text: string; timestampSec: number | null }> = [];
  for (const line of lines) {
    if (/^#{1,6}\s*(?:TL;?DR|Key takeaways|Detailed summary|Concise summary|Notable details|Worth your time\??)$/i.test(line)) {
      continue;
    }
    const clean = stripInlineMarkdown(line.replace(/^[-*•]\s+/, '').replace(/^#{1,6}\s+/, '')).trim();
    if (clean.length < 18) continue;
    insights.push({
      text: clean,
      timestampSec: extractTimestampSecFromText(line)
    });
  }
  if (insights.length === 0 && formatted.trim()) {
    insights.push({ text: formatted.trim().slice(0, 260), timestampSec: 0 });
  }
  return insights;
}

export function buildDeterministicPodcastEpisode(options: {
  videoTitle: string;
  summaryText: string;
  hosts: PodcastHost[];
}): PodcastEpisode {
  const hosts = Array.isArray(options.hosts) && options.hosts.length >= 2
    ? options.hosts
    : buildDefaultPodcastHosts(2);
  const title = (options.videoTitle || 'Video Deep Dive').trim();
  const insights = extractSummaryKeyInsights(options.summaryText);
  const turns: PodcastTurn[] = [];

  const introHost = hosts[0];
  turns.push({
    id: 'pod_turn_1',
    speaker: introHost.name,
    role: introHost.role,
    voiceName: introHost.voiceName,
    pitch: introHost.pitch,
    text: `Welcome back to Deep Dive Studio! Today our ${hosts.length}-host panel is breaking down "${title}". ${insights[0] ? insights[0].text : 'Let us unpack the core thesis right away.'}`,
    timestampSec: insights[0]?.timestampSec ?? 0
  });

  const maxDiscussionTurns = Math.max(hosts.length + 1, Math.min(12, Math.max(insights.length, hosts.length) + 1));
  for (let i = 1; i < maxDiscussionTurns; i++) {
    const host = hosts[i % hosts.length];
    const insight = insights[i % Math.max(1, insights.length)];
    let spoken = '';
    if (i === 1) {
      spoken = `From the ${host.role.toLowerCase()} lens, the standout point here is: ${insight?.text || title}.`;
    } else if (i % hosts.length === 2) {
      spoken = `Hold on — let us stress-test that claim. Specifically, the video notes: ${insight?.text || 'every benchmark still depends on real-world constraints.'}`;
    } else if (i % hosts.length === 3) {
      spoken = `Practically speaking, look closely at how this lands in day-to-day workflows: ${insight?.text || 'execution efficiency is the real differentiator.'}`;
    } else {
      spoken = `Adding onto what ${hosts[(i - 1) % hosts.length].name} raised, another critical detail from the summary is: ${insight?.text || 'this shifts long-term expectations.'}`;
    }
    turns.push({
      id: `pod_turn_${turns.length + 1}`,
      speaker: host.name,
      role: host.role,
      voiceName: host.voiceName,
      pitch: host.pitch,
      text: spoken,
      timestampSec: insight?.timestampSec ?? null
    });
  }

  const wrapHost = hosts[hosts.length - 1];
  turns.push({
    id: `pod_turn_${turns.length + 1}`,
    speaker: wrapHost.name,
    role: wrapHost.role,
    voiceName: wrapHost.voiceName,
    pitch: wrapHost.pitch,
    text: `That wraps our main breakdown — jump in anytime with a text or voice question if you want us to zoom into any point!`,
    timestampSec: null
  });

  return {
    title: `Podcast: ${title}`,
    hostCount: hosts.length,
    hosts,
    turns,
    createdAt: Date.now()
  };
}

export function buildDeterministicPodcastInteractionResponse(options: {
  videoTitle: string;
  summaryText: string;
  hosts: PodcastHost[];
  listenerQuery: string;
  isVoice?: boolean;
}): { userTurn: PodcastTurn; responseTurns: PodcastTurn[] } {
  const hosts = Array.isArray(options.hosts) && options.hosts.length >= 2
    ? options.hosts
    : buildDefaultPodcastHosts(2);
  const query = String(options.listenerQuery || '').trim();
  const insights = extractSummaryKeyInsights(options.summaryText);
  const queryWords = query
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 4);

  let bestInsight = insights[0] || { text: `the core takeaways from "${options.videoTitle || 'this video'}"`, timestampSec: 0 };
  let bestScore = -1;
  for (const ins of insights) {
    const low = ins.text.toLowerCase();
    let score = 0;
    for (const w of queryWords) {
      if (low.includes(w)) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      bestInsight = ins;
    }
  }

  const uid = Date.now().toString(36);
  const userTurn: PodcastTurn = {
    id: `pod_user_${uid}`,
    speaker: 'You (Listener)',
    role: options.isVoice ? 'Voice Question' : 'Text Question',
    voiceName: 'Kore',
    pitch: 1.0,
    text: query,
    isUser: true,
    isVoiceInput: Boolean(options.isVoice),
    timestampSec: null
  };

  const lead = hosts[0];
  const partner = hosts[1] || hosts[0];
  const third = hosts.length >= 3 ? hosts[2] : null;

  const responseTurns: PodcastTurn[] = [
    {
      id: `pod_resp_1_${uid}`,
      speaker: lead.name,
      role: lead.role,
      voiceName: lead.voiceName,
      pitch: lead.pitch,
      text: `Great question! Pausing right here to address what you asked about "${query.slice(0, 80)}${query.length > 80 ? '…' : ''}". Based on the video summary: ${bestInsight.text}`,
      isResponse: true,
      timestampSec: bestInsight.timestampSec
    },
    {
      id: `pod_resp_2_${uid}`,
      speaker: partner.name,
      role: partner.role,
      voiceName: partner.voiceName,
      pitch: partner.pitch,
      text: `To add to ${lead.name}'s point on that: it connects directly back to the video's main argument around ${insights[Math.min(1, insights.length - 1)]?.text || 'practical real-world trade-offs'}.`,
      isResponse: true,
      timestampSec: insights[Math.min(1, insights.length - 1)]?.timestampSec ?? null
    }
  ];

  if (third) {
    responseTurns.push({
      id: `pod_resp_3_${uid}`,
      speaker: third.name,
      role: third.role,
      voiceName: third.voiceName,
      pitch: third.pitch,
      text: `And one caveat to watch for: keep testing those assumptions against your own workload before jumping back into the rest of the episode!`,
      isResponse: true,
      timestampSec: null
    });
  }

  return { userTurn, responseTurns };
}

export function splicePodcastInteractionTurns(
  turns: PodcastTurn[],
  insertAfterIndex: number,
  userTurn: PodcastTurn,
  responseTurns: PodcastTurn[]
): { nextTurns: PodcastTurn[]; firstResponseIndex: number } {
  const safeTurns = Array.isArray(turns) ? turns.slice() : [];
  const validIdx =
    Number.isFinite(insertAfterIndex) && insertAfterIndex >= 0 && insertAfterIndex < safeTurns.length
      ? Math.floor(insertAfterIndex)
      : safeTurns.length - 1;
  const insertAt = validIdx + 1;
  const inserted = [userTurn, ...(Array.isArray(responseTurns) ? responseTurns : [])];
  safeTurns.splice(insertAt, 0, ...inserted);
  return {
    nextTurns: safeTurns,
    firstResponseIndex: responseTurns.length > 0 ? insertAt + 1 : insertAt
  };
}

export function buildGeminiMultiSpeakerTtsBody(
  turns: Array<{ speaker: string; text: string }>,
  hosts: PodcastHost[]
): Record<string, unknown> {
  const safeHosts = Array.isArray(hosts) && hosts.length >= 2 ? hosts : buildDefaultPodcastHosts(2);
  const primaryTwo = safeHosts.slice(0, 2);
  const parts = (turns || []).slice(0, 6).map((t, i) => {
    const matched = matchPodcastHost(t.speaker, safeHosts, i);
    const assigned = primaryTwo.find((h) => h.name === matched.name) || primaryTwo[i % 2];
    return {
      text: `${assigned.name}: ${String(t.text || '').trim()}`,
      speechMetadata: {
        speaker: assigned.name,
        style: matched.style || assigned.style
      }
    };
  });

  return {
    contents: [{ role: 'user', parts }],
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        multiSpeakerVoiceConfig: {
          speakerVoiceConfigs: primaryTwo.map((h) => ({
            speaker: h.name,
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: h.voiceName }
            }
          }))
        }
      }
    }
  };
}




