# Project Memory & State — YouTube Feed Summariser (Gemini)

> Single source of truth governed by pstack engineering & token-efficiency principles.
> Keep entries terse, factual, and free of raw chat transcripts or dead-end logs.

## 1. Tech Stack & Architecture Rules
- **Production Userscript (`/youtube-feed-summariser.user.js`, v2.11.0 header / v2.12.0 export metadata)**:
  - Runs on `https://www.youtube.com/*` with `@run-at document-idle` and Shadow DOM isolation (`#yt-ai-summary-host`).
  - **Strict Trusted Types & CSP**: Zero `innerHTML`, `outerHTML`, `insertAdjacentHTML`, or `document.write` sinks; build DOM strictly with `h()` / `hSvg()` / `clearEl()`. Zero `window.alert()` / blocking dialogs.
  - **Background Media & Network Discipline**: Feed alt-title generation disables `/watch` iframe fallback (`allowIframeFallback: false`) and gates offscreen `/watch` fetches via `IntersectionObserver` + `pageLoadSettled`; `Route B` / `Ask` iframes strip autoplay and mute/pause media via `silenceWatchDocumentMedia()`.
  - **Bounded GM Storage**: Cached summaries capped (`CONFIG.cacheMax = 100`), alt-title cache LRU (`500`), drafts LRU (`200`), ratings LRU (`500`); history tab badge uses O(keys) `getCachedSummariesCount()` without deserializing payloads.
- **Interactive React Simulator (`src/App.tsx`, `src/components/*`)**:
  - React 19 + TypeScript + Tailwind CSS v4 + Vite 8 (`port 3000`, HMR disabled in container).
  - Modular UI components under `src/components/`: `FeedSimulatorGrid.tsx`, `FloatingSummaryWindow.tsx`, `HistoryDock.tsx`, `PodcastStudioPanel.tsx`, `ReadabilityModal.tsx`, `ResponseRatingBar.tsx`, `SettingsDocsTabs.tsx`, `SimulatorTypes.ts`, `TimestampText.tsx`, `TtsControlBar.tsx`, `TtsWaveformVisualizer.tsx`.
- **AUD-08 Zero-Drift Core (`src/utils/userscript-helpers.ts`)**:
  - Pure domain logic (timestamps, math/speech cleaning, window bounds/adaptive tiers, channel title rules, personas, chapter chunking, Markdown/Obsidian export, multi-host podcast helpers, key/viewport perf gating) MUST match `youtube-feed-summariser.user.js` verbatim and pass VM parity assertions in `src/utils/userscript-helpers.test.ts`.
- **Sandbox Governance (`WORKFLOW.md`, `scripts/*`)**:
  - Prompt-end snapshots stored in `sandbox-storage/backups/`; harness state & adversarial reviews tracked in `sandbox-storage/memory/` and `sandbox-storage/reviews/`.

## 2. Active Playbook & Todo Checklist
- **Current Baseline (Stages 0–5 + Interactive Podcast & Page-Load Perf Completed)**:
  - [x] Multi-window floating containers, adaptive TTS bar scaling, waveform visualizer, Ask ladder fallback
  - [x] Auto-title replacement with DeArrow coexistence & per-channel rules (`FEAT-02`)
  - [x] Interactive timestamp jump-sync (`FEAT-01`), Summary Personas (`FEAT-03`), >45m chapter chunking (`FEAT-04`)
  - [x] Keyboard ergonomics & ARIA live announcements (`FEAT-05`), Offline Markdown/Obsidian bundle (`FEAT-06`)
  - [x] Multi-host NotebookLM-style Interactive Podcast Studio (`FEAT-07`)
  - [x] Page-load performance optimization (`@run-at document-idle`, lazy styles, key-only history count, `IntersectionObserver` deferral)
- **Active Session Setup (pstack Engineering Protocol)**:
  - [x] Scan workspace layout, git availability, sandbox memory, and test suites
  - [x] Initialize `/PROJECT_MEMORY.md` with architecture baseline, playbook, and verification contracts
  - [x] Install `/update_memory.py` at repository root and smoke-test execution
  - [ ] Await next task brief → perform read-only root-cause investigation → update Playbook milestones before coding

## 3. Verification Contracts
Before closing any implementation task, all applicable checks below MUST pass **after the final code edit**:
1. **Userscript Syntax**: `node --check youtube-feed-summariser.user.js`
2. **Unit & Zero-Drift Parity (42 tests)**: `npx --yes tsx --test src/utils/userscript-helpers.test.ts`
3. **Full E2E Playwright Suite (559 checks across 5 suites)**: `node run_all_tests.js`
4. **TypeScript Lint & Production Build**: `npm run lint && npm run build` (or `lint_applet` + `compile_applet`)
5. **Live Browser Check (`playwright-cli` on `http://localhost:3000`)**: Restart dev server when React/UI code changed, verify desktop (`1440x900`) & responsive (`390x844`) views with 0 console/runtime errors, and close browser (`playwright-cli close`).
6. **Pre-Session / Post-Commit Memory Sync**: Run `python3 update_memory.py` when `.git` commits are present; update `PROJECT_MEMORY.md` tightly at major milestones.
7. **Prompt-End Backup Integrity**: `npm run backup -- --label="prompt-end" --stage="<stageId>" && npm run backup:verify`

## 4. Key Decisions & Snapshot Baseline
- **Latest Verified Backup**: `snap-20261119-090503-prompt-end-perf-page-load` (`108` files, SHA-256 verified).
- **Git Status Note**: Current workspace does not have a `.git` directory yet (`git` v2+ is installed on PATH; Python 3.11.2 is available). `update_memory.py` gracefully exits with `[!] No git history or changes found to update.` until `git init` + commits exist, and can be wired to `.git/hooks/pre-commit` or `.git/hooks/post-commit` once a repo is initialized.

## Recent Progress & Git Activity

_No git commits recorded yet in this sandbox (`git` not initialized). Run `python3 update_memory.py` after commits to sync recent diffs here._
