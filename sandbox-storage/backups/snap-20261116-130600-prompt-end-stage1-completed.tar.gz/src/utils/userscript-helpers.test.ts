import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatSecondsToTimestamp,
  parseTimestampToSeconds,
  getCacheKeyPrefix,
  resolveNextModelDown,
  resolveAskFallbackPlan,
  cleanTextForSpeech,
  parseTranscriptCues,
  findActiveCueByCharIndex,
  findActiveCueByTime,
  detectYouTubeTheme,
  resolveReaderTheme,
  BoundedMemoryCache,
  getDraftStorageKey,
  getGranularTtsRates,
  getSpeedIndicatorType,
  clampPitch,
  formatSummaryExportJson,
  computeWaveformAmplitudes,
  normalizeHistoryTabVisibility,
  shouldShowHistoryTab,
  normalizeResponseRating,
  buildResponseRatingKey,
  applyResponseRating,
  formatMathSymbolsInText,
  clampWindowBounds,
  computeDefaultWindowBounds,
  classifyWindowSizeTier,
  getAdaptiveWindowFlags,
  normalizeAltTitlesEnabled,
  resolveFeedCardTitleMode,
  sanitizeGeneratedAltTitle,
  shouldCacheGeneratedAltTitle,
  normalizeCompactOptionsMap
} from './userscript-helpers';

test('formatSecondsToTimestamp formats correctly below and above 1 hour', () => {
  assert.equal(formatSecondsToTimestamp(5), '00:05');
  assert.equal(formatSecondsToTimestamp(75), '01:15');
  assert.equal(formatSecondsToTimestamp(3665), '1:01:05');
});

test('parseTimestampToSeconds parses standard and hour-long timestamps', () => {
  assert.equal(parseTimestampToSeconds('00:05'), 5);
  assert.equal(parseTimestampToSeconds('01:15'), 75);
  assert.equal(parseTimestampToSeconds('1:01:05'), 3665);
});

test('getCacheKeyPrefix selects the four designated cache slots', () => {
  assert.equal(getCacheKeyPrefix('summary', 'video'), 'sum:');
  assert.equal(getCacheKeyPrefix('transcript', 'video'), 'trn:');
  assert.equal(getCacheKeyPrefix('summary', 'text'), 'sut:');
  assert.equal(getCacheKeyPrefix('transcript', 'text'), 'trt:');
});

test('resolveNextModelDown traverses fallback ladder and respects key availability', () => {
  const ladder = [
    'gemini-3.1-pro-preview',
    'gemini-3.8-flash',
    'gemini-3.7-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash',
    'gemini-2.0-flash'
  ];
  const available = ['gemini-3.1-pro-preview', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.0-flash'];

  const next = resolveNextModelDown('gemini-3.8-flash', ladder, available);
  assert.equal(next, 'gemini-3.6-flash', 'Skips 3.7-flash because key lacks it and picks 3.6-flash');

  // When Ask fails, starts from index 0 of the fallback ladder
  assert.equal(
    resolveNextModelDown('YouTube Ask (Gemini in the page)', ladder, available),
    'gemini-3.1-pro-preview',
    'Selects top eligible ladder model (gemini-3.1-pro-preview) when Ask fails with full key'
  );
  assert.equal(
    resolveNextModelDown('YouTube Ask (Gemini in the page)', ladder, ['gemini-3.8-flash', 'gemini-3.6-flash']),
    'gemini-3.8-flash',
    'Selects first available non-pro ladder model when free key lacks pro'
  );
  assert.equal(
    resolveNextModelDown('Ask', ladder, []),
    'gemini-3.1-pro-preview',
    'Selects first model on ladder when availableModels list is empty'
  );
});

test('resolveAskFallbackPlan handles cancelled jobs, missing keys, and eligible ladder fallback', () => {
  const ladder = [
    'gemini-3.1-pro-preview',
    'gemini-3.8-flash',
    'gemini-3.7-flash',
    'gemini-3.6-flash'
  ];

  const cancelledPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.8-flash'],
    hasApiKey: true,
    cancelled: true,
    errorMessage: 'Ask job was cancelled'
  });
  assert.equal(cancelledPlan.shouldFallback, false);
  assert.equal(cancelledPlan.reason, 'cancelled');

  const noKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: [],
    hasApiKey: false,
    errorMessage: "YouTube's Ask button didn't appear"
  });
  assert.equal(noKeyPlan.shouldFallback, false);
  assert.equal(noKeyPlan.reason, 'no_key');

  const paidKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.1-pro-preview', 'gemini-3.8-flash'],
    hasApiKey: true,
    errorMessage: "YouTube's Ask button didn't appear\nExtra details"
  });
  assert.equal(paidKeyPlan.shouldFallback, true);
  assert.equal(paidKeyPlan.reason, 'ladder_fallback');
  assert.equal(paidKeyPlan.nextModel, 'gemini-3.1-pro-preview');
  assert.ok(paidKeyPlan.note?.includes('Automatically proceeding with gemini-3.1-pro-preview'));

  const freeKeyPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['gemini-3.8-flash', 'gemini-3.6-flash'],
    hasApiKey: true,
    errorMessage: 'Ask answer generation timed out'
  });
  assert.equal(freeKeyPlan.shouldFallback, true);
  assert.equal(freeKeyPlan.nextModel, 'gemini-3.8-flash');

  const exhaustedPlan = resolveAskFallbackPlan({
    currentModel: 'YouTube Ask (Gemini in the page)',
    fallbackLadder: ladder,
    availableModels: ['unrelated-model-only'],
    hasApiKey: true,
    errorMessage: 'Ask failed'
  });
  assert.equal(exhaustedPlan.shouldFallback, false);
  assert.equal(exhaustedPlan.reason, 'no_eligible_model');
});

test('cleanTextForSpeech strips visual markers and prepares natural spoken text', () => {
  const rawMarkdown = `## TL;DR
**Sodium batteries** achieve *great* results!
### [01:15] Cell Chemistry
[[FRAME 01:15 | diagram of cathode]]
Researchers found 90% retention at [1:05:30].
<script>alert("test")</script>
- Point 1: Read [Research Paper](https://example.com/paper).`;

  const spoken = cleanTextForSpeech(rawMarkdown);
  assert.ok(!spoken.includes('FRAME'), 'Visual markers stripped');
  assert.ok(!spoken.includes('script'), 'Script tags stripped');
  assert.ok(!spoken.includes('##'), 'Markdown heading hashes stripped');
  assert.ok(!spoken.includes('**'), 'Markdown bold asterisks stripped');
  assert.ok(!spoken.includes('https://'), 'URLs stripped');
  assert.ok(spoken.includes('at 1 minute 15 seconds'), 'Timestamp converted to spoken words');
  assert.ok(spoken.includes('at 1 hour 5 minutes 30 seconds'), 'Hour timestamp converted to spoken words');
});

test('parseTranscriptCues extracts cues, offsets, and spoken text correctly', () => {
  const sampleTranscript = `## Transcript (YouTube captions)

[00:00] First segment introduction.
[01:15] Second segment discussing architecture.
[05:30] Third segment covering benchmarks.`;

  const { cues, fullSpokenText } = parseTranscriptCues(sampleTranscript);
  assert.equal(cues.length, 3, 'Found 3 timestamped cues');
  assert.equal(cues[0].tsStr, '[00:00]');
  assert.equal(cues[0].startSec, 0);
  assert.equal(cues[1].tsStr, '[01:15]');
  assert.equal(cues[1].startSec, 75);
  assert.equal(cues[2].tsStr, '[05:30]');
  assert.equal(cues[2].startSec, 330);

  assert.ok(fullSpokenText.includes('First segment introduction'), 'Includes first segment text');
  assert.ok(fullSpokenText.includes('Second segment discussing architecture'), 'Includes second segment text');

  // Test character lookup
  const midFirst = cues[0].charStart + 5;
  const active1 = findActiveCueByCharIndex(cues, midFirst);
  assert.equal(active1?.tsStr, '[00:00]', 'Char index in cue 0 returns cue 0');

  const midSecond = cues[1].charStart + 10;
  const active2 = findActiveCueByCharIndex(cues, midSecond);
  assert.equal(active2?.tsStr, '[01:15]', 'Char index in cue 1 returns cue 1');

  // Test time lookup
  const timeActiveEarly = findActiveCueByTime(cues, 1, 100);
  assert.equal(timeActiveEarly?.tsStr, '[00:00]', 'Early progress maps to cue 0');

  const timeActiveMid = findActiveCueByTime(cues, 50, 100);
  assert.ok(timeActiveMid?.tsStr === '[01:15]' || timeActiveMid?.tsStr === '[05:30]', 'Mid progress maps to cue 1 or 2');
});

test('detectYouTubeTheme detects dark and light mode from DOM hierarchy', () => {
  // Test 1: html[dark] attribute present
  const mockDocDarkHtml = {
    documentElement: {
      hasAttribute: (attr: string) => attr === 'dark',
      getAttribute: (attr: string) => (attr === 'dark' ? '' : null),
      classList: { contains: () => false }
    },
    querySelector: () => null
  };
  assert.equal(detectYouTubeTheme(mockDocDarkHtml), 'dark', 'HTML element with dark attribute detected as dark');

  // Test 2: ytd-app[dark] present
  const mockDocDarkYtd = {
    documentElement: {
      hasAttribute: () => false,
      getAttribute: () => null,
      classList: { contains: () => false }
    },
    querySelector: (sel: string) => (sel === 'ytd-app[dark]' ? {} : null)
  };
  assert.equal(detectYouTubeTheme(mockDocDarkYtd), 'dark', 'ytd-app with dark attribute detected as dark');

  // Test 3: Standard light mode (no dark attributes)
  const mockDocLight = {
    documentElement: {
      hasAttribute: () => false,
      getAttribute: () => null,
      classList: { contains: () => false }
    },
    querySelector: () => null,
    body: { hasAttribute: () => false }
  };
  assert.equal(detectYouTubeTheme(mockDocLight), 'light', 'Document without dark attributes detected as light');
});

test('resolveReaderTheme respects sync toggle and manual fallback', () => {
  // When sync is ON, always matches detected YouTube theme
  assert.equal(resolveReaderTheme('sepia', true, 'dark'), 'dark', 'Sync ON overrides manual sepia with dark');
  assert.equal(resolveReaderTheme('sepia', true, 'light'), 'light', 'Sync ON overrides manual sepia with light');
  assert.equal(resolveReaderTheme('system', true, 'dark'), 'dark', 'Sync ON matches dark');

  // When sync is OFF, retains user manual choice
  assert.equal(resolveReaderTheme('sepia', false, 'dark'), 'sepia', 'Sync OFF retains sepia');
  assert.equal(resolveReaderTheme('light', false, 'dark'), 'light', 'Sync OFF retains light even if YouTube is dark');
  assert.equal(resolveReaderTheme('dark', false, 'light'), 'dark', 'Sync OFF retains dark even if YouTube is light');
});

test('BoundedMemoryCache respects capacity limit and evicts least-recently-used items', () => {
  const cache = new BoundedMemoryCache<string, string>(3);
  cache.set('a', 'alpha');
  cache.set('b', 'beta');
  cache.set('c', 'gamma');
  assert.equal(cache.size, 3);

  // Access 'a' to make it recently used: order is now b, c, a
  assert.equal(cache.get('a'), 'alpha');

  // Insert 'd': capacity 3 exceeded, 'b' is evicted
  cache.set('d', 'delta');
  assert.equal(cache.size, 3);
  assert.equal(cache.has('b'), false, 'Key "b" was evicted as LRU');
  assert.equal(cache.has('a'), true, 'Key "a" retained because it was accessed');
  assert.equal(cache.has('c'), true, 'Key "c" retained');
  assert.equal(cache.has('d'), true, 'Key "d" added');

  // Verify iteration and keys
  const keys = Array.from(cache.keys());
  assert.deepEqual(keys, ['c', 'a', 'd'], 'Keys preserve LRU-to-MRU iteration order');
  const values = Array.from(cache.values());
  assert.deepEqual(values, ['gamma', 'alpha', 'delta'], 'Values preserve iteration order');

  const iterated: string[] = [];
  cache.forEach((v, k) => {
    iterated.push(`${k}:${v}`);
  });
  assert.deepEqual(iterated, ['c:gamma', 'a:alpha', 'd:delta']);
});

test('getDraftStorageKey returns consistent namespaced draft key', () => {
  assert.equal(getDraftStorageKey('vid_123'), 'draft:vid_123');
  assert.equal(getDraftStorageKey('abc'), 'draft:abc');
});

test('getGranularTtsRates provides strictly 0.25x steps', () => {
  const rates = getGranularTtsRates();
  assert.deepEqual(rates, [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]);
  for (let i = 1; i < rates.length; i++) {
    const diff = Math.round((rates[i] - rates[i - 1]) * 100) / 100;
    assert.equal(diff, 0.25, `Step between ${rates[i - 1]} and ${rates[i]} is exactly 0.25x`);
  }
});

test('getSpeedIndicatorType classifies speed presets accurately', () => {
  assert.equal(getSpeedIndicatorType(1.0), 'speed-normal');
  assert.equal(getSpeedIndicatorType(1.25), 'speed-boost');
  assert.equal(getSpeedIndicatorType(2.0), 'speed-boost');
  assert.equal(getSpeedIndicatorType(0.75), 'speed-slow');
  assert.equal(getSpeedIndicatorType(0.5), 'speed-slow');
});

test('clampPitch validates and bounds voice pitch within 0.5x to 2.0x', () => {
  assert.equal(clampPitch(1.0), 1.0, 'Baseline pitch is 1.0');
  assert.equal(clampPitch(0.5), 0.5, 'Minimum pitch boundary is 0.5');
  assert.equal(clampPitch(2.0), 2.0, 'Maximum pitch boundary is 2.0');
  assert.equal(clampPitch(0.2), 0.5, 'Sub-minimum pitch clamps to 0.5');
  assert.equal(clampPitch(3.5), 2.0, 'Super-maximum pitch clamps to 2.0');
  assert.equal(clampPitch(NaN), 1.0, 'NaN defaults safely to 1.0');
  assert.equal(clampPitch(Infinity), 1.0, 'Infinity defaults safely to 1.0');
  assert.equal(clampPitch(-Infinity), 1.0, '-Infinity defaults safely to 1.0');
  assert.equal(clampPitch(null), 1.0, 'Null defaults safely to 1.0');
  assert.equal(clampPitch(undefined), 1.0, 'Undefined defaults safely to 1.0');
  assert.equal(clampPitch('1.75'), 1.75, 'String representations parse and clamp accurately');
});

test('formatSummaryExportJson generates valid JSON with video title, channel, and processing mode', () => {
  const jsonStr = formatSummaryExportJson({
    videoId: 'abc123xyz',
    videoTitle: 'Quantum Computing Deep Dive',
    channel: 'Tech Architecture Network',
    mode: 'transcript',
    processingMode: 'deep',
    model: 'gemini-3.8-flash',
    text: '## Detailed Summary\nChronological overview of quantum gate latency.',
    factCheck: 'All quantum telemetry claims verified against peer reviews.',
    citations: [{ uri: 'https://arxiv.org/abs/2301.00000', title: 'Quantum Telemetry Preprint' }],
    followUpQuestions: [
      {
        question: 'What is the coherence time?',
        answer: 'Measured coherence time exceeds 120 microseconds [04:12].',
        sources: [{ uri: 'https://arxiv.org/abs/2301.00000', title: 'Paper Citation' }]
      }
    ],
    ttsRate: 1.25,
    ttsVolume: 0.85,
    ttsPitch: 1.15,
    ttsVoice: 'ai:Zephyr'
  });

  const parsed = JSON.parse(jsonStr);
  assert.equal(parsed.generator, 'YouTube Feed Summariser (Gemini)');
  assert.equal(parsed.metadata.videoId, 'abc123xyz');
  assert.equal(parsed.metadata.videoTitle, 'Quantum Computing Deep Dive');
  assert.equal(parsed.metadata.channel, 'Tech Architecture Network');
  assert.equal(parsed.metadata.processingMode, 'deep');
  assert.equal(parsed.metadata.mode, 'transcript');
  assert.equal(parsed.metadata.model, 'gemini-3.8-flash');
  assert.equal(parsed.metadata.ttsSettings.pitch, 1.15);
  assert.equal(parsed.metadata.ttsSettings.rate, 1.25);
  assert.equal(parsed.metadata.ttsSettings.volume, 0.85);
  assert.equal(parsed.metadata.ttsSettings.voice, 'ai:Zephyr');
  assert.equal(parsed.content.factCheck, 'All quantum telemetry claims verified against peer reviews.');
  assert.equal(parsed.content.citations.length, 1);
  assert.equal(parsed.content.followUpQuestions.length, 1);
  assert.equal(parsed.content.followUpQuestions[0].question, 'What is the coherence time?');
});

test('computeWaveformAmplitudes generates dynamic voice frequency bands and responds to playback state', () => {
  // Test 1: Idle or stopped speech returns resting flatline
  const idleAmps = computeWaveformAmplitudes({ isPlaying: false, barCount: 8 });
  assert.equal(idleAmps.length, 8, 'Returns requested bar count');
  assert.ok(idleAmps.every((a) => a === 0.08), 'All bars return resting baseline (0.08) when idle');

  // Test 2: Muted speech (volume = 0) returns resting flatline even if isPlaying is true
  const mutedAmps = computeWaveformAmplitudes({ isPlaying: true, volume: 0, barCount: 8 });
  assert.ok(mutedAmps.every((a) => a === 0.08), 'All bars return flatline when volume is zero');

  // Test 3: Active playback produces modulated positive amplitudes
  const activeAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 1.0,
    rate: 1.0,
    timestamp: 1000,
    barCount: 12
  });
  assert.equal(activeAmps.length, 12);
  assert.ok(activeAmps.some((a) => a > 0.15), 'Active speech produces elevated amplitudes above baseline');
  assert.ok(activeAmps.every((a) => a >= 0.08 && a <= 1.0), 'All amplitudes remain strictly clamped in [0.08, 1.0]');

  // Test 4: Pitch shift elevates relative high-frequency formant energy
  const lowPitchAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 0.5,
    rate: 1.0,
    timestamp: 2500,
    barCount: 10
  });
  const highPitchAmps = computeWaveformAmplitudes({
    isPlaying: true,
    volume: 1.0,
    pitch: 2.0,
    rate: 1.0,
    timestamp: 2500,
    barCount: 10
  });
  // Upper frequencies (last 3 bars) have higher relative formant resonance with high pitch
  const lowTrebleEnergy = lowPitchAmps.slice(-3).reduce((acc, v) => acc + v, 0);
  const highTrebleEnergy = highPitchAmps.slice(-3).reduce((acc, v) => acc + v, 0);
  assert.ok(highTrebleEnergy > lowTrebleEnergy, 'High pitch shifts formant resonance towards upper frequency bands');

  // Test 5: Syllable pulse increases immediate speech attack
  const normalAmp = computeWaveformAmplitudes({ isPlaying: true, timestamp: 3000, boundaryPulse: 0, barCount: 6 });
  const pulsedAmp = computeWaveformAmplitudes({ isPlaying: true, timestamp: 3000, boundaryPulse: 0.8, barCount: 6 });
  const normalSum = normalAmp.reduce((a, b) => a + b, 0);
  const pulsedSum = pulsedAmp.reduce((a, b) => a + b, 0);
  assert.ok(pulsedSum > normalSum, 'Syllable boundary pulse increases speech amplitude attack');
});

test('normalizeHistoryTabVisibility and shouldShowHistoryTab enforce visibility modes', () => {
  assert.equal(normalizeHistoryTabVisibility('always'), 'always');
  assert.equal(normalizeHistoryTabVisibility('with_tabs'), 'with_tabs');
  assert.equal(normalizeHistoryTabVisibility('never'), 'never');
  assert.equal(normalizeHistoryTabVisibility('invalid'), 'always');

  // Always mode: shown when cached summaries exist regardless of active tab count
  assert.equal(shouldShowHistoryTab({ visibility: 'always', cachedCount: 3, activeTabCount: 0 }), true);
  assert.equal(shouldShowHistoryTab({ visibility: 'always', cachedCount: 0, activeTabCount: 2 }), false);

  // With_tabs mode: shown ONLY when other tabs are open or minimized
  assert.equal(shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 0 }), false);
  assert.equal(shouldShowHistoryTab({ visibility: 'with_tabs', cachedCount: 3, activeTabCount: 1 }), true);

  // Never mode: never shown even with cached summaries and open tabs
  assert.equal(shouldShowHistoryTab({ visibility: 'never', cachedCount: 5, activeTabCount: 3 }), false);
});

test('response rating helpers toggle, switch, and preserve notes cleanly', () => {
  assert.equal(normalizeResponseRating('up'), 'up');
  assert.equal(normalizeResponseRating('down'), 'down');
  assert.equal(normalizeResponseRating('other'), null);
  assert.equal(buildResponseRatingKey('vid_1', 'summary'), 'vid_1:summary:main');
  assert.equal(buildResponseRatingKey('vid_1', 'followup', 'turn_2'), 'vid_1:followup:turn_2');

  let map: Record<string, any> = {};
  const upRes = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'up', timestamp: 100 });
  assert.equal(upRes.record?.rating, 'up');
  map = upRes.nextMap;
  assert.equal(Object.keys(map).length, 1);

  // Switching from up to down replaces rating
  const downRes = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'down', note: 'Inaccurate', timestamp: 200 });
  assert.equal(downRes.record?.rating, 'down');
  assert.equal(downRes.record?.note, 'Inaccurate');
  map = downRes.nextMap;

  // Clicking the same rating again without note toggles it off
  const toggleOff = applyResponseRating(map, { videoId: 'vid_1', targetType: 'summary', rating: 'down' });
  assert.equal(toggleOff.record, null);
  assert.equal(Object.keys(toggleOff.nextMap).length, 0);
});

test('formatMathSymbolsInText converts LaTeX scientific symbols without breaking currency', () => {
  const boilingSample =
    'At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of $100^\\circ\\text{C}$ to approximately $87^\\circ\\text{C}$.';
  const formatted = formatMathSymbolsInText(boilingSample);
  assert.equal(
    formatted,
    'At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of 100°C to approximately 87°C.'
  );

  // Superscripts, subscripts, Greek letters, operators
  assert.equal(formatMathSymbolsInText('$E = mc^2$ and $\\text{H}_2\\text{O}$ at $\\approx 25^\\circ\\text{C}$'), 'E = mc² and H₂O at ≈ 25°C');
  assert.equal(formatMathSymbolsInText('$\\alpha \\le \\beta \\pm 0.5$ and $\\frac{a}{b}$'), 'α ≤ β ± 0.5 and a/b');

  // Currency preservation
  assert.equal(
    formatMathSymbolsInText('Sodium cells cost $0.30/kg vs $18/kg, saving between $100 and $200 per pack.'),
    'Sodium cells cost $0.30/kg vs $18/kg, saving between $100 and $200 per pack.'
  );

  // Parenthesized inline LaTeX \(...\)
  assert.equal(formatMathSymbolsInText('Cooling curve \\( f(T) = (100^\\circ\\text{C}) - 13^\\circ\\text{C} \\)'), 'Cooling curve f(T) = (100°C) - 13°C');

  // cleanTextForSpeech also converts LaTeX symbols
  const spoken = cleanTextForSpeech('Standard boiling point is $100^\\circ\\text{C}$ to $87^\\circ\\text{C}$.');
  assert.ok(spoken.includes('100°C') && spoken.includes('87°C') && !spoken.includes('\\circ'));
});

test('window bounds clamping, cascading defaults, and adaptive size tiers behave consistently', () => {
  const clamped = clampWindowBounds({ left: -50, top: 2000, width: 120, height: 1500 }, { width: 1280, height: 800 });
  assert.equal(clamped.width, 340, 'Enforces minWidth 340');
  assert.equal(clamped.height, 736, 'Clamps height to viewport - 64');
  assert.equal(clamped.left, 12, 'Clamps negative left inside viewport margin');
  assert.ok(clamped.top <= 800 - clamped.height - 52, 'Keeps window above bottom dock');

  const win0 = computeDefaultWindowBounds({ width: 1440, height: 900 }, 0);
  const win1 = computeDefaultWindowBounds({ width: 1440, height: 900 }, 1);
  assert.notEqual(win0.left, win1.left, 'Cascades consecutive windows horizontally');
  assert.notEqual(win0.top, win1.top, 'Cascades consecutive windows vertically');

  assert.equal(classifyWindowSizeTier(420), 'compact');
  assert.equal(classifyWindowSizeTier(539), 'compact');
  assert.equal(classifyWindowSizeTier(540), 'medium');
  assert.equal(classifyWindowSizeTier(779), 'medium');
  assert.equal(classifyWindowSizeTier(780), 'wide');

  const compactFlags = getAdaptiveWindowFlags(460, 420);
  assert.equal(compactFlags.tier, 'compact');
  assert.equal(compactFlags.useOverflowHeaderMenu, true);
  assert.equal(compactFlags.collapseOptionsRow, true);
  assert.equal(compactFlags.isShort, true);
  assert.equal(compactFlags.singleColumnAdvPanel, true);

  const wideFlags = getAdaptiveWindowFlags(900, 720);
  assert.equal(wideFlags.tier, 'wide');
  assert.equal(wideFlags.useOverflowHeaderMenu, false);
  assert.equal(wideFlags.collapseOptionsRow, false);
  assert.equal(wideFlags.compactTtsBar, false);
  assert.equal(wideFlags.isShort, false);
});

test('auto-title replacement defaults to enabled, respects settings off, and yields to DeArrow', () => {
  assert.equal(normalizeAltTitlesEnabled(undefined), true);
  assert.equal(normalizeAltTitlesEnabled(null), true);
  assert.equal(normalizeAltTitlesEnabled(true), true);
  assert.equal(normalizeAltTitlesEnabled(false), false);
  assert.equal(normalizeAltTitlesEnabled('false'), false);

  // Enabled by default on normal non-DeArrow cards
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: false, altTitlesEnabled: true }),
    'ai'
  );
  // Disabled in settings keeps original title on non-DeArrow cards
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: false, altTitlesEnabled: false }),
    'original'
  );
  // DeArrow always takes precedence when present on a card
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: true, altTitlesEnabled: true }),
    'dearrow'
  );
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: false, hasDeArrowTitle: true, altTitlesEnabled: false }),
    'dearrow'
  );
  // Music videos remain exempt regardless of setting
  assert.equal(
    resolveFeedCardTitleMode({ isMusic: true, hasDeArrowTitle: true, altTitlesEnabled: true }),
    'music'
  );

  // Title sanitization strips quotes/markdown and caps at 150 chars
  assert.equal(sanitizeGeneratedAltTitle('**"Clean Title Here"**'), 'Clean Title Here');
  const overlong = 'A'.repeat(180);
  const capped = sanitizeGeneratedAltTitle(overlong);
  assert.equal(capped.length, 150);
  assert.ok(capped.endsWith('...'));
});

test('shouldCacheGeneratedAltTitle blocks clickbait self-caching on empty/fallback titles', () => {
  assert.equal(
    shouldCacheGeneratedAltTitle('THIS CHANGES EVERYTHING!', 'THIS CHANGES EVERYTHING!', false),
    false
  );
  assert.equal(
    shouldCacheGeneratedAltTitle('THIS CHANGES EVERYTHING!', 'this changes everything!', true),
    false
  );
  assert.equal(shouldCacheGeneratedAltTitle('Too', 'Original Title', true), false);
  assert.equal(
    shouldCacheGeneratedAltTitle(
      'Benchmark comparison of 3nm ARM cores vs x86 efficiency',
      'THIS CHANGES EVERYTHING!',
      true
    ),
    true
  );
});

test('normalizeCompactOptionsMap validates stored compact options disclosure preferences', () => {
  assert.deepEqual(normalizeCompactOptionsMap(null), {});
  assert.deepEqual(normalizeCompactOptionsMap(['bad']), {});
  assert.deepEqual(
    normalizeCompactOptionsMap({ vid1: true, vid2: false, vid3: 'yes', '': true }),
    { vid1: true, vid2: false }
  );
  const polluted = JSON.parse('{"__proto__":true,"constructor":true,"vid1":true}');
  assert.deepEqual(normalizeCompactOptionsMap(polluted), { vid1: true });
});

