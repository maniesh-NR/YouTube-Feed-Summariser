export function formatSecondsToTimestamp(seconds: number): string {
  const s = Math.floor(seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  if (hrs > 0) {
    return `${hrs}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export function parseTimestampToSeconds(tsStr: string): number {
  const parts = tsStr.trim().split(':').map(Number);
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  return 0;
}

export function getCacheKeyPrefix(mode: 'summary' | 'transcript', source: 'video' | 'text'): string {
  if (mode === 'transcript') {
    return source === 'text' ? 'trt:' : 'trn:';
  }
  return source === 'text' ? 'sut:' : 'sum:';
}

export function resolveNextModelDown(currentModel: string, fallbackLadder: string[], availableModels: string[]): string | null {
  const isAsk = String(currentModel || '').toLowerCase().includes('ask');
  let startIdx = 0;
  if (!isAsk) {
    let idx = fallbackLadder.indexOf(currentModel);
    if (idx === -1) {
      idx = fallbackLadder.findIndex((m) => !m.includes('pro'));
      if (idx === -1) idx = 0;
    }
    startIdx = idx + 1;
  }
  for (let i = startIdx; i < fallbackLadder.length; i++) {
    const candidate = fallbackLadder[i];
    if (availableModels.length === 0 || availableModels.includes(candidate) || availableModels.includes(candidate + '-preview')) {
      return candidate;
    }
  }
  return null;
}

export interface AskFallbackDecision {
  shouldFallback: boolean;
  nextModel: string | null;
  reason: 'cancelled' | 'no_key' | 'no_eligible_model' | 'ladder_fallback';
  note?: string;
}

export function resolveAskFallbackPlan(options: {
  currentModel: string;
  fallbackLadder: string[];
  availableModels: string[];
  hasApiKey: boolean;
  cancelled?: boolean;
  errorMessage?: string;
}): AskFallbackDecision {
  if (options.cancelled) {
    return { shouldFallback: false, nextModel: null, reason: 'cancelled' };
  }
  if (!options.hasApiKey) {
    return { shouldFallback: false, nextModel: null, reason: 'no_key' };
  }
  const nextModel = resolveNextModelDown(
    options.currentModel,
    options.fallbackLadder,
    options.availableModels
  );
  if (!nextModel) {
    return { shouldFallback: false, nextModel: null, reason: 'no_eligible_model' };
  }
  const firstLine = (options.errorMessage || 'YouTube Ask failed').split('\n')[0];
  return {
    shouldFallback: true,
    nextModel,
    reason: 'ladder_fallback',
    note: `⚠ YouTube Ask failed (${firstLine}). Automatically proceeding with ${nextModel}.`
  };
}

export function cleanTextForSpeech(
  text: string,
  options: { skipSilence?: boolean } = { skipSilence: true }
): string {
  if (!text) return '';
  const skipSilence = options?.skipSilence !== false;
  let clean = text;

  if (skipSilence) {
    // 1. Filter out lines that are purely silence / pause / music / applause markers
    const silenceLineRegex = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,}|[-_—]{2,})\s*$/gim;
    clean = clean.replace(silenceLineRegex, '');

    // 2. Filter out standalone silence / pause markers without timestamps
    const standaloneSilenceRegex = /^\s*(\[(?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\]|\((?:silence|pause|music|applause|laughter|no audio|blank|sound|cheering)\)|\.{3,})\s*$/gim;
    clean = clean.replace(standaloneSilenceRegex, '');

    // 3. Remove inline silence / pause tokens
    clean = clean.replace(/\[(?:silence|pause|long pause|music|applause|laughter|no audio|blank)\]/gi, '');
    clean = clean.replace(/\((?:silence|pause|long pause|music|applause|laughter|no audio|blank)\)/gi, '');

    // 4. Collapse extended pause punctuation (e.g. ".....", "---")
    clean = clean.replace(/\.{3,}/g, '. ');
    clean = clean.replace(/[-_—]{2,}/g, ', ');

    // 5. Detect timestamp gaps > 3 seconds between consecutive timestamped transcript lines
    const lines = clean.split('\n');
    const processedLines: string[] = [];
    let prevTsSec = -1;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(line);
      if (tsMatch) {
        const hrs = tsMatch[1] ? parseInt(tsMatch[1], 10) : 0;
        const mins = parseInt(tsMatch[2], 10);
        const secs = parseInt(tsMatch[3], 10);
        const currentTsSec = hrs * 3600 + mins * 60 + secs;
        const rest = tsMatch[4].trim();

        // If line has no meaningful words (just filler/empty), skip it
        if (!rest || /^(?:\[.*?\]|\(.*?\)|[-_.\s]+)$/.test(rest)) {
          continue;
        }

        prevTsSec = currentTsSec;
        processedLines.push(line);
      } else {
        processedLines.push(line);
      }
    }
    clean = processedLines.join('\n');
  }

  // Strip visual markers
  clean = clean.replace(/\[\[(?:FRAME|IMG|GEN|IMAGE)[^\]]+\]\]/gi, '');
  // Strip HTML / script tags
  clean = clean.replace(/<[^>]+>/g, '');
  // Convert timestamps like [01:15] or [1:02:30] to spoken phrases
  clean = clean.replace(/\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]/g, (_match, h, m, s) => {
    const hrs = h ? parseInt(h, 10) : 0;
    const mins = parseInt(m, 10);
    const secs = parseInt(s, 10);
    const parts: string[] = [];
    if (hrs > 0) parts.push(`${hrs} hour${hrs > 1 ? 's' : ''}`);
    if (mins > 0) parts.push(`${mins} minute${mins > 1 ? 's' : ''}`);
    if (secs > 0) parts.push(`${secs} second${secs > 1 ? 's' : ''}`);
    return parts.length ? `at ${parts.join(' ')}` : '';
  });
  // Format LaTeX/scientific symbols (e.g., $100^\circ\text{C}$ -> 100°C)
  clean = formatMathSymbolsInText(clean);
  // Strip markdown formatting symbols
  clean = clean.replace(/#{1,6}\s+/g, '');
  clean = clean.replace(/\*\*([^*]+)\*\*/g, '$1');
  clean = clean.replace(/\*([^*]+)\*/g, '$1');
  clean = clean.replace(/`([^`]+)`/g, '$1');
  clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  clean = clean.replace(/https?:\/\/\S+/g, '');
  clean = clean.replace(/^[-*•]\s+/gm, '');
  return clean.replace(/\s+/g, ' ').trim();
}

export interface TranscriptCue {
  lineIndex: number;
  rawLine: string;
  tsStr: string;
  startSec: number;
  text: string;
  spokenText: string;
  charStart: number;
  charEnd: number;
}

export function parseTranscriptCues(
  transcriptText: string,
  options: { skipSilence?: boolean } = { skipSilence: true }
): { cues: TranscriptCue[]; fullSpokenText: string } {
  if (!transcriptText) return { cues: [], fullSpokenText: '' };
  const lines = transcriptText.split('\n');
  const cues: TranscriptCue[] = [];
  const spokenParts: string[] = [];
  let currentOffset = 0;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();
    if (!trimmed) continue;

    // Matches timestamp format: [01:15] or [1:02:30]
    const tsMatch = /^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*(.*)$/.exec(trimmed);
    if (!tsMatch) continue;

    const tsStr = trimmed.slice(0, trimmed.indexOf(']') + 1);
    const restText = trimmed.slice(tsStr.length).trim();
    const startSec = parseTimestampToSeconds(tsStr.slice(1, -1));

    const spokenLine = cleanTextForSpeech(trimmed, options);
    if (!spokenLine) continue;

    const charStart = currentOffset;
    const charEnd = currentOffset + spokenLine.length;
    currentOffset = charEnd + 1; // plus space separator
    spokenParts.push(spokenLine);

    cues.push({
      lineIndex: i,
      rawLine,
      tsStr,
      startSec,
      text: restText,
      spokenText: spokenLine,
      charStart,
      charEnd
    });
  }

  const fullSpokenText = spokenParts.join(' ');
  return { cues, fullSpokenText };
}

export function findActiveCueByCharIndex(cues: TranscriptCue[], charIndex: number): TranscriptCue | null {
  if (!cues || cues.length === 0) return null;
  if (charIndex <= 0) return cues[0];

  for (let i = 0; i < cues.length; i++) {
    const cue = cues[i];
    if (charIndex >= cue.charStart && charIndex <= cue.charEnd) {
      return cue;
    }
    if (i < cues.length - 1 && charIndex > cue.charEnd && charIndex < cues[i + 1].charStart) {
      return cue;
    }
  }

  if (charIndex > cues[cues.length - 1].charEnd) {
    return cues[cues.length - 1];
  }
  return cues[0];
}

export function findActiveCueByTime(
  cues: TranscriptCue[],
  currentTimeSec: number,
  totalDurationSec: number
): TranscriptCue | null {
  if (!cues || cues.length === 0) return null;
  if (totalDurationSec <= 0 || currentTimeSec <= 0) return cues[0];

  const progress = Math.min(1, Math.max(0, currentTimeSec / totalDurationSec));
  const totalChars = cues[cues.length - 1].charEnd;
  const targetChar = Math.round(progress * totalChars);

  return findActiveCueByCharIndex(cues, targetChar);
}

/**
 * Detects whether YouTube is currently rendering in Dark or Light mode.
 * Checks YouTube's root <html> attribute (html[dark]), ytd-app[dark],
 * theme attributes, and body attributes.
 */
export function detectYouTubeTheme(doc?: any): 'dark' | 'light' {
  const targetDoc = doc || (typeof document !== 'undefined' ? document : null);
  if (!targetDoc) return 'dark';

  const docEl = targetDoc.documentElement;
  if (docEl) {
    if (typeof docEl.hasAttribute === 'function' && docEl.hasAttribute('dark')) return 'dark';
    if (typeof docEl.getAttribute === 'function') {
      const darkAttr = docEl.getAttribute('dark');
      if (darkAttr !== null && darkAttr !== 'false') return 'dark';
      const themeAttr = docEl.getAttribute('theme');
      if (themeAttr === 'dark') return 'dark';
    }
    if (docEl.classList && docEl.classList.contains && (docEl.classList.contains('dark') || docEl.classList.contains('yt-dark'))) {
      return 'dark';
    }
  }

  if (typeof targetDoc.querySelector === 'function') {
    if (targetDoc.querySelector('html[dark]')) return 'dark';
    if (targetDoc.querySelector('ytd-app[dark]')) return 'dark';
    const ytdApp = targetDoc.querySelector('ytd-app');
    if (ytdApp && typeof ytdApp.hasAttribute === 'function' && ytdApp.hasAttribute('dark')) return 'dark';
    if (targetDoc.body && typeof targetDoc.body.hasAttribute === 'function' && targetDoc.body.hasAttribute('dark')) return 'dark';
  }

  return 'light';
}

/**
 * Resolves the effective reader view theme based on user's manual selection,
 * sync toggle state, and detected YouTube theme.
 */
export function resolveReaderTheme(
  manualTheme: 'system' | 'light' | 'sepia' | 'dark' | string,
  syncWithYouTube: boolean,
  detectedYtTheme: 'dark' | 'light'
): 'light' | 'sepia' | 'dark' | 'system' {
  if (syncWithYouTube) {
    return detectedYtTheme;
  }
  if (['light', 'sepia', 'dark', 'system'].includes(manualTheme)) {
    return manualTheme as 'light' | 'sepia' | 'dark' | 'system';
  }
  return 'system';
}

/**
 * Bounded memory cache with LRU eviction to prevent runaway memory usage
 * in long-lived YouTube SPA sessions.
 */
export class BoundedMemoryCache<K, V> {
  private map = new Map<K, V>();
  private readonly maxCapacity: number;

  constructor(maxCapacity = 500) {
    this.maxCapacity = Math.max(1, maxCapacity);
  }

  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key)!;
    // Refresh access order (delete and re-insert)
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  set(key: K, value: V): this {
    if (this.map.has(key)) {
      this.map.delete(key);
    } else if (this.map.size >= this.maxCapacity) {
      const oldestKey = this.map.keys().next().value;
      if (oldestKey !== undefined) {
        this.map.delete(oldestKey);
      }
    }
    this.map.set(key, value);
    return this;
  }

  has(key: K): boolean {
    return this.map.has(key);
  }

  delete(key: K): boolean {
    return this.map.delete(key);
  }

  clear(): void {
    this.map.clear();
  }

  get size(): number {
    return this.map.size;
  }

  keys(): IterableIterator<K> {
    return this.map.keys();
  }

  values(): IterableIterator<V> {
    return this.map.values();
  }

  entries(): IterableIterator<[K, V]> {
    return this.map.entries();
  }

  forEach(callbackfn: (value: V, key: K, map: Map<K, V>) => void, thisArg?: any): void {
    this.map.forEach(callbackfn, thisArg);
  }

  [Symbol.iterator](): IterableIterator<[K, V]> {
    return this.map[Symbol.iterator]();
  }
}

/**
 * Returns the storage key for auto-saved follow-up chat drafts.
 */
export function getDraftStorageKey(videoId: string): string {
  return 'draft:' + videoId;
}

/**
 * Returns granular TTS playback speed presets with 0.25x steps.
 */
export function getGranularTtsRates(): number[] {
  return [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
}

/**
 * Determines the visual indicator style type based on playback speed setting.
 */
export function getSpeedIndicatorType(rate: number): 'speed-normal' | 'speed-boost' | 'speed-slow' {
  if (Math.abs(rate - 1.0) < 0.01) return 'speed-normal';
  if (rate > 1.0) return 'speed-boost';
  return 'speed-slow';
}

/**
 * Validates and clamps voice pitch within [0.5, 2.0], defaulting to 1.0.
 */
export function clampPitch(val: unknown): number {
  const num = typeof val === 'number' ? val : parseFloat(String(val));
  if (isNaN(num) || !isFinite(num)) return 1.0;
  const clamped = Math.max(0.5, Math.min(2.0, num));
  return Math.round(clamped * 100) / 100;
}

export interface SummaryExportPayload {
  generator: string;
  version: string;
  exportedAt: string;
  metadata: {
    videoId: string;
    videoTitle: string;
    channel: string;
    videoUrl: string;
    mode: 'summary' | 'transcript' | string;
    source: 'video' | 'text' | string;
    processingMode: 'fast' | 'deep' | string;
    model: string;
    ttsSettings?: {
      rate: number;
      volume: number;
      pitch: number;
      voice: string;
    };
  };
  content: {
    rawText: string;
    formattedText?: string;
    factCheck?: string | null;
    citations?: Array<{ uri: string; title: string }>;
    followUpQuestions?: Array<{ question: string; answer: string; sources?: Array<{ uri: string; title: string }> }>;
    ratings?: {
      main: ResponseRatingRecord | null;
      followUps: Record<string, ResponseRatingRecord>;
    };
  };
}

/**
 * Formats a transcript summary and rich metadata into an indented JSON file string.
 */
export function formatSummaryExportJson(data: {
  videoId: string;
  videoTitle?: string;
  channel?: string;
  mode?: string;
  source?: string;
  processingMode?: string;
  model?: string;
  text?: string;
  formattedText?: string;
  factCheck?: string | null;
  citations?: Array<{ uri: string; title: string }>;
  followUpQuestions?: Array<{ question: string; answer: string; sources?: Array<{ uri: string; title: string }> }>;
  ttsRate?: number;
  ttsVolume?: number;
  ttsPitch?: number;
  ttsVoice?: string;
  ratings?: {
    main: ResponseRatingRecord | null;
    followUps: Record<string, ResponseRatingRecord>;
  };
}): string {
  const payload: SummaryExportPayload = {
    generator: 'YouTube Feed Summariser (Gemini)',
    version: '2.12.0',
    exportedAt: new Date().toISOString(),
    metadata: {
      videoId: data.videoId,
      videoTitle: data.videoTitle || data.videoId || 'Untitled Video',
      channel: data.channel || 'YouTube Creator',
      videoUrl: `https://www.youtube.com/watch?v=${data.videoId}`,
      mode: data.mode || 'summary',
      source: data.source || 'video',
      processingMode: data.processingMode || 'fast',
      model: data.model || 'gemini-3.8-flash',
      ttsSettings: {
        rate: typeof data.ttsRate === 'number' ? data.ttsRate : 1.0,
        volume: typeof data.ttsVolume === 'number' ? data.ttsVolume : 1.0,
        pitch: clampPitch(data.ttsPitch),
        voice: data.ttsVoice || 'ai:Kore'
      }
    },
    content: {
      rawText: data.text || '',
      formattedText: data.formattedText,
      factCheck: data.factCheck || null,
      citations: data.citations || [],
      followUpQuestions: data.followUpQuestions || [],
      ...(data.ratings ? { ratings: data.ratings } : {})
    }
  };

  return JSON.stringify(payload, null, 2);
}

/**
 * Calculates normalized amplitudes (0.0 to 1.0) for a dynamic speech waveform visualizer.
 * Models human voice frequency spectrum, pitch shifting, playback speed cadence,
 * and syllable attack pulses.
 */
export function computeWaveformAmplitudes(options: {
  isPlaying: boolean;
  volume?: number;
  pitch?: number;
  rate?: number;
  timestamp?: number;
  barCount?: number;
  boundaryPulse?: number;
}): number[] {
  const barCount = Math.max(4, options.barCount || 12);
  const volume = options.volume !== undefined ? Math.max(0, Math.min(1, options.volume)) : 1.0;
  const pitch = options.pitch !== undefined ? clampPitch(options.pitch) : 1.0;
  const rate = options.rate !== undefined ? Math.max(0.25, Math.min(3, options.rate)) : 1.0;
  const t = (options.timestamp !== undefined ? options.timestamp : Date.now()) / 1000;
  const pulse = Math.max(0, Math.min(1, options.boundaryPulse || 0));

  if (!options.isPlaying || volume === 0) {
    // Resting flatline
    return new Array(barCount).fill(0.08);
  }

  const bars: number[] = [];
  const baseFreq = 3.2 * rate;

  for (let i = 0; i < barCount; i++) {
    const normIdx = i / (barCount - 1); // 0 (bass) to 1 (treble)

    // Speech formant model: Human speech has formant energy peaks around low-mid frequencies
    // Shift formant peaks up or down according to pitch
    const formantCenter = 0.35 * Math.sqrt(pitch);
    const formantWidth = 0.28;
    const formantDist = Math.abs(normIdx - formantCenter);
    const formantWeight = Math.exp(-Math.pow(formantDist / formantWidth, 2));

    // Dynamic wave oscillations representing voice harmonics & prosody
    const harmonic1 = Math.sin(t * baseFreq * 2.1 + i * 0.8) * 0.5 + 0.5;
    const harmonic2 = Math.sin(t * baseFreq * 4.3 - i * 1.2) * 0.3 + 0.3;
    const harmonic3 = Math.cos(t * baseFreq * 1.1 + i * 0.4) * 0.2 + 0.2;

    // Boundary pulse creates syllable attack
    const attackBoost = pulse * (0.3 + 0.7 * Math.sin(i * 0.5));

    // Combine formants, harmonics, rhythm, and syllable pulse
    let amp = (formantWeight * 0.5 + 0.25) * (harmonic1 * 0.45 + harmonic2 * 0.35 + harmonic3 * 0.2) + attackBoost;

    // Apply speech volume and clamp
    amp = Math.max(0.08, Math.min(1.0, amp * volume));
    bars.push(Math.round(amp * 100) / 100);
  }

  return bars;
}

export type HistoryTabVisibility = 'always' | 'with_tabs' | 'never';

export function normalizeHistoryTabVisibility(val: unknown): HistoryTabVisibility {
  if (val === 'always' || val === 'with_tabs' || val === 'never') {
    return val;
  }
  return 'always';
}

export function shouldShowHistoryTab(options: {
  visibility: unknown;
  cachedCount: number;
  activeTabCount: number;
}): boolean {
  const visibility = normalizeHistoryTabVisibility(options.visibility);
  if (options.cachedCount <= 0) return false;
  if (visibility === 'never') return false;
  if (visibility === 'with_tabs') return options.activeTabCount > 0;
  return true;
}

export type ResponseRatingValue = 'up' | 'down' | null;

export interface ResponseRatingRecord {
  videoId: string;
  targetType: 'summary' | 'transcript' | 'followup';
  targetId: string;
  rating: 'up' | 'down';
  note?: string;
  updatedAt: number;
}

export function normalizeResponseRating(val: unknown): ResponseRatingValue {
  if (val === 'up' || val === 'down') return val;
  return null;
}

export function buildResponseRatingKey(
  videoId: string,
  targetType: 'summary' | 'transcript' | 'followup' | string,
  targetId = 'main'
): string {
  return `${videoId}:${targetType}:${targetId || 'main'}`;
}

export function applyResponseRating(
  ratingsMap: Record<string, ResponseRatingRecord>,
  options: {
    videoId: string;
    targetType: 'summary' | 'transcript' | 'followup';
    targetId?: string;
    rating: 'up' | 'down';
    note?: string;
    timestamp?: number;
  }
): {
  nextMap: Record<string, ResponseRatingRecord>;
  record: ResponseRatingRecord | null;
} {
  const targetId = options.targetId || 'main';
  const key = buildResponseRatingKey(options.videoId, options.targetType, targetId);
  const existing = ratingsMap[key];
  const nextMap = { ...ratingsMap };

  if (existing && existing.rating === options.rating && options.note === undefined) {
    delete nextMap[key];
    return { nextMap, record: null };
  }

  const record: ResponseRatingRecord = {
    videoId: options.videoId,
    targetType: options.targetType,
    targetId,
    rating: options.rating,
    note: options.note !== undefined ? options.note : existing?.note,
    updatedAt: options.timestamp ?? Date.now()
  };
  nextMap[key] = record;
  return { nextMap, record };
}

const SUPERSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
  'n': 'ⁿ', 'i': 'ⁱ'
};

const SUBSCRIPT_CHAR_MAP: Record<string, string> = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
  '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎',
  'a': 'ₐ', 'e': 'ₑ', 'o': 'ₒ', 'x': 'ₓ', 'h': 'ₕ',
  'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ', 'n': 'ₙ', 'p': 'ₚ',
  's': 'ₛ', 't': 'ₜ'
};

const LATEX_COMMAND_REPLACEMENTS: Array<[RegExp, string]> = [
  [/\\(?:text|mathrm|textbf|textit|mathbf|mathit|mathsf|mathtt|ce|units|operatorname)\{([^{}]*)\}/g, '$1'],
  [/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, '$1/$2'],
  [/\\sqrt\{([^{}]+)\}/g, '√$1'],
  [/\\(?:approx|asymp)\b/g, '≈'],
  [/\\simeq\b/g, '≃'],
  [/\\cong\b/g, '≅'],
  [/\\equiv\b/g, '≡'],
  [/\\sim\b/g, '~'],
  [/\\pm\b/g, '±'],
  [/\\mp\b/g, '∓'],
  [/\\times\b/g, '×'],
  [/\\cdot\b/g, '·'],
  [/\\div\b/g, '÷'],
  [/\\(?:leq|le)\b/g, '≤'],
  [/\\(?:geq|ge)\b/g, '≥'],
  [/\\(?:neq|ne)\b/g, '≠'],
  [/\\ll\b/g, '≪'],
  [/\\gg\b/g, '≫'],
  [/\\(?:rightarrow|to)\b/g, '→'],
  [/\\(?:leftarrow|gets)\b/g, '←'],
  [/\\leftrightarrow\b/g, '↔'],
  [/\\(?:Rightarrow|implies)\b/g, '⇒'],
  [/\\(?:Leftrightarrow|iff)\b/g, '⇔'],
  [/\\infty\b/g, '∞'],
  [/\\partial\b/g, '∂'],
  [/\\nabla\b/g, '∇'],
  [/\\sum\b/g, '∑'],
  [/\\prod\b/g, '∏'],
  [/\\int\b/g, '∫'],
  [/\\propto\b/g, '∝'],
  [/\\in\b/g, '∈'],
  [/\\notin\b/g, '∉'],
  [/\\subseteq\b/g, '⊆'],
  [/\\subset\b/g, '⊂'],
  [/\\cup\b/g, '∪'],
  [/\\cap\b/g, '∩'],
  [/\\emptyset\b/g, '∅'],
  [/\\forall\b/g, '∀'],
  [/\\exists\b/g, '∃'],
  [/\\therefore\b/g, '∴'],
  [/\\because\b/g, '∵'],
  [/\\angle\b/g, '∠'],
  [/\\triangle\b/g, '△'],
  [/\\(?:degree|deg|circ)\b/g, '°'],
  [/\\alpha\b/g, 'α'],
  [/\\beta\b/g, 'β'],
  [/\\gamma\b/g, 'γ'],
  [/\\delta\b/g, 'δ'],
  [/\\(?:varepsilon|epsilon)\b/g, 'ε'],
  [/\\zeta\b/g, 'ζ'],
  [/\\eta\b/g, 'η'],
  [/\\(?:vartheta|theta)\b/g, 'θ'],
  [/\\iota\b/g, 'ι'],
  [/\\kappa\b/g, 'κ'],
  [/\\lambda\b/g, 'λ'],
  [/\\(?:mu|micro)\b/g, 'μ'],
  [/\\nu\b/g, 'ν'],
  [/\\xi\b/g, 'ξ'],
  [/\\pi\b/g, 'π'],
  [/\\rho\b/g, 'ρ'],
  [/\\sigma\b/g, 'σ'],
  [/\\tau\b/g, 'τ'],
  [/\\upsilon\b/g, 'υ'],
  [/\\(?:varphi|phi)\b/g, 'φ'],
  [/\\chi\b/g, 'χ'],
  [/\\psi\b/g, 'ψ'],
  [/\\omega\b/g, 'ω'],
  [/\\Gamma\b/g, 'Γ'],
  [/\\Delta\b/g, 'Δ'],
  [/\\Theta\b/g, 'Θ'],
  [/\\Lambda\b/g, 'Λ'],
  [/\\Xi\b/g, 'Ξ'],
  [/\\Pi\b/g, 'Π'],
  [/\\Sigma\b/g, 'Σ'],
  [/\\Phi\b/g, 'Φ'],
  [/\\Psi\b/g, 'Ψ'],
  [/\\Omega\b/g, 'Ω'],
  [/\\hbar\b/g, 'ℏ'],
  [/\\ell\b/g, 'ℓ'],
  [/\\AA\b/g, 'Å'],
  [/\\%/g, '%'],
  [/\\\$/g, '$'],
  [/\\&/g, '&'],
  [/\\(?:left|right)\b/g, ''],
  [/\\[,;:! ]/g, ' ']
];

function mapUnicodeScript(raw: string, map: Record<string, string>, fallbackPrefix: string): string {
  const chars = Array.from(raw);
  if (chars.length > 0 && chars.every((ch) => map[ch] !== undefined)) {
    return chars.map((ch) => map[ch]).join('');
  }
  return raw.length > 1 ? `${fallbackPrefix}(${raw})` : `${fallbackPrefix}${raw}`;
}

function convertLatexFragment(fragment: string): string {
  let out = fragment.trim();
  // Degree shortcuts first
  out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
  out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
  // Apply command replacements iteratively for nested \text{} / \frac{}
  for (let pass = 0; pass < 3; pass++) {
    const prev = out;
    for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
      out = out.replace(re, rep);
    }
    if (out === prev) break;
  }
  // Superscripts & subscripts
  out = out.replace(/\^\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUPERSCRIPT_CHAR_MAP, '^'));
  out = out.replace(/\^([0-9+\-=ni])/g, (_m, ch) => SUPERSCRIPT_CHAR_MAP[ch] || `^${ch}`);
  out = out.replace(/_\{([^{}]+)\}/g, (_m, inner) => mapUnicodeScript(inner, SUBSCRIPT_CHAR_MAP, '_'));
  out = out.replace(/_([0-9+\-=aehklmnopstx])/g, (_m, ch) => SUBSCRIPT_CHAR_MAP[ch] || `_${ch}`);
  // Clean remaining empty/redundant grouping braces inside math
  out = out.replace(/\{([^{}]*)\}/g, '$1');
  out = out.replace(/\s*°\s*/g, '°');
  out = out.replace(/\s{2,}/g, ' ').trim();
  return out;
}

/**
 * Formats inline/display LaTeX math & scientific symbols (such as $100^\circ\text{C}$ -> 100°C)
 * into clean Unicode text while preserving currency amounts like "$100 to $200".
 */
export function formatMathSymbolsInText(text: string): string {
  if (!text) return '';
  let out = String(text);

  // 1. Display math $$...$$ and \[...\]
  out = out.replace(/\$\$([\s\S]+?)\$\$/g, (_m, inner) => convertLatexFragment(inner));
  out = out.replace(/\\\[([\s\S]+?)\\\]/g, (_m, inner) => convertLatexFragment(inner));

  // 2. Inline math \(...\)
  out = out.replace(/\\\(([^\n]+?)\\\)/g, (_m, inner) => convertLatexFragment(inner));

  // 3. Inline math $...$ (guard against currency amounts like "$100 to $200")
  out = out.replace(/\$([^$\n]+?)\$/g, (match, inner) => {
    if (!inner || /^\s|\s$/.test(inner)) return match;
    const hasMathSignal =
      /[\\^{}_=<>~±×÷≈≠≤≥°]/.test(inner) ||
      /^[A-Za-z](?:\d+|['’])?$/.test(inner);
    if (!hasMathSignal) return match;
    return convertLatexFragment(inner);
  });

  // 4. Bare LaTeX scientific symbols outside $...$ (e.g., 100^\circ\text{C}, \approx, \pm)
  out = out.replace(/\^\s*\{\s*\\(?:circ|degree|deg)\s*\}/g, '°');
  out = out.replace(/\^\s*\\(?:circ|degree|deg)\b/g, '°');
  if (/\\(?:text|mathrm|textbf|textit|ce|approx|pm|times|div|leq|geq|neq|degree|circ|alpha|beta|gamma|delta|theta|lambda|mu|pi|sigma|omega|Delta|Sigma|Omega)\b/.test(out)) {
    for (const [re, rep] of LATEX_COMMAND_REPLACEMENTS) {
      out = out.replace(re, rep);
    }
    out = out.replace(/\s*°\s*/g, '°');
  }

  return out;
}

export interface WindowBounds {
  left: number;
  top: number;
  width: number;
  height: number;
}

export type WindowSizeTier = 'compact' | 'medium' | 'wide';

export function clampWindowBounds(
  bounds: WindowBounds,
  viewport: { width: number; height: number },
  minWidth = 340,
  minHeight = 300
): WindowBounds {
  const vw = Math.max(360, viewport.width || 1280);
  const vh = Math.max(360, viewport.height || 800);
  const maxW = Math.max(minWidth, vw - 24);
  const maxH = Math.max(minHeight, vh - 64);

  const width = Math.round(Math.max(minWidth, Math.min(maxW, bounds.width)));
  const height = Math.round(Math.max(minHeight, Math.min(maxH, bounds.height)));
  const maxLeft = Math.max(12, vw - width - 12);
  const maxTop = Math.max(12, vh - height - 52);
  const left = Math.round(Math.max(12, Math.min(maxLeft, bounds.left)));
  const top = Math.round(Math.max(12, Math.min(maxTop, bounds.top)));

  return { left, top, width, height };
}

export function computeDefaultWindowBounds(
  viewport: { width: number; height: number },
  cascadeIndex = 0,
  preferred?: Partial<WindowBounds> | null
): WindowBounds {
  const vw = Math.max(360, viewport.width || 1280);
  const vh = Math.max(360, viewport.height || 800);
  const defaultWidth = preferred?.width ?? Math.min(920, Math.max(360, vw - 64));
  const defaultHeight = preferred?.height ?? Math.min(760, Math.max(380, vh - 110));
  const step = (Math.max(0, cascadeIndex) % 5) * 28;
  const baseLeft = preferred?.left ?? Math.max(16, Math.round((vw - defaultWidth) / 2) + step - 28);
  const baseTop = preferred?.top ?? Math.max(16, Math.round((vh - defaultHeight - 44) / 2) + step - 28);

  return clampWindowBounds(
    { left: baseLeft, top: baseTop, width: defaultWidth, height: defaultHeight },
    { width: vw, height: vh }
  );
}

export function classifyWindowSizeTier(width: number): WindowSizeTier {
  if (width < 540) return 'compact';
  if (width < 780) return 'medium';
  return 'wide';
}

export function getAdaptiveWindowFlags(width: number, height: number) {
  const tier = classifyWindowSizeTier(width);
  return {
    tier,
    isCompact: tier === 'compact',
    isMedium: tier === 'medium',
    isWide: tier === 'wide',
    isShort: height < 460,
    useOverflowHeaderMenu: width < 540,
    collapseOptionsRow: width < 540,
    compactTtsBar: width < 780,
    singleColumnAdvPanel: width < 580
  };
}

export type FeedCardTitleMode = 'ai' | 'dearrow' | 'original' | 'music';

export function normalizeAltTitlesEnabled(val: unknown): boolean {
  if (val === false || val === 'false' || val === 0) return false;
  return true;
}

export function resolveFeedCardTitleMode(options: {
  isMusic?: boolean;
  hasDeArrowTitle?: boolean;
  altTitlesEnabled?: boolean;
  manualOverride?: 'ai' | 'dearrow' | 'original' | null;
}): FeedCardTitleMode {
  if (options.isMusic) return 'music';
  if (options.manualOverride === 'ai') return 'ai';
  if (options.manualOverride === 'dearrow') {
    return options.hasDeArrowTitle ? 'dearrow' : 'original';
  }
  if (options.manualOverride === 'original') {
    return options.hasDeArrowTitle ? 'dearrow' : 'original';
  }
  if (options.hasDeArrowTitle) return 'dearrow';
  return options.altTitlesEnabled !== false ? 'ai' : 'original';
}

export function sanitizeGeneratedAltTitle(rawTitle: string, fallbackTitle = ''): string {
  const cleaned = String(rawTitle || '')
    .replace(/^["'#*`]+|["'#*`]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const candidate = cleaned || String(fallbackTitle || '').replace(/\s+/g, ' ').trim();
  if (!candidate) return '';
  if (candidate.length > 150) {
    return candidate.slice(0, 147).trim() + '...';
  }
  return candidate;
}

export function shouldCacheGeneratedAltTitle(
  generated: string,
  originalTitle: string,
  generatedFromContent: boolean
): boolean {
  if (!generatedFromContent) return false;
  const cleanGen = String(generated || '').replace(/\s+/g, ' ').trim();
  const cleanOrig = String(originalTitle || '').replace(/\s+/g, ' ').trim();
  if (!cleanGen || cleanGen.length < 5) return false;
  if (cleanOrig && cleanGen.toLowerCase() === cleanOrig.toLowerCase()) return false;
  return true;
}

export function normalizeCompactOptionsMap(raw: unknown): Record<string, boolean> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: Record<string, boolean> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (k && k !== '__proto__' && k !== 'constructor' && k !== 'prototype' && typeof v === 'boolean') {
      out[k] = v;
    }
  }
  return out;
}

