#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

const ROOT = path.resolve(process.cwd());
const STORAGE_ROOT = path.join(ROOT, 'sandbox-storage');
const BACKUPS_DIR = path.join(STORAGE_ROOT, 'backups');
const MEMORY_DIR = path.join(STORAGE_ROOT, 'memory');
const POLICY_PATH = path.join(MEMORY_DIR, 'workflow-policy.json');
const STATE_PATH = path.join(MEMORY_DIR, 'state.json');
const INDEX_PATH = path.join(BACKUPS_DIR, 'index.json');
const LATEST_PATH = path.join(BACKUPS_DIR, 'latest.json');
const EPISODES_PATH = path.join(MEMORY_DIR, 'episodes.jsonl');

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (token.startsWith('--')) {
      const eq = token.indexOf('=');
      if (eq !== -1) {
        args[token.slice(2, eq)] = token.slice(eq + 1);
      } else {
        const next = argv[i + 1];
        if (next && !next.startsWith('--')) {
          args[token.slice(2)] = next;
          i++;
        } else {
          args[token.slice(2)] = true;
        }
      }
    } else {
      args._.push(token);
    }
  }
  return args;
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  const buf = fs.readFileSync(filePath);
  hash.update(buf);
  return hash.digest('hex');
}

function walkFiles(dir, excludes, relBase = '') {
  const results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
  for (const entry of entries) {
    const rel = relBase ? `${relBase}/${entry.name}` : entry.name;
    if (excludes.some((ex) => rel === ex || rel.startsWith(ex + '/') || entry.name === ex)) {
      continue;
    }
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...walkFiles(full, excludes, rel));
    } else if (entry.isFile()) {
      results.push(rel);
    }
  }
  return results;
}

function computeWorkspaceDigest(files) {
  const h = crypto.createHash('sha256');
  for (const rel of files) {
    const full = path.join(ROOT, rel);
    const content = fs.readFileSync(full);
    h.update(rel);
    h.update('\0');
    h.update(crypto.createHash('sha256').update(content).digest('hex'));
    h.update('\n');
  }
  return h.digest('hex');
}

function formatStamp(d = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return (
    `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}` +
    `-${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}`
  );
}

function sanitizeSlug(raw) {
  return String(raw || 'prompt-end')
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || 'prompt-end';
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.interval || args.cron || args.watch) {
    console.error('Policy violation: fixed-interval or cron backups are disabled. Backups run at execution-plan/prompt end only.');
    process.exit(2);
  }

  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  const policy = readJson(POLICY_PATH, {});
  const excludes = policy?.backupPolicy?.excludes || [
    'node_modules',
    'dist',
    '.playwright-cli',
    '.git',
    'sandbox-storage/backups'
  ];
  const maxRetained = policy?.backupPolicy?.maxRetainedSnapshots || 30;
  const index = readJson(INDEX_PATH, { backups: [] });

  if (args.list) {
    console.log(JSON.stringify(index, null, 2));
    return;
  }

  if (args.verify) {
    const targetId = args.verify === 'latest' ? index.backups[0]?.id : args.verify;
    const entry = index.backups.find((b) => b.id === targetId);
    if (!entry) {
      console.error(`Snapshot not found: ${args.verify}`);
      process.exit(1);
    }
    const archivePath = path.join(ROOT, entry.archivePath);
    if (!fs.existsSync(archivePath)) {
      console.error(`Archive missing: ${archivePath}`);
      process.exit(1);
    }
    const actualSha = sha256File(archivePath);
    if (actualSha !== entry.archiveSha256) {
      console.error(`Checksum mismatch for ${entry.id}: expected ${entry.archiveSha256}, got ${actualSha}`);
      process.exit(1);
    }
    const listed = execFileSync('tar', ['-tzf', archivePath], { encoding: 'utf8' })
      .trim()
      .split('\n')
      .filter(Boolean);
    console.log(JSON.stringify({ verified: true, id: entry.id, archivePath: entry.archivePath, fileCount: listed.length, archiveSha256: actualSha }, null, 2));
    return;
  }

  if (args.restore) {
    const targetId = args.restore === 'latest' ? index.backups[0]?.id : args.restore;
    const entry = index.backups.find((b) => b.id === targetId);
    if (!entry) {
      console.error(`Snapshot not found: ${args.restore}`);
      process.exit(1);
    }
    const archivePath = path.join(ROOT, entry.archivePath);
    const actualSha = sha256File(archivePath);
    if (actualSha !== entry.archiveSha256) {
      console.error(`Refusing restore: checksum mismatch for ${entry.id}`);
      process.exit(1);
    }
    if (args['dry-run']) {
      const files = execFileSync('tar', ['-tzf', archivePath], { encoding: 'utf8' })
        .trim()
        .split('\n')
        .filter(Boolean);
      console.log(JSON.stringify({ dryRun: true, id: entry.id, filesWouldRestore: files.length }, null, 2));
      return;
    }
    execFileSync('tar', ['-xzf', archivePath, '-C', ROOT], { stdio: 'inherit' });
    console.log(JSON.stringify({ restored: true, id: entry.id, archivePath: entry.archivePath }, null, 2));
    return;
  }

  // Default action: create verified prompt-end sandbox snapshot
  const state = readJson(STATE_PATH, {});
  const stage = String(args.stage || state.currentStageId || 'stage-0-baseline-examination');
  const label = sanitizeSlug(args.label || 'prompt-end');
  const stamp = formatStamp();
  const id = `snap-${stamp}-${label}`;
  const archiveName = `${id}.tar.gz`;
  const archiveRel = `sandbox-storage/backups/${archiveName}`;
  const archiveAbs = path.join(ROOT, archiveRel);

  const files = walkFiles(ROOT, excludes);
  const workspaceDigest = computeWorkspaceDigest(files);

  const listFile = path.join(BACKUPS_DIR, `.${id}.files`);
  fs.writeFileSync(listFile, files.join('\n') + '\n', 'utf8');
  try {
    execFileSync('tar', ['-czf', archiveAbs, '-C', ROOT, '-T', listFile], { stdio: 'pipe' });
  } finally {
    fs.rmSync(listFile, { force: true });
  }

  // Verify archive readability immediately
  const archivedEntries = execFileSync('tar', ['-tzf', archiveAbs], { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 })
    .trim()
    .split('\n')
    .filter(Boolean);
  const stat = fs.statSync(archiveAbs);
  const archiveSha256 = sha256File(archiveAbs);

  const record = {
    id,
    createdAt: new Date().toISOString(),
    trigger: 'prompt-end',
    label,
    stageId: stage,
    fileCount: files.length,
    archivedEntryCount: archivedEntries.length,
    bytes: stat.size,
    workspaceDigest,
    archiveSha256,
    archivePath: archiveRel,
    verified: archivedEntries.length === files.length
  };

  const nextBackups = [record, ...index.backups];
  if (nextBackups.length > maxRetained) {
    const removed = nextBackups.splice(maxRetained);
    for (const old of removed) {
      const oldPath = path.join(ROOT, old.archivePath);
      if (fs.existsSync(oldPath)) fs.rmSync(oldPath, { force: true });
    }
  }

  writeJson(INDEX_PATH, { updatedAt: record.createdAt, backups: nextBackups });
  writeJson(LATEST_PATH, record);

  const updatedState = {
    ...state,
    lastBackup: {
      id: record.id,
      createdAt: record.createdAt,
      trigger: record.trigger,
      stageId: record.stageId,
      archivePath: record.archivePath,
      archiveSha256: record.archiveSha256,
      workspaceDigest: record.workspaceDigest,
      fileCount: record.fileCount,
      bytes: record.bytes
    },
    updatedAt: record.createdAt
  };
  writeJson(STATE_PATH, updatedState);

  fs.mkdirSync(path.dirname(EPISODES_PATH), { recursive: true });
  fs.appendFileSync(
    EPISODES_PATH,
    JSON.stringify({
      ts: record.createdAt,
      type: 'backup',
      stage: record.stageId,
      summary: `Prompt-end snapshot ${record.id} (${record.fileCount} files, ${record.bytes} bytes, sha256:${record.archiveSha256.slice(0, 12)}) verified.`
    }) + '\n',
    'utf8'
  );

  console.log(JSON.stringify(record, null, 2));
}

main();
