import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from 'playwright';
import { createServer } from 'vite';

export async function runSimulatorUiTests() {
  console.log('\n--- Running Test Suite 5: React Simulator Parity, Accessibility & Mobile Stress ---');
  let passed = 0;
  let server;
  let browser;

  try {
    server = await createServer({
      server: {
        host: '127.0.0.1',
        port: 0,
        hmr: false,
        watch: null
      },
      logLevel: 'silent'
    });
    await server.listen();
    const address = server.httpServer?.address();
    const port = typeof address === 'object' && address ? address.port : 4173;
    const baseUrl = `http://127.0.0.1:${port}/`;

    let executablePath = undefined;
    const knownPaths = [
      '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
      '/ms-playwright/chrome-headless-shell-linux64/chrome-headless-shell'
    ];
    for (const p of knownPaths) {
      if (fs.existsSync(p)) {
        executablePath = p;
        break;
      }
    }

    browser = await chromium.launch({
      headless: true,
      executablePath,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const context = await browser.newContext({
      viewport: { width: 1440, height: 900 }
    });
    const page = await context.newPage();

    const pageErrors = [];
    page.on('pageerror', (err) => pageErrors.push(err.message));

    let dialogTriggered = false;
    page.on('dialog', async (d) => {
      dialogTriggered = true;
      await d.dismiss();
    });

    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.waitForSelector('h1');

    // 1. Open first two video summary windows via 3-dot card menus
    const menuButtons = page.locator('button[title="Action menu"]');
    await menuButtons.nth(0).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');

    // Minimize window 1 first so card 2 3-dot menu is unobscured
    await page.locator('.yt-window-box[data-video-id="D_clickbait_chip"] button[aria-label="Minimize window"]').click();
    await page.waitForTimeout(100);
    const liveAfterMin = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterMin || '').includes('Minimized'), 'Simulator ARIA live region announces window minimization');
    passed++;

    await menuButtons.nth(1).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_space_webb"]');

    // Restore window 1 via dock tab
    const restoreBtn = page.locator('button[title="Restore window"]').first();
    await restoreBtn.click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const liveAfterRestore = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterRestore || '').includes('Restored'), 'Simulator ARIA live region announces window restoration');
    passed++;

    // 2. Verify all 8 resize handles + keyboard move/resize + north drag in Simulator
    const win1 = page.locator('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const handleDirs = await win1.locator('.yt-resize-handle').evaluateAll((els) =>
      els.map((el) => el.getAttribute('data-resize-dir')).sort()
    );
    assert.deepEqual(handleDirs, ['e', 'n', 'ne', 'nw', 's', 'se', 'sw', 'w'], 'Simulator renders all 8 resize handles');
    passed++;

    const boxBefore = await win1.boundingBox();
    const grip = win1.locator('.yt-win-drag-grip');
    await grip.focus();
    await page.keyboard.press('ArrowRight');
    await page.keyboard.press('Shift+ArrowDown');
    const boxAfterGrip = await win1.boundingBox();
    assert.ok(boxAfterGrip && boxBefore && Math.round(boxAfterGrip.x - boxBefore.x) === 16, 'Simulator grip ArrowRight moves left +16px');
    assert.ok(boxAfterGrip && boxBefore && Math.round(boxAfterGrip.y - boxBefore.y) === 48, 'Simulator grip Shift+ArrowDown moves top +48px');
    passed += 2;

    const northHandle = win1.locator('[data-resize-dir="n"]');
    await northHandle.focus();
    await page.keyboard.press('ArrowUp');
    const boxAfterNorth = await win1.boundingBox();
    assert.ok(boxAfterNorth && boxAfterGrip && Math.round(boxAfterNorth.height - boxAfterGrip.height) === 16, 'Simulator N handle ArrowUp expands height +16px');
    passed++;

    // 3. Multi-window per-card toast isolation
    await win1.locator('.yt-tts-skip-silence-btn').click();
    const toastWin1Visible = await page.locator('[data-toast-video-id="D_clickbait_chip"]').isVisible();
    const toastWin2Count = await page.locator('[data-toast-video-id="D_space_webb"]').count();
    assert.ok(toastWin1Visible, 'Simulator renders scoped TTS toast inside triggered window');
    assert.equal(toastWin2Count, 0, 'Simulator TTS toast isolates strictly to target video window');
    passed++;

    // 4. Compact Options persistence across page reload
    const seHandle = win1.locator('[data-resize-dir="se"]');
    const seBox = await seHandle.boundingBox();
    if (seBox && boxAfterNorth) {
      await page.mouse.move(seBox.x + seBox.width / 2, seBox.y + seBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(boxAfterNorth.x + 420, boxAfterNorth.y + 420, { steps: 6 });
      await page.mouse.up();
    }
    const tierAfterResize = await win1.getAttribute('data-size-tier');
    assert.equal(tierAfterResize, 'compact', 'Resizing Simulator window below 540px enters compact tier');
    const compactOptsBtn = win1.locator('.yt-compact-options-btn');
    await compactOptsBtn.click();
    const storedCompactOpts = await page.evaluate(() => localStorage.getItem('yt_compact_options_expanded'));
    assert.ok(storedCompactOpts && storedCompactOpts.includes('"D_clickbait_chip":true'), 'Simulator persists compact Options disclosure to localStorage');
    passed += 2;

    // 5. ARIA rating announcement + YouTube Ask fallback transition announcement
    const ratingUpBtn = win1.locator('.yt-rating-up').first();
    await ratingUpBtn.click();
    const liveAfterRating = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.equal(liveAfterRating, 'Thumbs up rating saved', 'Simulator ARIA live region announces thumbs up rating persistence');
    passed++;

    // Select Ask + Simulate Ask failure -> click Regenerate
    const modelSelect = win1.locator('select[aria-label="Gemini Model Selector"]');
    const hasAskOption = await win1.locator('option[value="Ask"]').count();
    assert.ok(hasAskOption > 0, 'Simulator exposes YouTube Ask option in model selector');
    await modelSelect.selectOption('Ask');
    const failToggle = win1.locator('label:has-text("Simulate Ask failure") input[type="checkbox"]');
    await failToggle.check();
    await win1.locator('button:has-text("Regenerate")').click();
    const liveAfterAsk = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterAsk || '').includes('YouTube Ask failed, switched to'), 'Simulator ARIA live region announces Ask fallback model transition');
    passed++;

    // Reload persistence check for compact Options state
    await page.reload({ waitUntil: 'networkidle' });
    await page.locator('button[title="Action menu"]').nth(0).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const storedAfterReload = await page.evaluate(() => localStorage.getItem('yt_compact_options_expanded'));
    assert.ok(storedAfterReload && storedAfterReload.includes('"D_clickbait_chip":true'), 'Compact Options preference survives page reload');
    passed++;

    // 6. Mobile narrow viewport (<400px) zero-overflow stress test
    await page.setViewportSize({ width: 375, height: 812 });
    await page.waitForTimeout(150);
    const mobileMetrics = await page.evaluate(() => {
      const winBox = document.querySelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
      const rect = winBox?.getBoundingClientRect();
      return {
        innerWidth: window.innerWidth,
        docScrollWidth: document.documentElement.scrollWidth,
        winLeft: rect?.left || 0,
        winRight: rect?.right || 0,
        winWidth: rect?.width || 0
      };
    });
    assert.ok(mobileMetrics.docScrollWidth <= mobileMetrics.innerWidth, `Mobile 375px Simulator has zero horizontal overflow (${mobileMetrics.docScrollWidth} <= ${mobileMetrics.innerWidth})`);
    assert.ok(mobileMetrics.winLeft >= 0 && mobileMetrics.winRight <= mobileMetrics.innerWidth, `Mobile 375px floating window fits inside viewport (${mobileMetrics.winLeft}..${mobileMetrics.winRight} <= ${mobileMetrics.innerWidth})`);
    assert.equal(dialogTriggered, false, 'Simulator emits zero blocking alert/confirm dialogs');
    assert.equal(pageErrors.length, 0, `Zero runtime page errors (${pageErrors.join('; ')})`);
    passed += 4;

    console.log(`✓ Suite 5 passed: ${passed} checks verified.`);
    return { passed, total: passed };
  } finally {
    if (browser) await browser.close();
    if (server) await server.close();
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runSimulatorUiTests()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
