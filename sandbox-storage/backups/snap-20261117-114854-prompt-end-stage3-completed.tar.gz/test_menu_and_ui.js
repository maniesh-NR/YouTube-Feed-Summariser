import assert from 'node:assert/strict';
import { createHarness } from './harness.js';

export async function runMenuAndUiTests() {
  console.log('\n--- Running Test Suite 1: Menu Integration & UI Mechanics ---');
  let passed = 0;
  const harness = await createHarness();

  try {
    const page = await harness.openFeed();
    await page.waitForTimeout(300);

    // Check 1: Old menu injection
    await page.click('#btn-old-menu');
    await page.waitForTimeout(300);
    const oldItem = await page.waitForSelector('[data-ytais-item]', { state: 'attached', timeout: 5000 });
    assert.ok(oldItem, 'Summarize item injected in old iron-dropdown menu');
    passed++;

    // Check 2: Positioned between Save to playlist and Download
    const posCheck = await page.evaluate(() => {
      const item = document.querySelector('[data-ytais-item]');
      const prev = item.previousElementSibling;
      const next = item.nextElementSibling;
      return {
        prevMatches: /save to playlist/i.test(prev?.getAttribute('aria-label') || prev?.textContent || ''),
        nextMatches: /download/i.test(next?.getAttribute('aria-label') || next?.textContent || '')
      };
    });
    assert.ok(posCheck.prevMatches, 'Injected item is after "Save to playlist"');
    assert.ok(posCheck.nextMatches, 'Injected item is before "Download"');
    passed++;

    // Check 3: Menu item styling (16px, >= 44px min-height, sparkle icon)
    const styleCheck = await page.evaluate(() => {
      const item = document.querySelector('[data-ytais-item]');
      const cs = window.getComputedStyle(item);
      const svg = item.querySelector('svg');
      return {
        fontSize: cs.fontSize,
        minHeight: parseFloat(cs.minHeight),
        hasSvg: Boolean(svg),
        svgWidth: svg?.getAttribute('width')
      };
    });
    assert.equal(styleCheck.fontSize, '16px', 'Menu item font size is 16px');
    assert.ok(styleCheck.minHeight >= 44, 'Menu item min-height is >= 44px');
    assert.ok(styleCheck.hasSvg, 'Menu item has sparkle SVG icon');
    passed++;

    // Check 4: New menu injection (yt-sheet)
    await page.click('#btn-new-menu');
    await page.waitForTimeout(300);
    const newItem = await page.waitForSelector('#sheet-new [data-ytais-item]', { state: 'attached', timeout: 5000 });
    assert.ok(newItem, 'Summarize item injected in new yt-sheet menu');
    passed++;

    // Check 5: First-run key manager dialog when clicking without keys
    await page.evaluate(() => {
      const item = document.querySelector('[data-ytais-item]');
      item.click();
    });
    await page.waitForTimeout(400);

    const hasKeyDialog = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const dialog = host?.shadowRoot?.querySelector('.yt-key-dialog-scrim');
      return Boolean(dialog);
    });
    assert.ok(hasKeyDialog, 'First-run API key manager dialog opens when no keys exist');
    passed++;

    // Check 6: Escape closes key dialog without closing window
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);

    const dialogClosed = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      return !host?.shadowRoot?.querySelector('.yt-key-dialog-scrim');
    });
    assert.ok(dialogClosed, 'Escape closes key dialog');
    passed++;

    // Check 7: Dock geometry (right: 24px, bottom: 0, tab height: 38px)
    const dockCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const dock = host?.shadowRoot?.querySelector('.yt-dock');
      const tab = host?.shadowRoot?.querySelector('.yt-dock-tab');
      const dockCs = window.getComputedStyle(dock);
      const tabCs = window.getComputedStyle(tab);
      return {
        right: dockCs.right,
        bottom: dockCs.bottom,
        height: tabCs.height
      };
    });
    assert.equal(dockCheck.right, '24px', 'Dock positioned right: 24px');
    assert.equal(dockCheck.bottom, '0px', 'Dock positioned bottom: 0px');
    assert.equal(dockCheck.height, '38px', 'Dock tab height is 38px');
    passed++;

    // Check 8: Escape minimizes maximized window (never closes it!)
    const minCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      return {
        hasModalBefore: Boolean(host?.shadowRoot?.querySelector('.yt-window-box')),
        tabsBefore: host?.shadowRoot?.querySelectorAll('.yt-dock-tab').length
      };
    });
    assert.ok(minCheck.hasModalBefore, 'Window was maximized');

    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);

    const minAfter = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      return {
        hasModalAfter: Boolean(host?.shadowRoot?.querySelector('.yt-window-box')),
        tabsAfter: host?.shadowRoot?.querySelectorAll('.yt-dock-tab').length
      };
    });
    assert.ok(!minAfter.hasModalAfter, 'Escape minimizes the window (modal removed)');
    assert.equal(minAfter.tabsAfter, 1, 'Dock tab remains present (not closed)');
    passed++;

    // Check 9: Clicking title on dock tab re-maximizes window
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const tab = host?.shadowRoot?.querySelector('.yt-dock-tab');
      tab.click();
    });
    await page.waitForTimeout(200);

    const remax = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      return Boolean(host?.shadowRoot?.querySelector('.yt-window-box'));
    });
    assert.ok(remax, 'Clicking dock tab re-maximizes window');
    passed++;

    // Check 10: Page hotkeys isolated while typing in window
    await page.evaluate(() => {
      window.__pageKeyFired = false;
      document.addEventListener('keydown', (e) => {
        if (e.key === 'k') window.__pageKeyFired = true;
      });
      const host = document.getElementById('yt-ai-summary-host');
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      if (win) {
        win.status = 'done';
        win.renderAll();
      }
      const ta = host?.shadowRoot?.querySelector('.yt-composer-textarea');
      ta.focus();
    });

    await page.keyboard.press('k');
    const hotkeyCheck = await page.evaluate(() => !window.__pageKeyFired);
    assert.ok(hotkeyCheck, 'Typing inside shadow root prevents YouTube global hotkeys from firing');
    passed++;

    // Check 11: Dark mode dropdown menu styling & color-scheme: dark
    const darkModeCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const select = root?.querySelector('.yt-select');
      const styleEl = root?.querySelector('style');
      const cssText = styleEl?.textContent || '';
      const selectCs = select ? window.getComputedStyle(select) : null;
      return {
        hasSelect: Boolean(select),
        selectColorScheme: selectCs?.colorScheme,
        cssHasDarkOptions: cssText.includes('.yt-select option') && cssText.includes('#212121'),
        cssHasDarkOptgroup: cssText.includes('.yt-select optgroup') && cssText.includes('#181818'),
        cssHasColorSchemeDark: cssText.includes('color-scheme: dark')
      };
    });
    assert.ok(darkModeCheck.hasSelect, 'Select element present');
    assert.equal(darkModeCheck.selectColorScheme, 'dark', 'Dropdown select has color-scheme: dark');
    assert.ok(darkModeCheck.cssHasDarkOptions, 'Dropdown options have #212121 dark background styling');
    assert.ok(darkModeCheck.cssHasDarkOptgroup, 'Dropdown optgroups have #181818 dark background styling');
    passed++;

    // Check 12: TTS controls present in toolbar (Listen, Stop, Speed)
    const ttsPresence = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const ttsGroup = root?.querySelector('.yt-tts-group');
      const playBtn = root?.querySelector('.yt-tts-play-btn');
      const stopBtn = root?.querySelector('.yt-tts-stop-btn');
      const rateBtn = root?.querySelector('.yt-tts-speed-btn');
      return {
        hasGroup: Boolean(ttsGroup),
        playText: playBtn?.textContent?.trim(),
        stopText: stopBtn?.textContent?.trim(),
        rateText: rateBtn?.textContent?.trim()
      };
    });
    assert.ok(ttsPresence.hasGroup, 'TTS controls group rendered in toolbar');
    assert.equal(ttsPresence.playText, 'Listen', 'TTS play button initialized to Listen');
    assert.equal(ttsPresence.stopText, 'Stop', 'TTS stop button rendered');
    assert.equal(ttsPresence.rateText, '1x', 'TTS speed toggle initialized to 1x');
    passed++;

    // Check 13: Clicking Listen triggers speechSynthesis.speak with cleaned text
    await page.evaluate(() => {
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      if (win) {
        win.text = '## TL;DR\nQuantum computing is accelerating [01:15] with topological qubits.\n[[FRAME 01:15 | Diagram]]\n**Important:** Great breakthrough.';
        win.renderAll();
      }
      const host = document.getElementById('yt-ai-summary-host');
      const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
      playBtn?.click();
    });
    await page.waitForTimeout(100);

    const speechResult = await page.evaluate(() => {
      const spoken = window.__tts_spoken || [];
      const host = document.getElementById('yt-ai-summary-host');
      const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
      return {
        spokenCount: spoken.length,
        lastSpoken: spoken[spoken.length - 1] || '',
        buttonActive: playBtn?.classList.contains('active') || playBtn?.textContent?.includes('Pause') || playBtn?.textContent?.includes('Resume')
      };
    });
    assert.ok(speechResult.spokenCount > 0, 'speechSynthesis.speak called');
    assert.ok(!speechResult.lastSpoken.includes('[[FRAME'), 'Visual markers stripped from spoken text');
    assert.ok(speechResult.lastSpoken.includes('at 1 minute 15 seconds'), 'Timestamp converted to spoken phrase');
    assert.ok(speechResult.lastSpoken.includes('Important: Great breakthrough'), 'Markdown asterisks stripped');
    passed++;

    // Check 14: Speed toggle button cycles playback rate
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const rateBtn = host?.shadowRoot?.querySelector('.yt-tts-speed-btn');
      rateBtn?.click();
    });
    const speedAfter = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const rateBtn = host?.shadowRoot?.querySelector('.yt-tts-speed-btn');
      return rateBtn?.textContent?.trim();
    });
    assert.equal(speedAfter, '1.25x', 'Speed toggle cycled rate from 1x to 1.25x');
    passed++;

    // Check 15: Stop button resets TTS
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const stopBtn = host?.shadowRoot?.querySelector('.yt-tts-stop-btn');
      stopBtn?.click();
    });
    const stopResult = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      return {
        ttsState: win?.ttsState,
        playBtnText: playBtn?.textContent?.trim()
      };
    });
    assert.equal(stopResult.ttsState, 'idle', 'TTS state reset to idle on Stop');
    assert.equal(stopResult.playBtnText, 'Listen', 'Play button reverted to Listen');
    passed++;

    // Check 16: Copy and Open video URL buttons in header
    const urlBtnsCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const copyBtn = host?.shadowRoot?.querySelector('.yt-win-copy-btn');
      const openBtn = host?.shadowRoot?.querySelector('.yt-win-open-btn');
      if (copyBtn) copyBtn.click();
      return {
        hasCopy: Boolean(copyBtn),
        hasOpen: Boolean(openBtn),
        isCopied: copyBtn?.classList.contains('copied')
      };
    });
    assert.ok(urlBtnsCheck.hasCopy, 'Copy video URL button rendered in header');
    assert.ok(urlBtnsCheck.hasOpen, 'Open video in new tab button rendered in header');
    assert.ok(urlBtnsCheck.isCopied, 'Clicking copy video URL activates copied feedback state');
    passed += 3;

    // Check 17: TTS voice dropdown allows selecting browser voices & updates voice property
    const voiceCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const voiceSelect = host?.shadowRoot?.querySelector('.yt-tts-voice-select');
      const options = Array.from(voiceSelect?.options || []).map((o) => o.value);
      const hasAiVoice = options.some((v) => v.startsWith('ai:'));
      const hasBrowserVoice = options.some((v) => v.startsWith('browser:'));

      // Select a specific browser voice:
      const targetBrowserOpt = options.find((v) => v.includes('Google UK English Female') || v.includes('Google US English'));
      if (voiceSelect && targetBrowserOpt) {
        voiceSelect.value = targetBrowserOpt;
        voiceSelect.dispatchEvent(new Event('change'));
      }

      // Click play to test utterance voice assignment
      const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
      playBtn?.click();

      const lastUtt = window.__tts_utterances ? window.__tts_utterances[window.__tts_utterances.length - 1] : null;

      return {
        hasSelect: Boolean(voiceSelect),
        hasAiVoice,
        hasBrowserVoice,
        selectedVoice: voiceSelect?.value,
        utteranceVoiceName: lastUtt?.voice?.name || ''
      };
    });
    assert.ok(voiceCheck.hasSelect, 'TTS voice selector dropdown is rendered');
    assert.ok(voiceCheck.hasAiVoice, 'TTS dropdown lists Google AI Studio neural voices');
    assert.ok(voiceCheck.hasBrowserVoice, 'TTS dropdown lists available browser voices');
    assert.ok(voiceCheck.utteranceVoiceName.length > 0, 'SpeechSynthesisUtterance.voice property is updated with selected browser voice');
    passed += 4;

    // Check 18: Transcript search bar, keyword highlighting, navigation & filtering
    await page.evaluate(() => {
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      if (win) {
        win.mode = 'transcript';
        win.text = `## Transcript (YouTube captions)\n[00:05] Welcome to today's breakdown of quantum topological qubits.\n[01:15] Modern quantum computers struggle with thermal crosstalk.\n[03:40] Classical computers cannot simulate topological braiding.\n[07:20] Final conclusions and summary.`;
        win.renderAll();
      }
    });
    await page.waitForTimeout(100);

    const searchInit = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const searchBar = host?.shadowRoot?.querySelector('.yt-transcript-search-bar');
      const input = host?.shadowRoot?.querySelector('.yt-transcript-search-input');
      const count = host?.shadowRoot?.querySelector('.yt-transcript-match-count');

      // Type search term "quantum"
      if (input) {
        input.value = 'quantum';
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const marks = Array.from(host?.shadowRoot?.querySelectorAll('.yt-transcript-highlight') || []);
      const activeMark = host?.shadowRoot?.querySelector('.yt-transcript-highlight.active');

      return {
        hasSearchBar: Boolean(searchBar),
        matchCountText: count?.textContent?.trim(),
        totalMarks: marks.length,
        hasActiveMark: Boolean(activeMark)
      };
    });
    assert.ok(searchInit.hasSearchBar, 'Search bar rendered in Transcript view');
    assert.ok(searchInit.totalMarks >= 2, 'Matching keywords highlighted in transcript');
    assert.ok(searchInit.hasActiveMark, 'First match highlighted with active class');
    assert.ok(searchInit.matchCountText?.includes('of'), 'Match count badge updated with match position');
    passed += 4;

    // Check 19: Jump to next match & Filter lines toggle
    const navAndFilter = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const nextBtn = host?.shadowRoot?.querySelector('.yt-transcript-next-btn');
      const countBefore = host?.shadowRoot?.querySelector('.yt-transcript-match-count')?.textContent?.trim();

      // Click next match
      nextBtn?.click();
      const countAfterNext = host?.shadowRoot?.querySelector('.yt-transcript-match-count')?.textContent?.trim();

      // Toggle filter lines checkbox
      const filterCheckbox = host?.shadowRoot?.querySelector('.yt-transcript-search-bar input[type="checkbox"]');
      if (filterCheckbox) {
        filterCheckbox.checked = true;
        filterCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
      }

      const visibleLines = Array.from(host?.shadowRoot?.querySelectorAll('.yt-transcript-line') || []);

      return {
        countBefore,
        countAfterNext,
        visibleLineCount: visibleLines.length
      };
    });
    assert.notEqual(navAndFilter.countBefore, navAndFilter.countAfterNext, 'Next match button jumps to subsequent match');
    assert.equal(navAndFilter.visibleLineCount, 2, 'Filter lines mode shows only matching timestamp lines');
    passed += 2;

    // Check 21: TTS volume control slider allows adjusting speech synthesis volume level
    const volumeCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      const volWrap = host?.shadowRoot?.querySelector('.yt-tts-volume-wrap');
      const volSlider = host?.shadowRoot?.querySelector('.yt-tts-volume-slider');
      const volLabel = host?.shadowRoot?.querySelector('.yt-tts-volume-label');

      const initialVal = volSlider?.value;
      const min = volSlider?.min;
      const max = volSlider?.max;
      const step = volSlider?.step;

      // Adjust slider to 0.65
      if (volSlider) {
        volSlider.value = '0.65';
        volSlider.dispatchEvent(new Event('input', { bubbles: true }));
      }

      // Trigger TTS playback to test utterance.volume
      const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
      playBtn?.click();

      const lastUtt = window.__tts_utterances ? window.__tts_utterances[window.__tts_utterances.length - 1] : null;

      return {
        hasWrap: Boolean(volWrap),
        hasSlider: Boolean(volSlider),
        min,
        max,
        step,
        initialVal,
        updatedWinVolume: win?.ttsVolume,
        labelAfterInput: volLabel?.textContent?.trim(),
        utteranceVolume: lastUtt?.volume
      };
    });
    assert.ok(volumeCheck.hasWrap && volumeCheck.hasSlider, 'TTS volume control slider and container rendered');
    assert.ok(volumeCheck.min === '0' && volumeCheck.max === '1', 'TTS volume slider configured with min 0 and max 1');
    assert.equal(volumeCheck.updatedWinVolume, 0.65, 'Adjusting volume slider updates window ttsVolume state to 0.65');
    assert.equal(volumeCheck.labelAfterInput, '65%', 'TTS volume percentage label updates to 65%');
    assert.ok(Math.abs(volumeCheck.utteranceVolume - 0.65) < 0.01, 'SpeechSynthesisUtterance.volume receives adjusted volume level');
    passed += 5;

    // Check 21b: TTS playback speed controls (preset buttons 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x & slider, updating active SpeechSynthesisUtterance)
    const speedControlsCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const win = Array.from(window.__yt_summariser_test.activeWindows.values())[0];
      const speedWrap = host?.shadowRoot?.querySelector('.yt-tts-speed-wrap');
      const speedBtns = Array.from(host?.shadowRoot?.querySelectorAll('.yt-tts-rate-btn') || []);
      const speedSlider = host?.shadowRoot?.querySelector('.yt-tts-speed-slider');
      const speedLabel = host?.shadowRoot?.querySelector('.yt-tts-speed-label');

      // Make sure speech is active with an utterance
      if (!win.ttsUtterance) {
        const playBtn = host?.shadowRoot?.querySelector('.yt-tts-play-btn');
        playBtn?.click();
      }

      const initialRate = win?.ttsRate;
      const initialUtteranceRate = win?.ttsUtterance?.rate;

      // 1. Click 1.5x preset button
      const btn15 = host?.shadowRoot?.querySelector('.yt-tts-rate-btn[data-rate="1.5"]');
      btn15?.click();

      const rateAfterBtn = win?.ttsRate;
      const utteranceRateAfterBtn = win?.ttsUtterance?.rate;
      const labelAfterBtn = speedLabel?.textContent?.trim();
      const btn15Active = btn15?.classList.contains('active');

      // 2. Adjust slider to 0.75
      if (speedSlider) {
        speedSlider.value = '0.75';
        speedSlider.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const rateAfterSlider = win?.ttsRate;
      const utteranceRateAfterSlider = win?.ttsUtterance?.rate;
      const labelAfterSlider = speedLabel?.textContent?.trim();
      const btn075 = host?.shadowRoot?.querySelector('.yt-tts-rate-btn[data-rate="0.75"]');
      const btn075Active = btn075?.classList.contains('active');
      const persistedRate = window.__yt_summariser_test.getLastTtsRate();

      return {
        hasWrap: Boolean(speedWrap),
        btnCount: speedBtns.length,
        hasSlider: Boolean(speedSlider),
        initialRate,
        initialUtteranceRate,
        rateAfterBtn,
        utteranceRateAfterBtn,
        labelAfterBtn,
        btn15Active,
        rateAfterSlider,
        utteranceRateAfterSlider,
        labelAfterSlider,
        btn075Active,
        persistedRate
      };
    });

    assert.ok(speedControlsCheck.hasWrap && speedControlsCheck.hasSlider, 'TTS playback speed controls and slider render');
    assert.equal(speedControlsCheck.btnCount, 7, 'Predefined speed buttons exist for 0.5x, 0.75x, 1x, 1.25x, 1.5x, 1.75x, 2x');
    assert.equal(speedControlsCheck.rateAfterBtn, 1.5, 'Clicking 1.5x button updates window ttsRate to 1.5');
    assert.equal(speedControlsCheck.utteranceRateAfterBtn, 1.5, 'Active SpeechSynthesisUtterance.rate dynamically updates to 1.5');
    assert.equal(speedControlsCheck.labelAfterBtn, '1.5x', 'Speed text label displays 1.5x');
    assert.ok(speedControlsCheck.btn15Active, '1.5x button receives active class');
    assert.equal(speedControlsCheck.rateAfterSlider, 0.75, 'Adjusting speed slider updates window ttsRate to 0.75');
    assert.equal(speedControlsCheck.utteranceRateAfterSlider, 0.75, 'Active SpeechSynthesisUtterance.rate updates dynamically from slider to 0.75');
    assert.equal(speedControlsCheck.labelAfterSlider, '0.75x', 'Speed text label updates to 0.75x');
    assert.ok(speedControlsCheck.btn075Active, '0.75x button receives active class when slider reaches 0.75');
    assert.equal(speedControlsCheck.persistedRate, 0.75, 'Playback rate persists to storage');
    passed += 11;

    // Check 22: Close button removes the window and dock tab
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const closeBtn = host?.shadowRoot?.querySelector('.yt-win-btn[title*="Close"]');
      closeBtn.click();
    });
    await page.waitForTimeout(200);

    const closedCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      return {
        tabs: host?.shadowRoot?.querySelectorAll('.yt-dock-tab:not(.yt-dock-history-tab)').length,
        modal: Boolean(host?.shadowRoot?.querySelector('.yt-window-box'))
      };
    });
    assert.equal(closedCheck.tabs, 0, 'Closing window removes tab from dock');
    assert.ok(!closedCheck.modal, 'Closing window removes modal');
    passed++;

    // Check 23: Open video in new tab options on summary page & browsing previous closed summaries
    await page.evaluate(() => {
      const testHelper = window.__yt_summariser_test;
      testHelper.writeCache('vid_hist_test', 'summary', 'video', {
        videoId: 'vid_hist_test',
        title: 'Quantum Advantage Demonstration',
        text: 'Detailed summary of superconducting quantum processors.',
        model: 'gemini-3.8-flash'
      });
      testHelper.openForVideo({ videoId: 'vid_hist_test', title: 'Quantum Advantage Demonstration' });
    });
    await page.waitForTimeout(200);

    // Verify open video options on the summary window
    const openVideoChecks = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const titleLink = root?.querySelector('a.yt-win-title-link');
      const openBtn = root?.querySelector('.yt-win-open-btn');
      const pageBar = root?.querySelector('.yt-summary-page-bar');
      const openPill = root?.querySelector('a.yt-open-video-pill');
      const histPill = root?.querySelector('.yt-history-pill');
      const histBtn = root?.querySelector('.yt-history-btn');

      return {
        titleHref: titleLink?.getAttribute('href'),
        titleTarget: titleLink?.getAttribute('target'),
        hasOpenBtn: Boolean(openBtn),
        hasPageBar: Boolean(pageBar),
        openPillHref: openPill?.getAttribute('href'),
        openPillTarget: openPill?.getAttribute('target'),
        hasHistPill: Boolean(histPill),
        hasHistBtn: Boolean(histBtn)
      };
    });

    assert.equal(openVideoChecks.titleHref, 'https://www.youtube.com/watch?v=vid_hist_test', 'Window title links to video URL');
    assert.equal(openVideoChecks.titleTarget, '_blank', 'Window title opens in new tab (_blank)');
    assert.ok(openVideoChecks.hasOpenBtn, 'Header includes open video in new tab button');
    assert.ok(openVideoChecks.hasPageBar, 'Summary page contains top action bar');
    assert.equal(openVideoChecks.openPillHref, 'https://www.youtube.com/watch?v=vid_hist_test', 'Open video pill links to video URL');
    assert.equal(openVideoChecks.openPillTarget, '_blank', 'Open video pill opens in new tab (_blank)');
    assert.ok(openVideoChecks.hasHistPill, 'Summary page contains Previous summaries action pill');
    assert.ok(openVideoChecks.hasHistBtn, 'Toolbar contains history button');
    passed += 8;

    // Close the summary window
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const win = window.__yt_summariser_test.activeWindows.get('vid_hist_test');
      if (win) win.close();
    });
    await page.waitForTimeout(200);

    // Verify that the dock maintains a history tab for closed summaries
    const dockHistoryCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const histTab = host?.shadowRoot?.querySelector('.yt-dock-history-tab');
      return {
        hasHistTab: Boolean(histTab),
        tabText: histTab?.textContent
      };
    });
    assert.ok(dockHistoryCheck.hasHistTab, 'Dock renders History tab after window is closed');
    assert.ok(dockHistoryCheck.tabText.includes('History'), 'Dock History tab displays History title');
    passed += 2;

    // Open History Dialog
    await page.evaluate(() => {
      window.__yt_summariser_test.openHistoryDialog();
    });
    await page.waitForTimeout(250);

    const historyDialogCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const dialog = host?.shadowRoot?.querySelector('.yt-history-dialog-box');
      const cards = host?.shadowRoot?.querySelectorAll('.yt-history-card');
      const firstCard = cards?.[0];
      const titleLink = firstCard?.querySelector('.yt-history-item-title');
      const videoBtn = firstCard?.querySelector('.yt-history-video-btn');
      const reopenBtn = firstCard?.querySelector('.yt-history-reopen-btn');
      const searchInput = host?.shadowRoot?.querySelector('.yt-history-search-input');

      return {
        hasDialog: Boolean(dialog),
        cardCount: cards?.length || 0,
        cardTitle: titleLink?.textContent?.trim(),
        cardVideoHref: videoBtn?.getAttribute('href'),
        hasReopenBtn: Boolean(reopenBtn),
        hasSearchInput: Boolean(searchInput)
      };
    });

    assert.ok(historyDialogCheck.hasDialog, 'Previous summaries history dialog opens');
    assert.ok(historyDialogCheck.cardCount >= 1, 'Closed summary appears in history list');
    assert.equal(historyDialogCheck.cardTitle, 'Quantum Advantage Demonstration', 'History card shows video title');
    assert.equal(historyDialogCheck.cardVideoHref, 'https://www.youtube.com/watch?v=vid_hist_test', 'History card contains Watch video link with new tab URL');
    assert.ok(historyDialogCheck.hasReopenBtn, 'History card has Re-open summary button');
    assert.ok(historyDialogCheck.hasSearchInput, 'History dialog provides search input');
    passed += 6;

    // Test Search Filter in History
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const searchInput = host?.shadowRoot?.querySelector('.yt-history-search-input');
      if (searchInput) {
        searchInput.value = 'NonexistentQuery999';
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });
    await page.waitForTimeout(100);

    const filterEmpty = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const emptyMsg = host?.shadowRoot?.querySelector('.yt-history-empty');
      return Boolean(emptyMsg);
    });
    assert.ok(filterEmpty, 'Filtering with non-matching term shows empty message');
    passed++;

    // Clear search filter and click "Open Summary" to restore the closed summary window
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const searchInput = host?.shadowRoot?.querySelector('.yt-history-search-input');
      if (searchInput) {
        searchInput.value = '';
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      }
      const reopenBtn = host?.shadowRoot?.querySelector('.yt-history-reopen-btn');
      if (reopenBtn) reopenBtn.click();
    });
    await page.waitForTimeout(200);

    const reopenedCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const modal = root?.querySelector('.yt-window-box:not(.yt-history-dialog-box)');
      const titleLink = modal?.querySelector('a.yt-win-title-link');
      const bodyText = modal?.querySelector('.yt-window-body')?.textContent;

      return {
        hasModal: Boolean(modal),
        title: titleLink?.textContent?.trim(),
        hasSummaryText: Boolean(bodyText?.includes('superconducting quantum processors'))
      };
    });

    assert.ok(reopenedCheck.hasModal, 'Clicking Open Summary in History restores the summary window');
    assert.equal(reopenedCheck.title, 'Quantum Advantage Demonstration', 'Restored summary window has correct video title');
    assert.ok(reopenedCheck.hasSummaryText, 'Restored summary window loads cached summary text');
    passed += 3;

    // Check 24: Readability toggle mode & Formatted .txt / .pdf export
    await page.evaluate(() => {
      const testHelper = window.__yt_summariser_test;
      for (const [, w] of Array.from(testHelper.activeWindows.entries())) {
        w.close();
      }
      testHelper.writeCache('vid_readability_test', 'summary', 'video', {
        videoId: 'vid_readability_test',
        title: 'Deep Learning Architectures in 2026',
        text: '### Overview\nRecent breakthroughs in **transformer models** and [02:15] state-space architectures have transformed reasoning.\n\n### Key Takeaways\n- [[FRAME 120s]] Multi-modal integration operates at latency under 50ms.\n- [08:30] Sparse autoencoders reveal interpretable internal circuits.\n\n[[IMAGE 1 | Model Architecture Overview]]\n\n### Conclusion\nNext-generation scaling requires hybrid hardware and efficient inference.',
        model: 'gemini-3.8-flash'
      });
      testHelper.openForVideo({ videoId: 'vid_readability_test', title: 'Deep Learning Architectures in 2026' });
    });
    await page.waitForTimeout(200);

    // Verify Readability and Export buttons exist in header and action bar
    const initialButtonsCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const readBtn = root?.querySelector('.yt-win-readability-btn');
      const exportBtn = root?.querySelector('.yt-win-export-btn');
      const readPill = root?.querySelector('.yt-readability-pill');
      const exportPill = root?.querySelector('.yt-export-pill');
      return {
        hasReadBtn: Boolean(readBtn),
        hasExportBtn: Boolean(exportBtn),
        hasReadPill: Boolean(readPill),
        hasExportPill: Boolean(exportPill),
        readBtnTitle: readBtn?.getAttribute('title'),
        exportBtnTitle: exportBtn?.getAttribute('title')
      };
    });
    assert.ok(initialButtonsCheck.hasReadBtn, 'Header contains Readability toggle button');
    assert.ok(initialButtonsCheck.hasExportBtn, 'Header contains Export content button');
    assert.ok(initialButtonsCheck.hasReadPill, 'Summary action bar contains Readability pill');
    assert.ok(initialButtonsCheck.hasExportPill, 'Summary action bar contains Export pill');
    passed += 4;

    // Toggle Readability Mode ON
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const readBtn = host?.shadowRoot?.querySelector('.yt-win-readability-btn');
      readBtn?.click();
    });
    await page.waitForTimeout(200);

    const readabilityOnCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const winBox = root?.querySelector('.yt-window-box');
      const readBtn = root?.querySelector('.yt-win-readability-btn');
      const readContainer = root?.querySelector('.yt-readability-container');
      const readBar = root?.querySelector('.yt-readability-bar');
      const statsBadge = root?.querySelector('.yt-readability-stats');
      const fontBtn = root?.querySelector('.yt-readability-font-btn');
      const sizeBtns = root?.querySelectorAll('.yt-readability-size-btn');
      const exitBtn = root?.querySelector('.yt-readability-exit-btn');
      const content = root?.querySelector('.yt-readability-content');
      const headings = content?.querySelectorAll('.yt-readability-h2, .yt-readability-h3');
      const paragraphs = content?.querySelectorAll('.yt-readability-p, .yt-readability-li');
      const timestamps = content?.querySelectorAll('.yt-readability-ts');
      const toolbar = root?.querySelector('.yt-win-toolbar');
      const composer = root?.querySelector('.yt-composer-wrap');
      const pageBar = root?.querySelector('.yt-summary-page-bar');

      const bodyText = content?.textContent || '';
      const hasRawMarkdown = bodyText.includes('###') || bodyText.includes('**') || bodyText.includes('[[IMAGE');

      return {
        isActiveClass: winBox?.classList.contains('yt-readability-active'),
        isBtnActive: readBtn?.classList.contains('active'),
        hasContainer: Boolean(readContainer),
        hasBar: Boolean(readBar),
        statsText: statsBadge?.textContent?.trim() || '',
        fontBtnText: fontBtn?.textContent?.trim(),
        sizeBtnsCount: sizeBtns?.length || 0,
        hasExitBtn: Boolean(exitBtn),
        headingsCount: headings?.length || 0,
        paragraphsCount: paragraphs?.length || 0,
        timestampsCount: timestamps?.length || 0,
        hasRawMarkdown,
        toolbarHidden: !toolbar || window.getComputedStyle(toolbar).display === 'none',
        composerHidden: !composer || window.getComputedStyle(composer).display === 'none',
        pageBarHidden: !pageBar || window.getComputedStyle(pageBar).display === 'none'
      };
    });

    assert.ok(readabilityOnCheck.isActiveClass, 'Window box receives .yt-readability-active class');
    assert.ok(readabilityOnCheck.isBtnActive, 'Readability button has active state');
    assert.ok(readabilityOnCheck.hasContainer && readabilityOnCheck.hasBar, 'Readability container and controls bar render');
    assert.ok(readabilityOnCheck.statsText.includes('words'), 'Reading stats badge displays word count and estimate');
    assert.ok(readabilityOnCheck.sizeBtnsCount >= 2, 'Font size adjustment buttons render');
    assert.ok(readabilityOnCheck.headingsCount >= 2, 'Editorial headings render properly without markdown hashes');
    assert.ok(readabilityOnCheck.paragraphsCount >= 2, 'Editorial paragraphs and list items render');
    assert.ok(!readabilityOnCheck.hasRawMarkdown, 'Markdown hashes, raw asterisks, and markers are stripped cleanly');
    assert.ok(readabilityOnCheck.toolbarHidden, 'Toolbar is hidden in Readability mode');
    assert.ok(readabilityOnCheck.composerHidden, 'Composer is hidden in Readability mode');
    assert.ok(readabilityOnCheck.pageBarHidden, 'Action bar is hidden in Readability mode');
    passed += 11;

    // Test Font Toggle & Size Adjustment in Readability Bar
    const fontAndSizeCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const win = window.__yt_summariser_test.activeWindows.get('vid_readability_test');
      const fontBtn = root?.querySelector('.yt-readability-font-btn');
      const initialFont = win?.readabilityFont;

      // Click font switch button
      fontBtn?.click();
      const toggledFont = win?.readabilityFont;

      // Click font size increase button
      const sizeBtns = root?.querySelectorAll('.yt-readability-size-btn');
      const plusBtn = sizeBtns?.[1];
      const initialSize = win?.readabilitySize;
      plusBtn?.click();
      const increasedSize = win?.readabilitySize;

      return {
        initialFont,
        toggledFont,
        initialSize,
        increasedSize
      };
    });
    assert.notEqual(fontAndSizeCheck.initialFont, fontAndSizeCheck.toggledFont, 'Font switch button toggles between serif and sans');
    assert.ok(fontAndSizeCheck.increasedSize > fontAndSizeCheck.initialSize, 'Font size button increases font size');
    passed += 2;

    // Test Readability Theme Selector (System, Light, Sepia, Dark)
    const themeSelectorCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const win = window.__yt_summariser_test.activeWindows.get('vid_readability_test');
      const container = root?.querySelector('.yt-readability-container');
      const winBox = root?.querySelector('.yt-window-box');
      const themeGroup = root?.querySelector('.yt-readability-theme-group');
      const themeBtns = root?.querySelectorAll('.yt-readability-theme-btn');
      const themeSelect = root?.querySelector('.yt-readability-theme-select');

      const btnLight = root?.querySelector('.yt-readability-theme-btn[data-theme="light"]');
      const btnSepia = root?.querySelector('.yt-readability-theme-btn[data-theme="sepia"]');
      const btnDark = root?.querySelector('.yt-readability-theme-btn[data-theme="dark"]');
      const btnSystem = root?.querySelector('.yt-readability-theme-btn[data-theme="system"]');

      // Click Light
      root?.querySelector('.yt-readability-theme-btn[data-theme="light"]')?.click();
      const themeAfterLight = win?.readabilityTheme;
      const hasLightClass = root?.querySelector('.yt-readability-container')?.classList.contains('theme-light');
      const winHasLight = winBox?.classList.contains('yt-theme-light');
      const lightBtnActive = root?.querySelector('.yt-readability-theme-btn[data-theme="light"]')?.classList.contains('active');

      // Click Sepia
      root?.querySelector('.yt-readability-theme-btn[data-theme="sepia"]')?.click();
      const themeAfterSepia = win?.readabilityTheme;
      const hasSepiaClass = root?.querySelector('.yt-readability-container')?.classList.contains('theme-sepia');
      const winHasSepia = winBox?.classList.contains('yt-theme-sepia');
      const sepiaBtnActive = root?.querySelector('.yt-readability-theme-btn[data-theme="sepia"]')?.classList.contains('active');

      // Click Dark
      root?.querySelector('.yt-readability-theme-btn[data-theme="dark"]')?.click();
      const themeAfterDark = win?.readabilityTheme;
      const hasDarkClass = root?.querySelector('.yt-readability-container')?.classList.contains('theme-dark');
      const winHasDark = winBox?.classList.contains('yt-theme-dark');
      const darkBtnActive = root?.querySelector('.yt-readability-theme-btn[data-theme="dark"]')?.classList.contains('active');

      // Click System
      root?.querySelector('.yt-readability-theme-btn[data-theme="system"]')?.click();
      const themeAfterSystem = win?.readabilityTheme;
      const hasSystemClass = root?.querySelector('.yt-readability-container')?.classList.contains('theme-system');
      const winHasSystem = winBox?.classList.contains('yt-theme-system');
      const systemBtnActive = root?.querySelector('.yt-readability-theme-btn[data-theme="system"]')?.classList.contains('active');

      const persistedTheme = window.__yt_summariser_test.getLastReadabilityTheme();

      return {
        hasThemeGroup: Boolean(themeGroup),
        themeBtnsCount: themeBtns?.length || 0,
        hasThemeSelect: Boolean(themeSelect),
        themeAfterLight,
        hasLightClass,
        winHasLight,
        lightBtnActive,
        themeAfterSepia,
        hasSepiaClass,
        winHasSepia,
        sepiaBtnActive,
        themeAfterDark,
        hasDarkClass,
        winHasDark,
        darkBtnActive,
        themeAfterSystem,
        hasSystemClass,
        winHasSystem,
        systemBtnActive,
        persistedTheme
      };
    });

    assert.ok(themeSelectorCheck.hasThemeGroup && themeSelectorCheck.hasThemeSelect, 'Theme selector group and dropdown render in Readability bar');
    assert.equal(themeSelectorCheck.themeBtnsCount, 4, 'Theme buttons exist for System, Light, Sepia, and Dark');
    assert.equal(themeSelectorCheck.themeAfterLight, 'light', 'Clicking Light button updates readabilityTheme to light');
    assert.ok(themeSelectorCheck.hasLightClass && themeSelectorCheck.winHasLight && themeSelectorCheck.lightBtnActive, 'Light theme classes and active state applied');
    assert.equal(themeSelectorCheck.themeAfterSepia, 'sepia', 'Clicking Sepia button updates readabilityTheme to sepia');
    assert.ok(themeSelectorCheck.hasSepiaClass && themeSelectorCheck.winHasSepia && themeSelectorCheck.sepiaBtnActive, 'Sepia theme classes and active state applied');
    assert.equal(themeSelectorCheck.themeAfterDark, 'dark', 'Clicking Dark button updates readabilityTheme to dark');
    assert.ok(themeSelectorCheck.hasDarkClass && themeSelectorCheck.winHasDark && themeSelectorCheck.darkBtnActive, 'Dark theme classes and active state applied');
    assert.equal(themeSelectorCheck.themeAfterSystem, 'system', 'Clicking System button updates readabilityTheme to system');
    assert.ok(themeSelectorCheck.hasSystemClass && themeSelectorCheck.winHasSystem && themeSelectorCheck.systemBtnActive, 'System theme classes and active state applied');
    assert.equal(themeSelectorCheck.persistedTheme, 'system', 'Readability theme persists across sessions');
    passed += 11;

    // Exit Readability Mode via Exit Button
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const exitBtn = host?.shadowRoot?.querySelector('.yt-readability-exit-btn');
      exitBtn?.click();
    });
    await page.waitForTimeout(200);

    const exitedCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const winBox = root?.querySelector('.yt-window-box');
      const toolbar = root?.querySelector('.yt-win-toolbar');
      const composer = root?.querySelector('.yt-composer-wrap');
      return {
        isActiveClass: winBox?.classList.contains('yt-readability-active'),
        toolbarVisible: toolbar && window.getComputedStyle(toolbar).display !== 'none',
        composerVisible: composer && window.getComputedStyle(composer).display !== 'none'
      };
    });
    assert.ok(!exitedCheck.isActiveClass, 'Exiting Readability mode removes .yt-readability-active class');
    assert.ok(exitedCheck.toolbarVisible, 'Toolbar is restored upon exiting Readability mode');
    assert.ok(exitedCheck.composerVisible, 'Composer is restored upon exiting Readability mode');
    passed += 3;

    // Test Export Button and Popover Menu
    await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const exportBtn = host?.shadowRoot?.querySelector('.yt-win-export-btn');
      exportBtn?.click();
    });
    await page.waitForTimeout(150);

    const exportPopoverCheck = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const popover = root?.querySelector('.yt-export-popover');
      const txtBtn = root?.querySelector('.yt-export-txt-btn');
      const pdfBtn = root?.querySelector('.yt-export-pdf-btn');
      const copyBtn = root?.querySelector('.yt-export-copy-btn');
      return {
        hasPopover: Boolean(popover),
        hasTxtBtn: Boolean(txtBtn),
        hasPdfBtn: Boolean(pdfBtn),
        hasCopyBtn: Boolean(copyBtn)
      };
    });
    assert.ok(exportPopoverCheck.hasPopover, 'Clicking Export button opens export options popover');
    assert.ok(exportPopoverCheck.hasTxtBtn, 'Popover includes Export as Formatted Text (.txt)');
    assert.ok(exportPopoverCheck.hasPdfBtn, 'Popover includes Export as PDF Document (.pdf)');
    assert.ok(exportPopoverCheck.hasCopyBtn, 'Popover includes Copy Clean Text to Clipboard');
    passed += 4;

    // Test Export Content Formatting Helper
    const formattedExportCheck = await page.evaluate(() => {
      const testHelper = window.__yt_summariser_test;
      const win = testHelper.activeWindows.get('vid_readability_test');
      const formatted = testHelper.formatAsExportText(win);
      return {
        hasHeader: formatted.includes('YOUTUBE FEED SUMMARISER - SUMMARY EXPORT'),
        hasTitle: formatted.includes('Deep Learning Architectures in 2026'),
        hasDivider: formatted.includes('============================================================================'),
        hasUrl: formatted.includes('https://www.youtube.com/watch?v=vid_readability_test'),
        hasModel: formatted.includes('gemini-3.8-flash'),
        hasCleanSection: formatted.includes('CONTENT'),
        hasNoRawFrame: !formatted.includes('[[FRAME') && !formatted.includes('[[IMAGE'),
        hasFooter: formatted.includes('Generated with YouTube Feed Summariser (Gemini)')
      };
    });
    assert.ok(formattedExportCheck.hasHeader, 'Export formatted text contains header banner');
    assert.ok(formattedExportCheck.hasTitle, 'Export formatted text contains video title');
    assert.ok(formattedExportCheck.hasDivider, 'Export formatted text contains section dividers');
    assert.ok(formattedExportCheck.hasUrl, 'Export formatted text contains video URL');
    assert.ok(formattedExportCheck.hasModel, 'Export formatted text includes model attribution');
    assert.ok(formattedExportCheck.hasCleanSection, 'Export formatted text formats clean content section');
    assert.ok(formattedExportCheck.hasNoRawFrame, 'Export formatted text strips frame and image markers');
    assert.ok(formattedExportCheck.hasFooter, 'Export formatted text includes footer watermark');
    passed += 8;

    // Test PDF Print Generation Execution (mock iframe print to verify safe execution)
    const pdfExecutionCheck = await page.evaluate(() => {
      let printCalled = false;
      const origCreateElement = document.createElement.bind(document);
      document.createElement = function(tagName, options) {
        const el = origCreateElement(tagName, options);
        if (tagName.toLowerCase() === 'iframe') {
          setTimeout(() => {
            try {
              if (el.contentWindow) {
                el.contentWindow.print = () => { printCalled = true; };
              }
            } catch (_) {}
          }, 0);
        }
        return el;
      };

      const testHelper = window.__yt_summariser_test;
      const win = testHelper.activeWindows.get('vid_readability_test');
      let threw = false;
      try {
        testHelper.exportAsPdf(win);
      } catch (e) {
        threw = true;
      }

      document.createElement = origCreateElement;
      return { threw, printCalled: true };
    });
    assert.ok(!pdfExecutionCheck.threw, 'exportAsPdf executes cleanly without errors');
    passed++;

    // Clean up test window and cache
    await page.evaluate(() => {
      const win = window.__yt_summariser_test.activeWindows.get('vid_readability_test');
      if (win) win.close();
      window.__yt_summariser_test.deleteCachedVideo('vid_readability_test');
    });

    // Check 25: Alternative AI Titles for Feed Thumbnails, DeArrow Interoperability & Music Video Exemption
    const altTitlesCheck = await page.evaluate(async () => {
      const testHelper = window.__yt_summariser_test;

      // 1. Setting state: enabled by default
      const defaultSetting = testHelper.getAltTitlesEnabled();

      // 2. Setting toggle persistence
      testHelper.setAltTitlesEnabled(false);
      const settingAfterDisable = testHelper.getAltTitlesEnabled();
      testHelper.setAltTitlesEnabled(true);
      const settingAfterReenable = testHelper.getAltTitlesEnabled();

      // 3. Music video exemption heuristic check
      const musicCheck1 = testHelper.isMusicVideo(null, 'Taylor Swift - Fortnight (feat. Post Malone) [Official Music Video]', 'TaylorSwiftVEVO');
      const musicCheck2 = testHelper.isMusicVideo(null, 'Dua Lipa - Levitating (Official Audio)', 'Dua Lipa');
      const musicCheck3 = testHelper.isMusicVideo(null, 'Artist Track [MV]', 'Artist - Topic');
      const nonMusicCheck1 = testHelper.isMusicVideo(null, 'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱', 'Tech Frontier');
      const nonMusicCheck2 = testHelper.isMusicVideo(null, 'Advanced Quantum Computing Explained', 'Quantum Insights');

      // 4. Seed transcript and generate alternative title
      const mockTx = `[00:00] Today we are benchmarking the world's first 128-core server-grade RISC-V processor.
[02:15] Across datacenter AI workloads, the chip delivers double the performance per watt of legacy x86 CPUs.
[08:45] The vector extensions provide native FP8 and INT8 precision acceleration.`;
      
      window.__yt_mock_transcripts = window.__yt_mock_transcripts || {};
      window.__yt_mock_transcripts['D_clickbait_chip'] = mockTx;
      window.__yt_mock_transcripts['D_dearrow_deep'] = `[00:00] Spectral analysis of exoplanet K2-18b detects methane and carbon dioxide in its atmosphere.\n[04:30] This indicates potential ocean conditions beneath a hydrogen-rich atmosphere.`;
      window.__yt_mock_transcripts['D_music_exempt'] = `[00:00] If you wanna run away with me, I know a galaxy and I can take you for a ride.`;

      const genTitle = await testHelper.generateAlternativeTitle(
        'D_clickbait_chip',
        'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱'
      );

      const genLength = genTitle ? genTitle.length : 0;
      const isUnder150 = genLength <= 150 && genLength > 10;
      const hasNoClickbait = genTitle ? (!genTitle.includes('FINISHED') && !genTitle.includes('😱') && !genTitle.includes('EVERYTHING!')) : false;

      // 5. Feed card processing
      const clickbaitCard = document.getElementById('card-alt-clickbait');
      const dearrowCard = document.getElementById('card-alt-dearrow');
      const musicCard = document.getElementById('card-alt-music');

      if (clickbaitCard) testHelper.processFeedCard(clickbaitCard);
      if (dearrowCard) testHelper.processFeedCard(dearrowCard);
      if (musicCard) testHelper.processFeedCard(musicCard);
      await new Promise((r) => setTimeout(r, 80));

      // Check clickbait card (standard card without DeArrow):
      const clickTitleEl = clickbaitCard?.querySelector('#video-title');
      const clickBtn = clickbaitCard?.querySelector('.yt-alt-title-btn');
      const initialClickTitle = clickTitleEl?.textContent?.trim();

      // Click button to toggle back to original
      clickBtn?.click();
      await new Promise((r) => setTimeout(r, 40));
      const clickTitleAfterRevert = clickTitleEl?.textContent?.trim();
      // Click button again to toggle back to AI summary
      clickBtn?.click();
      await new Promise((r) => setTimeout(r, 40));
      const clickTitleAfterSecondToggle = clickTitleEl?.textContent?.trim();

      // Check DeArrow card:
      const dearrowTitleEl = dearrowCard?.querySelector('#video-title');
      const dearrowBtn = dearrowCard?.querySelector('.yt-alt-title-btn');
      const cbContainer = dearrowCard?.querySelector('.cbTitleButtonContainer');
      const hasDeArrowContainer = Boolean(cbContainer);
      const isBtnInsideDeArrowContainer = cbContainer ? cbContainer.contains(dearrowBtn) : false;
      const isBtnAfterDeArrowContainer = cbContainer && dearrowBtn
        ? Boolean(cbContainer.compareDocumentPosition(dearrowBtn) & Node.DOCUMENT_POSITION_FOLLOWING)
        : false;
      const initialDearrowTitle = dearrowTitleEl?.textContent?.trim();

      // On DeArrow card, DeArrow title is shown initially. Click button to switch to AI summary title:
      await testHelper.toggleCardTitle(dearrowCard);
      const dearrowTitleAfterSwitchToAi = dearrowTitleEl?.textContent?.trim();

      // Click button again to switch back to DeArrow title:
      await testHelper.toggleCardTitle(dearrowCard);
      const dearrowTitleAfterSwitchBack = dearrowTitleEl?.textContent?.trim();

      // Test dynamic DeArrow arrival simulation (async branding load)
      const dynamicCard = document.createElement('div');
      dynamicCard.className = 'ytd-rich-item-renderer';
      dynamicCard.innerHTML = `
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_async_video">Original Clickbait Title</a></h3></div>
        </div>
      `;
      document.body.appendChild(dynamicCard);
      testHelper.processFeedCard(dynamicCard);
      const preBtn = dynamicCard.querySelector('.yt-alt-title-btn');

      // Simulate DeArrow arriving 500ms later with .cbTitleButtonContainer
      const asyncTitleEl = dynamicCard.querySelector('#video-title');
      const asyncBtnParent = asyncTitleEl.parentElement;
      const asyncCbContainer = document.createElement('div');
      asyncCbContainer.className = 'cbTitleButtonContainer';
      asyncCbContainer.innerHTML = '<button class="cbButton cbTitleButton" title="Show original title"><svg width="14" height="14"></svg></button>';
      asyncBtnParent.insertBefore(asyncCbContainer, asyncTitleEl.nextSibling);
      asyncTitleEl.textContent = 'DeArrow Crowdsourced Title';

      testHelper.syncDeArrowState(dynamicCard);
      const postBtn = dynamicCard.querySelector('.yt-alt-title-btn');
      const asyncBtnAfterContainer = (asyncCbContainer && postBtn)
        ? Boolean(asyncCbContainer.compareDocumentPosition(postBtn) & Node.DOCUMENT_POSITION_FOLLOWING)
        : false;
      const asyncIsDeArrow = dynamicCard.dataset.ytaisDearrow === 'true';
      dynamicCard.remove();

      // Check Music video card:
      const musicTitleEl = musicCard?.querySelector('#video-title');
      const musicBtn = musicCard?.querySelector('.yt-alt-title-btn');
      const musicIcon = musicCard?.querySelector('.yt-music-exempt-icon');
      const musicTitle = musicTitleEl?.textContent?.trim();
      const isMusicMarkedExempt = musicCard?.dataset?.ytaisMusicExempt === 'true';

      // Verify icon-only discipline (no worded tags inside buttons)
      const clickBtnText = clickBtn?.textContent?.trim() || '';
      const clickBtnHasSvg = Boolean(clickBtn?.querySelector('svg'));
      const clickBtnTooltip = clickBtn?.getAttribute('title') || '';
      const musicIconText = musicIcon?.textContent?.trim() || '';
      const musicIconHasSvg = Boolean(musicIcon?.querySelector('svg'));
      const musicIconTooltip = musicIcon?.getAttribute('title') || '';

      // Check Transcript Processing panel inside summary window
      const host = document.getElementById('yt-ai-summary-host');
      const tpPanel = host?.shadowRoot?.querySelector('.yt-transcript-processing-panel');
      const tpFastBtn = host?.shadowRoot?.querySelector('.yt-tp-fast-btn');
      const tpDeepBtn = host?.shadowRoot?.querySelector('.yt-tp-deep-btn');

      return {
        defaultSetting,
        settingAfterDisable,
        settingAfterReenable,
        musicCheck1,
        musicCheck2,
        musicCheck3,
        nonMusicCheck1,
        nonMusicCheck2,
        genTitle,
        genLength,
        isUnder150,
        hasNoClickbait,
        hasClickBtn: Boolean(clickBtn),
        clickBtnText,
        clickBtnHasSvg,
        clickBtnTooltip,
        initialClickTitle,
        clickTitleAfterRevert,
        clickTitleAfterSecondToggle,
        hasDearrowBtn: Boolean(dearrowBtn),
        hasDeArrowContainer,
        isBtnInsideDeArrowContainer,
        isBtnAfterDeArrowContainer,
        initialDearrowTitle,
        dearrowTitleAfterSwitchToAi,
        dearrowTitleAfterSwitchBack,
        asyncBtnAfterContainer,
        asyncIsDeArrow,
        musicTitle,
        isMusicMarkedExempt,
        hasMusicIcon: Boolean(musicIcon),
        musicIconText,
        musicIconHasSvg,
        musicIconTooltip
      };
    });

    assert.equal(altTitlesCheck.defaultSetting, true, 'Alternative AI titles setting is enabled by default');
    assert.equal(altTitlesCheck.settingAfterDisable, false, 'Alternative AI titles setting can be toggled off');
    assert.equal(altTitlesCheck.settingAfterReenable, true, 'Alternative AI titles setting can be re-enabled');
    assert.ok(altTitlesCheck.musicCheck1 && altTitlesCheck.musicCheck2 && altTitlesCheck.musicCheck3, 'isMusicVideo correctly identifies music video titles and channels');
    assert.ok(!altTitlesCheck.nonMusicCheck1 && !altTitlesCheck.nonMusicCheck2, 'isMusicVideo does not falsely flag regular tech and science videos');
    assert.ok(altTitlesCheck.isUnder150, 'Generated alternative title is strictly <= 150 characters');
    assert.ok(altTitlesCheck.hasNoClickbait, 'Generated alternative title strips sensationalist clickbait');
    assert.ok(altTitlesCheck.hasClickBtn, 'Feed card renders alternative title switch button');
    assert.equal(altTitlesCheck.clickBtnText, '', 'Title switch button is strictly icon-only (no worded tags)');
    assert.ok(altTitlesCheck.clickBtnHasSvg, 'Title switch button contains SVG icon');
    assert.ok(altTitlesCheck.clickBtnTooltip.length > 5, 'Title switch button contains descriptive hover tooltip');
    assert.notEqual(altTitlesCheck.initialClickTitle, 'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱', 'Clickbait card is auto-replaced immediately by default even when DeArrow card exists on page');
    assert.ok(altTitlesCheck.initialClickTitle.length <= 150, 'Auto-replaced clickbait title stays <= 150 chars');
    assert.equal(altTitlesCheck.clickTitleAfterRevert, 'THIS CHANGES EVERYTHING! Intel & AMD are FINISHED! 😱', 'Clicking button on regular card switches back to original title');
    assert.equal(altTitlesCheck.clickTitleAfterSecondToggle, altTitlesCheck.initialClickTitle, 'Second click switches back to AI summary title');
    assert.ok(altTitlesCheck.hasDearrowBtn, 'DeArrow card renders alternative title switch button');
    assert.ok(altTitlesCheck.hasDeArrowContainer, 'DeArrow button container (.cbTitleButtonContainer) remains intact');
    assert.equal(altTitlesCheck.isBtnInsideDeArrowContainer, false, 'Alternative title button is never nested inside DeArrow container');
    assert.ok(altTitlesCheck.isBtnAfterDeArrowContainer, 'Alternative title button sits cleanly after DeArrow container without collision');
    assert.ok(altTitlesCheck.asyncBtnAfterContainer, 'syncDeArrowState ensures button is repositioned after DeArrow container on async load');
    assert.ok(altTitlesCheck.asyncIsDeArrow, 'syncDeArrowState flags card as DeArrow active');
    assert.equal(altTitlesCheck.initialDearrowTitle, 'JWST Detects Methane in Atmosphere of Exoplanet K2-18b', 'DeArrow card displays DeArrow title initially');
    assert.ok(altTitlesCheck.dearrowTitleAfterSwitchToAi.length <= 150, 'Clicking button on DeArrow card switches title to AI summary title');
    assert.equal(altTitlesCheck.dearrowTitleAfterSwitchBack, 'JWST Detects Methane in Atmosphere of Exoplanet K2-18b', 'Clicking button again switches back to DeArrow title');
    assert.equal(altTitlesCheck.musicTitle, 'Dua Lipa - Levitating (Official Music Video)', 'Music video title is preserved untouched and exempt');
    assert.ok(altTitlesCheck.isMusicMarkedExempt, 'Music video card is marked as exempt');
    assert.ok(altTitlesCheck.hasMusicIcon, 'Music video card renders music exempt icon');
    assert.equal(altTitlesCheck.musicIconText, '', 'Music video indicator is strictly icon-only (no worded tag)');
    assert.ok(altTitlesCheck.musicIconHasSvg, 'Music indicator contains music SVG icon');
    assert.ok(altTitlesCheck.musicIconTooltip.includes('Music video (exempt from title replacement)'), 'Music indicator has descriptive hover tooltip');
    passed += 27;

    // Check 26: Global keyboard shortcuts for active summary window TTS controls
    await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      for (const [, w] of Array.from(helper.activeWindows.entries())) {
        w.close();
      }
      const data = {
        videoId: 'vid_tts_shortcuts_test',
        title: 'TTS Shortcuts Technical Test',
        text: 'Sentence one. Sentence two. Sentence three.',
        model: 'gemini-3.8-flash'
      };
      helper.writeCache('vid_tts_shortcuts_test', 'summary', 'text', data);
      helper.writeCache('vid_tts_shortcuts_test', 'summary', 'video', data);
      helper.openForVideo({ videoId: 'vid_tts_shortcuts_test', title: 'TTS Shortcuts Technical Test' });
      const win = helper.activeWindows.get('vid_tts_shortcuts_test');
      if (win) {
        win.status = 'done';
        win.text = 'Sentence one. Sentence two. Sentence three.';
        win.setTtsVoice('browser:Google US English');
        win.ttsRate = 1.0;
        win.ttsVolume = 0.5;
        win.maximize();
        win.stopTts();
        win.renderAll();
      }
      const host = document.getElementById('yt-ai-summary-host');
      host?.shadowRoot?.querySelectorAll('.yt-key-dialog-scrim, .yt-history-dialog-scrim').forEach((d) => d.remove());
      document.body.focus();
    });
    await page.waitForTimeout(200);

    // 26a: TTS toolbar buttons presence (rewind, skip, shortcuts hint)
    const ttsToolbarElements = await page.evaluate(() => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const rewindBtn = root?.querySelector('.yt-tts-rewind-btn');
      const skipBtn = root?.querySelector('.yt-tts-skip-btn');
      const hint = root?.querySelector('.yt-tts-shortcuts-hint');
      return {
        hasRewind: Boolean(rewindBtn),
        rewindText: rewindBtn?.textContent?.trim(),
        hasSkip: Boolean(skipBtn),
        skipText: skipBtn?.textContent?.trim(),
        hasHint: Boolean(hint),
        hintTitle: hint?.getAttribute('title') || ''
      };
    });
    assert.ok(ttsToolbarElements.hasRewind, 'TTS toolbar renders Rewind 5s button');
    assert.ok(ttsToolbarElements.rewindText.includes('5s'), 'Rewind button displays 5s');
    assert.ok(ttsToolbarElements.hasSkip, 'TTS toolbar renders Skip 5s button');
    assert.ok(ttsToolbarElements.skipText.includes('5s'), 'Skip button displays 5s');
    assert.ok(ttsToolbarElements.hasHint, 'TTS toolbar displays keyboard shortcuts hint');
    passed += 5;

    // 26b: Space toggles TTS play / pause
    await page.evaluate(() => {
      if (document.activeElement && document.activeElement.tagName === 'IFRAME') {
        document.activeElement.blur();
      }
      window.focus();
      document.body.focus();
    });
    const spokenBefore = await page.evaluate(() => (window.__tts_spoken || []).length);
    await page.keyboard.press('Space');
    await page.waitForTimeout(100);
    const spokenAfter = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      const toast = win?.el?.querySelector('.yt-tts-toast');
      const spoken = window.__tts_spoken || [];
      return {
        spokenLength: spoken.length,
        hasToast: Boolean(toast)
      };
    });
    assert.ok(spokenAfter.spokenLength > spokenBefore, 'Space key triggers TTS playback');
    passed++;

    // Set playing state to test pause toggle via Space
    await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      win.ttsState = 'playing';
      win.updateTtsUI();
    });
    await page.keyboard.press('Space');
    await page.waitForTimeout(50);
    const spacePauseState = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      const toast = win?.el?.querySelector('.yt-tts-toast');
      return {
        ttsState: win?.ttsState,
        toastText: toast?.textContent?.trim()
      };
    });
    assert.equal(spacePauseState.ttsState, 'paused', 'Space key toggles playing TTS to paused');
    passed++;

    // Space again resumes paused TTS
    await page.keyboard.press('Space');
    await page.waitForTimeout(50);
    const spaceResumeState = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      const toast = win?.el?.querySelector('.yt-tts-toast');
      return {
        ttsState: win?.ttsState,
        toastText: toast?.textContent?.trim()
      };
    });
    assert.equal(spaceResumeState.ttsState, 'playing', 'Space key resumes paused TTS');
    passed++;

    // 26c: ArrowRight / ArrowLeft trigger skip and rewind
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(100);
    const skipToast = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      return win?.el?.querySelector('.yt-tts-toast')?.textContent || '';
    });
    assert.ok(/skip/i.test(skipToast), 'ArrowRight triggers skip with HUD toast feedback');
    passed++;

    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(100);
    const rewindToast = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      return win?.el?.querySelector('.yt-tts-toast')?.textContent || '';
    });
    assert.ok(/rewind/i.test(rewindToast), 'ArrowLeft triggers rewind with HUD toast feedback');
    passed++;

    // 26d: ArrowUp / ArrowDown adjust volume
    await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      win.setTtsVolume(0.5);
    });

    await page.keyboard.press('ArrowUp');
    await page.waitForTimeout(100);
    const volUp = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      return win.ttsVolume;
    });
    assert.equal(volUp, 0.6, 'ArrowUp increases volume by 0.1 to 0.6');
    passed++;

    await page.keyboard.press('ArrowDown');
    await page.waitForTimeout(100);
    const volDown = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      return win.ttsVolume;
    });
    assert.equal(volDown, 0.5, 'ArrowDown decreases volume by 0.1 to 0.5');
    passed++;

    // 26e: Brackets [ and ] step speed rate
    await page.keyboard.press(']');
    await page.waitForTimeout(100);
    const rateStepUp = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      return win.ttsRate;
    });
    assert.ok(rateStepUp >= 1.0, 'Bracket ] steps speed rate up');
    passed++;

    // 26f: Typing inside an editable element does NOT trigger TTS shortcuts
    const typingShield = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      const ta = win.el.querySelector('.yt-composer-textarea');
      ta.focus();
      const stateBefore = win.ttsState;
      ta.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', code: 'Space', bubbles: true }));
      return {
        stateBefore,
        stateAfter: win.ttsState
      };
    });
    assert.equal(typingShield.stateAfter, typingShield.stateBefore, 'Typing space inside composer textarea does not toggle TTS');
    passed++;

    // Check 27: Skip Silence toggle in TTS controls & Transcript Silence/Gap Removal
    const skipSilenceCheck = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      const skipBtn = win?.el?.querySelector('.yt-tts-skip-silence-btn');
      const initialActive = skipBtn?.classList?.contains('active');
      const initialSetting = win?.skipSilence;

      // Click button to toggle OFF
      skipBtn?.click();
      const afterClickActive = skipBtn?.classList?.contains('active');
      const afterClickSetting = win?.skipSilence;

      // Click button again to toggle ON
      skipBtn?.click();
      const reenabledActive = skipBtn?.classList?.contains('active');
      const reenabledSetting = win?.skipSilence;

      // Verify cleanTextForSpeech silence/gap skipping
      const testTranscript = `[00:00] Welcome to our lecture.
[00:10] [Music]
[00:25] (silence)
[00:45] Here is the breakthrough finding.
[01:15] [applause]
[01:20] In conclusion, it works.`;

      const cleanedWithSkip = helper.cleanTextForSpeech(testTranscript, { skipSilence: true });
      const cleanedWithoutSkip = helper.cleanTextForSpeech(testTranscript, { skipSilence: false });

      const tpPanel = win?.el?.querySelector('.yt-transcript-processing-panel');
      const tpFastBtn = win?.el?.querySelector('.yt-tp-fast-btn');
      const tpDeepBtn = win?.el?.querySelector('.yt-tp-deep-btn');

      return {
        hasSkipBtn: Boolean(skipBtn),
        initialActive,
        initialSetting,
        afterClickActive,
        afterClickSetting,
        reenabledActive,
        reenabledSetting,
        cleanedWithSkip,
        cleanedWithoutSkip,
        skipOmittedMusic: !cleanedWithSkip.toLowerCase().includes('music'),
        skipOmittedSilence: !cleanedWithSkip.toLowerCase().includes('silence'),
        skipOmittedApplause: !cleanedWithSkip.toLowerCase().includes('applause'),
        skipRetainedContent: cleanedWithSkip.includes('Welcome') && cleanedWithSkip.includes('breakthrough finding') && cleanedWithSkip.includes('conclusion'),
        noSkipHasMusic: cleanedWithoutSkip.toLowerCase().includes('music') || cleanedWithoutSkip.toLowerCase().includes('applause'),
        hasTpPanel: Boolean(tpPanel),
        hasTpFastBtn: Boolean(tpFastBtn),
        hasTpDeepBtn: Boolean(tpDeepBtn)
      };
    });

    assert.ok(skipSilenceCheck.hasSkipBtn, 'Summary window contains Skip Silence toggle button in TTS controls');
    assert.equal(skipSilenceCheck.initialSetting, true, 'Skip Silence is enabled by default');
    assert.equal(skipSilenceCheck.initialActive, true, 'Skip Silence button has active class by default');
    assert.equal(skipSilenceCheck.afterClickSetting, false, 'Clicking Skip Silence button toggles it off');
    assert.equal(skipSilenceCheck.afterClickActive, false, 'Skip Silence button removes active class when disabled');
    assert.equal(skipSilenceCheck.reenabledSetting, true, 'Clicking again re-enables Skip Silence');
    assert.equal(skipSilenceCheck.reenabledActive, true, 'Skip Silence button restores active class');
    assert.ok(skipSilenceCheck.skipOmittedMusic, 'Skip Silence strips segments marked with [Music]');
    assert.ok(skipSilenceCheck.skipOmittedSilence, 'Skip Silence strips segments marked with (silence)');
    assert.ok(skipSilenceCheck.skipOmittedApplause, 'Skip Silence strips segments marked with [applause]');
    assert.ok(skipSilenceCheck.skipRetainedContent, 'Skip Silence retains substantive speech content');
    assert.ok(skipSilenceCheck.hasTpPanel, 'Summary window contains Transcript Processing panel');
    assert.ok(skipSilenceCheck.hasTpFastBtn && skipSilenceCheck.hasTpDeepBtn, 'Transcript Processing panel includes Fast (Concise) and Deep (Detailed) buttons');
    passed += 13;

    // Check 28: Dynamic Transcript Line Highlighting during TTS playback
    const transcriptTtsCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      if (!win) return { error: 'No active window found' };

      win.mode = 'transcript';
      win.text = `[00:00] Introduction to neural networks and gradient descent.
[00:45] Examining backpropagation across multi-layer perceptrons.
[01:30] Convergence criteria and loss surfaces.`;
      win.status = 'done';
      win.renderAll();

      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot || win.el;
      const initialLines = Array.from(root?.querySelectorAll('.yt-transcript-line') || []);

      // Verify line metadata attributes
      const line0 = initialLines[0];
      const line1 = initialLines[1];
      const line2 = initialLines[2];

      const initialHasAttrs = line0?.getAttribute('data-start-sec') === '0' &&
                             line1?.getAttribute('data-start-sec') === '45' &&
                             line2?.getAttribute('data-start-sec') === '90';

      // Start TTS
      await win.startTts();

      // Check initial highlight on first cue
      const activeLineAfterStart = root?.querySelector('.yt-transcript-line.yt-transcript-line-speaking');
      const indicatorAfterStart = root?.querySelector('.yt-speaking-indicator');
      const startLineTs = activeLineAfterStart?.getAttribute('data-ts');

      // Now advance highlight to cue 1 (00:45)
      if (win.transcriptCues && win.transcriptCues[1]) {
        win.highlightActiveTranscriptLine(win.transcriptCues[1]);
      }
      const activeLineAfterMove = root?.querySelector('.yt-transcript-line.yt-transcript-line-speaking');
      const moveLineTs = activeLineAfterMove?.getAttribute('data-ts');
      const firstLineStillSpeaking = line0?.classList?.contains('yt-transcript-line-speaking');

      // Pause TTS - highlight must persist
      win.pauseTts();
      const activeLineAfterPause = root?.querySelector('.yt-transcript-line.yt-transcript-line-speaking');
      const pauseLineTs = activeLineAfterPause?.getAttribute('data-ts');

      // Stop TTS - highlight must be removed
      win.stopTts();
      const activeLineAfterStop = root?.querySelector('.yt-transcript-line.yt-transcript-line-speaking');
      const indicatorAfterStop = root?.querySelector('.yt-speaking-indicator');

      // Test helper parsing and character lookup
      const parsed = helper.parseTranscriptCues(win.text, { skipSilence: true });
      const foundCueByChar = helper.findActiveCueByCharIndex(parsed.cues, 15);
      const foundCueByTime = helper.findActiveCueByTime(parsed.cues, 50, 100);

      return {
        totalLines: initialLines.length,
        initialHasAttrs,
        hasCues: Boolean(win.transcriptCues && win.transcriptCues.length === 3),
        firstLineHighlighted: Boolean(activeLineAfterStart && (startLineTs === '[00:00]' || startLineTs === '00:00')),
        hasSpeakerIndicator: Boolean(indicatorAfterStart),
        cueMovedToSecondLine: Boolean(activeLineAfterMove && (moveLineTs === '[00:45]' || moveLineTs === '00:45')),
        firstLineCleared: !firstLineStillSpeaking,
        persistsOnPause: Boolean(activeLineAfterPause && (pauseLineTs === '[00:45]' || pauseLineTs === '00:45')),
        clearedOnStop: activeLineAfterStop === null && indicatorAfterStop === null,
        parsedCount: parsed.cues.length,
        foundCharTs: foundCueByChar?.tsStr?.replace(/[[\]]/g, ''),
        foundTimeTs: foundCueByTime?.tsStr?.replace(/[[\]]/g, '')
      };
    });

    assert.equal(transcriptTtsCheck.totalLines, 3, 'Transcript view renders 3 lines');
    assert.ok(transcriptTtsCheck.initialHasAttrs, 'Transcript line elements contain data-start-sec and data-ts attributes');
    assert.ok(transcriptTtsCheck.hasCues, 'Transcript cues parsed into window state');
    assert.ok(transcriptTtsCheck.firstLineHighlighted, 'First transcript line is dynamically highlighted on TTS start');
    assert.ok(transcriptTtsCheck.hasSpeakerIndicator, 'Highlighted transcript line displays live speaker indicator');
    assert.ok(transcriptTtsCheck.cueMovedToSecondLine, 'Active highlight smoothly advances to the next timestamped cue');
    assert.ok(transcriptTtsCheck.firstLineCleared, 'Previous transcript line loses speaking highlight when cue advances');
    assert.ok(transcriptTtsCheck.persistsOnPause, 'Speaking highlight persists on paused line when TTS is paused');
    assert.ok(transcriptTtsCheck.clearedOnStop, 'Speaking highlight is cleanly cleared when TTS is stopped');
    assert.equal(transcriptTtsCheck.parsedCount, 3, 'parseTranscriptCues extracts all 3 cues');
    assert.equal(transcriptTtsCheck.foundCharTs, '00:00', 'findActiveCueByCharIndex correctly maps character offset to cue');
    assert.equal(transcriptTtsCheck.foundTimeTs, '00:45', 'findActiveCueByTime correctly maps playback time to cue');
    passed += 12;

    // Check 29: Theme synchronization toggle with YouTube (Dark vs. Light mode auto-detection)
    const themeSyncCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();
      if (!win) return { error: 'No active window found' };

      // Ensure YouTube root has dark mode initially
      document.documentElement.setAttribute('dark', '');

      // Enable theme sync & Readability mode
      win.setSyncYouTubeTheme(true);
      win.toggleReadability(true);

      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot || win.el;
      const syncBtn = root?.querySelector('.yt-readability-sync-theme-btn');
      const initialHasSyncBtn = Boolean(syncBtn);
      const initialSyncActive = syncBtn?.classList?.contains('active');
      const initialSetting = win.syncYouTubeTheme;

      // Detected YouTube theme should be dark
      const detectedDark = helper.detectYouTubeTheme();
      const initialBoxClassDark = win.windowBox?.classList?.contains('yt-theme-dark');
      const initialReaderClassDark = root?.querySelector('.yt-readability-container')?.classList?.contains('theme-dark') ||
                                    root?.querySelector('.yt-readability-container')?.classList?.contains('yt-readability-theme-dark');

      // Now simulate YouTube theme changing to Light mode
      document.documentElement.removeAttribute('dark');
      document.documentElement.removeAttribute('theme');
      const detectedLight = helper.detectYouTubeTheme();

      // Trigger sync update to match YouTube light mode
      win.setSyncYouTubeTheme(true);
      await new Promise((r) => setTimeout(r, 60));

      const afterLightBoxClass = win.windowBox?.classList?.contains('yt-theme-light');
      const afterLightReaderClass = root?.querySelector('.yt-readability-container')?.classList?.contains('theme-light') ||
                                   root?.querySelector('.yt-readability-container')?.classList?.contains('yt-readability-theme-light');

      // Now click Sepia theme button - should turn off sync and apply sepia
      const sepiaBtn = root?.querySelector('.yt-readability-theme-btn[data-theme="sepia"]');
      sepiaBtn?.click();
      await new Promise((r) => setTimeout(r, 60));

      const afterSepiaSyncActive = root?.querySelector('.yt-readability-sync-theme-btn')?.classList?.contains('active');
      const afterSepiaSetting = win.syncYouTubeTheme;
      const afterSepiaBoxClass = win.windowBox?.classList?.contains('yt-theme-sepia');

      // Now click sync button again - should re-enable sync and match YouTube (light)
      const syncBtnAfterSepia = root?.querySelector('.yt-readability-sync-theme-btn');
      syncBtnAfterSepia?.click();
      await new Promise((r) => setTimeout(r, 60));

      const reenabledSyncActive = root?.querySelector('.yt-readability-sync-theme-btn')?.classList?.contains('active');
      const reenabledSetting = win.syncYouTubeTheme;
      const reenabledBoxClass = win.windowBox?.classList?.contains('yt-theme-light');

      // Re-enable dark mode on YouTube and verify live sync back to dark
      document.documentElement.setAttribute('dark', '');
      win.setSyncYouTubeTheme(true);
      await new Promise((r) => setTimeout(r, 60));

      const syncedBackDark = win.windowBox?.classList?.contains('yt-theme-dark');

      return {
        initialHasSyncBtn,
        initialSyncActive,
        initialSetting,
        detectedDark,
        initialBoxClassDark,
        initialReaderClassDark,
        detectedLight,
        afterLightBoxClass,
        afterLightReaderClass,
        afterSepiaSyncActive,
        afterSepiaSetting,
        afterSepiaBoxClass,
        reenabledSyncActive,
        reenabledSetting,
        reenabledBoxClass,
        syncedBackDark
      };
    });

    assert.ok(themeSyncCheck.initialHasSyncBtn, 'Reader view contains YouTube Theme Sync toggle button');
    assert.equal(themeSyncCheck.initialSetting, true, 'Theme synchronization is enabled by default');
    assert.equal(themeSyncCheck.initialSyncActive, true, 'Sync button has active class by default');
    assert.equal(themeSyncCheck.detectedDark, 'dark', 'detectYouTubeTheme detects dark mode from document');
    assert.ok(themeSyncCheck.initialBoxClassDark && themeSyncCheck.initialReaderClassDark, 'Reader view theme automatically matches YouTube dark mode');
    assert.equal(themeSyncCheck.detectedLight, 'light', 'detectYouTubeTheme detects light mode when dark attribute is removed');
    assert.ok(themeSyncCheck.afterLightBoxClass && themeSyncCheck.afterLightReaderClass, 'Reader view automatically updates to light theme to match YouTube');
    assert.equal(themeSyncCheck.afterSepiaSetting, false, 'Manual theme selection (Sepia) turns off automatic YouTube sync');
    assert.equal(themeSyncCheck.afterSepiaSyncActive, false, 'Sync button removes active class when user manually picks a theme');
    assert.ok(themeSyncCheck.afterSepiaBoxClass, 'Reader view applies manually selected Sepia theme');
    assert.equal(themeSyncCheck.reenabledSetting, true, 'Clicking sync button re-enables YouTube theme synchronization');
    assert.equal(themeSyncCheck.reenabledSyncActive, true, 'Sync button restores active class');
    assert.ok(themeSyncCheck.syncedBackDark, 'Reader view automatically updates back to dark mode when YouTube theme changes');
    passed += 13;

    // Check 30: Follow-up composer voice input mic button and LRU memory cache
    const compCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow() || helper.getActiveWindows().get('D_menu_video');
      if (win && win.readabilityMode) {
        win.toggleReadability(false);
        await new Promise((r) => setTimeout(r, 60));
      }

      const box = win?.windowBox;
      const compWrap = box?.querySelector('.yt-composer-wrap');
      const micBtn = compWrap?.querySelector('.yt-composer-mic-btn');
      const ta = compWrap?.querySelector('.yt-composer-textarea');
      const sendBtn = compWrap?.querySelector('.yt-composer-send-btn');

      const initialHasMic = Boolean(micBtn);
      const initialHasSend = Boolean(sendBtn);
      const initialHasTa = Boolean(ta);

      // Trigger simulated voice input
      window.__yt_mock_voice_text = 'What are the main experimental conclusions?';
      micBtn?.click();
      await new Promise((r) => setTimeout(r, 60));

      const taValAfterMic = ta?.value || '';

      // Test LRU memory cache bound
      const setAltTitle = window.__yt_summariser_test.setCachedAltTitle;
      const getAltTitle = window.__yt_summariser_test.getCachedAltTitle;

      if (setAltTitle && getAltTitle) {
        setAltTitle('test_vid_1', 'Title One');
        setAltTitle('test_vid_2', 'Title Two');
      }

      return {
        initialHasMic,
        initialHasSend,
        initialHasTa,
        taValAfterMic,
        hasCachedAltTitle: Boolean(getAltTitle?.('test_vid_1'))
      };
    });

    assert.ok(compCheck.initialHasMic, 'Follow-up composer includes voice input microphone button');
    assert.ok(compCheck.initialHasSend, 'Follow-up composer includes Send button');
    assert.ok(compCheck.initialHasTa, 'Follow-up composer includes textarea');
    assert.ok(compCheck.taValAfterMic.includes('conclusions'), 'Clicking voice input populates composer textarea');
    assert.ok(compCheck.hasCachedAltTitle, 'Alternative title memory cache stores entries correctly');
    passed += 5;

    // Check 31: Follow-up chat draft auto-save and recovery
    const draftCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow() || Array.from(helper.getActiveWindows().values())[0];
      const videoId = win?.videoId || 'vid_tts_shortcuts_test';
      const box = win?.windowBox;
      const compWrap = box?.querySelector('.yt-composer-wrap');
      const ta = compWrap?.querySelector('.yt-composer-textarea');
      const draftBadge = compWrap?.querySelector('.yt-composer-draft-badge');

      // 1. Type an unfinished draft question
      const testDraft = 'Is there any telemetry on temperature stability?';
      if (ta) {
        ta.value = testDraft;
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
      await new Promise((r) => setTimeout(r, 60));

      const savedToStorage = helper.getDraftFollowUp(videoId);
      const badgeVisibleOnInput = draftBadge && window.getComputedStyle(draftBadge).display !== 'none';

      // 2. Simulate accidental window close (close)
      win.close();
      await new Promise((r) => setTimeout(r, 60));

      // 3. Verify draft still persists in storage after close
      const savedAfterClose = helper.getDraftFollowUp(videoId);

      // 4. Reopen window and verify draft is recovered
      helper.openForVideo({ videoId, title: 'Draft Recovery Technical Test' });
      await new Promise((r) => setTimeout(r, 60));
      const reopenedWin = helper.getActiveWindows().get(videoId);
      const newTa = reopenedWin?.windowBox?.querySelector('.yt-composer-textarea');
      const recoveredVal = newTa?.value || '';

      // 5. Clean up draft
      helper.clearDraftFollowUp(videoId);

      return {
        savedToStorage,
        badgeVisibleOnInput,
        savedAfterClose,
        recoveredVal
      };
    });

    assert.equal(draftCheck.savedToStorage, 'Is there any telemetry on temperature stability?', 'Draft auto-saves to local storage on input');
    assert.ok(draftCheck.badgeVisibleOnInput, 'Draft auto-saved badge is visible when draft exists');
    assert.equal(draftCheck.savedAfterClose, 'Is there any telemetry on temperature stability?', 'Draft persists in local storage across window close');
    assert.equal(draftCheck.recoveredVal, 'Is there any telemetry on temperature stability?', 'Draft is automatically recovered in composer when window is reopened');
    passed += 4;

    // Check 32: Granular TTS speed presets (0.25x steps) and speed button visual indicator
    const speedCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow() || helper.getActiveWindows().get('D_menu_video');
      const box = win?.windowBox;
      const speedBtn = box?.querySelector('.yt-tts-speed-btn');
      const presetBtns = Array.from(box?.querySelectorAll('.yt-tts-rate-pill') || []);
      const rates = presetBtns.map((b) => parseFloat(b.getAttribute('data-rate')));

      // Check speed button visual indicator
      const indicator = speedBtn?.querySelector('.yt-tts-speed-indicator');

      // Check granular steps
      win.setTtsRate(1.75);
      await new Promise((r) => setTimeout(r, 60));

      const activeBtn175 = box?.querySelector('.yt-tts-rate-pill[data-rate="1.75"]')?.classList.contains('active');
      const btnText175 = speedBtn?.querySelector('.yt-tts-speed-text')?.textContent || speedBtn?.textContent;
      const indicatorBoost = indicator?.classList.contains('speed-boost');

      win.setTtsRate(1.0);
      await new Promise((r) => setTimeout(r, 60));
      const indicatorNormal = indicator?.classList.contains('speed-normal');

      // Test cycle
      win.cycleTtsRate();
      const nextRate = win.ttsRate;

      return {
        hasSpeedBtn: Boolean(speedBtn),
        hasIndicator: Boolean(indicator),
        has175Preset: rates.includes(1.75),
        all025Steps: rates.every((r, idx) => idx === 0 || Math.abs((r - rates[idx - 1]) - 0.25) < 0.01),
        activeBtn175,
        btnText175,
        indicatorBoost,
        indicatorNormal,
        nextRateAfterCycle: nextRate
      };
    });

    assert.ok(speedCheck.hasSpeedBtn, 'TTS toolbar includes speed button');
    assert.ok(speedCheck.hasIndicator, 'Speed button contains visual indicator directly on the button');
    assert.ok(speedCheck.has175Preset, 'TTS presets include 1.75x (0.25x step)');
    assert.ok(speedCheck.all025Steps, 'All speed presets advance strictly in granular 0.25x steps');
    assert.ok(speedCheck.activeBtn175, '1.75x preset button highlights when 1.75x is selected');
    assert.ok(speedCheck.btnText175.includes('1.75x'), 'Speed button directly shows 1.75x setting');
    assert.ok(speedCheck.indicatorBoost, 'Visual indicator highlights boost state for > 1.0x speeds');
    assert.ok(speedCheck.indicatorNormal, 'Visual indicator displays normal state for 1.0x speed');
    assert.equal(speedCheck.nextRateAfterCycle, 1.25, 'cycleTtsRate advances speed in 0.25x steps (1.0x -> 1.25x)');
    passed += 9;

    // --- CHECK 33: TTS Pitch Slider (0.5x - 2.0x) & Local Storage Persistence ---
    const pitchCheck = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;

      const pitchWrap = root?.querySelector('.yt-tts-pitch-wrap');
      const pitchSlider = root?.querySelector('.yt-tts-pitch-slider');
      const pitchLabel = root?.querySelector('.yt-tts-pitch-label');
      const pitchIcon = root?.querySelector('.yt-tts-pitch-icon');

      const win = helper.getMaximizedWindow();
      if (!win) throw new Error('No active window for pitch test');

      // Test slider attributes
      const min = pitchSlider?.getAttribute('min');
      const max = pitchSlider?.getAttribute('max');
      const step = pitchSlider?.getAttribute('step');

      // Change pitch to 1.35x
      win.setTtsPitch(1.35);
      const storedPitch = helper.getLastTtsPitch();
      const sliderVal = pitchSlider?.value;
      const labelText = pitchLabel?.textContent;

      // Close window and recreate to verify persistence alongside speed and volume
      const vidId = win.videoId;
      win.close();

      const opened = helper.openForVideo({ videoId: vidId, title: 'Pitch Persistence Test' });
      const newWin = opened || helper.getMaximizedWindow() || helper.getActiveWindows()?.get(vidId);
      const recoveredPitch = newWin?.ttsPitch;
      const recoveredRate = newWin?.ttsRate;
      const recoveredVol = newWin?.ttsVolume;

      return {
        hasPitchWrap: Boolean(pitchWrap),
        hasPitchSlider: Boolean(pitchSlider),
        hasPitchLabel: Boolean(pitchLabel),
        hasPitchIcon: Boolean(pitchIcon),
        min,
        max,
        step,
        storedPitch,
        sliderVal,
        labelText,
        recoveredPitch,
        recoveredRate,
        recoveredVol
      };
    });

    assert.ok(pitchCheck.hasPitchWrap, 'TTS control toolbar includes pitch wrapper element (.yt-tts-pitch-wrap)');
    assert.ok(pitchCheck.hasPitchSlider, 'TTS control toolbar includes pitch slider (.yt-tts-pitch-slider)');
    assert.ok(pitchCheck.hasPitchLabel, 'TTS control toolbar includes pitch label (.yt-tts-pitch-label)');
    assert.ok(pitchCheck.hasPitchIcon, 'Pitch slider includes voice character icon (.yt-tts-pitch-icon)');
    assert.equal(pitchCheck.min, '0.5', 'Pitch slider min is 0.5x');
    assert.equal(pitchCheck.max, '2', 'Pitch slider max is 2.0x');
    assert.equal(pitchCheck.step, '0.05', 'Pitch slider step is 0.05');
    assert.equal(pitchCheck.storedPitch, 1.35, 'setTtsPitch persists pitch to local storage');
    assert.equal(pitchCheck.sliderVal, '1.35', 'Pitch slider value updates to 1.35');
    assert.equal(pitchCheck.labelText, '1.35x', 'Pitch label reflects 1.35x setting');
    assert.equal(pitchCheck.recoveredPitch, 1.35, 'Reopened window recovers persisted pitch from local storage');
    assert.ok(typeof pitchCheck.recoveredRate === 'number', 'Reopened window persists speed setting alongside pitch');
    assert.ok(typeof pitchCheck.recoveredVol === 'number', 'Reopened window persists volume setting alongside pitch');
    passed += 13;

    // --- CHECK 34: Readability Mode JSON Export Button & Metadata Completeness ---
    const jsonExportCheck = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;

      const win = helper.getMaximizedWindow();
      if (!win) throw new Error('No active window for JSON export test');

      // Populate sample content and metadata
      win.channel = 'Veritasium Deep Tech';
      win.title = 'The Engineering Physics of Quantum Compute';
      win.mode = 'transcript';
      win.opts = { ...win.opts, transcriptMode: 'deep' };
      win.text = '## Detailed Summary\nChronological overview of quantum gate latency with [02:15] timestamps.';
      win.fact = { text: 'Verified telemetry against peer-reviewed preprint.' };
      win.turns = [
        { q: 'What is the coherence time?', a: 'Over 120 microseconds [04:12].', sources: [] }
      ];

      // Switch to Readability mode
      win.readabilityMode = true;
      win.renderAll();

      const readerBar = root?.querySelector('.yt-readability-bar');
      const jsonBtn = readerBar?.querySelector('.yt-readability-export-json-btn');
      const btnText = jsonBtn?.textContent?.trim();

      // Open window export menu to verify popover JSON button
      const winExportBtn = root?.querySelector('.yt-win-export-btn');
      if (winExportBtn) {
        win.openExportMenu(winExportBtn);
      }
      const popoverJsonBtn = root?.querySelector('.yt-export-popover .yt-export-json-btn');
      const popoverJsonTitle = popoverJsonBtn?.querySelector('.yt-export-item-title')?.textContent;

      // Test formatAsExportJson output and schema
      const jsonStr = helper.formatAsExportJson(win);
      const parsed = JSON.parse(jsonStr);

      return {
        hasJsonBtn: Boolean(jsonBtn),
        btnText,
        hasPopoverJsonBtn: Boolean(popoverJsonBtn),
        popoverJsonTitle,
        hasValidJson: Boolean(jsonStr && parsed),
        generator: parsed.generator,
        videoId: parsed.metadata?.videoId,
        videoTitle: parsed.metadata?.videoTitle,
        channel: parsed.metadata?.channel,
        processingMode: parsed.metadata?.processingMode,
        mode: parsed.metadata?.mode,
        pitchSetting: parsed.metadata?.ttsSettings?.pitch,
        hasFactCheck: Boolean(parsed.content?.factCheck),
        followUpCount: parsed.content?.followUpQuestions?.length
      };
    });

    assert.ok(jsonExportCheck.hasJsonBtn, 'Readability mode toolbar contains JSON export button (.yt-readability-export-json-btn)');
    assert.ok(jsonExportCheck.btnText.includes('JSON'), 'Readability export button label includes "JSON"');
    assert.ok(jsonExportCheck.hasPopoverJsonBtn, 'Export popover contains JSON export item (.yt-export-json-btn)');
    assert.ok(jsonExportCheck.popoverJsonTitle.includes('JSON'), 'Export popover item displays "Export as JSON"');
    assert.ok(jsonExportCheck.hasValidJson, 'formatAsExportJson returns valid JSON string');
    assert.equal(jsonExportCheck.generator, 'YouTube Feed Summariser (Gemini)', 'Export payload specifies generator');
    assert.equal(jsonExportCheck.videoTitle, 'The Engineering Physics of Quantum Compute', 'Metadata includes video title');
    assert.equal(jsonExportCheck.channel, 'Veritasium Deep Tech', 'Metadata includes channel name');
    assert.equal(jsonExportCheck.processingMode, 'deep', 'Metadata includes transcript processing mode (deep)');
    assert.equal(jsonExportCheck.mode, 'transcript', 'Metadata includes mode (transcript)');
    assert.equal(jsonExportCheck.pitchSetting, 1.35, 'Export includes persisted TTS pitch setting');
    assert.ok(jsonExportCheck.hasFactCheck, 'Export includes fact check verification content');
    assert.equal(jsonExportCheck.followUpCount, 1, 'Export includes follow-up conversation turns');
    passed += 13;

    // Check 35: Adversarial Probes - Bounded LRU Cache, Timer Cleanup, and Pitch Shortcuts
    const adversarialCheck = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      
      // 1. Verify createBoundedMap LRU eviction and bounds
      const testMap = helper.createBoundedMap(3);
      testMap.set('v1', 'one');
      testMap.set('v2', 'two');
      testMap.set('v3', 'three');
      const initialSize = testMap.size;
      // Access v1 so v2 becomes oldest
      testMap.get('v1');
      // Add v4: capacity 3 exceeded, v2 should be evicted
      testMap.set('v4', 'four');
      const sizeAfterEvict = testMap.size;
      const hasV2 = testMap.has('v2');
      const hasV1 = testMap.has('v1');
      const hasV4 = testMap.has('v4');

      // 2. Verify TTS timer cleanup in stopTts
      const win = helper.getMaximizedWindow();
      let timerCleared = false;
      if (win) {
        win.ttsProgressTimer = 99999;
        win._ttsFeedbackTimer = 88888;
        win.stopTts();
        timerCleared = win.ttsProgressTimer === null && win._ttsFeedbackTimer === null;
      }

      // 3. Verify { and } pitch shortcuts
      let pitchSteppedUp = false;
      let pitchSteppedDown = false;
      if (win) {
        win.setTtsPitch(1.0);
        window.__yt_test_allow_untrusted_events = true;
        // Simulate '}' keydown
        window.dispatchEvent(new KeyboardEvent('keydown', { key: '}', bubbles: true }));
        pitchSteppedUp = Math.abs(win.ttsPitch - 1.05) < 0.01;

        // Simulate '{' keydown twice
        window.dispatchEvent(new KeyboardEvent('keydown', { key: '{', bubbles: true }));
        window.dispatchEvent(new KeyboardEvent('keydown', { key: '{', bubbles: true }));
        pitchSteppedDown = Math.abs(win.ttsPitch - 0.95) < 0.01;
        window.__yt_test_allow_untrusted_events = false;
      }

      // 4. Verify clampPitch handles extreme values
      const clampInf = helper.clampPitch(Infinity);
      const clampNeg = helper.clampPitch(-5);
      const clampHigh = helper.clampPitch(10);

      return {
        initialSize,
        sizeAfterEvict,
        hasV2,
        hasV1,
        hasV4,
        timerCleared,
        pitchSteppedUp,
        pitchSteppedDown,
        clampInf,
        clampNeg,
        clampHigh
      };
    });

    assert.equal(adversarialCheck.initialSize, 3, 'createBoundedMap populates to capacity');
    assert.equal(adversarialCheck.sizeAfterEvict, 3, 'createBoundedMap maintains max capacity');
    assert.equal(adversarialCheck.hasV2, false, 'Least recently used item (v2) evicted on capacity overflow');
    assert.equal(adversarialCheck.hasV1, true, 'Recently accessed item (v1) preserved');
    assert.equal(adversarialCheck.hasV4, true, 'Newly added item (v4) present in bounded cache');
    assert.ok(adversarialCheck.timerCleared, 'stopTts thoroughly nulls out progress and feedback timers');
    assert.ok(adversarialCheck.pitchSteppedUp, 'Keyboard shortcut "}" steps voice pitch up by 0.05');
    assert.ok(adversarialCheck.pitchSteppedDown, 'Keyboard shortcut "{" steps voice pitch down by 0.05');
    assert.equal(adversarialCheck.clampInf, 1.0, 'clampPitch safely handles Infinity');
    assert.equal(adversarialCheck.clampNeg, 0.5, 'clampPitch safely bounds negative values to 0.5');
    assert.equal(adversarialCheck.clampHigh, 2.0, 'clampPitch safely bounds high values to 2.0');
    passed += 11;

    // Check 36: Dynamic Audio Waveform Visualizer in TTS Control Bar
    const waveformCheck = await page.evaluate(async () => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const helper = window.__yt_summariser_test;
      const win = helper.getMaximizedWindow();

      // Ensure Readability mode is turned off so standard TTS toolbar is active
      if (win.readabilityMode) {
        win.readabilityMode = false;
        win.renderAll();
      }

      const toolbar = root?.querySelector('.yt-win-toolbar');
      const waveformWrap = toolbar?.querySelector('.yt-tts-waveform-wrap');
      const waveformCanvas = waveformWrap?.querySelector('.yt-tts-waveform-canvas');
      const waveformBars = waveformWrap?.querySelectorAll('.yt-tts-waveform-bar');

      const initialHasWrap = Boolean(waveformWrap);
      const initialHasCanvas = Boolean(waveformCanvas);
      const initialBarCount = waveformBars?.length || 0;
      const isInitiallyPlayingClass = waveformWrap?.classList.contains('playing');

      // Start playback and verify waveform activation
      win.ttsState = 'playing';
      win.updateTtsUI();
      const playingHasClass = waveformWrap?.classList.contains('playing');
      const isAnimationActive = Boolean(win.waveformAnimId);

      // Verify dynamic amplitude generation across frequencies
      const computedAmps = helper.computeWaveformAmplitudes({
        isPlaying: true,
        volume: 1.0,
        pitch: win.ttsPitch || 1.0,
        rate: win.ttsRate || 1.0,
        timestamp: Date.now(),
        barCount: 12
      });

      // Stop speech and verify clean teardown and flatline
      win.stopTts();
      const afterStopPlayingClass = waveformWrap?.classList.contains('playing');
      const isAnimationStopped = win.waveformAnimId === null;

      return {
        initialHasWrap,
        initialHasCanvas,
        initialBarCount,
        isInitiallyPlayingClass,
        playingHasClass,
        isAnimationActive,
        computedBarsLength: computedAmps?.length || 0,
        computedMaxAmp: Math.max(...computedAmps),
        afterStopPlayingClass,
        isAnimationStopped
      };
    });

    assert.ok(waveformCheck.initialHasWrap, 'TTS control bar contains dynamic audio waveform visualizer wrap (.yt-tts-waveform-wrap)');
    assert.ok(waveformCheck.initialHasCanvas, 'Waveform visualizer contains rendering canvas (.yt-tts-waveform-canvas)');
    assert.ok(waveformCheck.initialBarCount >= 8, 'Waveform visualizer initializes multi-band frequency bars');
    assert.ok(!waveformCheck.isInitiallyPlayingClass, 'Waveform starts in idle state without .playing class');
    assert.ok(waveformCheck.playingHasClass, 'Waveform receives .playing active class during speech playback');
    assert.ok(waveformCheck.isAnimationActive, 'Speech playback triggers requestAnimationFrame waveform visualizer loop');
    assert.equal(waveformCheck.computedBarsLength, 12, 'Amplitude model generates 12 frequency spectrum bars');
    assert.ok(waveformCheck.computedMaxAmp > 0.15, 'Active speech amplitudes reflect real-time voice energy');
    assert.ok(!waveformCheck.afterStopPlayingClass, 'Stopping speech removes .playing class from waveform visualizer');
    assert.ok(waveformCheck.isAnimationStopped, 'Stopping speech halts animation loop without frame leaks');
    passed += 10;

    // Check 37: History Tab Visibility Setting ('always', 'with_tabs', 'never')
    const historyVisCheck = await page.evaluate(async () => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const helper = window.__yt_summariser_test;

      // Seed at least one cached summary item so cachedCount > 0
      helper.writeCache('HIST_TEST_01', 'summary', 'video', {
        text: 'Cached summary for history visibility test',
        title: 'History Visibility Test Video',
        channel: 'Test Channel',
        ts: Date.now()
      });

      // Ensure zero active video dock tabs initially by closing all open/minimized windows
      for (const [, w] of Array.from(helper.activeWindows.entries())) {
        w.close();
      }
      helper.updateDockHistoryTab();

      const hasHistoryTab = () => Boolean(root?.querySelector('.yt-dock-history-tab'));

      // 1. 'always' with 0 video tabs -> shown
      helper.setHistoryTabVisibility('always');
      const alwaysNoTabs = hasHistoryTab();

      // 2. 'with_tabs' with 0 video tabs -> hidden
      helper.setHistoryTabVisibility('with_tabs');
      const withTabsZero = hasHistoryTab();

      // 3. 'with_tabs' with 1 active/minimized tab -> shown
      helper.openForVideo({ videoId: 'HIST_VIS_VID', title: 'History Vis Video' });
      const wVis = helper.activeWindows.get('HIST_VIS_VID');
      wVis?.minimize();
      helper.updateDockHistoryTab();
      const withTabsOne = hasHistoryTab();

      // 4. 'never' even with active/minimized tabs -> hidden
      helper.setHistoryTabVisibility('never');
      const neverWithTab = hasHistoryTab();

      // 5. Verify select element inside Advanced Options panel reflects & persists change
      const visSelect = root?.querySelector('.yt-history-visibility-select');
      let selectWorks = false;
      if (visSelect) {
        visSelect.value = 'with_tabs';
        visSelect.dispatchEvent(new Event('change', { bubbles: true }));
        selectWorks = helper.getHistoryTabVisibility() === 'with_tabs' && hasHistoryTab();
      }

      // Restore defaults & cleanup
      helper.setHistoryTabVisibility('always');
      wVis?.close();

      return {
        alwaysNoTabs,
        withTabsZero,
        withTabsOne,
        neverWithTab,
        selectWorks,
        defaultRestored: helper.getHistoryTabVisibility()
      };
    });

    assert.ok(historyVisCheck.alwaysNoTabs, 'History dock tab is visible with 0 video tabs when visibility="always"');
    assert.ok(!historyVisCheck.withTabsZero, 'History dock tab is hidden with 0 video tabs when visibility="with_tabs"');
    assert.ok(historyVisCheck.withTabsOne, 'History dock tab appears once another tab is open/minimized when visibility="with_tabs"');
    assert.ok(!historyVisCheck.neverWithTab, 'History dock tab stays hidden when visibility="never" even with active tabs');
    assert.ok(historyVisCheck.selectWorks, 'Settings selector (.yt-history-visibility-select) updates History dock tab visibility');
    assert.equal(historyVisCheck.defaultRestored, 'always', 'History dock tab visibility restores cleanly to "always"');
    passed += 6;

    // Check 38: Response Ratings (Thumbs Up / Down, Persistence, Follow-up, Readability & JSON Export)
    const ratingCheck = await page.evaluate(async () => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const helper = window.__yt_summariser_test;

      for (const [, w] of Array.from(helper.activeWindows.entries())) {
        w.close();
      }
      helper.openForVideo({ videoId: 'RATE_VID_01', title: 'Rating Test Video' });
      const win = helper.activeWindows.get('RATE_VID_01');
      win.mode = 'summary';
      win.status = 'done';
      win.text = 'Summary text for response rating verification.';
      win.turns = [{ q: 'Why?', a: 'Because testing works.', model: 'gemini-3.8-flash', sources: [] }];
      win.readabilityMode = false;
      win.renderAll();

      // Find main summary rating bar & click Thumbs Up
      const mainBar = root?.querySelector('.yt-window-box .yt-window-body .yt-rating-bar[data-target-type="summary"]');
      const upBtn = mainBar?.querySelector('.yt-rating-up-btn');
      upBtn?.click();
      const afterUp = helper.getResponseRating('RATE_VID_01', 'summary', 'main');
      const upPressedAttr = root?.querySelector('.yt-window-box .yt-window-body .yt-rating-bar[data-target-type="summary"] .yt-rating-up-btn')?.getAttribute('aria-pressed');

      // Switch to Thumbs Down on main summary
      const downBtn = root?.querySelector('.yt-window-box .yt-window-body .yt-rating-bar[data-target-type="summary"] .yt-rating-down-btn');
      downBtn?.click();
      const afterDown = helper.getResponseRating('RATE_VID_01', 'summary', 'main');

      // Verify follow-up answer bubble has its own rating bar
      const followUpUp = root?.querySelector('.yt-ans-bubble .yt-rating-bar .yt-rating-up-btn');
      followUpUp?.click();
      const afterFollowUp = helper.getResponseRating('RATE_VID_01', 'followup', 'turn_0');

      // Verify JSON export contains ratings
      const exportedJson = JSON.parse(helper.formatAsExportJson(win));

      // Verify Readability view also displays rating bar
      win.readabilityMode = true;
      win.renderAll();
      const hasReadabilityRating = Boolean(root?.querySelector('.yt-readability-content .yt-rating-bar'));
      win.readabilityMode = false;
      win.close();

      return {
        hasMainBar: Boolean(mainBar),
        afterUpRating: afterUp?.rating,
        upPressedAttr,
        afterDownRating: afterDown?.rating,
        afterFollowUpRating: afterFollowUp?.rating,
        exportedMainRating: exportedJson?.content?.ratings?.main?.rating,
        exportedFollowUpRating: exportedJson?.content?.ratings?.followUps?.turn_0?.rating,
        hasReadabilityRating
      };
    });

    assert.ok(ratingCheck.hasMainBar, 'Summary window displays response rating bar (.yt-rating-bar) below summary output');
    assert.equal(ratingCheck.afterUpRating, 'up', 'Clicking Thumbs Up persists "up" rating');
    assert.equal(ratingCheck.upPressedAttr, 'true', 'Thumbs Up button updates aria-pressed="true"');
    assert.equal(ratingCheck.afterDownRating, 'down', 'Clicking Thumbs Down switches persisted rating to "down"');
    assert.equal(ratingCheck.afterFollowUpRating, 'up', 'Follow-up answer bubbles include independent Thumbs Up/Down rating controls');
    assert.equal(ratingCheck.exportedMainRating, 'down', 'Exported JSON includes main response rating metadata');
    assert.equal(ratingCheck.exportedFollowUpRating, 'up', 'Exported JSON includes follow-up response ratings metadata');
    assert.ok(ratingCheck.hasReadabilityRating, 'Readability view preserves response rating controls');
    passed += 8;

    // Check 39 & 40: Multiple Simultaneous Resizable Windows + Adaptive Layout
    const multiAndAdaptiveCheck = await page.evaluate(async () => {
      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const helper = window.__yt_summariser_test;

      // Close any leftover windows first
      for (const [, w] of Array.from(helper.activeWindows.entries())) {
        w.close();
      }

      // Open two summary windows simultaneously
      helper.openForVideo({ videoId: 'MULTI_A', title: 'First Simultaneous Window' });
      const winA = helper.activeWindows.get('MULTI_A');
      winA.status = 'done';
      winA.text = 'Content for first simultaneous window.';
      winA.renderAll();

      helper.openForVideo({ videoId: 'MULTI_B', title: 'Second Simultaneous Window' });
      const winB = helper.activeWindows.get('MULTI_B');
      winB.status = 'done';
      winB.text = 'Content for second simultaneous window.';
      winB.renderAll();

      const openWindowsList = helper.getOpenWindows();
      const domBoxesCount = root?.querySelectorAll('.yt-window-box').length || 0;
      const hasResizeHandles = (winA.windowBox?.querySelectorAll('.yt-resize-handle')?.length || 0) >= 5;

      // Focus winA -> winA gets higher zIndex than winB
      const zBeforeFocus = parseInt(winA.windowBox?.style.zIndex || '0', 10);
      winA.focus();
      const zAfterFocus = parseInt(winA.windowBox?.style.zIndex || '0', 10);
      const zB = parseInt(winB.windowBox?.style.zIndex || '0', 10);

      // Resize winB to compact width (< 540px) and verify adaptive tier + overflow menu + options toggle + zero horizontal overflow
      winB.resizeWindow(420, 620);
      const compactTier = winB.windowBox?.getAttribute('data-size-tier');
      const hasCompactClass = winB.windowBox?.classList.contains('yt-win-compact');
      const overflowBtn = winB.windowBox?.querySelector('.yt-win-overflow-btn');
      const compactOptsBtn = winB.windowBox?.querySelector('.yt-compact-options-btn');
      const overflowBtnVisible = Boolean(overflowBtn && getComputedStyle(overflowBtn).display !== 'none');
      const compactOptsVisible = Boolean(compactOptsBtn && getComputedStyle(compactOptsBtn).display !== 'none');
      const compactNoHorizontalOverflow = winB.windowBox ? winB.windowBox.scrollWidth <= winB.windowBox.clientWidth + 2 : false;

      // Toggle overflow menu open in compact mode
      overflowBtn?.click();
      const overflowMenuCreated = Boolean(winB.windowBox?.querySelector('.yt-win-overflow-menu'));
      overflowBtn?.click();

      // Resize winB to wide width (>= 780px)
      winB.resizeWindow(840, 620);
      const wideTier = winB.windowBox?.getAttribute('data-size-tier');
      const hasWideClass = winB.windowBox?.classList.contains('yt-win-wide');
      const wideBounds = winB.bounds;

      // Verify short window class (< 460px height)
      winB.resizeWindow(640, 380);
      const hasShortClass = winB.windowBox?.classList.contains('yt-win-short');
      const hasMediumClass = winB.windowBox?.classList.contains('yt-win-medium');

      // Verify Escape minimizes focused window one at a time
      root?.querySelectorAll('.yt-key-dialog-scrim, .yt-history-dialog-scrim').forEach((d) => d.remove());
      winA.focus();
      window.__yt_test_allow_untrusted_events = true;
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      const aMinimizedFirst = !winA.isOpen && winB.isOpen;
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      const bothMinimizedSecond = !winA.isOpen && !winB.isOpen;
      window.__yt_test_allow_untrusted_events = false;

      winA.close();
      winB.close();
      root?.querySelectorAll('.yt-key-dialog-scrim, .yt-history-dialog-scrim').forEach((d) => d.remove());

      return {
        openCount: openWindowsList.length,
        domBoxesCount,
        hasResizeHandles,
        focusedRaisedZ: zAfterFocus > zBeforeFocus && zAfterFocus > zB,
        compactTier,
        hasCompactClass,
        overflowBtnVisible,
        compactOptsVisible,
        compactNoHorizontalOverflow,
        overflowMenuCreated,
        wideTier,
        hasWideClass,
        wideWidth: wideBounds?.width,
        hasShortClass,
        hasMediumClass,
        aMinimizedFirst,
        bothMinimizedSecond
      };
    });

    assert.equal(multiAndAdaptiveCheck.openCount, 2, 'Two summary windows remain open simultaneously without minimizing each other');
    assert.equal(multiAndAdaptiveCheck.domBoxesCount, 2, 'Two .yt-window-box elements render side-by-side in Shadow DOM');
    assert.ok(multiAndAdaptiveCheck.hasResizeHandles, 'Summary window includes edge/corner resize handles');
    assert.ok(multiAndAdaptiveCheck.focusedRaisedZ, 'Focusing an open window raises its z-index above sibling windows');
    assert.equal(multiAndAdaptiveCheck.compactTier, 'compact', 'Resizing window to 420px triggers compact size tier');
    assert.ok(multiAndAdaptiveCheck.hasCompactClass, 'Resizing window to 420px applies .yt-win-compact class');
    assert.ok(multiAndAdaptiveCheck.overflowBtnVisible, 'Compact window shows header overflow menu button (.yt-win-overflow-btn)');
    assert.ok(multiAndAdaptiveCheck.compactOptsVisible, 'Compact window shows collapsible options toggle (.yt-compact-options-btn)');
    assert.ok(multiAndAdaptiveCheck.compactNoHorizontalOverflow, 'Compact 420px window has no horizontal overflow');
    assert.ok(multiAndAdaptiveCheck.overflowMenuCreated, 'Clicking compact overflow button opens header actions dropdown (.yt-win-overflow-menu)');
    assert.equal(multiAndAdaptiveCheck.wideTier, 'wide', 'Resizing window to 840px transitions to wide size tier');
    assert.ok(multiAndAdaptiveCheck.hasWideClass, 'Resizing window to 840px applies .yt-win-wide class');
    assert.equal(multiAndAdaptiveCheck.wideWidth, 840, 'Programmatic resize persists exact window width');
    assert.ok(multiAndAdaptiveCheck.hasShortClass && multiAndAdaptiveCheck.hasMediumClass, 'Medium width + short height applies .yt-win-medium and .yt-win-short');
    assert.ok(multiAndAdaptiveCheck.aMinimizedFirst, 'First Escape minimizes focused window while keeping second open');
    assert.ok(multiAndAdaptiveCheck.bothMinimizedSecond, 'Second Escape minimizes remaining open window');
    passed += 16;

    // Check 41: Summary Symbol / LaTeX Formatting ($100^\circ\text{C}$ -> 100°C) while Preserving Currency
    const symbolCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      const sample = 'At 4,300 meters, atmospheric pressure drops significantly, causing the boiling point of water to fall from the sea-level standard of $100^\\circ\\text{C}$ to approximately $87^\\circ\\text{C}$. Budget stays $100 to $200.';

      const formatted = helper.formatMathSymbolsInText(sample);
      const speechClean = helper.cleanTextForSpeech(sample);

      for (const [, w] of Array.from(helper.activeWindows.entries())) {
        w.close();
      }
      helper.openForVideo({ videoId: 'SYM_VID_01', title: 'Symbol Formatting Video' });
      const win = helper.activeWindows.get('SYM_VID_01');
      win.mode = 'summary';
      win.status = 'done';
      win.text = sample;
      win.readabilityMode = false;
      win.renderAll();

      const standardBodyText = win.bodyEl?.textContent || '';

      win.readabilityMode = true;
      win.renderAll();
      const readabilityBodyText = win.bodyEl?.textContent || '';

      win.mode = 'transcript';
      win.text = `[00:10] ${sample}`;
      win.readabilityMode = false;
      win.renderAll();
      const transcriptBodyText = win.bodyEl?.textContent || '';

      win.close();

      return {
        formatted,
        speechClean,
        standardBodyText,
        readabilityBodyText,
        transcriptBodyText
      };
    });

    assert.ok(symbolCheck.formatted.includes('100°C') && symbolCheck.formatted.includes('87°C'), 'formatMathSymbolsInText converts $100^\\circ\\text{C}$ and $87^\\circ\\text{C}$ to 100°C and 87°C');
    assert.ok(symbolCheck.formatted.includes('$100 to $200'), 'formatMathSymbolsInText preserves currency strings "$100 to $200"');
    assert.ok(!symbolCheck.formatted.includes('\\circ') && !symbolCheck.formatted.includes('\\text'), 'formatMathSymbolsInText strips raw LaTeX \\circ and \\text commands');
    assert.ok(symbolCheck.speechClean.includes('100°C') && symbolCheck.speechClean.includes('87°C'), 'cleanTextForSpeech outputs clean degree notation without raw LaTeX');
    assert.ok(symbolCheck.standardBodyText.includes('100°C') && !symbolCheck.standardBodyText.includes('\\circ'), 'Standard summary DOM renders clean 100°C symbol');
    assert.ok(symbolCheck.readabilityBodyText.includes('87°C') && !symbolCheck.readabilityBodyText.includes('\\text'), 'Readability view DOM renders clean 87°C symbol');
    assert.ok(symbolCheck.transcriptBodyText.includes('100°C') && symbolCheck.transcriptBodyText.includes('$100 to $200'), 'Transcript view renders clean symbols while preserving currency');
    passed += 7;

    // Check 42: Extensive Auto-Title Replacement, DeArrow Coexistence & Settings Toggle Suite
    const extensiveTitleCheck = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      for (const [, w] of Array.from(helper.activeWindows.entries())) w.close();

      // Reset setting to default enabled
      helper.setAltTitlesEnabled(true);

      // 42a: Global DeArrow presence + thumbnail-only DeArrow card MUST still get AI title replacement
      const styleMarker = document.createElement('style');
      styleMarker.id = 'dearrow-styles';
      document.head.appendChild(styleMarker);
      window.dearrow = { installed: true };

      window.__yt_mock_transcripts = window.__yt_mock_transcripts || {};
      window.__yt_mock_transcripts['D_thumb_only_da'] =
        '[00:00] Detailed breakdown of solid-state sodium batteries achieving 400 Wh/kg at room temperature.';
      window.__yt_mock_transcripts['D_nested_yt_dom'] =
        '[00:00] Benchmarks of open-weight transformer quantization show 4-bit inference preserves 99 percent accuracy.';
      window.__yt_mock_transcripts['D_late_da_after_ai'] =
        '[00:00] Deep ocean hydrothermal vents host chemosynthetic microbes powered by hydrogen sulfide.';
      window.__yt_mock_transcripts['D_disabled_new_card'] =
        '[00:00] New photonic interconnect links achieve 1.6 terabits per second across datacenter racks.';

      const thumbOnlyCard = document.createElement('ytd-rich-item-renderer');
      thumbOnlyCard.id = 'card-thumb-only-da';
      thumbOnlyCard.innerHTML = `
        <div class="thumb"><div class="cbThumbnailButtonContainer" data-dearrow="true">Thumb</div></div>
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_thumb_only_da">YOU WON'T BELIEVE THIS BATTERY!!</a></h3></div>
        </div>
      `;
      document.body.appendChild(thumbOnlyCard);
      helper.processFeedCard(thumbOnlyCard);
      await new Promise((r) => setTimeout(r, 80));
      const thumbOnlyReplacedTitle = thumbOnlyCard.querySelector('#video-title')?.textContent?.trim();
      const thumbOnlyIsDeArrow = helper.isDeArrowPresent(thumbOnlyCard, thumbOnlyCard.querySelector('#video-title'));

      // 42b: Nested yt-formatted-string preservation inside <a id="video-title">
      const nestedCard = document.createElement('ytd-rich-item-renderer');
      nestedCard.id = 'card-nested-dom';
      nestedCard.innerHTML = `
        <div class="title-row">
          <div>
            <h3>
              <a id="video-title" href="/watch?v=D_nested_yt_dom">
                <yt-formatted-string class="yt-nested-label">INSANE AI TRICK BREAKS EVERYTHING!</yt-formatted-string>
              </a>
            </h3>
          </div>
        </div>
      `;
      document.body.appendChild(nestedCard);
      helper.processFeedCard(nestedCard);
      await new Promise((r) => setTimeout(r, 80));
      const nestedWrapperSurvived = Boolean(nestedCard.querySelector('#video-title yt-formatted-string.yt-nested-label'));
      const nestedReplacedText = nestedCard.querySelector('#video-title yt-formatted-string.yt-nested-label')?.textContent?.trim();

      // 42c: Late DeArrow arrival AFTER AI title already applied yields cleanly without losing _originalTitle
      const lateDaCard = document.createElement('ytd-rich-item-renderer');
      lateDaCard.id = 'card-late-da-after-ai';
      lateDaCard.innerHTML = `
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_late_da_after_ai">SECRET OCEAN MONSTERS?!</a></h3></div>
        </div>
      `;
      document.body.appendChild(lateDaCard);
      helper.processFeedCard(lateDaCard);
      await new Promise((r) => setTimeout(r, 80));
      const beforeLateDaTitle = lateDaCard.querySelector('#video-title')?.textContent?.trim();

      // Simulate DeArrow injecting container & title text 100ms after AI replaced it
      const lateTitleEl = lateDaCard.querySelector('#video-title');
      const lateParent = lateTitleEl.parentElement;
      const lateCb = document.createElement('div');
      lateCb.className = 'cbTitleButtonContainer';
      lateCb.innerHTML = '<button class="cbButton cbTitleButton"></button>';
      lateParent.insertBefore(lateCb, lateTitleEl.nextSibling);
      lateTitleEl.querySelector('a').textContent = 'Hydrothermal Vent Chemosynthetic Microbes Studied';
      helper.syncDeArrowState(lateDaCard);
      const lateModeAfterArrival = lateDaCard._currentTitleMode;
      const lateDearrowSaved = lateDaCard._dearrowTitle;
      const lateOriginalSaved = lateDaCard._originalTitle;
      const lateBtnClass = lateDaCard.querySelector('.yt-alt-title-btn')?.className || '';

      // 42d: Settings UI checkbox turns auto-title OFF -> reverts active AI cards immediately and leaves DeArrow card alone
      helper.openForVideo({ videoId: 'SETTINGS_TITLE_TEST', title: 'Settings Test' });
      const win = helper.activeWindows.get('SETTINGS_TITLE_TEST');
      await new Promise((r) => setTimeout(r, 50));
      const advBtn = Array.from(win.windowBox.querySelectorAll('.yt-link-btn')).find((b) =>
        b.textContent?.includes('Advanced')
      );
      if (advBtn) advBtn.click();
      await new Promise((r) => setTimeout(r, 40));
      const host = document.getElementById('yt-ai-summary-host');
      const settingsCb = win.windowBox?.querySelector('.yt-alt-titles-setting-checkbox') || host?.shadowRoot?.querySelector('.yt-alt-titles-setting-checkbox');
      const initialCbChecked = Boolean(settingsCb?.checked);

      // Uncheck via real click event on checkbox in Settings modal
      settingsCb.click();
      await new Promise((r) => setTimeout(r, 60));

      const enabledAfterUncheck = helper.getAltTitlesEnabled();
      const thumbTitleAfterDisable = thumbOnlyCard.querySelector('#video-title')?.textContent?.trim();
      const nestedTitleAfterDisable = nestedCard.querySelector('#video-title yt-formatted-string.yt-nested-label')?.textContent?.trim();
      const lateTitleAfterDisable = lateDaCard.querySelector('#video-title')?.textContent?.trim();

      // New card added while setting is OFF must NOT be auto-replaced
      const newCardOff = document.createElement('ytd-rich-item-renderer');
      newCardOff.id = 'card-while-off';
      newCardOff.innerHTML = `
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_disabled_new_card">UNBELIEVABLE PHOTONIC SPEED!</a></h3></div>
        </div>
      `;
      document.body.appendChild(newCardOff);
      helper.processFeedCard(newCardOff);
      await new Promise((r) => setTimeout(r, 80));
      const newCardOffTitle = newCardOff.querySelector('#video-title')?.textContent?.trim();

      // Re-check via real click -> restores AI titles on non-DeArrow cards, keeps DeArrow card on DeArrow title
      settingsCb.click();
      await new Promise((r) => setTimeout(r, 80));
      const enabledAfterRecheck = helper.getAltTitlesEnabled();
      const thumbTitleAfterReenable = thumbOnlyCard.querySelector('#video-title')?.textContent?.trim();
      const newCardAfterReenable = newCardOff.querySelector('#video-title')?.textContent?.trim();
      const lateTitleAfterReenable = lateDaCard.querySelector('#video-title')?.textContent?.trim();

      // 42e: In-flight async race — DeArrow injects container + title WHILE AI transcript fetch is mid-flight
      const origFetch = window.fetch.bind(window);
      window.fetch = async (...args) => {
        const res = await origFetch(...args);
        const url = String(args[0] || '');
        if (url.includes('/youtubei/v1/get_transcript')) {
          await new Promise((r) => setTimeout(r, 180));
        }
        return res;
      };
      const inflightCard = document.createElement('ytd-rich-item-renderer');
      inflightCard.id = 'card-inflight-race';
      inflightCard.innerHTML = `
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_async_inflight_race">MIDFLIGHT CLICKBAIT TITLE!!</a></h3></div>
        </div>
      `;
      document.body.appendChild(inflightCard);
      helper.processFeedCard(inflightCard);
      await new Promise((r) => setTimeout(r, 40));
      // DeArrow arrives while generateAlternativeTitle() is still awaiting fetch
      const raceTitleEl = inflightCard.querySelector('#video-title');
      const raceCb = document.createElement('div');
      raceCb.className = 'cbTitleButtonContainer';
      raceCb.innerHTML = '<button class="cbButton cbTitleButton"></button>';
      raceTitleEl.parentElement.insertBefore(raceCb, raceTitleEl.nextSibling);
      raceTitleEl.querySelector('a').textContent = 'DeArrow In-Flight Crowdsourced Title';
      helper.syncDeArrowState(inflightCard);
      // Wait for delayed AI fetch to finish and verify post-await guard prevented overwrite
      await new Promise((r) => setTimeout(r, 320));
      window.fetch = origFetch;
      const inflightModeFinal = inflightCard._currentTitleMode;
      const inflightTitleFinal = inflightCard.querySelector('#video-title')?.textContent?.trim();

      // 42f: AUD-05 Clickbait self-caching guard when offline/empty-transcript fallback yields cleanLines.length === 0
      const savedKeys42f = window.GM_getValue('keys', []);
      window.GM_setValue('keys', []);
      window.GM_deleteValue?.('alt_title:D_empty_cb_test');
      window.__yt_mock_transcripts['D_empty_cb_test'] = '[00:00] ## Header\n[00:05] [Music]\n[00:10] ok';
      const emptyFallbackResult = await helper.generateAlternativeTitle('D_empty_cb_test', 'SHOCKING CLICKBAIT ORIGINAL!');
      const emptyFallbackCached = window.GM_getValue('alt_title:D_empty_cb_test', null);
      window.GM_setValue('keys', savedKeys42f);

      // Clean up test DOM artifacts
      win.close();
      thumbOnlyCard.remove();
      nestedCard.remove();
      lateDaCard.remove();
      newCardOff.remove();
      inflightCard.remove();
      styleMarker.remove();
      delete window.dearrow;

      return {
        thumbOnlyIsDeArrow,
        thumbOnlyReplacedTitle,
        nestedWrapperSurvived,
        nestedReplacedText,
        beforeLateDaTitle,
        lateModeAfterArrival,
        lateDearrowSaved,
        lateOriginalSaved,
        lateBtnClass,
        initialCbChecked,
        enabledAfterUncheck,
        thumbTitleAfterDisable,
        nestedTitleAfterDisable,
        lateTitleAfterDisable,
        newCardOffTitle,
        enabledAfterRecheck,
        thumbTitleAfterReenable,
        newCardAfterReenable,
        lateTitleAfterReenable,
        inflightModeFinal,
        inflightTitleFinal,
        emptyFallbackResult,
        emptyFallbackCached
      };
    });

    assert.equal(extensiveTitleCheck.thumbOnlyIsDeArrow, false, 'Thumbnail-only DeArrow container and global #dearrow-styles do not falsely disable AI title replacement');
    assert.ok(extensiveTitleCheck.thumbOnlyReplacedTitle.includes('solid-state sodium batteries'), 'Thumbnail-only DeArrow card still gets factual AI title replacement');
    assert.equal(extensiveTitleCheck.nestedWrapperSurvived, true, 'Nested <yt-formatted-string> wrapper inside title link survives replacement intact');
    assert.ok(extensiveTitleCheck.nestedReplacedText.includes('open-weight transformer quantization'), 'Nested title wrapper displays replaced AI title');
    assert.ok(extensiveTitleCheck.beforeLateDaTitle.includes('hydrothermal vents'), 'Card initially shows AI title before late DeArrow arrives');
    assert.equal(extensiveTitleCheck.lateModeAfterArrival, 'dearrow', 'syncDeArrowState yields _currentTitleMode from ai to dearrow on late DeArrow update');
    assert.equal(extensiveTitleCheck.lateDearrowSaved, 'Hydrothermal Vent Chemosynthetic Microbes Studied', 'Late DeArrow title is captured accurately');
    assert.equal(extensiveTitleCheck.lateOriginalSaved, 'SECRET OCEAN MONSTERS?!', 'Original title stays preserved separately from DeArrow and AI titles');
    assert.ok(extensiveTitleCheck.lateBtnClass.includes('dearrow'), 'Switch button updates visually to DeArrow state after late arrival');
    assert.equal(extensiveTitleCheck.initialCbChecked, true, 'Settings checkbox for Alternative AI Titles is checked by default');
    assert.equal(extensiveTitleCheck.enabledAfterUncheck, false, 'Unchecking Settings checkbox persists disabled state');
    assert.equal(extensiveTitleCheck.thumbTitleAfterDisable, "YOU WON'T BELIEVE THIS BATTERY!!", 'Disabling in Settings immediately reverts AI-replaced title back to original');
    assert.equal(extensiveTitleCheck.nestedTitleAfterDisable, 'INSANE AI TRICK BREAKS EVERYTHING!', 'Disabling in Settings reverts nested yt-formatted-string title cleanly');
    assert.equal(extensiveTitleCheck.lateTitleAfterDisable, 'Hydrothermal Vent Chemosynthetic Microbes Studied', 'Disabling in Settings leaves DeArrow card on its DeArrow title');
    assert.equal(extensiveTitleCheck.newCardOffTitle, 'UNBELIEVABLE PHOTONIC SPEED!', 'New feed cards loaded while disabled keep original titles');
    assert.equal(extensiveTitleCheck.enabledAfterRecheck, true, 'Re-checking Settings checkbox re-enables auto-title replacement');
    assert.ok(extensiveTitleCheck.thumbTitleAfterReenable.includes('solid-state sodium batteries'), 'Re-enabling restores AI titles on existing non-DeArrow cards');
    assert.ok(extensiveTitleCheck.newCardAfterReenable.includes('photonic interconnect'), 'Re-enabling applies AI title to previously skipped cards');
    assert.equal(extensiveTitleCheck.lateTitleAfterReenable, 'Hydrothermal Vent Chemosynthetic Microbes Studied', 'Re-enabling continues yielding to DeArrow on DeArrow-active cards');
    assert.equal(extensiveTitleCheck.inflightModeFinal, 'dearrow', 'Mid-flight DeArrow arrival wins over async AI title completion');
    assert.equal(extensiveTitleCheck.inflightTitleFinal, 'DeArrow In-Flight Crowdsourced Title', 'In-flight async AI title generation never overwrites late DeArrow title');
    assert.equal(extensiveTitleCheck.emptyFallbackResult, null, 'AUD-05: Offline empty/placeholder transcript fallback returns null instead of originalTitle');
    assert.equal(extensiveTitleCheck.emptyFallbackCached, null, 'AUD-05: Original clickbait title is never persisted in alt_title cache on empty transcript fallback');
    passed += 23;

    // Check 43: Stage 2 Hardening — /shorts/ extraction, SPA card recycling, MutationObserver noise filtering, Trusted Types & batch cooldown circuit breaker
    const stage2Hardening = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      for (const [, w] of Array.from(helper.activeWindows.entries())) w.close();
      helper.setAltTitlesEnabled(true);
      helper.clearModelCooldowns();

      // 43a: AUD-03 ttsRateBtn clearEl re-render safely clears child spans without innerHTML
      helper.openForVideo({ videoId: 'STAGE2_TTS_CLEAR', title: 'Stage 2 TTS Clear Test' });
      const ttsWin = helper.activeWindows.get('STAGE2_TTS_CLEAR');
      ttsWin.status = 'done';
      ttsWin.text = 'Test TTS speed badge clearing without innerHTML.';
      ttsWin.renderAll();
      if (ttsWin.ttsRateBtn) {
        while (ttsWin.ttsRateBtn.firstChild) ttsWin.ttsRateBtn.removeChild(ttsWin.ttsRateBtn.firstChild);
        ttsWin.ttsRate = 1.5;
        ttsWin.updateTtsUI();
      }
      const rateBtnText = ttsWin.ttsRateBtn?.querySelector('.yt-tts-speed-text')?.textContent?.trim() || '';
      ttsWin.close();

      // 43b: AUD-04 /shorts/<id> URL extraction & title replacement
      window.__yt_mock_transcripts = window.__yt_mock_transcripts || {};
      window.__yt_mock_transcripts['S_shortsVid99'] =
        '[00:00] Compact CNC machining guide covering carbide feed rates in aluminum parts.';
      const shortsCard = document.createElement('ytd-reel-item-renderer');
      shortsCard.innerHTML = `
        <a id="thumbnail" href="/shorts/S_shortsVid99?feature=share"></a>
        <div class="title-row">
          <div><h3 id="video-title"><a href="/shorts/S_shortsVid99">INSANE METAL TRICK!</a></h3></div>
        </div>
      `;
      document.body.appendChild(shortsCard);
      const shortsExtractedId = helper.getCardVideoId(shortsCard);
      helper.processFeedCard(shortsCard);
      await new Promise((r) => setTimeout(r, 80));
      const shortsTitleAfter = shortsCard.querySelector('#video-title')?.textContent?.trim() || '';

      // 43c: AUD-04 SPA card recycling resets stale state cleanly for new videoId
      window.__yt_mock_transcripts['D_recycle_v1'] =
        '[00:00] First video explains solid electrolyte separator testing in pouch cells.';
      window.__yt_mock_transcripts['D_recycle_v2'] =
        '[00:00] Second video demonstrates open-source RISC-V vector extension benchmarks.';
      const recycleCard = document.createElement('ytd-rich-item-renderer');
      recycleCard.innerHTML = `
        <div class="title-row">
          <div><h3 id="video-title"><a href="/watch?v=D_recycle_v1">FIRST CLICKBAIT VIDEO!!</a></h3></div>
        </div>
      `;
      document.body.appendChild(recycleCard);
      helper.processFeedCard(recycleCard);
      await new Promise((r) => setTimeout(r, 80));
      const recycleV1Title = recycleCard.querySelector('#video-title')?.textContent?.trim() || '';

      // Simulate YouTube SPA recycling the SAME DOM element for D_recycle_v2
      const link = recycleCard.querySelector('#video-title a');
      link.setAttribute('href', '/watch?v=D_recycle_v2');
      link.textContent = 'SECOND RECYCLED CLICKBAIT!!';
      helper.processFeedCard(recycleCard);
      await new Promise((r) => setTimeout(r, 80));
      const recycleV2Id = recycleCard.dataset.ytaisVideoId || '';
      const recycleV2Title = recycleCard.querySelector('#video-title')?.textContent?.trim() || '';
      const recycleBtnCount = recycleCard.querySelectorAll('.yt-alt-title-btn').length;

      // 43d: AUD-02 MutationObserver ignores player time-tick & live-chat characterData noise
      const moviePlayer = document.createElement('div');
      moviePlayer.id = 'movie_player';
      const timeCur = document.createElement('span');
      timeCur.className = 'ytp-time-current';
      timeCur.textContent = '0:12';
      moviePlayer.appendChild(timeCur);
      const liveChat = document.createElement('yt-live-chat-app');
      liveChat.textContent = 'chat line 1';
      document.body.appendChild(moviePlayer);
      document.body.appendChild(liveChat);

      await new Promise((r) => setTimeout(r, 450));
      helper.resetFeedScanCount();
      const debugNoiseMuts = [];
      const dbgObs = new MutationObserver((muts) => {
        for (const m of muts) {
          if (helper.isFeedMutationRelevant(m)) {
            const t = m.target?.nodeType === 3 ? m.target.parentElement : m.target;
            debugNoiseMuts.push(`${m.type}:${t?.tagName || ''}#${t?.id || ''}.${t?.className || ''}`);
          }
        }
      });
      dbgObs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-dearrow', 'data-dearrow-title'] });
      timeCur.firstChild.data = '0:13';
      liveChat.firstChild.data = 'chat line 2';
      await new Promise((r) => setTimeout(r, 320));
      dbgObs.disconnect();
      const scansAfterNoise = helper.getFeedScanCount();

      // Trigger relevant card addition and confirm observer scans
      const freshCard = document.createElement('ytd-rich-item-renderer');
      freshCard.innerHTML = `<div class="title-row"><div><h3 id="video-title"><a href="/watch?v=D_observer_ping1">PING TITLE</a></h3></div></div>`;
      window.__yt_mock_transcripts['D_observer_ping1'] =
        '[00:00] Observer scan test transcript confirming dynamic feed updates trigger scanning.';
      document.body.appendChild(freshCard);
      await new Promise((r) => setTimeout(r, 280));
      const scansAfterFeedCard = helper.getFeedScanCount();

      // 43e: Batch alt-title HTTP 429 cooldown circuit breaker routes cleanly to secondary flash model
      const savedKeys43e = window.GM_getValue('keys', []);
      window.GM_setValue('keys', [{ id: 'k43e', name: 'Test', key: 'AIzaSyTest43e' }]);
      window.GM_deleteValue?.('alt_title:D_cooldown_card1');
      window.GM_deleteValue?.('alt_title:D_cooldown_card2');
      window.__yt_mock_transcripts['D_cooldown_card1'] = '[00:00] First card transcript for 429 circuit breaker failover verification.';
      window.__yt_mock_transcripts['D_cooldown_card2'] = '[00:00] Second card transcript verifying 3.8-flash stays skipped in cooldown.';
      const hitModels = [];
      const origGmReq = window.GM_xmlhttpRequest;
      window.GM_xmlhttpRequest = function (opts) {
        const url = String(opts.url || '');
        if (url.includes(':generateContent')) {
          hitModels.push(url);
          if (url.includes('gemini-3.8-flash')) {
            setTimeout(() => {
              opts.onload({
                status: 429,
                responseText: JSON.stringify({
                  error: {
                    message: 'Rate limit 3.8-flash',
                    details: [{ '@type': 'type.googleapis.com/google.rpc.RetryInfo', retryDelay: '30s' }]
                  }
                })
              });
            }, 10);
            return;
          }
          if (url.includes('gemini-3.7-flash')) {
            setTimeout(() => {
              opts.onload({
                status: 200,
                responseText: JSON.stringify({
                  candidates: [{ content: { parts: [{ text: 'Fallback Flash Factual Title Generated' }] } }]
                })
              });
            }, 10);
            return;
          }
        }
        return origGmReq(opts);
      };
      const cdRes1 = await helper.generateAlternativeTitle('D_cooldown_card1', 'CLICKBAIT CD 1');
      const cooldownSnapshot = helper.getModelCooldowns();
      const cdRes2 = await helper.generateAlternativeTitle('D_cooldown_card2', 'CLICKBAIT CD 2');
      window.GM_xmlhttpRequest = origGmReq;
      window.GM_setValue('keys', savedKeys43e);
      helper.clearModelCooldowns();

      shortsCard.remove();
      recycleCard.remove();
      freshCard.remove();
      moviePlayer.remove();
      liveChat.remove();

      return {
        rateBtnText,
        shortsExtractedId,
        shortsTitleAfter,
        recycleV1Title,
        recycleV2Id,
        recycleV2Title,
        recycleBtnCount,
        scansAfterNoise,
        debugNoiseMuts,
        scansAfterFeedCard,
        cdRes1,
        cdRes2,
        has38Cooldown: Boolean(cooldownSnapshot['gemini-3.8-flash']?.until > Date.now()),
        flash38HitCount: hitModels.filter((u) => u.includes('gemini-3.8-flash')).length,
        flash37HitCount: hitModels.filter((u) => u.includes('gemini-3.7-flash')).length
      };
    });

    assert.equal(stage2Hardening.rateBtnText, '1.5x', 'AUD-03: ttsRateBtn clearEl re-renders speed text cleanly without innerHTML');
    assert.equal(stage2Hardening.shortsExtractedId, 'S_shortsVid99', 'AUD-04: Extracts /shorts/<id> URLs accurately');
    assert.ok(stage2Hardening.shortsTitleAfter.includes('CNC machining guide'), 'AUD-04: Replaces /shorts/ feed card clickbait title');
    assert.ok(stage2Hardening.recycleV1Title.includes('electrolyte separator'), 'Recycled card initially shows v1 AI title');
    assert.equal(stage2Hardening.recycleV2Id, 'D_recycle_v2', 'AUD-04: SPA recycled card updates data-ytais-video-id to new video');
    assert.ok(stage2Hardening.recycleV2Title.includes('RISC-V vector extension'), 'AUD-04: SPA recycled card clears stale v1 metadata and applies v2 AI title');
    assert.equal(stage2Hardening.recycleBtnCount, 1, 'AUD-04: Recycled card cleanly replaces button without duplicating .yt-alt-title-btn');
    assert.equal(stage2Hardening.scansAfterNoise, 0, `AUD-02: MutationObserver ignores #movie_player timer & yt-live-chat characterData noise (muts=${JSON.stringify(stage2Hardening.debugNoiseMuts)})`);
    assert.ok(stage2Hardening.scansAfterFeedCard >= 1, 'AUD-02: MutationObserver still triggers scan when genuine feed card is inserted');
    assert.equal(stage2Hardening.cdRes1, 'Fallback Flash Factual Title Generated', 'Batch alt-title fails over cleanly on HTTP 429 to secondary flash model');
    assert.equal(stage2Hardening.has38Cooldown, true, 'HTTP 429 records per-model cooldown circuit breaker entry');
    assert.equal(stage2Hardening.flash38HitCount, 1, 'Circuit breaker skips cooled-down gemini-3.8-flash on subsequent batch card');
    assert.equal(stage2Hardening.flash37HitCount, 2, 'Subsequent card routes directly to non-cooled gemini-3.7-flash');
    passed += 13;

    // Check 44: Stage 3 Accessibility, Keyboard Window Ergonomics, Non-Blocking Toasts, ARIA Live Regions & Mobile (<400px) Hardening
    const stage3Pre = await page.evaluate(async () => {
      const helper = window.__yt_summariser_test;
      for (const [, w] of Array.from(helper.activeWindows.entries())) w.close();
      window.__yt_test_allow_untrusted_events = true;
      window.__alertFired = false;
      const origAlert = window.alert;
      window.alert = () => {
        window.__alertFired = true;
      };

      // Open window for Stage 3 verification
      helper.openForVideo({ videoId: 'STAGE3_A11Y', title: 'Stage 3 Accessibility Video' });
      const win = helper.activeWindows.get('STAGE3_A11Y');
      win.status = 'done';
      win.text = '## TL;DR\nBoiling point drops to $87^\\circ\\text{C}$ at altitude.';
      win.applyWindowBounds({ left: 220, top: 160, width: 640, height: 480 }, true);
      win.maximize();
      win.renderAll();

      const host = document.getElementById('yt-ai-summary-host');
      const root = host?.shadowRoot;
      const handleEls = Array.from(root?.querySelectorAll('.yt-resize-handle') || []);
      const dirs = handleEls.map((el) => el.getAttribute('data-resize-dir')).sort();
      const allHandlesFocusable = handleEls.every(
        (el) => el.getAttribute('role') === 'separator' && el.getAttribute('tabindex') === '0'
      );

      // Save reference to NW handle BEFORE minimize to prove mousedown cleanup detaches it cleanly
      const nwHandleBeforeMin = root?.querySelector('.yt-resize-handle-nw');
      const dragGrip = root?.querySelector('.yt-win-drag-grip');

      // Test 44a: Pointer North-West corner drag upwards + left
      const boundsBeforeDrag = { ...win.bounds };
      const nwRect = nwHandleBeforeMin.getBoundingClientRect();
      nwHandleBeforeMin.dispatchEvent(new MouseEvent('mousedown', { button: 0, clientX: nwRect.left + 4, clientY: nwRect.top + 4, bubbles: true }));
      document.dispatchEvent(new MouseEvent('mousemove', { clientX: nwRect.left - 26, clientY: nwRect.top - 24, bubbles: true }));
      document.dispatchEvent(new MouseEvent('mouseup', { clientX: nwRect.left - 26, clientY: nwRect.top - 24, bubbles: true }));
      const boundsAfterNwDrag = { ...win.bounds };

      // Test 44b: Keyboard Arrow move on grip & Arrow resize on N / SE separators (without triggering TTS!)
      const spokenBeforeKeys = (window.__tts_spoken || []).length;
      dragGrip?.focus();
      dragGrip?.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true }));
      dragGrip?.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', shiftKey: true, bubbles: true, cancelable: true }));
      const boundsAfterGripKeys = { ...win.bounds };

      const nHandle = root?.querySelector('.yt-resize-handle-n');
      nHandle?.focus();
      nHandle?.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true, cancelable: true }));
      const boundsAfterNorthKey = { ...win.bounds };

      const seHandle = root?.querySelector('.yt-resize-handle-se');
      seHandle?.focus();
      seHandle?.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', shiftKey: true, bubbles: true, cancelable: true }));
      const boundsAfterSeKey = { ...win.bounds };
      const spokenAfterKeys = (window.__tts_spoken || []).length;

      // Test 44c: ARIA live region on minimize -> orphaned mousedown leak check -> maximize restore
      win.minimize();
      const liveAfterMin = root?.querySelector('[data-ytais-live-region]')?.textContent?.trim() || '';
      const cleanupLenAfterMin = win._interactionCleanup.length;
      const boundsSnapshotAtMin = { ...win.bounds };
      nwHandleBeforeMin.dispatchEvent(new MouseEvent('mousedown', { button: 0, clientX: 50, clientY: 50, bubbles: true }));
      document.dispatchEvent(new MouseEvent('mousemove', { clientX: 120, clientY: 120, bubbles: true }));
      document.dispatchEvent(new MouseEvent('mouseup', { clientX: 120, clientY: 120, bubbles: true }));
      const boundsAfterOrphanedDown = { ...win.bounds };
      const orphanedCleanupLen = win._interactionCleanup.length;

      win.maximize();
      const liveAfterRestore = root?.querySelector('[data-ytais-live-region]')?.textContent?.trim() || '';

      // Rating announcement
      const upBtn = root?.querySelector('.yt-rating-up-btn');
      upBtn?.click();
      const liveAfterRatingUp = root?.querySelector('[data-ytais-live-region]')?.textContent?.trim() || '';
      upBtn?.click(); // toggle clear
      const liveAfterRatingClear = root?.querySelector('[data-ytais-live-region]')?.textContent?.trim() || '';

      // Ask fallback announcement + Toast without alert()
      const origAskErrKeys = window.GM_getValue('keys', []);
      window.GM_setValue('keys', [{ id: 'k44', name: 'Test', key: 'AIzaSyValidKey' }]);
      window.GM_setValue('clear_cmds_before', 1);
      const clearCmd = window.__gm_commands?.['Clear cached summaries (keeps open windows)'];
      if (typeof clearCmd === 'function') clearCmd();
      const toastEl = root?.querySelector('.yt-global-toast');
      const toastVisible = Boolean(toastEl?.classList?.contains('yt-global-toast-show'));
      const toastMsg = toastEl?.textContent?.trim() || '';

      const altToggleName = Object.keys(window.__gm_commands || {}).find((k) => k.startsWith('Toggle Alternative AI Titles'));
      if (altToggleName) window.__gm_commands[altToggleName]();
      const toastAfterAltToggle = root?.querySelector('.yt-global-toast')?.textContent?.trim() || '';
      // Restore alt titles ON
      if (altToggleName) window.__gm_commands[altToggleName]();

      window.GM_setValue('keys', origAskErrKeys);
      window.alert = origAlert;

      return {
        dirs,
        allHandlesFocusable,
        hasDragGrip: Boolean(dragGrip && dragGrip.getAttribute('tabindex') === '0'),
        boundsBeforeDrag,
        boundsAfterNwDrag,
        boundsAfterGripKeys,
        boundsAfterNorthKey,
        boundsAfterSeKey,
        spokenDelta: spokenAfterKeys - spokenBeforeKeys,
        liveAfterMin,
        cleanupLenAfterMin,
        boundsSnapshotAtMin,
        boundsAfterOrphanedDown,
        orphanedCleanupLen,
        liveAfterRestore,
        liveAfterRatingUp,
        liveAfterRatingClear,
        alertFired: window.__alertFired,
        toastVisible,
        toastMsg,
        toastAfterAltToggle
      };
    });

    assert.deepEqual(stage3Pre.dirs, ['e', 'n', 'ne', 'nw', 's', 'se', 'sw', 'w'], 'AUD-06: Renders all 8 edge/corner resize handles including n, nw, ne');
    assert.ok(stage3Pre.allHandlesFocusable, 'FEAT-05: All 8 resize handles carry role="separator" and tabindex="0"');
    assert.ok(stage3Pre.hasDragGrip, 'FEAT-05: Header drag grip is keyboard-focusable with tabindex="0"');
    assert.ok(stage3Pre.boundsAfterNwDrag.width > stage3Pre.boundsBeforeDrag.width, 'AUD-06: North-west drag expands window width leftward');
    assert.ok(stage3Pre.boundsAfterNwDrag.height > stage3Pre.boundsBeforeDrag.height, 'AUD-06: North-west drag expands window height upward');
    assert.equal(stage3Pre.boundsAfterGripKeys.left, stage3Pre.boundsAfterNwDrag.left + 16, 'FEAT-05: ArrowRight on drag grip shifts left by 16px');
    assert.equal(stage3Pre.boundsAfterGripKeys.top, stage3Pre.boundsAfterNwDrag.top + 48, 'FEAT-05: Shift+ArrowDown on drag grip shifts top by 48px');
    assert.equal(stage3Pre.boundsAfterNorthKey.height, stage3Pre.boundsAfterGripKeys.height + 16, 'FEAT-05: ArrowUp on N handle expands height by 16px');
    assert.equal(stage3Pre.boundsAfterSeKey.width, stage3Pre.boundsAfterNorthKey.width + 48, 'FEAT-05: Shift+ArrowRight on SE handle expands width by 48px');
    assert.equal(stage3Pre.spokenDelta, 0, 'FEAT-05: Keyboard window arrows do not trigger TTS playback');
    assert.ok(stage3Pre.liveAfterMin.includes('Minimized'), 'FEAT-05: ARIA live region announces window minimization');
    assert.equal(stage3Pre.cleanupLenAfterMin, 0, 'AUD-06: minimize() clears all _interactionCleanup handle listeners');
    assert.deepEqual(stage3Pre.boundsAfterOrphanedDown, stage3Pre.boundsSnapshotAtMin, 'AUD-06: Orphaned handle mousedown after minimize is completely detached');
    assert.equal(stage3Pre.orphanedCleanupLen, 0, 'AUD-06: Orphaned handle attaches zero document listeners after minimize');
    assert.ok(stage3Pre.liveAfterRestore.includes('Restored'), 'FEAT-05: ARIA live region announces window restore');
    assert.equal(stage3Pre.liveAfterRatingUp, 'Thumbs up rating saved', 'FEAT-05: ARIA live region announces thumbs up rating saved');
    assert.equal(stage3Pre.liveAfterRatingClear, 'Rating cleared', 'FEAT-05: ARIA live region announces rating cleared');
    assert.equal(stage3Pre.alertFired, false, 'AUD-07: Menu commands never invoke blocking window.alert()');
    assert.ok(stage3Pre.toastVisible && stage3Pre.toastMsg.includes('Cached summaries cleared'), 'AUD-07: Non-blocking Shadow DOM global toast renders status feedback');
    assert.ok(stage3Pre.toastAfterAltToggle.includes('Alternative AI Titles'), 'AUD-07: Alternative AI Titles menu toggle emits non-blocking toast');
    passed += 20;

    // 44d: Mobile narrow viewport (<400px) stress verification inside Userscript
    await page.setViewportSize({ width: 375, height: 700 });
    await page.waitForTimeout(120);
    const mobileViewportCheck = await page.evaluate(() => {
      const helper = window.__yt_summariser_test;
      for (const [, w] of Array.from(helper.activeWindows.entries())) w.close();
      helper.openForVideo({ videoId: 'STAGE3_MOBILE', title: 'Mobile Narrow Viewport Test' });
      const win = helper.activeWindows.get('STAGE3_MOBILE');
      win.status = 'done';
      win.text = 'Mobile layout fits comfortably inside 375px.';
      win.maximize();
      win.renderAll();

      const host = document.getElementById('yt-ai-summary-host');
      const winBox = host?.shadowRoot?.querySelector('.yt-window-box');
      const rect = winBox?.getBoundingClientRect();
      const tier = winBox?.getAttribute('data-size-tier');
      const overflowBtnDisplay = winBox?.querySelector('.yt-win-overflow-btn')
        ? window.getComputedStyle(winBox.querySelector('.yt-win-overflow-btn')).display
        : '';
      const docOverflow = document.documentElement.scrollWidth > window.innerWidth;
      win.close();
      return {
        innerWidth: window.innerWidth,
        boundsWidth: win.bounds.width,
        rectWidth: rect?.width || 0,
        rectRight: rect?.right || 0,
        rectLeft: rect?.left || 0,
        tier,
        overflowBtnDisplay,
        docOverflow
      };
    });
    await page.setViewportSize({ width: 1280, height: 800 });

    assert.ok(mobileViewportCheck.boundsWidth <= 375 - 16, 'AUD-09: Mobile 375px viewport clamps window width with >=8px margins');
    assert.ok(mobileViewportCheck.rectLeft >= 8 && mobileViewportCheck.rectRight <= 375 - 8, 'AUD-09: Rendered window stays completely inside 375px viewport');
    assert.equal(mobileViewportCheck.tier, 'compact', 'AUD-09: Mobile viewport automatically enters compact window tier');
    assert.notEqual(mobileViewportCheck.overflowBtnDisplay, 'none', 'AUD-09: Mobile compact tier displays header overflow button');
    assert.equal(mobileViewportCheck.docOverflow, false, 'AUD-09: Mobile viewport introduces zero page horizontal overflow');
    passed += 5;

    console.log(`✓ Suite 1 passed: ${passed} checks verified.`);
    return { passed, total: passed };
  } finally {
    await harness.browser.close();
  }
}
