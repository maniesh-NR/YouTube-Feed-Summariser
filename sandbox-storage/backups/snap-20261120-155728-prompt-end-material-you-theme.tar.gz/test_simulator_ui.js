import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from 'playwright';
import { createServer } from 'vite';

export async function runSimulatorUiTests() {
  console.log('\n--- Running Test Suite 5: React Simulator Parity, Accessibility & Mobile Stress ---');
  let passed = 0;
  let server;
  let browser;

  try {
    server = await createServer({
      server: {
        host: '127.0.0.1',
        port: 0,
        hmr: false,
        watch: null
      },
      logLevel: 'silent'
    });
    await server.listen();
    const address = server.httpServer?.address();
    const port = typeof address === 'object' && address ? address.port : 4173;
    const baseUrl = `http://127.0.0.1:${port}/`;

    let executablePath = undefined;
    const knownPaths = [
      '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
      '/ms-playwright/chrome-headless-shell-linux64/chrome-headless-shell'
    ];
    for (const p of knownPaths) {
      if (fs.existsSync(p)) {
        executablePath = p;
        break;
      }
    }

    browser = await chromium.launch({
      headless: true,
      executablePath,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const context = await browser.newContext({
      viewport: { width: 1440, height: 900 }
    });
    const page = await context.newPage();

    const pageErrors = [];
    page.on('pageerror', (err) => pageErrors.push(err.message));

    let dialogTriggered = false;
    page.on('dialog', async (d) => {
      dialogTriggered = true;
      await d.dismiss();
    });

    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.waitForSelector('h1');

    // 1. Open first two video summary windows via 3-dot card menus
    const menuButtons = page.locator('button[title="Action menu"]');
    await menuButtons.nth(0).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');

    // Minimize window 1 first so card 2 3-dot menu is unobscured
    await page.locator('.yt-window-box[data-video-id="D_clickbait_chip"] button[aria-label="Minimize window"]').click();
    await page.waitForTimeout(100);
    const liveAfterMin = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterMin || '').includes('Minimized'), 'Simulator ARIA live region announces window minimization');
    passed++;

    await menuButtons.nth(1).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_space_webb"]');

    // Restore window 1 via dock tab
    const restoreBtn = page.locator('button[title="Restore window"]').first();
    await restoreBtn.click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const liveAfterRestore = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterRestore || '').includes('Restored'), 'Simulator ARIA live region announces window restoration');
    passed++;

    // 2. Verify all 8 resize handles + keyboard move/resize + north drag in Simulator
    const win1 = page.locator('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const handleDirs = await win1.locator('.yt-resize-handle').evaluateAll((els) =>
      els.map((el) => el.getAttribute('data-resize-dir')).sort()
    );
    assert.deepEqual(handleDirs, ['e', 'n', 'ne', 'nw', 's', 'se', 'sw', 'w'], 'Simulator renders all 8 resize handles');
    passed++;

    const boxBefore = await win1.boundingBox();
    const grip = win1.locator('.yt-win-drag-grip');
    await grip.focus();
    await page.keyboard.press('ArrowRight');
    await page.keyboard.press('Shift+ArrowDown');
    const boxAfterGrip = await win1.boundingBox();
    assert.ok(boxAfterGrip && boxBefore && Math.round(boxAfterGrip.x - boxBefore.x) === 16, 'Simulator grip ArrowRight moves left +16px');
    assert.ok(boxAfterGrip && boxBefore && Math.round(boxAfterGrip.y - boxBefore.y) === 48, 'Simulator grip Shift+ArrowDown moves top +48px');
    passed += 2;

    const northHandle = win1.locator('[data-resize-dir="n"]');
    await northHandle.focus();
    await page.keyboard.press('ArrowUp');
    const boxAfterNorth = await win1.boundingBox();
    assert.ok(boxAfterNorth && boxAfterGrip && Math.round(boxAfterNorth.height - boxAfterGrip.height) === 16, 'Simulator N handle ArrowUp expands height +16px');
    passed++;

    // 3. Multi-window per-card toast isolation
    await win1.locator('.yt-tts-skip-silence-btn').click();
    const toastWin1Visible = await page.locator('[data-toast-video-id="D_clickbait_chip"]').isVisible();
    const toastWin2Count = await page.locator('[data-toast-video-id="D_space_webb"]').count();
    assert.ok(toastWin1Visible, 'Simulator renders scoped TTS toast inside triggered window');
    assert.equal(toastWin2Count, 0, 'Simulator TTS toast isolates strictly to target video window');
    passed++;

    // 4. Compact Options persistence across page reload
    const seHandle = win1.locator('[data-resize-dir="se"]');
    const seBox = await seHandle.boundingBox();
    if (seBox && boxAfterNorth) {
      await page.mouse.move(seBox.x + seBox.width / 2, seBox.y + seBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(boxAfterNorth.x + 420, boxAfterNorth.y + 420, { steps: 6 });
      await page.mouse.up();
    }
    const tierAfterResize = await win1.getAttribute('data-size-tier');
    assert.equal(tierAfterResize, 'compact', 'Resizing Simulator window below 540px enters compact tier');
    const compactOptsBtn = win1.locator('.yt-compact-options-btn');
    await compactOptsBtn.click();
    const storedCompactOpts = await page.evaluate(() => localStorage.getItem('yt_compact_options_expanded'));
    assert.ok(storedCompactOpts && storedCompactOpts.includes('"D_clickbait_chip":true'), 'Simulator persists compact Options disclosure to localStorage');
    passed += 2;

    // 5. ARIA rating announcement + YouTube Ask fallback transition announcement
    const ratingUpBtn = win1.locator('.yt-rating-up').first();
    await ratingUpBtn.click();
    const liveAfterRating = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.equal(liveAfterRating, 'Thumbs up rating saved', 'Simulator ARIA live region announces thumbs up rating persistence');
    passed++;

    // Select Ask + Simulate Ask failure -> click Regenerate
    const modelSelect = win1.locator('select[aria-label="Gemini Model Selector"]');
    const hasAskOption = await win1.locator('option[value="Ask"]').count();
    assert.ok(hasAskOption > 0, 'Simulator exposes YouTube Ask option in model selector');
    await modelSelect.selectOption('Ask');
    const failToggle = win1.locator('label:has-text("Simulate Ask failure") input[type="checkbox"]');
    await failToggle.check();
    await win1.locator('button:has-text("Regenerate")').click();
    const liveAfterAsk = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.ok((liveAfterAsk || '').includes('YouTube Ask failed, switched to'), 'Simulator ARIA live region announces Ask fallback model transition');
    passed++;

    // Reload persistence check for compact Options state
    await page.reload({ waitUntil: 'networkidle' });
    await page.locator('button[title="Action menu"]').nth(0).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const storedAfterReload = await page.evaluate(() => localStorage.getItem('yt_compact_options_expanded'));
    assert.ok(storedAfterReload && storedAfterReload.includes('"D_clickbait_chip":true'), 'Compact Options preference survives page reload');
    passed++;

    // 5b. Stage 4 FEAT-01 (Interactive Timestamp Jump + Follow-Along Lock) & FEAT-03 (Summary Persona persistence)
    const winReloaded = page.locator('.yt-window-box[data-video-id="D_clickbait_chip"]');
    const tsBtn = winReloaded.locator('.yt-ts-jump-btn[data-seek-ts="[02:15]"]').first();
    await tsBtn.click();
    const liveAfterSeek = await page.locator('[data-ytais-live-region="true"]').textContent();
    assert.equal(liveAfterSeek, 'Jumped to 02:15', 'Simulator ARIA live region announces timestamp seek');
    assert.ok(await winReloaded.locator('[data-seek-banner="[02:15]"]').isVisible(), 'Simulator shows active seek banner at [02:15]');
    passed += 2;

    // Switch to Transcribe tab and verify Follow-Along Lock toggle + highlighted cue
    await winReloaded.locator('button:has-text("Transcribe")').click();
    const followAlongBtn = winReloaded.locator('.yt-follow-along-btn');
    assert.equal(await followAlongBtn.getAttribute('aria-pressed'), 'true', 'Simulator Follow-Along Lock defaults to true');
    await followAlongBtn.click();
    assert.equal(await followAlongBtn.getAttribute('aria-pressed'), 'false', 'Simulator Follow-Along Lock toggles off');
    passed += 2;

    // Switch Summary Persona to Deep Technical / Code -> updates prompt inspector -> survives reload
    const personaSelect = winReloaded.locator('select.yt-persona-select');
    await personaSelect.selectOption('technical');
    const promptPreview = await winReloaded.locator('.yt-system-prompt-preview').textContent();
    assert.ok((promptPreview || '').includes('Principal Systems Engineer'), 'Simulator persona selector updates live Gemini systemInstruction');
    passed++;

    // 5c. Stage 4 FEAT-02 Per-channel auto-title Exempt rule updates card title & survives reload
    // Minimize window so card header is unobstructed
    await winReloaded.locator('button[aria-label="Minimize window"]').click();
    const firstCard = page.locator('[data-card-video-id="D_clickbait_chip"]');
    await firstCard.locator('.yt-channel-rule-btn').click();
    await firstCard.locator('.yt-channel-rule-menu [data-rule-option="exempt"]').click();
    const firstCardTitleAfterExempt = await firstCard.locator('.yt-card-display-title').textContent();
    assert.equal(firstCardTitleAfterExempt, 'New RISC-V 128-Core Server Processor Announced', 'FEAT-02: Setting Tech Frontier Exempt yields immediately to DeArrow');

    await page.reload({ waitUntil: 'networkidle' });
    const persistedPersona = await page.evaluate(() => localStorage.getItem('yt_summary_persona'));
    const persistedChannelRules = await page.evaluate(() => localStorage.getItem('yt_channel_title_rules'));
    assert.equal(persistedPersona, 'technical', 'FEAT-03: Persona preset survives page reload');
    assert.ok((persistedChannelRules || '').includes('"tech frontier":"exempt"'), 'FEAT-02: Channel rule survives page reload');
    // Re-open window before mobile layout stress test
    await page.locator('button[title="Action menu"]').nth(0).click();
    await page.locator('span:text-is("Summarize")').first().click();
    await page.waitForSelector('.yt-window-box[data-video-id="D_clickbait_chip"]');
    passed += 3;

    // 5d. Stage 5 FEAT-04 Long-video Chapter Bar + FEAT-06 Markdown (.md) Export triggers
    await winReloaded.locator('button[aria-label="Minimize window"]').click();
    const longCard = page.locator('[data-card-video-id="D_long_lecture"]');
    await longCard.locator('button[title="Action menu"]').click();
    await page.locator('span:text-is("Summarize")').first().click();
    const winLong = page.locator('.yt-window-box[data-video-id="D_long_lecture"]');
    await winLong.waitFor();
    const chapterCount = await winLong.locator('.yt-chapter-btn').count();
    assert.equal(chapterCount, 4, 'FEAT-04: Simulator renders 4 chapter navigation buttons for D_long_lecture');
    const chunkMeta = await winLong.locator('.yt-chapter-meta').textContent();
    assert.ok((chunkMeta || '').includes('>45m'), 'FEAT-04: Simulator displays >45m chapter-aware chunked badge');
    const secChapBtn = winLong.locator('.yt-chapter-btn[data-chapter-ts="[14:20]"]');
    await secChapBtn.click();
    assert.ok((await winLong.locator('[data-seek-banner="[14:20]"]').isVisible()), 'FEAT-04: Clicking chapter button seeks to [14:20]');
    assert.equal(await page.locator('[data-ytais-live-region="true"]').textContent(), 'Jumped to 14:20', 'FEAT-04: Chapter jump updates ARIA live region');

    await winLong.locator('.yt-win-export-btn').click();
    assert.ok(await winLong.locator('.yt-export-md-btn').isVisible(), 'FEAT-06: Export menu exposes Markdown / Obsidian (.md) button');
    await winLong.locator('.yt-export-md-btn').click();
    assert.ok(await page.locator('[data-ytais-live-region="true"]').textContent() === 'Exported Obsidian Markdown bundle', 'FEAT-06: Clicking Export .md announces export completion');

    await winLong.locator('.yt-win-readability-btn').click();
    assert.ok(await winLong.locator('.yt-readability-export-md-btn').isVisible(), 'FEAT-06: Readability mode exposes Export .md button');
    await winLong.locator('.yt-readability-exit-btn').click();
    passed += 7;

    // 6. Mobile narrow viewport (<400px) & multi-width TTS control bar scaling zero-overflow stress test
    // First check wide/desktop TTS fit
    const desktopTtsMetrics = await page.evaluate(() => {
      const winBox = document.querySelector('.yt-window-box[data-video-id="D_long_lecture"]');
      const ttsBar = winBox?.querySelector('.yt-tts-control-bar');
      const speedBtns = winBox?.querySelector('.yt-tts-speed-btns');
      const winRect = winBox?.getBoundingClientRect();
      const ttsRect = ttsBar?.getBoundingClientRect();
      return {
        tier: winBox?.getAttribute('data-size-tier'),
        ttsFitsInsideWin: Boolean(winRect && ttsRect && ttsRect.right <= winRect.right + 1.5 && ttsRect.left >= winRect.left - 1.5),
        ttsNoScrollOverflow: Boolean(ttsBar && ttsBar.scrollWidth <= ttsBar.clientWidth + 2),
        speedBtnsDisplay: speedBtns ? getComputedStyle(speedBtns).display : 'none'
      };
    });
    assert.ok(desktopTtsMetrics.ttsFitsInsideWin, 'Desktop Simulator TTS bar fits within floating window bounds');
    assert.ok(desktopTtsMetrics.ttsNoScrollOverflow, 'Desktop Simulator TTS bar has no internal horizontal overflow');
    assert.notEqual(desktopTtsMetrics.speedBtnsDisplay, 'none', 'Desktop Simulator keeps granular speed buttons visible');

    // Resize floating window to compact (420px) and medium (620px) via SE handle or viewport
    await page.setViewportSize({ width: 620, height: 812 });
    await page.waitForTimeout(120);
    const mediumTtsMetrics = await page.evaluate(() => {
      const winBox = document.querySelector('.yt-window-box[data-video-id="D_long_lecture"]');
      const ttsBar = winBox?.querySelector('.yt-tts-control-bar');
      const speedBtns = winBox?.querySelector('.yt-tts-speed-btns');
      const winRect = winBox?.getBoundingClientRect();
      const ttsRect = ttsBar?.getBoundingClientRect();
      return {
        tier: winBox?.getAttribute('data-size-tier'),
        compactAttr: ttsBar?.getAttribute('data-compact-tts'),
        ttsFitsInsideWin: Boolean(winRect && ttsRect && ttsRect.right <= winRect.right + 1.5 && ttsRect.left >= winRect.left - 1.5),
        ttsNoScrollOverflow: Boolean(ttsBar && ttsBar.scrollWidth <= ttsBar.clientWidth + 2),
        speedBtnsDisplay: speedBtns ? getComputedStyle(speedBtns).display : 'none'
      };
    });
    assert.equal(mediumTtsMetrics.compactAttr, 'true', '620px viewport activates compact TTS bar attribute');
    assert.ok(mediumTtsMetrics.ttsFitsInsideWin && mediumTtsMetrics.ttsNoScrollOverflow, 'Medium Simulator TTS bar wraps cleanly without clipping');
    assert.notEqual(mediumTtsMetrics.speedBtnsDisplay, 'none', 'Medium Simulator keeps wrapping speed buttons visible');

    await page.setViewportSize({ width: 375, height: 812 });
    await page.waitForTimeout(150);
    const mobileMetrics = await page.evaluate(() => {
      const winBox = document.querySelector('.yt-window-box[data-video-id="D_long_lecture"]');
      const ttsBar = winBox?.querySelector('.yt-tts-control-bar');
      const speedBtns = winBox?.querySelector('.yt-tts-speed-btns');
      const rect = winBox?.getBoundingClientRect();
      const ttsRect = ttsBar?.getBoundingClientRect();
      return {
        innerWidth: window.innerWidth,
        docScrollWidth: document.documentElement.scrollWidth,
        winLeft: rect?.left || 0,
        winRight: rect?.right || 0,
        winWidth: rect?.width || 0,
        tier: winBox?.getAttribute('data-size-tier'),
        ttsFitsInsideWin: Boolean(rect && ttsRect && ttsRect.right <= rect.right + 1.5 && ttsRect.left >= rect.left - 1.5),
        ttsNoScrollOverflow: Boolean(ttsBar && ttsBar.scrollWidth <= ttsBar.clientWidth + 2),
        speedBtnsDisplay: speedBtns ? getComputedStyle(speedBtns).display : 'none'
      };
    });
    assert.ok(mobileMetrics.docScrollWidth <= mobileMetrics.innerWidth, `Mobile 375px Simulator has zero horizontal overflow (${mobileMetrics.docScrollWidth} <= ${mobileMetrics.innerWidth})`);
    assert.ok(mobileMetrics.winLeft >= 0 && mobileMetrics.winRight <= mobileMetrics.innerWidth, `Mobile 375px floating window fits inside viewport (${mobileMetrics.winLeft}..${mobileMetrics.winRight} <= ${mobileMetrics.innerWidth})`);
    assert.equal(mobileMetrics.tier, 'compact', 'Mobile 375px Simulator enters compact tier');
    assert.ok(mobileMetrics.ttsFitsInsideWin && mobileMetrics.ttsNoScrollOverflow, 'Mobile 375px Simulator TTS bar wraps cleanly inside compact window');
    assert.equal(mobileMetrics.speedBtnsDisplay, 'none', 'Mobile 375px compact Simulator collapses speed pills cleanly while keeping speed slider');
    assert.equal(dialogTriggered, false, 'Simulator emits zero blocking alert/confirm dialogs');
    assert.equal(pageErrors.length, 0, `Zero runtime page errors (${pageErrors.join('; ')})`);
    passed += 12;

    // 7. FEAT-07 Interactive Multi-Host Podcast Studio inside React Simulator (desktop & 375px mobile)
    await page.setViewportSize({ width: 1280, height: 860 });
    await page.waitForTimeout(100);
    await winLong.locator('.yt-podcast-mode-btn').click();
    await winLong.locator('.yt-podcast-studio').waitFor({ state: 'visible' });

    // Configure 4 hosts & generate podcast
    await winLong.locator('.yt-podcast-host-count-select').selectOption('4');
    await page.waitForFunction(() => document.querySelectorAll('.yt-podcast-host-card').length === 4);
    await winLong.locator('.yt-podcast-generate-btn').click();
    await winLong.locator('.yt-podcast-player-card').waitFor({ state: 'visible' });

    const simPodcastInfo = await page.evaluate(() => {
      const box = document.querySelector('.yt-window-box[data-video-id="D_long_lecture"]');
      const turns = Array.from(box?.querySelectorAll('.yt-podcast-turn') || []);
      const speakers = new Set(turns.map((el) => el.querySelector('.yt-podcast-turn-speaker')?.textContent?.trim()));
      const hostNames = Array.from(box?.querySelectorAll('.yt-podcast-host-name-input') || []).map((i) => i.value);
      return {
        turnCount: turns.length,
        hostCount: hostNames.length,
        allHostsPresent: hostNames.every((n) => speakers.has(n))
      };
    });
    assert.equal(simPodcastInfo.hostCount, 4, 'Simulator configures 4 podcast hosts');
    assert.ok(simPodcastInfo.turnCount >= 5, 'Simulator generates multi-turn podcast script');
    assert.ok(simPodcastInfo.allHostsPresent, 'Simulator includes all 4 hosts in podcast dialogue');

    // Typed question & Voice interruption
    await winLong.locator('.yt-podcast-qa-input').fill('How do ReadIndex leases avoid disk fsync latency?');
    await winLong.locator('.yt-podcast-ask-btn').click();
    await winLong.locator('.yt-podcast-turn-user').waitFor({ state: 'visible' });
    await winLong.locator('.yt-podcast-turn-reply').first().waitFor({ state: 'visible' });

    await page.evaluate(() => {
      window.__yt_mock_voice_text = 'Why do split votes resolve faster with randomized timeouts?';
    });
    await winLong.locator('.yt-podcast-mic-btn').click();
    await page.waitForFunction(
      () =>
        document.querySelectorAll('.yt-window-box[data-video-id="D_long_lecture"] .yt-podcast-turn-user')
          .length >= 2
    );

    // Verify 375px mobile fit on active Podcast tab
    await page.setViewportSize({ width: 375, height: 812 });
    await page.waitForTimeout(140);
    const simMobilePod = await page.evaluate(() => {
      const box = document.querySelector('.yt-window-box[data-video-id="D_long_lecture"]');
      const studio = box?.querySelector('.yt-podcast-studio');
      delete window.__yt_mock_voice_text;
      return {
        docOverflow: document.documentElement.scrollWidth > window.innerWidth,
        studioOverflow: Boolean(studio && studio.scrollWidth > studio.clientWidth + 2)
      };
    });
    assert.equal(simMobilePod.docOverflow, false, 'Simulator Podcast tab has zero page overflow at 375px');
    assert.equal(simMobilePod.studioOverflow, false, 'Simulator Podcast studio fits cleanly inside compact 375px window');
    assert.equal(pageErrors.length, 0, `Zero runtime page errors after Podcast tests (${pageErrors.join('; ')})`);
    passed += 7;

    // 8. Material You UI Theme Toggle (System / Light / Dark), reload persistence, & OS tracking
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.waitForTimeout(100);
    const themeToggle = page.locator('[data-testid="app-theme-toggle"]');
    await themeToggle.waitFor({ state: 'visible' });

    // Switch to Light mode
    await themeToggle.locator('button[data-app-theme-option="light"]').click();
    await page.waitForFunction(() => !document.documentElement.classList.contains('dark') && getComputedStyle(document.body).backgroundColor === 'rgb(249, 249, 255)');
    const lightState = await page.evaluate(() => ({
      hasDarkClass: document.documentElement.classList.contains('dark'),
      colorScheme: getComputedStyle(document.documentElement).colorScheme,
      bodyBg: getComputedStyle(document.body).backgroundColor,
      stored: localStorage.getItem('yt_app_theme_mode'),
      pressed: document.querySelector('[data-app-theme-option="light"]')?.getAttribute('aria-pressed'),
      overflow: document.documentElement.scrollWidth > window.innerWidth
    }));
    assert.equal(lightState.hasDarkClass, false, 'Light mode removes .dark class from html root');
    assert.equal(lightState.colorScheme, 'light', 'Light mode sets colorScheme to light');
    assert.equal(lightState.stored, 'light', 'Light mode persists in localStorage');
    assert.equal(lightState.pressed, 'true', 'Light toggle button exposes aria-pressed="true"');
    assert.equal(lightState.overflow, false, 'Desktop 1440px Light mode has zero overflow');

    // Switch to Dark mode
    await themeToggle.locator('button[data-app-theme-option="dark"]').click();
    await page.waitForFunction(() => document.documentElement.classList.contains('dark') && getComputedStyle(document.body).backgroundColor === 'rgb(17, 19, 24)');
    const darkState = await page.evaluate(() => ({
      hasDarkClass: document.documentElement.classList.contains('dark'),
      colorScheme: getComputedStyle(document.documentElement).colorScheme,
      bodyBg: getComputedStyle(document.body).backgroundColor,
      stored: localStorage.getItem('yt_app_theme_mode'),
      pressed: document.querySelector('[data-app-theme-option="dark"]')?.getAttribute('aria-pressed')
    }));
    assert.equal(darkState.hasDarkClass, true, 'Dark mode adds .dark class to html root');
    assert.equal(darkState.colorScheme, 'dark', 'Dark mode sets colorScheme to dark');
    assert.notEqual(darkState.bodyBg, lightState.bodyBg, 'Dark mode changes Material You surface background color');
    assert.equal(darkState.stored, 'dark', 'Dark mode persists in localStorage');
    assert.equal(darkState.pressed, 'true', 'Dark toggle button exposes aria-pressed="true"');

    // Reload persistence check for Light mode
    await themeToggle.locator('button[data-app-theme-option="light"]').click();
    await page.reload({ waitUntil: 'networkidle' });
    const afterReloadLight = await page.evaluate(() => ({
      hasDarkClass: document.documentElement.classList.contains('dark'),
      stored: localStorage.getItem('yt_app_theme_mode'),
      pressed: document.querySelector('[data-app-theme-option="light"]')?.getAttribute('aria-pressed')
    }));
    assert.equal(afterReloadLight.hasDarkClass, false, 'Light mode survives page reload via anti-FOUC + React init');
    assert.equal(afterReloadLight.stored, 'light', 'localStorage preserves light mode after reload');
    assert.equal(afterReloadLight.pressed, 'true', 'Light toggle stays pressed after reload');

    // System mode follows prefers-color-scheme media query
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.locator('[data-testid="app-theme-toggle"] button[data-app-theme-option="system"]').click();
    await page.waitForFunction(() => document.documentElement.classList.contains('dark'));
    await page.emulateMedia({ colorScheme: 'light' });
    await page.waitForFunction(() => !document.documentElement.classList.contains('dark'));

    // Mobile 375px Light & Dark overflow check
    await page.setViewportSize({ width: 375, height: 812 });
    await page.waitForTimeout(120);
    const mobileLightOverflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
    assert.equal(mobileLightOverflow, false, 'Mobile 375px Light mode has zero horizontal overflow');
    assert.equal(pageErrors.length, 0, `Zero runtime page errors after Material You theme tests (${pageErrors.join('; ')})`);
    passed += 14;

    console.log(`✓ Suite 5 passed: ${passed} checks verified.`);
    return { passed, total: passed };
  } finally {
    if (browser) await browser.close();
    if (server) await server.close();
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runSimulatorUiTests()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
